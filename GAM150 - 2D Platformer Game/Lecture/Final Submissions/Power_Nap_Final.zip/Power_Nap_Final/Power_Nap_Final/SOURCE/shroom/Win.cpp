/**********************************************************************************
* \File name	 Win.cpp
* \Project name  Jump!Shroom!

* \Author(s)	 Wei Zhe, Goh       103 Lines x 93.25% Code Contribution
				 Yan Han, Dong		103 Lines x 6.75% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#include "shroom.h"

AEGfxVertexList		* playerMesh;
AEGfxTexture		* pTex;
AEGfxVertexList		* enemyMesh;

const float			WTimer = 5.0f;
float				wTIMER = 0.0f;

/******************************************************************************/
/*!
	"Load" function of this game state
*/
/******************************************************************************/
void Win_Load()
{
	AEGfxSetBackgroundColor(0.f, 0.f, 0.f);
	WinBG_Load();

	AEGfxMeshStart();
	AEGfxTriAdd(
		-95.5f, -95.5f, 0xFFFFFFFF, 0.0f, 0.5f,
		95.5f, -95.5f, 0xFFFFFFFF, 0.2f, 0.5f,
		-95.5f, 95.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		95.5f, -95.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		95.5f, 95.5f, 0xFFFFFFFF, 0.20f, 0.0f,
		-95.5f, 95.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	playerMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(playerMesh, "fail to create Hero object!!");
	pTex = AEGfxTextureLoad("assert\\art\\Shroom.png");
	AE_ASSERT_MESG(pTex, "fail to create Hero texture!!");

	AEGfxMeshStart();
	AEGfxTriAdd(
		-95.5f, -95.5f, 0xFFFFFFFF, 0.0f, 0.5f,
		95.5f, -95.5f, 0xFFFFFFFF, 0.2f, 0.5f,
		-95.5f, 95.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		95.5f, -95.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		95.5f, 95.5f, 0xFFFFFFFF, 0.20f, 0.0f,
		-95.5f, 95.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	enemyMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(enemyMesh, "fail to create instruction object!!");
}

/******************************************************************************/
/*!
	"Initialize" function of this game state
*/
/******************************************************************************/
void Win_Init()
{
	AEGfxSetCamPosition(0, 0);
}

/******************************************************************************/
/*!
	"Update" function of this game state
*/
/******************************************************************************/
void Win_Update()
{
	if (AEInputCheckTriggered(AEVK_ESCAPE))				//Press ESCAPE to return back to main menu
	{
		next = GS_MainMenu;
	}

	if (wTIMER >= 0.0f)
	{
		wTIMER -= g_dt;
	}
	else
	{
		next = GS_CUTSCENE;
		level = 4;
	}

	if (AEInputCheckTriggered(AEVK_F))					//Press F key to full screen
	{
		if (fullscreen)
			fullscreen = false;
		else
			fullscreen = true;
		AEToogleFullScreen(fullscreen);
	}
}

/******************************************************************************/
/*!
	"Draw" function of this game state
*/
/******************************************************************************/
void Win_Draw()
{
	AEGfxSetBlendMode(AE_GFX_BM_BLEND);
	AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);

	AEGfxSetPosition(-250.f, -20.f);
	AEGfxTextureSet(pTex, 0.f, 0.f);
	AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
	AEGfxSetTransparency(1.0f);
	AEGfxMeshDraw(playerMesh, AE_GFX_MDM_TRIANGLES);

	// dave
	AEGfxSetBlendMode(AE_GFX_BM_BLEND);
	AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
	AEGfxSetPosition(250.f, -20.f);
	AEGfxTextureSet(pTex, 0.f, 0.5f);
	AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
	AEGfxSetTransparency(1.0f);
	AEGfxMeshDraw(enemyMesh, AE_GFX_MDM_TRIANGLES);

	AEGfxSetBlendMode(AE_GFX_BM_BLEND);
	AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);

	AEMtx33 transBG, scaleBG, transformBG;

	char strBuffer[100], strBuffer2[100];

	memset(strBuffer, 0, 100 * sizeof(char));
	memset(strBuffer2, 0, 100 * sizeof(char));

	sprintf_s(strBuffer, "You Won!");
	sprintf_s(strBuffer2, "Press ESC back to Main Menu");

	AEGfxSetBlendMode(AE_GFX_BM_BLEND);
	AEGfxPrint(Font, strBuffer, -0.25f, 0.0f, 1.f, 1.f, 1.f, 1.f);
	AEGfxPrint(Font, strBuffer2, -0.40f, -0.5f, 0.5f, 1.f, 1.f, 1.f);

	AEMtx33Trans(&transBG, 0, 0);
	AEMtx33Scale(&scaleBG, (f32)AEGetWindowWidth(), (f32)AEGetWindowHeight());
	AEMtx33Concat(&transformBG, &transBG, &scaleBG);
	AEGfxSetTransform(transformBG.m);
}

/******************************************************************************/
/*!
	"Free" function of this game state
*/
/******************************************************************************/
void Win_Free(){}

/******************************************************************************/
/*!
	"Unload" function of this game state
*/
/******************************************************************************/
void Win_Unload()
{
	WinBG_Unload();

	AEGfxMeshFree(playerMesh);
	AEGfxMeshFree(enemyMesh);

	AEGfxTextureUnload(pTex);
}