/**********************************************************************************
* \File name	 GameStateManager.h
* \Project name  Jump!Shroom!

* \Author(s)	 Yan Han, Dong	6 lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#pragma once

typedef void(*FP)(void);

extern int current, previous, next;										 // game state

extern FP fpLoad, fpInitialize, fpUpdate, fpDraw, fpFree, fpUnload;		// function pointer 

void GSM_Initialize(int startingState);									//init game state manager 
void GSM_Update();														// update game state manager 
