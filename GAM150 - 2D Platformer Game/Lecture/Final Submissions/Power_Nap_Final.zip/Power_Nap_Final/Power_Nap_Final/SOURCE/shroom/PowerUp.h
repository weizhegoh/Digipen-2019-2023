/**********************************************************************************
* \File name		PowerUp.h
* \Project name		Jump!Shroom!

* \Author(s)		Benjamin Liew       22 lines x 100% Code Contribution

* \Copyright information
	All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#pragma once
#include "shroom.h"

extern "C" class PowerUp
{
	float duration = 10.0f;
public:
	bool  activation = false;
	bool  invincibility = false;
	bool  freeze = false;
	float durationCounter = 0;
	u32   powerupCounter = 0;
	u32	  levelProgress = 0;

	float getPowerUpDuration()
	{
		return this->duration;
	}
};

void BluePowerUpActivation();
void BluePowerUpDeactivation();
void BluePowerUpCountDown(float& durationCounter);
void BluePowerUpCounter();

void levelProgressReset();