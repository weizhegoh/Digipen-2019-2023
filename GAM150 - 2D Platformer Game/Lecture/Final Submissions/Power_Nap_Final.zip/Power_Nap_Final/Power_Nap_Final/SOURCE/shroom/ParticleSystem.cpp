/**********************************************************************************
* \File name	 ParticleSystem.cpp
* \Project name  Jump!Shroom!

* \Author(s)	 Hong Fu, Wong       85 lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#include "shroom.h"

AEGfxTexture		*particleTex  = nullptr;
AEGfxVertexList		*pMesh = nullptr;

Particle			myParticle1[MAX_PARTICLES_NUM];
Particle			myParticle1Jump[MAX_PARTICLES_NUM];

/******************************************************************************/
/*!
	Load function for particle system
*/
/******************************************************************************/
void ParticleSystemLoad()
{
	// Drawing Mesh for Particle
	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.3f, -0.3f, 0xFFFFFFF, 0.0f, 1.0f,
		0.3f, -0.3f, 0xFFFFFFFF, 1.0f, 1.0f,
		-0.3f, 0.3f, 0xFFFFFFFF, 0.0f, 0.0f);
	AEGfxTriAdd(
		0.3f, -0.3f, 0xFFFFFFFF, 1.0f, 1.0f,
		0.3f, 0.3f, 0xFFFFFFFF, 1.0f, 0.0f,
		-0.3f, 0.3f, 0xFFFFFFFF, 0.0f, 0.0f);

	pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pMesh, "Failed to create particle mesh");
	particleTex = AEGfxTextureLoad("assert\\art\\Clouds.png");
	AE_ASSERT_MESG(particleTex, "Failed to create particle texture");
}

/******************************************************************************/
/*!
	Function to create a new particle
*/
/******************************************************************************/
void ParticleSpawn(Particle* myParticle, float posX, float posY)
{
	// If a max particle cap is not reached, and particlespawn is called, create
	// a new particle
	for (int i = 0; i < MAX_PARTICLES_NUM; ++i)
	{
		if (myParticle[i].flag == 1)
			continue;

		myParticle[i].position.x = posX;
		myParticle[i].position.y = posY;
		myParticle[i].flag = 1;
		myParticle[i].dirCurr = static_cast<float>(rand());
		break;
	}
}

/******************************************************************************/
/*!
	Updates position for particles
*/
/******************************************************************************/
void ParticleUpdate(Particle* myParticle)
{
	// Updating of Particles
	for (int i = 0; i < MAX_PARTICLES_NUM; ++i)
	{
		if (myParticle[i].flag == 0)
			continue;

		AEMtx33 scale;
		AEMtx33 rot;
		AEMtx33 trans;

		// Initialize the values
		myParticle[i].size = myParticle[i].lifeTime;
		AEMtx33Scale(&scale, myParticle[i].scale, myParticle[i].scale);
		AEMtx33Rot(&rot, myParticle[i].dirCurr);
		AEMtx33Trans(&trans, myParticle[i].position.x, myParticle[i].position.y);
		AEMtx33Concat(&myParticle[i].transform, &scale, &rot);
		AEMtx33Concat(&myParticle[i].transform, &trans, &myParticle[i].transform);

		// Update particle position
		myParticle[i].velocity.x = AERandFloat() * 0.01f;
		myParticle[i].velocity.y = AERandFloat() * 0.01f;
		myParticle[i].position.x += myParticle[i].velocity.x;
		myParticle[i].position.y -= myParticle[i].velocity.y;

		// Calculate particle's lifetime
		myParticle[i].lifeTime -= g_dt;

		// Destroy when run out of lifetime
		if (myParticle[i].lifeTime <= 0.0f)
		{
			myParticle[i].flag = 0;
			myParticle[i].lifeTime = 1.0f;
		}
	}
}

/******************************************************************************/
/*!
	Draws the particles
*/
/******************************************************************************/
void ParticleDraw(Particle* myParticle)
{
	// Render Particles on Screen.
	for (int i = 0; i < MAX_PARTICLES_NUM; ++i)
	{

		if (myParticle[i].flag == 0)
			continue;

		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxTextureSet(particleTex, 0.f, 0.f);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f,myParticle[i].lifeTime);
		AEGfxSetTransparency(1.0f);

		AEMtx33Concat(&myParticle[i].transform, &MapTransform, &myParticle[i].transform);
		AEGfxSetTransform(myParticle[i].transform.m);
		AEGfxMeshDraw(pMesh, AE_GFX_MDM_TRIANGLES);
	}

}

/******************************************************************************/
/*!
	Free the particles
*/
/******************************************************************************/
void ParticleFree()
{
	//AEGfxMeshFree(pMesh);
}

/******************************************************************************/
/*!
	Unload the particles
*/
/******************************************************************************/
void ParticleUnload()
{
	AEGfxMeshFree(pMesh);
 	AEGfxTextureUnload(particleTex);
}