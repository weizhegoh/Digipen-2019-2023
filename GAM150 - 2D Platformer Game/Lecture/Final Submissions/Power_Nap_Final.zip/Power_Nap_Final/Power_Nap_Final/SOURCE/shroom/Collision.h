/**********************************************************************************
* \File name	 Collision.h
* \Project name  Jump!Shroom!

* \Author(s)	 Yan Han, Dong       8 lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#pragma once

struct AABB
{
	AEVec2 min;
	AEVec2 max;
};

/****************************************************************************/
/*!
\fn CollisionIntersection_RectRect(const AABB& aabb1, const AEVec2& Vecl1,
									const AABB& aabb2, const AEVec2& vel2)

\brief AABB collision check

\param const AABB& aabb1

\param const AEVec2& Vecl1

\param const AABB& aabb2

\param const AEVec2& vel2

\returns boolen 
*/
/****************************************************************************/

bool CollisionIntersection_RectRect(const AABB& aabb1, const AEVec2& Vecl1,
									const AABB& aabb2, const AEVec2& vel2);