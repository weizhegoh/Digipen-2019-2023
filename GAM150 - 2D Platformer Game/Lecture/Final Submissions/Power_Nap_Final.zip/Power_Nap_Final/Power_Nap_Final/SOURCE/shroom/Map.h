/**********************************************************************************
* \File name		Map.h
* \Project name		Jump!Shroom!

* \Author(s)		Benjamin Liew       64 lines x 100% Code Contribution

* \Copyright information
	All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#ifndef BINARY_MAP_H_
#define BINARY_MAP_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern "C" class Map
{
public:
	u32 randomisedMapSelect()
	{
		int num = rand() % 2;
		if (num > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
};

extern "C" class UI
{
	float UIFlashTimer = 2.0f;
public:
	bool  UIFlash = 0;
	float greenColor = 0.0f;
	float blueColor = 0.0f;
	float redColor = 0.0f;
	f32   UIFlashTimerGreen = UIFlashTimer;
	f32   UIFlashTimerBlue = UIFlashTimer;
	f32   UIFlashTimerRed = UIFlashTimer;

	float getUIFlashTimer()
	{
		return this->UIFlashTimer;
	}
};

const int	   COLLISION_LEFT = 0x00000001;	    //0001
const int	   COLLISION_RIGHT = 0x00000002;	//0010
const int	   COLLISION_TOP = 0x00000004;		//0100
const int	   COLLISION_BOTTOM = 0x00000008;	//1000

extern int     BINARY_MAP_WIDTH;
extern int     BINARY_MAP_HEIGHT;
extern int     ** MapData;
extern int     ** BinaryCollisionArray;
extern AEMtx33 MapTransform;
extern int     TotalCoins; 

int		GetCellValue(int X, int Y);
int		CheckInstanceBinaryMapCollision(float PosX, float PosY,
										float scaleX, float scaleY);
void	SnapToCell(float* Coordinate);
int		ImportMapDataFromFile(const char* FileName);
void	PrintRetrievedInformation(void);

void	UIFlashGreen();							//Function to flash Green on Lives UI when picking up Green Powerup
void	UIFlashBlue();							//Function to flash Blue on Blue powerup UI when picking up Bue powerup
void	UIFlashRedDecreaseLife();				//Function to flash Red on Lives/ Blue powerup UI when they are used
void	UIFlashRedDecreaseBluepowerup();		//Function to flash Red on Lives/ Blue powerup UI when they are used

void	Map_Load();
void	Map_Init();
void	Map_Update();
void	Map_Draw();
void	Map_Free();
void	Map_Unload();

#endif // BINARY_MAP_H_