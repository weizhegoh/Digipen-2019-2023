/**********************************************************************************
* \File name     ParticleSystem.h
* \Project name  Jump!Shroom!

* \Author(s)     Hong Fu, Wong       21 lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#pragma once
#define MAX_PARTICLES_NUM 20

/******************************************************************************/
/*!
	Struct used in particle systems
*/
/******************************************************************************/
struct Particle
{
	int flag = 0;

	AEVec2 position = { 0.0f, 0.0f };		// Particle Position
	AEVec2 velocity = { 0.0f, 0.0f };		// Particle Velocity


	float lifeTime = 1.0f;					// Particle LifeTime
	float size = 0.0f;						// Particle Size
	float dirCurr = 0.0f;					// Particle Direction
	float scale = 1.0f;						// Particle Scale

	AEMtx33 transform = { 0.0f, 0.0f };		// Particle Transform
};

extern Particle	myParticle1[MAX_PARTICLES_NUM];
extern Particle	myParticle1Jump[MAX_PARTICLES_NUM];

void ParticleSystemLoad();
void ParticleSpawn(Particle* myParticle, float posX, float posY);
void ParticleUpdate(Particle* myParticle);
void ParticleDraw(Particle* myParticle);
void ParticleFree();
void ParticleUnload();
