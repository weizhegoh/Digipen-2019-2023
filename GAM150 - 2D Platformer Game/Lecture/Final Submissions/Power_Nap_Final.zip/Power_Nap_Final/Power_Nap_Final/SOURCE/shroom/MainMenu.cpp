/**********************************************************************************
* \File name	 MainMenu.cpp
* \Project name  Jump!Shroom!

* \Author(s)	Hong Fu, Wong       497 lines x 98.75% Code Contribution
				Wei Zhe, Goh		497 lines x 1.25% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#include "shroom.h"
#include <iostream>

// Main / choosing options
unsigned int			chooseQuit;
unsigned int			chooseLevel;
unsigned int			chooseOptions;

// Credits & instructions
bool					instBool = false;
bool					creditsBool = false;

// Quit confirmation
bool					quitBool = false;

// Options
bool					setMute = false;
bool					setUnmute = false;
bool					optionsBool = false;
bool					decreaseVolume = false;
bool					increaseVolume = false;	

extern bool				fullscreen;

float					vTIME = 0.f;
float					vTIMER = 0.f;

static AEMtx33			mmTransform;

static AEGfxTexture		*mmTex;
static AEGfxVertexList	*mmMesh, *mmMesh2;


/******************************************************************************/
/*!
	Load function for main menu
*/
/******************************************************************************/
void MainMenu_Load()
{
	AEGfxSetBackgroundColor(0.f, 0.f, 0.f);

	// Shroom
	AEGfxMeshStart();
	AEGfxTriAdd(
		-95.5f, -95.5f, 0xFFFFFFFF, 0.0f, 0.5f,
		95.5f, -95.5f, 0xFFFFFFFF, 0.2f, 0.5f,
		-95.5f, 95.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		95.5f, -95.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		95.5f, 95.5f, 0xFFFFFFFF, 0.20f, 0.0f,
		-95.5f, 95.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	mmMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(mmMesh, "fail to create Hero object!!");
	mmTex = AEGfxTextureLoad("assert\\art\\Shroom.png");
	AE_ASSERT_MESG(mmTex, "fail to create Hero texture!!");

	// Dave
	AEGfxMeshStart();
	AEGfxTriAdd(
		-45.5f, -45.5f, 0xFFFFFFFF, 0.0f, 0.5f,
		45.5f, -45.5f, 0xFFFFFFFF, 0.2f, 0.5f,
		-45.5f, 45.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		45.5f, -45.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		45.5f, 45.5f, 0xFFFFFFFF, 0.20f, 0.0f,
		-45.5f, 45.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	mmMesh2 = AEGfxMeshEnd();
	AE_ASSERT_MESG(mmMesh, "fail to create instruction object!!");

	mainMenuBG_Load();
}

/******************************************************************************/
/*!
	Initialize function for main menu
*/
/******************************************************************************/
void MainMenu_Init()
{
	chooseLevel = 0;
	pauseMenu_Init();
	AEGfxSetCamPosition(0, 0);
	AudioEngine_Initialize();
	SetWindowPos(AESysGetWindowHandle(), HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_DRAWFRAME | SWP_NOSIZE);
}

/******************************************************************************/
/*!
	Update function for main menu
*/
/******************************************************************************/
void MainMenu_Update()
{
	// Choosing buttons
	if (AEInputCheckTriggered(AEVK_UP))
	{
		if (!instBool && !creditsBool && !optionsBool && !quitBool)
		{
			if (chooseLevel != 0)
			{
				chooseLevel -= 1;
			}
			else
			{
				chooseLevel = 0;
			}
		}
		if (optionsBool)
		{
			if (chooseOptions != 0)
			{
				chooseOptions -= 1;
			}
			else
			{
				chooseOptions = 0;
			}
		}
		if (quitBool)
		{
			if (chooseQuit != 0)
			{
				chooseQuit -= 1;
			}
			else
			{
				chooseQuit = 0;
			}
		}
	}
	else if (AEInputCheckTriggered(AEVK_DOWN))
	{
		if (!instBool && !creditsBool && ! optionsBool && !quitBool)
		{
			if (chooseLevel != 4)
			{
				chooseLevel += 1;
			}
			else
				chooseLevel = 4;
		}
		if (optionsBool)
		{
			if (chooseOptions != 3)
			{
				chooseOptions += 1;
			}
			else
			{
				chooseOptions = 3;
			}
		}
		if (quitBool)
		{
			if (chooseQuit != 1)
			{
				chooseQuit += 1;
			}
			else
			{
				chooseQuit = 1;
			}
		}
	}
	
	// Selecting button
	if (AEInputCheckTriggered(AEVK_RETURN)) 
	{
		if (!instBool && !creditsBool && !optionsBool && !quitBool) 
		{
			switch (chooseLevel)
			{
			case 0:
				next = GS_LevelSelect;
				break;
			case 1:
				instBool = true;
				break;
			case 2:
				optionsBool = true;
				chooseOptions = 0;
				break;
			case 3:
				creditsBool = true;
				break;
			case 4:
				quitBool = true;
				chooseQuit = 0;
				break;
			}
		}
		else if (optionsBool)
		{
			switch (chooseOptions)
			{
			case 0:
				fullscreen = !fullscreen;
				AEToogleFullScreen(fullscreen);
				break;
			case 1:
				decreaseVolume = true;
				break;
			case 2:
				increaseVolume = true;
				break;
			case 3:
				if (setMute)
				{
					setMute = false;
					setUnmute = true;

					mainMenuBG_Unload();
					mainMenuBG_Load();
				}
				else
				{
					setMute = true;
					setUnmute = false;
				}
				break;
			}
		}
		else if (quitBool)
		{
			switch (chooseQuit)
			{
			case 0:
				quitBool = false;
				break;
			case 1:
				next = GS_QUIT;
				break;
			}
		}
	}

	// Escape to Main Menu
	if (AEInputCheckCurr(AEVK_ESCAPE)) 
	{
		instBool = false;
		quitBool = false;
		creditsBool = false;
		optionsBool = false;
	}

	// Fullscreen
	if (AEInputCheckTriggered(AEVK_F))
	{
		if (fullscreen)
			fullscreen = false;
		else
			fullscreen = true;
		AEToogleFullScreen(fullscreen);
	}
}

/******************************************************************************/
/*!
	Draw function for main menu
*/
/******************************************************************************/
void MainMenu_Draw()
{
	if (instBool || creditsBool || optionsBool || quitBool)
	{
		// render functions below
	}
	else
	{
		// Shroom
		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(-250.f, -20.f);
		AEGfxTextureSet(mmTex, 0.f, 0.f);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
		AEGfxSetTransparency(1.0f);
		AEGfxMeshDraw(mmMesh, AE_GFX_MDM_TRIANGLES);

		// Dave
		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(250.f, -20.f);
		AEGfxTextureSet(mmTex, 0.f, 0.5f);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
		AEGfxSetTransparency(1.0f);
		AEGfxMeshDraw(mmMesh, AE_GFX_MDM_TRIANGLES);
	}
	char strBuffer[1024];

	// Render the Main Menu
	AEGfxSetRenderMode(AE_GFX_RM_COLOR);

	if (instBool)
	{
		// Instructions
		sprintf_s(strBuffer, "Instructions");
		AEGfxPrint(Font, strBuffer, -0.25f, 0.7f, 0.8f, 1.f, 1.f, 1.f);
		// Underline
		sprintf_s(strBuffer, "________");
		AEGfxPrint(Font, strBuffer, -0.25f, 0.65f, 0.8f, 1.f, 1.f, 1.f);
		// ESC
		sprintf_s(strBuffer, "ESC : Return to menu");
		AEGfxPrint(Font, strBuffer, -0.6f, 0.35f, 0.5f, 0.8f, 0.8f, 0.8f);
		// S to freeze
		sprintf_s(strBuffer, "S: Freeze powerup");
		AEGfxPrint(Font, strBuffer, 0.1f, 0.35f, 0.5f, 0.8f, 0.8f, 0.8f);
		// D to mushroom
		sprintf_s(strBuffer, "D: Spawn mushroom");
		AEGfxPrint(Font, strBuffer, 0.1f, 0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
		// Arrow keys to move
		sprintf_s(strBuffer, "< and > to move");
		AEGfxPrint(Font, strBuffer, -0.6f, -0.15f, 0.5f, 0.8f, 0.8f, 0.8f);
		// Space to Jump
		sprintf_s(strBuffer, "Space to jump");
		AEGfxPrint(Font, strBuffer, 0.1f, -0.15f, 0.5f, 0.8f, 0.8f, 0.8f);
		// F to fullscreen
		sprintf_s(strBuffer, "F: Fullscreen");
		AEGfxPrint(Font, strBuffer, -0.6f, 0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
	}
	else if (creditsBool)
	{
		// Credits
		sprintf_s(strBuffer, "Credits");
		AEGfxPrint(Font, strBuffer, -0.15f, 0.7f, 0.8f, 1.f, 1.f, 1.f);
		// Underline
		sprintf_s(strBuffer, "_____");
		AEGfxPrint(Font, strBuffer, -0.15f, 0.65f, 0.8f, 1.f, 1.f, 1.f);
		// Digipen Institute of Technology
		sprintf_s(strBuffer, "Digipen Institute of Technology");
		AEGfxPrint(Font, strBuffer, -0.3f, 0.55f, 0.4f, 1.f, 1.f, 1.f);
		// Copyright
		sprintf_s(strBuffer, "WWW.DIGIPEN.EDU COPYRIGHT. 2020 BY DIGIPEN CORP, SINGAPORE. ALL RIGHTS RESERVED.");
		AEGfxPrint(Font, strBuffer, -0.55f, 0.48f, 0.2f, 0.8f, 0.8f, 0.8f);
		// Team name
		sprintf_s(strBuffer, "Developed by team Power_Nap");
		AEGfxPrint(Font, strBuffer, -0.3f, 0.35f, 0.4f, 1.f, 1.f, 1.f);
		// Team members, alphabatical order
		sprintf_s(strBuffer, "Benjamin Liew, Dong Yan Han, Goh Wei Zhe, Wong Hong Fu");
		AEGfxPrint(Font, strBuffer, -0.65f, 0.25f, 0.4f, 0.8f, 0.8f, 0.8f);
		// Instructors
		sprintf_s(strBuffer, "Instructors");
		AEGfxPrint(Font, strBuffer, -0.1f, 0.1f, 0.4f, 1.f, 1.f, 1.f);
		// Name of instructors
		sprintf_s(strBuffer, "Elie Hosry, Yannick Gerber");
		AEGfxPrint(Font, strBuffer, -0.3f, 0.0f, 0.4f, 0.8f, 0.8f, 0.8f);
		// President
		sprintf_s(strBuffer, "President");
		AEGfxPrint(Font, strBuffer, -0.09f, -0.15f, 0.4f, 1.f, 1.f, 1.f);
		// Name of president
		sprintf_s(strBuffer, "Claude Comair");
		AEGfxPrint(Font, strBuffer, -0.14f, -0.25f, 0.4f, 0.8f, 0.8f, 0.8f);
		// Executives
		sprintf_s(strBuffer, "Executives");
		AEGfxPrint(Font, strBuffer, -0.1f, -0.4f, 0.4f, 1.f, 1.f, 1.f);
		// Name of executives
		sprintf_s(strBuffer, "Jason Chu, John Bauer, Samir Abou Samra, Raymond Yan, Prasanna Ghali");
		AEGfxPrint(Font, strBuffer, -0.85f, -0.5f, 0.4f, 0.8f, 0.8f, 0.8f);
		// Name of executives part 2
		sprintf_s(strBuffer, "Michele Comair, Xin Li, Angela Kugler, Melvin Gonsalvez, Meighan Mckelvey");
		AEGfxPrint(Font, strBuffer, -0.85f, -0.6f, 0.4f, 0.8f, 0.8f, 0.8f);
	}
	else if (optionsBool)
	{
		// Arrow
		switch (chooseOptions)
		{
		case 0:
			sprintf_s(strBuffer, ">>>>");
			AEGfxPrint(Font, strBuffer, -0.45f, 0.4f, 0.5f, 1.f, 1.f, 1.f);
			break;
		case 1:
			sprintf_s(strBuffer, ">>>>");
			AEGfxPrint(Font, strBuffer, -0.45f, 0.2f, 0.5f, 1.f, 1.f, 1.f);
			break;
		case 2:
			sprintf_s(strBuffer, ">>>>");
			AEGfxPrint(Font, strBuffer, -0.45f, 0.f, 0.5f, 1.f, 1.f, 1.f);
			break;
		case 3:
			sprintf_s(strBuffer, ">>>>");
			AEGfxPrint(Font, strBuffer, -0.45f, -0.2f, 0.5f, 1.f, 1.f, 1.f);
			break;
		}

		// Options
		sprintf_s(strBuffer, "Options");
		AEGfxPrint(Font, strBuffer, -0.15f, 0.7f, 0.8f, 1.f, 1.f, 1.f);
		// Underline
		sprintf_s(strBuffer, "_____");
		AEGfxPrint(Font, strBuffer, -0.15f, 0.65f, 0.85f, 1.f, 1.f, 1.f);

		// F to fullscreen
		if (fullscreen)
		{
			sprintf_s(strBuffer, "Fullscreen");
			AEGfxPrint(Font, strBuffer, -0.2f, 0.4f, 0.5f, 0.f, 1.f, 0.f);
		}
		else
		{
			sprintf_s(strBuffer, "Fullscreen");
			AEGfxPrint(Font, strBuffer, -0.2f, 0.4f, 0.5f, 0.8f, 0.8f, 0.8f);
		}

		// Decrease volume
		if (decreaseVolume)
		{
			sprintf_s(strBuffer, "Decrease Volume");
			AEGfxPrint(Font, strBuffer, -0.2f, 0.2f, 0.5f, 0.f, 1.f, 0.f);

			if (vTIMER >= 0.10f)
			{
				decreaseVolume = false;
				vTIMER = vTIME;
			}
			else
				vTIMER += g_dt;
		}
		else
		{
			sprintf_s(strBuffer, "Decrease Volume");
			AEGfxPrint(Font, strBuffer, -0.2f, 0.2f, 0.5f, 0.8f, 0.8f, 0.8f);
		}

		// Increase volume
		if (increaseVolume)
		{
			sprintf_s(strBuffer, "Increase Volume");
			AEGfxPrint(Font, strBuffer, -0.2f, 0.f, 0.5f, 0.f, 1.f, 0.f);

			if (vTIMER >= 0.10f)
			{
				increaseVolume = false;
				vTIMER = vTIME;
			}
			else
				vTIMER += g_dt;
		}
		else
		{
			sprintf_s(strBuffer, "Increase Volume");
			AEGfxPrint(Font, strBuffer, -0.2f, 0.f, 0.5f, 0.8f, 0.8f, 0.8f);
		}

		// Muting the game
		if (setMute)
		{
			sprintf_s(strBuffer, "Mute");
			AEGfxPrint(Font, strBuffer, -0.2f, -0.2f, 0.5f, 0.f, 1.f, 0.f);
		}
		else 
		{
			sprintf_s(strBuffer, "Mute");
			AEGfxPrint(Font, strBuffer, -0.2f, -0.2f, 0.5f, 0.8f, 0.8f, 0.8f);
		}
	}

	// Quit page
	else if (quitBool)
	{
		// Quit?
		sprintf_s(strBuffer, "Quit?");
		AEGfxPrint(Font, strBuffer, -0.10f, 0.7f, 0.8f, 1.f, 1.f, 1.f);
		// Underline
		sprintf_s(strBuffer, "___");
		AEGfxPrint(Font, strBuffer, -0.10f, 0.65f, 0.85f, 1.f, 1.f, 1.f);

		switch (chooseQuit)
		{
		case 0:
			sprintf_s(strBuffer, ">>>>");
			AEGfxPrint(Font, strBuffer, -0.25f, 0.4f, 0.5f, 1.f, 1.f, 1.f);
			sprintf_s(strBuffer, "No");
			AEGfxPrint(Font, strBuffer, -0.05f, 0.4f, 0.5f, 1.f, 1.f, 1.f);
			sprintf_s(strBuffer, "Yes");
			AEGfxPrint(Font, strBuffer, -0.05f, 0.2f, 0.5f, 0.8f, 0.8f, 0.8f);
			break;
		case 1:
			sprintf_s(strBuffer, ">>>>");
			AEGfxPrint(Font, strBuffer, -0.25f, 0.2f, 0.5f, 1.f, 1.f, 1.f);
			sprintf_s(strBuffer, "No");
			AEGfxPrint(Font, strBuffer, -0.05f, 0.4f, 0.5f, 0.8f, 0.8f, 0.8f);
			sprintf_s(strBuffer, "Yes");
			AEGfxPrint(Font, strBuffer, -0.05f, 0.2f, 0.5f, 1.f, 1.f, 1.f);
			break;
		}
  }
	// Main menu
	else
	{
		switch (chooseLevel)
		{
		case 0:
			sprintf_s(strBuffer, "Jump! Shroom!");
			AEGfxPrint(Font, strBuffer, -0.40f, 0.5f, 1.f, 1.f, 1.f, 1.f);
			// Underline
			sprintf_s(strBuffer, "_____________");
			AEGfxPrint(Font, strBuffer, -0.40f, 0.45f, 0.8f, 1.f, 1.f, 1.f);
			// Arrow
			sprintf_s(strBuffer, ">>>>");
			AEGfxPrint(Font, strBuffer, -0.3f, 0.1f, 0.5f, 1.f, 1.f, 1.f);
			// Start Game
			sprintf_s(strBuffer, "Start Game");
			AEGfxPrint(Font, strBuffer, -0.1f, 0.1f, 0.8f, 1.f, 1.f, 1.f);
			// Controls
			sprintf_s(strBuffer, "Controls");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Options
			sprintf_s(strBuffer, "Options");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.3f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Credits
			sprintf_s(strBuffer, "Credits");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.5f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Quit
			sprintf_s(strBuffer, "Quit");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.7f, 0.5f, 0.8f, 0.8f, 0.8f);
			break;
		case 1:
			// Title
			sprintf_s(strBuffer, "Jump! Shroom!");
			AEGfxPrint(Font, strBuffer, -0.40f, 0.5f, 1.f, 1.f, 1.f, 1.f);
			// Underline
			sprintf_s(strBuffer, "_____________");
			AEGfxPrint(Font, strBuffer, -0.40f, 0.45f, 0.8f, 1.f, 1.f, 1.f);
			// Arrow
			sprintf_s(strBuffer, ">>>>");
			AEGfxPrint(Font, strBuffer, -0.3f, -0.1f, 0.5f, 1.f, 1.f, 1.f);
			// Start Game
			sprintf_s(strBuffer, "Start Game");
			AEGfxPrint(Font, strBuffer, -0.1f, 0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Controls
			sprintf_s(strBuffer, "Controls");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.1f, 0.8f, 1.f, 1.f, 1.f);
			// Options
			sprintf_s(strBuffer, "Options");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.3f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Credits
			sprintf_s(strBuffer, "Credits");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.5f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Quit
			sprintf_s(strBuffer, "Quit");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.7f, 0.5f, 0.8f, 0.8f, 0.8f);
			break;
		case 2:
			// Jump! Shroom!
			sprintf_s(strBuffer, "Jump! Shroom!");
			AEGfxPrint(Font, strBuffer, -0.40f, 0.5f, 1.f, 1.f, 1.f, 1.f);
			// Underline
			sprintf_s(strBuffer, "_____________");
			AEGfxPrint(Font, strBuffer, -0.40f, 0.45f, 0.8f, 1.f, 1.f, 1.f);
			// Arrow
			sprintf_s(strBuffer, ">>>>");
			AEGfxPrint(Font, strBuffer, -0.3f, -0.3f, 0.5f, 1.f, 1.f, 1.f);
			// Start Game
			sprintf_s(strBuffer, "Start Game");
			AEGfxPrint(Font, strBuffer, -0.1f, 0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Controls
			sprintf_s(strBuffer, "Controls");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Options
			sprintf_s(strBuffer, "Options");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.3f, 0.8f, 1.f, 1.f, 1.f);
			// Credits
			sprintf_s(strBuffer, "Credits");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.5f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Quit
			sprintf_s(strBuffer, "Quit");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.7f, 0.5f, 0.8f, 0.8f, 0.8f);
			break;
		case 3:
			// Jump Shroom!
			sprintf_s(strBuffer, "Jump! Shroom!");
			AEGfxPrint(Font, strBuffer, -0.40f, 0.5f, 1.f, 1.f, 1.f, 1.f);
			// Underline
			sprintf_s(strBuffer, "_____________");
			AEGfxPrint(Font, strBuffer, -0.40f, 0.45f, 0.8f, 1.f, 1.f, 1.f);
			// Arrow
			sprintf_s(strBuffer, ">>>>");
			AEGfxPrint(Font, strBuffer, -0.35f, -0.5f, 0.5f, 1.f, 1.f, 1.f);
			// Start game
			sprintf_s(strBuffer, "Start Game");
			AEGfxPrint(Font, strBuffer, -0.1f, 0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Controls
			sprintf_s(strBuffer, "Controls");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Options
			sprintf_s(strBuffer, "Options");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.3f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Credits
			sprintf_s(strBuffer, "Credits");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.5f, 0.8f, 1.f, 1.f, 1.f);
			// Quit
			sprintf_s(strBuffer, "Quit");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.7f, 0.5f, 0.8f, 0.8f, 0.8f);
			break;
		case 4:
			// Jump Shroom
			sprintf_s(strBuffer, "Jump! Shroom!");
			AEGfxPrint(Font, strBuffer, -0.40f, 0.5f, 1.f, 1.f, 1.f, 1.f);
			// Underline
			sprintf_s(strBuffer, "_____________");
			AEGfxPrint(Font, strBuffer, -0.40f, 0.45f, 0.8f, 1.f, 1.f, 1.f);
			// Arrows
			sprintf_s(strBuffer, ">>>>");
			AEGfxPrint(Font, strBuffer, -0.3f, -0.7f, 0.5f, 1.f, 1.f, 1.f);
			// Start Game
			sprintf_s(strBuffer, "Start Game");
			AEGfxPrint(Font, strBuffer, -0.1f, 0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Controls
			sprintf_s(strBuffer, "Controls");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Options
			sprintf_s(strBuffer, "Options");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.3f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Credits
			sprintf_s(strBuffer, "Credits");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.5f, 0.5f, 0.8f, 0.8f, 0.8f);
			// Quit
			sprintf_s(strBuffer, "Quit");
			AEGfxPrint(Font, strBuffer, -0.1f, -0.7f, 0.8f, 1.f, 1.f, 1.f);
			break;
		}
	}
}

/******************************************************************************/
/*!
	Free function for main menu
*/
/******************************************************************************/
void MainMenu_Free()
{
}

/******************************************************************************/
/*!
	Unload function for main menu
*/
/******************************************************************************/
void MainMenu_Unload()
{
	AEGfxMeshFree(mmMesh);
	AEGfxMeshFree(mmMesh2);
	AEGfxTextureUnload(mmTex);

	mainMenuBG_Unload();
}