/**********************************************************************************
* \File name	 Object.cpp
* \Project name  Jump!Shroom!

* \Author(s)	 Yan Han, Dong    43 lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#include "shroom.h"

/******************************************************************************/
/*!
	File globals
*/
/******************************************************************************/

GameObj* sGameObjList;
unsigned int sGameObjNum;

// list of object instances
GameObjInst* sGameObjInstList;

GameObjInst* pHero;
GameObj* pObj;

GameObjInst* pBlackInstance;
GameObjInst* pWhiteInstance;

/******************************************************************************/
/*!
	Create game object Instances
*/
/******************************************************************************/
GameObjInst* gameObjInstCreate(unsigned int type, float scale,
								AEVec2* pPos, AEVec2* pVel,
								float dir, enum STATE startState)
{
	AEVec2 zero;
	AEVec2Zero(&zero);

	AE_ASSERT_PARM(type < sGameObjNum);

	// loop through the object instance list to find a non-used object instance
	for (unsigned int i = 0; i < GAME_OBJ_INST_NUM_MAX; i++)
	{
		GameObjInst* pInst = sGameObjInstList + i;

		// check if current instance is not used
		if (pInst->flag == 0)
		{
			// it is not used => use it to create the new instance
			pInst->pObject = sGameObjList + type;
			pInst->flag = FLAG_ACTIVE | FLAG_VISIBLE;
			pInst->scale = scale;
			pInst->posCurr = pPos ? *pPos : zero;
			pInst->velCurr = pVel ? *pVel : zero;
			pInst->dirCurr = dir;
			pInst->pUserData = 0;
			pInst->gridCollisionFlag = 0;
			//pinst currentframe
			//timer
			//numofframe
			//numb states
			pInst->state = startState;
			pInst->innerState = INNER_STATE::INNER_STATE_ON_ENTER;
			//pInst->name = DEFAULT;
			pInst->counter = 0;
			pInst->directioncheck = 1;

			// return the newly created instance
			return pInst;
		}
	}

	return 0;
}

/******************************************************************************/
/*!
	Destory Game Object Instances
*/
/******************************************************************************/
void gameObjInstDestroy(GameObjInst* pInst)
{
	// if instance is destroyed before, just return
	if (pInst->flag == 0)
		return;

	// zero out the flag
	pInst->flag = 0;
}

