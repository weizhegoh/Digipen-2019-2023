/**********************************************************************************
* \File name		Enemy.h
* \Project name		Jump!Shroom!

* \Author(s)		Yan Han, Dong       5 lines x 80% Code Contribution
					Wei Zhe, Goh		5 lines x 20% Code Contribution

* \Copyright information
	All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#pragma once

extern float	   g_dt;
extern double	   g_appTime;
extern const float ENEMY_ROT_SPEED;	// enemy rotation speed (degree/second)

void EnemyStateMachine(GameObjInst* pInst);