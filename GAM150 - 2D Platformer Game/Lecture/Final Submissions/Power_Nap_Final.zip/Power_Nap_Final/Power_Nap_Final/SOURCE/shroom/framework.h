/**********************************************************************************
* \File name	 framework.h
* \Project name  Jump!Shroom!

* \Author(s)     Yan Han, Dong  2 lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#pragma once
#define WIN32_LEAN_AND_MEAN             // Exclude rarely-used stuff from Windows headers

