/**********************************************************************************
* \File name		pauseMenu.cpp
* \Project name		Jump!Shroom!

* \Author(s)		Wei Zhe, Goh	339 lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#include "shroom.h"

/******************************************************************************/
/*!
	File globals
*/
/******************************************************************************/

int menuState;
int option;
int quitGame;
int restartGame;

bool enterOptionMenuState;
bool enterQuitGameState;
bool enterRestartGameState;
bool pauseGame;

/******************************************************************************/
/*!
	"Load" pause menu function
*/
/******************************************************************************/

void pauseMenu_Load()
{
	AEGfxSetBackgroundColor(0.f, 0.f, 0.f);
}

/******************************************************************************/
/*!
	"Initialize" pause menu function
*/
/******************************************************************************/
void pauseMenu_Init()
{
	AEGfxSetCamPosition(0, 0);

	menuState = RESUME;
	restartGame = NO;
	quitGame = NO;
	option = FULLSCREEN;

	enterOptionMenuState = false;
	enterRestartGameState = false;
	enterQuitGameState = false;
	pauseGame = false;
}

/******************************************************************************/
/*!
	"Update" pause menu function
*/
/******************************************************************************/
void pauseMenu_Update()
{
	if (AEInputCheckTriggered(AEVK_F))										//Press F key to full screen
	{
		if (fullscreen)
			fullscreen = false;
		else
			fullscreen = true;
		AEToogleFullScreen(fullscreen);
	}

	if (!enterOptionMenuState)
	{
		if (enterQuitGameState)												//Enter quit game confirmation page
		{
			if (AEInputCheckTriggered(AEVK_UP))
			{
				quitGame = NO;
			}

			if (AEInputCheckTriggered(AEVK_DOWN))
			{
				quitGame = YES;
			}

			if (AEInputCheckReleased(AEVK_RETURN) && quitGame == NO)
			{
				enterQuitGameState = false;
			}

			if (AEInputCheckReleased(AEVK_RETURN) && quitGame == YES)
			{
				changeGameState = true;
				next = GS_MainMenu;
			}
		}
		else if (enterRestartGameState)										//Enter restart game confirmation page
		{
			if (AEInputCheckTriggered(AEVK_UP))
			{
				restartGame = NO;
			}

			if (AEInputCheckTriggered(AEVK_DOWN))
			{
				restartGame = YES;
			}

			if (AEInputCheckReleased(AEVK_RETURN) && restartGame == NO)
			{
				enterRestartGameState = false;
			}

			if (AEInputCheckReleased(AEVK_RETURN) && restartGame == YES)
			{
				pauseGame = false;
				next = GS_RESTART;
				enterRestartGameState = false;
			}
		}
		else
		{
			if (AEInputCheckTriggered(AEVK_UP) && !(menuState <= 0))
			{
				--menuState;
			}

			if (AEInputCheckTriggered(AEVK_DOWN) && menuState < 3)
			{
				++menuState;
			}

			if (AEInputCheckReleased(AEVK_RETURN))
			{
				if (menuState == RESUME)
				{
					pauseGame = false;
				}
				else if (menuState == RESTART)
				{
					enterRestartGameState = true;
				}
				else if (menuState == OPTION)
				{
					enterOptionMenuState = true;
				}
				else
				{
					enterQuitGameState = true;
				}
			}
		}
	}
	else
	{
		if (AEInputCheckTriggered(AEVK_ESCAPE))
		{
			enterOptionMenuState = false;
		}

		if (AEInputCheckTriggered(AEVK_DOWN) && option < 1)
		{
			++option;
		}

		if (AEInputCheckTriggered(AEVK_UP) && !(option <= 0))
		{
			--option;
		}

		if (AEInputCheckTriggered(AEVK_RETURN) && option == MUTE)
		{
			if (setMute)
			{
				setMute = false;
				setUnmute = true;

				if (current == GS_LevelSelect)
				{
					mainMenuBG_Unload();
					AudioEngine_Unload();
					AudioEngine_Load();
					mainMenuBG_Load();
					AudioEngine_Initialize();
				}
				
				if (current == GS_CUTSCENE)
				{
					cutSceneBG_Unload();
					AudioEngine_Unload();
					AudioEngine_Load();
					cutSceneBG_Load();
					AudioEngine_Initialize();
				}
				
				if(current == GS_LEVEL1)
				{
					level1BG_Unload();
					AudioEngine_Unload();
					AudioEngine_Load();
					level1BG_Load();
					AudioEngine_Initialize();
				}
				
				if (current == GS_LEVEL2)
				{
					level2BG_Unload();
					AudioEngine_Unload();
					AudioEngine_Load();
					level2BG_Load();
					AudioEngine_Initialize();
				}
				
				if (current == GS_LEVEL3)
				{
					level3BG_Unload();
					AudioEngine_Unload();
					AudioEngine_Load();
					level3BG_Load();
					AudioEngine_Initialize();
				}
			}
			else
			{
				setMute = true;
				setUnmute = false;
			}
		}

		if (AEInputCheckTriggered(AEVK_RETURN) && option == FULLSCREEN)			
		{
			if (fullscreen)
				fullscreen = false;
			else
				fullscreen = true;

			AEToogleFullScreen(fullscreen);
		}
	}
}

/******************************************************************************/
/*!
	"Draw" pause menu function
*/
/******************************************************************************/
void pauseMenu_Draw()
{
	AEGfxSetBlendMode(AE_GFX_BM_BLEND);
	AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);

	AEMtx33 transBG, scaleBG, transformBG;

	char strBuffer[100], strBuffer2[100], strBuffer3[100], strBuffer4[100], strBuffer5[100], strBuffer6[100], strBuffer7[100];

	memset(strBuffer, 0, 100 * sizeof(char));
	memset(strBuffer2, 0, 100 * sizeof(char));
	memset(strBuffer3, 0, 100 * sizeof(char));
	memset(strBuffer4, 0, 100 * sizeof(char));
	memset(strBuffer5, 0, 100 * sizeof(char));
	memset(strBuffer6, 0, 100 * sizeof(char));
	memset(strBuffer7, 0, 100 * sizeof(char));

	sprintf_s(strBuffer6, "Paused Menu");
	sprintf_s(strBuffer7,"_________");

	sprintf_s(strBuffer, "Resume Game");
	sprintf_s(strBuffer2, "Restart Game");
	sprintf_s(strBuffer3, "Option Menu");
	sprintf_s(strBuffer4, "Quit Game");
	sprintf_s(strBuffer5, ">>>>");

	switch (menuState)
	{
	case RESUME:
		AEGfxPrint(Font, strBuffer, -0.30f, 0.1f, 0.8f, 1.f, 1.f, 1.f);
		AEGfxPrint(Font, strBuffer2, -0.30f, -0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
		AEGfxPrint(Font, strBuffer3, -0.30f, -0.3f, 0.5f, 0.8f, 0.8f, 0.8f);
		AEGfxPrint(Font, strBuffer4, -0.30f, -0.5f, 0.5f, 0.8f, 0.8f, 0.8f);
		AEGfxPrint(Font, strBuffer5, -0.50f, 0.1f, 0.5f, 1.f, 1.f, 1.f);
		
		AEGfxPrint(Font, strBuffer6, -0.30f, 0.4f, 0.8f, 1.f, 1.f, 1.f);
		AEGfxPrint(Font, strBuffer7, -0.30f, 0.35f, 0.85f, 1.f, 1.f, 1.f);
		break;
	case RESTART:
		if (!enterRestartGameState)
		{
			AEGfxPrint(Font, strBuffer, -0.30f, 0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
			AEGfxPrint(Font, strBuffer2, -0.30f, -0.1f, 0.8f, 1.f, 1.f, 1.f);
			AEGfxPrint(Font, strBuffer3, -0.30f, -0.3f, 0.5f, 0.8f, 0.8f, 0.8f);
			AEGfxPrint(Font, strBuffer4, -0.30f, -0.5f, 0.5f, 0.8f, 0.8f, 0.8f);
			AEGfxPrint(Font, strBuffer5, -0.50f, -0.1f, 0.5f, 1.f, 1.f, 1.f);
			
			AEGfxPrint(Font, strBuffer6, -0.30f, 0.4f, 0.8f, 1.f, 1.f, 1.f);
			AEGfxPrint(Font, strBuffer7, -0.30f, 0.35f, 0.85f, 1.f, 1.f, 1.f);
			break;
		}
		else
		{
			sprintf_s(strBuffer, "Are you sure you want to restart the game?");
			sprintf_s(strBuffer2, "No");
			sprintf_s(strBuffer3, "Yes");
			sprintf_s(strBuffer4, ">>>>");

			AEGfxPrint(Font, strBuffer, -0.55f, 0.3f, 0.5f, 1.f, 1.f, 1.f);

			switch (restartGame)
			{
			case NO:
				AEGfxPrint(Font, strBuffer2, -0.10f, -0.1f, 0.8f, 1.f, 1.f, 1.f);
				AEGfxPrint(Font, strBuffer3, -0.10f, -0.3f, 0.5f, 0.8f, 0.8f, 0.8f);
				AEGfxPrint(Font, strBuffer4, -0.30f, -0.1f, 0.5f, 1.f, 1.f, 1.f);
				break;

			case YES:
				AEGfxPrint(Font, strBuffer2, -0.10f, -0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
				AEGfxPrint(Font, strBuffer3, -0.10f, -0.3f, 0.8f, 1.f, 1.f, 1.f);
				AEGfxPrint(Font, strBuffer4, -0.30f, -0.3f, 0.5f, 1.f, 1.f, 1.f);
				break;
			}
			break;
		}
	case OPTION:

		if (!enterOptionMenuState)
		{
			AEGfxPrint(Font, strBuffer, -0.30f, 0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
			AEGfxPrint(Font, strBuffer2, -0.30f, -0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
			AEGfxPrint(Font, strBuffer3, -0.30f, -0.3f, 0.8f, 1.f, 1.f, 1.f);
			AEGfxPrint(Font, strBuffer4, -0.30f, -0.5f, 0.5f, 0.8f, 0.8f, 0.8f);
			AEGfxPrint(Font, strBuffer5, -0.50f, -0.3f, 0.5f, 1.f, 1.f, 1.f);
			
			AEGfxPrint(Font, strBuffer6, -0.30f, 0.4f, 0.8f, 1.f, 1.f, 1.f);
			AEGfxPrint(Font, strBuffer7, -0.30f, 0.35f, 0.85f, 1.f, 1.f, 1.f);
			break;
		}
		else
		{
			sprintf_s(strBuffer2, "Options");
			sprintf_s(strBuffer3, "_____");

			sprintf_s(strBuffer, "F: Fullscreen");
			sprintf_s(strBuffer4, "Mute");
			sprintf_s(strBuffer5, ">>>>");

			AEGfxPrint(Font, strBuffer2, -0.15f, 0.2f, 0.8f, 1.f, 1.f, 1.f);
			AEGfxPrint(Font, strBuffer3, -0.15f, 0.15f, 0.85f, 1.f, 1.f, 1.f);

			AEGfxPrint(Font, strBuffer, -0.15f, -0.1f, 0.5f, 1.f, 1.f, 1.f);
			AEGfxPrint(Font, strBuffer4, -0.15f, -0.3f, 0.5f, 1.f, 1.f, 1.f);

			if (fullscreen)
			{
				AEGfxPrint(Font, strBuffer, -0.15f, -0.1f, 0.5f, 0.f, 1.f, 0.f);
			}

			if (setMute)
			{
				AEGfxPrint(Font, strBuffer4, -0.15f, -0.3f, 0.5f, 0.f, 1.f, 0.f);
			}
			else
			{
				AEGfxPrint(Font, strBuffer4, -0.15f, -0.3f, 0.5f, 1.f, 1.f, 1.f);
			}

			switch (option)
			{
			case FULLSCREEN:
				AEGfxPrint(Font, strBuffer5, -0.35f, -0.1f, 0.5f, 1.f, 1.f, 1.f);
				break;

			case MUTE:
				AEGfxPrint(Font, strBuffer5, -0.35f, -0.3f, 0.5f, 1.f, 1.f, 1.f);
				break;
			}
			break;
		}
	case QUIT:
		if (!enterQuitGameState)
		{
			AEGfxPrint(Font, strBuffer, -0.30f, 0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
			AEGfxPrint(Font, strBuffer2, -0.30f, -0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
			AEGfxPrint(Font, strBuffer3, -0.30f, -0.3f, 0.5f, 0.8f, 0.8f, 0.8f);
			AEGfxPrint(Font, strBuffer4, -0.30f, -0.5f, 0.8f, 1.f, 1.f, 1.f);
			AEGfxPrint(Font, strBuffer5, -0.50f, -0.5f, 0.5f, 1.f, 1.f, 1.f);
			
			AEGfxPrint(Font, strBuffer6, -0.30f, 0.4f, 0.8f, 1.f, 1.f, 1.f);
			AEGfxPrint(Font, strBuffer7, -0.30f, 0.35f, 0.85f, 1.f, 1.f, 1.f);
			break;
		}
		else
		{
			sprintf_s(strBuffer, "Are you sure you want to quit the game?");
			sprintf_s(strBuffer2, "No");
			sprintf_s(strBuffer3, "Yes");
			sprintf_s(strBuffer4, ">>>>");

			AEGfxPrint(Font, strBuffer, -0.55f, 0.3f, 0.5f, 1.f, 1.f, 1.f);

			switch (quitGame)
			{
			case NO:
				AEGfxPrint(Font, strBuffer2, -0.10f, -0.1f, 0.8f, 1.f, 1.f, 1.f);
				AEGfxPrint(Font, strBuffer3, -0.10f, -0.3f, 0.5f, 0.8f, 0.8f, 0.8f);
				AEGfxPrint(Font, strBuffer4, -0.30f, -0.1f, 0.5f, 1.f, 1.f, 1.f);
				break;

			case YES:
				AEGfxPrint(Font, strBuffer2, -0.10f, -0.1f, 0.5f, 0.8f, 0.8f, 0.8f);
				AEGfxPrint(Font, strBuffer3, -0.10f, -0.3f, 0.8f, 1.f, 1.f, 1.f);
				AEGfxPrint(Font, strBuffer4, -0.30f, -0.3f, 0.5f, 1.f, 1.f, 1.f);
				break;
			}
			break;
		}
	}

	AEMtx33Trans(&transBG, 0, 0);
	AEMtx33Scale(&scaleBG, (f32)AEGetWindowWidth(), (f32)AEGetWindowHeight());
	AEMtx33Concat(&transformBG, &transBG, &scaleBG);
	AEGfxSetTransform(transformBG.m);
}

/******************************************************************************/
/*!
	"Free" all object instance function
*/
/******************************************************************************/
void pauseMenu_Free() {}

/******************************************************************************/
/*!
	"Unload" pause menu function
*/
/******************************************************************************/
void pauseMenu_Unload() {}
