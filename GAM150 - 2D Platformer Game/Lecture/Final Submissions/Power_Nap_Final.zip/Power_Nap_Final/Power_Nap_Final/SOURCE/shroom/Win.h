/**********************************************************************************
* \File name     Win.h
* \Project name  Jump!Shroom!

* \Author(s)	 Wei Zhe, Goh	7 Lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#pragma once

void Win_Load();
void Win_Init();
void Win_Update();
void Win_Draw();
void Win_Free();
void Win_Unload();

