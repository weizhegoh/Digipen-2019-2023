/**********************************************************************************
* \File name	LevelSelect.cpp
* \Project name Jump!Shroom!

* \Author(s)	Hong Fu, Wong       471 Lines x 89.25% Code Contribution
				Wei Zhe, Goh		471 Lines x 10.5% Code Contribution
				Yan Han, Dong		471 Lines x 0.25% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#include "shroom.h"
#include <iostream>

/******************************************************************************/
/*!
	Defines
*/
/******************************************************************************/

//Gameplay related variables and values
const int				HERO_LIVES = 3;
const float				GRAVITY	= -20.0f;
const float				JUMP_VELOCITY	= 11.0f;
const float				MOVE_VELOCITY_HERO = 4.0f;

/******************************************************************************/
/*!
	File globals
*/
/******************************************************************************/
int						level;
int						HeroLives;
int						TotalCoins;
int						Hero_Initial_X;
int						Hero_Initial_Y;

//Binary map data
extern GameObjInst		*pBlackInstance;
extern GameObjInst		*pWhiteInstance;

// Font
extern s8				Font;
static int				currHero;

//Loading
int						loadscreen = 0;
bool					jumpBool = false;
																			 
// Particle Timer											 
float					pTIMER = 0.0f;
const float				pTIME = 0.0f;
																			 
// Instruction Timer									 
bool					iBool = false;
float					iTimer = 0.0f;
const float				iTime = 0.0f;

// Instructions
static AEGfxVertexList	*mmMesh, *mmMesh2;
static AEGfxTexture		*mmTex, *mmTex2, *mmTex3;

/******************************************************************************/
/*!
	Load function for level select
*/
/******************************************************************************/
void LevelSelect_Load()
{
	if (!pauseGame)
	{
		sGameObjList = (GameObj*)calloc(GAME_OBJ_NUM_MAX, sizeof(GameObj));
		sGameObjInstList = (GameObjInst*)calloc(GAME_OBJ_INST_NUM_MAX, sizeof(GameObjInst));
		sGameObjNum = 0;

		if (!sGameObjList || !sGameObjInstList)
		{
			return;
		}

		blackObject_Load();					//Load black object
		whiteObject_Load();					//Load white object

		characterTexture_Load();			//Load character texture
		enemyTexture_Load();				//Load basic enemy texture
		coinTexture_Load();					//Load coin texture
		greenPowerUpTexture_Load();			//Load green power up texture
		bluePowerUpTexture_Load();			//Load blue power up texture 

		level1Object_Load();
		level2Object_Load();
		level3Object_Load();

		spawnMushroomTexture_Load();			//Load spawned mushroom texture

		//Setting intital binary map values
		MapData = 0;
		BinaryCollisionArray = 0;
		BINARY_MAP_WIDTH = 0;
		BINARY_MAP_HEIGHT = 0;

		//Importing Data
		if (!ImportMapDataFromFile("assert\\text_files\\LevelSelect.txt"))
			next = GS_QUIT;

		// Camera
		AEMtx33 scale, trans;

		float x = static_cast<float>(BINARY_MAP_WIDTH) / 2;
		float y = static_cast<float>(BINARY_MAP_HEIGHT) / 2;

		AEMtx33Trans(&trans, -x, -y);
		AEMtx33Scale(&scale, static_cast<float>(AEGetWindowWidth() / BINARY_MAP_WIDTH), static_cast<float>(AEGetWindowHeight() / BINARY_MAP_HEIGHT));
		AEMtx33Concat(&MapTransform, &scale, &trans);

		// Instruction
		AEGfxMeshStart();
		AEGfxTriAdd(
			-40.5f, -40.5f, 0xFFFFFFFF, 0.0f, 1.f,
			40.5f, -40.5f, 0xFFFFFFFF, 1.f, 1.f,
			-40.5f, 40.5f, 0xFFFFFFFF, 0.0f, 0.0f);

		AEGfxTriAdd(
			40.5f, -40.5f, 0xFFFFFFFF, 1.f, 1.f,
			40.5f, 40.5f, 0xFFFFFFFF, 1.f, 0.0f,
			-40.5f, 40.5f, 0xFFFFFFFF, 0.0f, 0.0f);

		mmMesh = AEGfxMeshEnd();
		AE_ASSERT_MESG(mmMesh, "fail to create Hero object!!");
		mmTex = AEGfxTextureLoad("assert\\art\\arrow2.png");
		AE_ASSERT_MESG(mmTex, "fail to create Hero texture!!");

		AEGfxMeshStart();
		AEGfxTriAdd(
			-305.5f, -60.5f, 0xFFFFFFFF, 0.0f, 1.f,
			305.5f, -60.5f, 0xFFFFFFFF, 1.f, 1.f,
			-305.5f, 60.5f, 0xFFFFFFFF, 0.0f, 0.0f);

		AEGfxTriAdd(
			305.5f, -60.5f, 0xFFFFFFFF, 1.f, 1.f,
			305.5f, 60.5f, 0xFFFFFFFF, 1.f, 0.0f,
			-305.5f, 60.5f, 0xFFFFFFFF, 0.0f, 0.0f);

		mmMesh2 = AEGfxMeshEnd();
		AE_ASSERT_MESG(mmMesh2, "fail to create Hero object!!");
		mmTex2 = AEGfxTextureLoad("assert\\art\\backgroundbannerwhite.png");
		AE_ASSERT_MESG(mmTex2, "fail to create Hero texture!!");
		mmTex3 = AEGfxTextureLoad("assert\\art\\spacebar_1.png");
		AE_ASSERT_MESG(mmTex3, "fail to create Hero texture!!");

		ParticleSystemLoad();
   		AudioEngine_Load();
		mainMenuBG_Load();
	}
}

/******************************************************************************/
/*!
	Initialize function for level select
*/
/******************************************************************************/
void LevelSelect_Init()
{
	int i, j;

	pHero = 0;
	TotalCoins = 0;
	pBlackInstance = 0;
	pWhiteInstance = 0;
	
	AEVec2 Pos;
	AEVec2 LevelPos = { 4,12 };
	AEVec2 Level2Pos = { 10,12 };
	AEVec2 Level3Pos = { 16,12 };

	GameObjInst* pInst;

	pauseMenu_Init();
	AudioEngine_Initialize();

	// For Alt tabbing
	SetWindowPos(AESysGetWindowHandle(), HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_DRAWFRAME | SWP_NOSIZE);

	// 3 level bars
	pInst = gameObjInstCreate(TYPE_OBJECT_LEVEL1, 1.0f, &LevelPos, 0, 0.0f, STATE::STATE_NONE);
	pInst = gameObjInstCreate(TYPE_OBJECT_LEVEL2, 1.0f, &Level2Pos, 0, 0.0f, STATE::STATE_NONE);
	pInst = gameObjInstCreate(TYPE_OBJECT_LEVEL3, 1.0f, &Level3Pos, 0, 0.0f, STATE::STATE_NONE);

	//Create an object instance representing the black cell.
	pBlackInstance = gameObjInstCreate(TYPE_OBJECT_EMPTY, 1.0f, 0, 0, 0.0f, STATE::STATE_NONE);
	pBlackInstance->flag ^= FLAG_VISIBLE;
	pBlackInstance->flag |= FLAG_NON_COLLIDABLE;

	//Create an object instance representing the white cell.
	pWhiteInstance = gameObjInstCreate(TYPE_OBJECT_COLLISION, 1.0f, 0, 0, 0.0f, STATE::STATE_NONE);
	pWhiteInstance->flag ^= FLAG_VISIBLE;
	pWhiteInstance->flag |= FLAG_NON_COLLIDABLE;

	//Setting the inital number of hero lives
	HeroLives = HERO_LIVES;

	for (i = 0; i < BINARY_MAP_WIDTH; ++i)
	{
		for (j = 0; j < BINARY_MAP_HEIGHT; ++j)
		{
			Pos.x = j + 0.5f;
			Pos.y = i + 0.5f;

			if (MapData[i][j] == 2) // Create Hero
			{
				pHero = gameObjInstCreate(TYPE_OBJECT_HERO, 1.0f, &Pos, 0, 0.0f, STATE::STATE_NONE);
				Hero_Initial_X = static_cast<int>(Pos.x);
				Hero_Initial_Y = static_cast<int>(Pos.y);
			}
		}
	}
}

/******************************************************************************/
/*!
	Update function for level select
*/
/******************************************************************************/
void LevelSelect_Update()
{
	if (GetFocus() == 0)
	{
		pauseGame = true;
	}

	if (AEInputCheckReleased(AEVK_ESCAPE))
	{
		pauseGame = true;
	}

	if (pauseGame)
	{
		pauseMenu_Update();
		AudioEngine_Update();
	}

	if (!pauseGame)
	{
		level = 0;
		unsigned int i;
		GameObjInst* pInst;

		// Moving right
		if (AEInputCheckCurr(AEVK_RIGHT))
		{
			pHero->velCurr.x = MOVE_VELOCITY_HERO;

			if (pHero->gridCollisionFlag & COLLISION_BOTTOM)
			{
				if (pTIMER >= 0.10f)
				{
					ParticleSpawn(myParticle1, (float)(pHero->posCurr.x), (float)(pHero->posCurr.y - 0.35));
					pTIMER = pTIME;
				}
				else
					pTIMER += g_dt;
			}
		}
		// Moving left
		else if (AEInputCheckCurr(AEVK_LEFT)) 
		{
			pHero->velCurr.x = -MOVE_VELOCITY_HERO;

			if (pHero->gridCollisionFlag & COLLISION_BOTTOM)
				if (pTIMER >= 0.10f)
				{
					ParticleSpawn(myParticle1, (float)(pHero->posCurr.x), (float)(pHero->posCurr.y - 0.35));
					pTIMER = pTIME;
				}
				else
				{
					pTIMER += g_dt;
				}
		}
		else
		{
			pHero->velCurr.x = 0;
		}

		// Jumping
		if (AEInputCheckTriggered(AEVK_SPACE) && pHero->gridCollisionFlag >= COLLISION_BOTTOM)
		{
			JumpAndOnGround = true;
			pHero->velCurr.y = JUMP_VELOCITY;
			jumpBool = true;
			ParticleSpawn(myParticle1, pHero->posCurr.x, pHero->posCurr.y);
		}

		// Press escape to return to main menu
		if (AEInputCheckReleased(AEVK_ESCAPE)) 
		{
			next = GS_MainMenu;
		}

		AudioEngine_Update();
		graphic_Update();

		//Update object instances physics and behavior
		for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
		{
			pInst = sGameObjInstList + i;

			// skip non-active object
			if (0 == (pInst->flag & FLAG_ACTIVE))
				continue;

			if (pInst->pObject->type != TYPE_OBJECT_COIN &&
					pInst->pObject->type != TYPE_OBJECT_LEVEL1 &&
				  pInst->pObject->type != TYPE_OBJECT_LEVEL2 &&
				  pInst->pObject->type != TYPE_OBJECT_LEVEL3)
			{
				pInst->velCurr.y = GRAVITY * g_dt + pInst->velCurr.y;

				// 2nd parabolic arc
				if (pInst->pObject->type == TYPE_OBJECT_HERO && pInst->velCurr.y < 0)
				{
					pInst->velCurr.y = GRAVITY * 2 * g_dt + pInst->velCurr.y;
				}
			}

			// Player position, used to track which level to select
			if (pInst->pObject->type == TYPE_OBJECT_HERO)
			{
				currHero = static_cast<int>(pInst->posCurr.x);
			}

			// Enemy State Machine
			if (pInst->pObject->type == TYPE_OBJECT_ENEMY1)
			{
				EnemyStateMachine(pInst);
			}
		}

		//Update object instances positions
		for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
		{
			pInst = sGameObjInstList + i;

			// skip non-active object
			if (0 == (pInst->flag & FLAG_ACTIVE))
				continue;

			// Update gameobject positions
			pInst->posCurr.x = pInst->velCurr.x * g_dt + pInst->posCurr.x;
			pInst->posCurr.y = pInst->velCurr.y * g_dt + pInst->posCurr.y;

			// Setting Bounding Box
			AEVec2Set(&pInst->boundingBox.min, -0.5f * pInst->scale + pInst->posCurr.x, -0.5f * pInst->scale + pInst->posCurr.y);
			AEVec2Set(&pInst->boundingBox.max, 0.5f * pInst->scale + pInst->posCurr.x, 0.5f * pInst->scale + pInst->posCurr.y);
		}

		//Check for grid collision
		for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
		{
			pInst = sGameObjInstList + i;

			// skip non-active object instances
			if (0 == (pInst->flag & FLAG_ACTIVE))
				continue;

			pInst->gridCollisionFlag = CheckInstanceBinaryMapCollision(pInst->posCurr.x, pInst->posCurr.y, 1, 1);

			// Checking for bottom Collision
			if (pInst->gridCollisionFlag & COLLISION_BOTTOM)
			{
				SnapToCell(&pInst->posCurr.y);

				pInst->velCurr.y = 0;
			}

			// Checking for top collision
			if (pInst->gridCollisionFlag & COLLISION_TOP)
			{
				SnapToCell(&pInst->posCurr.y);

				pInst->velCurr.y = 0;
			}

			// Checking for left collision
			if (pInst->gridCollisionFlag & COLLISION_LEFT)
			{
				SnapToCell(&pInst->posCurr.x);

				pInst->velCurr.x = 0;
			}

			// Checking for right collision
			if (pInst->gridCollisionFlag & COLLISION_RIGHT)
			{
				SnapToCell(&pInst->posCurr.x);

				pInst->velCurr.x = 0;
			}
		}

		for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
		{
			pInst = sGameObjInstList + i;

			if (0 == (pInst->flag & FLAG_ACTIVE))
				continue;

			// ADD CODE FOR COLLISION TO TRANSITION
			if (jumpBool == true && pHero->gridCollisionFlag & COLLISION_BOTTOM)
			{
				switch (loadscreen)
				{
				case 0:
					next = GS_CUTSCENE;
					level = 1;
					break;
				case 1:
					next = GS_CUTSCENE;
					level = 2;
					break;
				case 2:
					next = GS_CUTSCENE;
					level = 3;
					break;
				case 3:
					break;
				}
				jumpBool = false;
			}
		}

		//Computing the transformation matrices of the game object instances
		for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
		{
			AEMtx33 scale, rot, trans;
			pInst = sGameObjInstList + i;

			// skip non-active object
			if (0 == (pInst->flag & FLAG_ACTIVE))
				continue;

			AEMtx33Scale(&scale, pInst->scale, pInst->scale);
			AEMtx33Rot(&rot, pInst->dirCurr);
			AEMtx33Trans(&trans, pInst->posCurr.x, pInst->posCurr.y);

			AEMtx33Concat(&pInst->transform, &rot, &scale);
			AEMtx33Concat(&pInst->transform, &trans, &pInst->transform);

		}

		ParticleUpdate(myParticle1);
	}
}

/******************************************************************************/
/*!
	Draw function for level select
*/
/******************************************************************************/
void LevelSelect_Draw()
{
	if (pauseGame)
	{
		pauseMenu_Draw();
	}

	if (!pauseGame)
	{
		//Drawing the tile map (the grid)
		int i, j;
		AEMtx33 cellTranslation, cellFinalTransformation;

		AEGfxSetBackgroundColor(0.6f, 0.3f, 0.1f);
		AEGfxSetBlendMode(AE_GFX_BM_NONE);
		AEGfxSetRenderMode(AE_GFX_RM_COLOR);
		AEGfxTextureSet(nullptr, 0, 0);

		AEGfxSetRenderMode(AE_GFX_RM_COLOR);
		AEGfxSetBlendMode(AE_GFX_BM_BLEND);

		// Code to determine which level the player is overlapping, affects which level to load
		if (currHero <= 6)
			loadscreen = 0;
		if (currHero > 6 && currHero <= 12)
			loadscreen = 1;
		if (currHero > 12)
			loadscreen = 2;

		//Printing text
		char strBuffer[1024];

		// Printing the 3 bars for level select
		for (unsigned int k = 0; k < GAME_OBJ_INST_NUM_MAX; ++k)
		{
			GameObjInst* pInst = sGameObjInstList + k;

			// skip non-active object
			if (0 == (pInst->flag & FLAG_ACTIVE) || 0 == (pInst->flag & FLAG_VISIBLE))
				continue;
			if (pInst->pObject->type == TYPE_OBJECT_LEVEL1)
			{
				AEGfxSetBlendMode(AE_GFX_BM_BLEND);
				AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
				AEGfxTextureSet(pInst->pObject->pTex, pHero->posCurr.x / 25, 1);

				// Code to highlight the bar selected
				if (loadscreen == 0)
					AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
				else
					AEGfxSetTintColor(0.8f, 0.8f, 0.8f, 1.0f);

				AEGfxSetTransparency(1.0f);
			}
			else if (pInst->pObject->type == TYPE_OBJECT_LEVEL2)
			{
				AEGfxSetBlendMode(AE_GFX_BM_BLEND);
				AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
				AEGfxTextureSet(pInst->pObject->pTex, pHero->posCurr.x / 25, 1);

				// Code to highlight the bar selected
				if (loadscreen == 1)
					AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
				else
					AEGfxSetTintColor(0.8f, 0.8f, 0.8f, 1.0f);
				AEGfxSetTransparency(1.0f);
			}
			else if (pInst->pObject->type == TYPE_OBJECT_LEVEL3)
			{
				AEGfxSetBlendMode(AE_GFX_BM_BLEND);
				AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
				AEGfxTextureSet(pInst->pObject->pTex, pHero->posCurr.x / 25, 1);

				// Code to highlight the bar selected
				if (loadscreen == 2)
					AEGfxSetTintColor(2.0f, 2.0f, 2.0f, 1.0f);
				else
					AEGfxSetTintColor(0.8f, 0.8f, 0.8f, 1.0f);
				AEGfxSetTransparency(1.0f);
			}
			else if (pInst->pObject->type == TYPE_OBJECT_HERO)
			{
				AEGfxSetBlendMode(AE_GFX_BM_BLEND);
				AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
				AEGfxTextureSet(pInst->pObject->pTex, U, V);
				AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
				AEGfxSetTransparency(1.0f);
			}
			AEMtx33Concat(&pInst->transform, &MapTransform, &pInst->transform);
			AEGfxSetTransform(pInst->transform.m);
			AEGfxMeshDraw(pInst->pObject->pMesh, AE_GFX_MDM_TRIANGLES);
		}

		ParticleDraw(myParticle1);

		for (i = 0; i < BINARY_MAP_WIDTH; ++i)
		{
			for (j = 0; j < BINARY_MAP_HEIGHT; ++j)
			{
				float xPos = i + 0.5f;
				float yPos = j + 0.5f;

				AEMtx33Trans(&cellTranslation, xPos, yPos);
				AEMtx33Concat(&cellFinalTransformation, &MapTransform, &cellTranslation);
				AEGfxSetTransform(cellFinalTransformation.m);

				AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
				if (GetCellValue(i, j) == TYPE_OBJECT_COLLISION)
				{
					AEGfxTextureSet(pWhiteInstance->pObject->pTex, 0.6f, 0.0f);
					AEGfxMeshDraw(pWhiteInstance->pObject->pMesh, AE_GFX_MDM_TRIANGLES);
				}
			}
		}

		switch (loadscreen)
		{
		case 0:
			sprintf_s(strBuffer, "Level 1");
			AEGfxPrint(Font, strBuffer, -0.725f, 0.1f, 0.6f, 1.f, 1.f, 1.f);

			sprintf_s(strBuffer, "Level 2");
			AEGfxPrint(Font, strBuffer, -0.125f, 0.1f, 0.6f, 0.8f, 0.8f, 0.8f);

			sprintf_s(strBuffer, "Level 3");
			AEGfxPrint(Font, strBuffer, 0.475f, 0.1f, 0.6f, 0.8f, 0.8f, 0.8f);
			break;
		case 1:
			sprintf_s(strBuffer, "Level 1");
			AEGfxPrint(Font, strBuffer, -0.725f, 0.1f, 0.6f, 0.8f, 0.8f, 0.8f);

			sprintf_s(strBuffer, "Level 2");
			AEGfxPrint(Font, strBuffer, -0.125f, 0.1f, 0.6f, 1.f, 1.f, 1.f);

			sprintf_s(strBuffer, "Level 3");
			AEGfxPrint(Font, strBuffer, 0.475f, 0.1f, 0.6f, 0.8f, 0.8f, 0.8f);
			break;
		case 2:
			sprintf_s(strBuffer, "Level 1");
			AEGfxPrint(Font, strBuffer, -0.725f, 0.1f, 0.6f, 0.8f, 0.8f, 0.8f);

			sprintf_s(strBuffer, "Level 2");
			AEGfxPrint(Font, strBuffer, -0.125f, 0.1f, 0.6f, 0.8f, 0.8f, 0.8f);

			sprintf_s(strBuffer, "Level 3");
			AEGfxPrint(Font, strBuffer, 0.475f, 0.1f, 0.6f, 1.f, 1.f, 1.f);
			break;
		}

		// banner
		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(0.f, 185.f);
		AEGfxTextureSet(mmTex2, 0.f, 0.f);
		AEGfxSetTintColor(1.f, 1.f, 1.f, 0.2f);
		AEGfxSetTransparency(1.0f);
		AEGfxMeshDraw(mmMesh2, AE_GFX_MDM_TRIANGLES);

		// Instructions arrow
		AEGfxSetBlendMode(AE_GFX_BM_ADD);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(-120.f, 190.f);
		AEGfxTextureSet(mmTex, 0.f, 0.f);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
		AEGfxSetTransparency(1.0f);
		AEGfxMeshDraw(mmMesh, AE_GFX_MDM_TRIANGLES);

		// Instrution text
		AEGfxSetRenderMode(AE_GFX_RM_COLOR);
		sprintf_s(strBuffer, "Arrow keys to move");
		AEGfxPrint(Font, strBuffer, -0.415f, 0.45f, 0.2f, 1.f, 1.f, 1.f);

		// Spacebar 
		AEGfxSetBlendMode(AE_GFX_BM_ADD);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(120.f, 190.f);
		AEGfxTextureSet(mmTex3, 0.f, 0.f);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
		AEGfxSetTransparency(1.0f);
		AEGfxMeshDraw(mmMesh, AE_GFX_MDM_TRIANGLES);

		// Spacebar text
		AEGfxSetRenderMode(AE_GFX_RM_COLOR);
		sprintf_s(strBuffer, "Space to jump");
		AEGfxPrint(Font, strBuffer, 0.22f, 0.45f, 0.2f, 1.f, 1.f, 1.f);
	}
}

/******************************************************************************/
/*!
	Free function for level select
*/
/******************************************************************************/
void LevelSelect_Free()
{
	if (!pauseGame || (pauseGame && quitGame == YES))
	{
		graphic_Free();
	}
}

/******************************************************************************/
/*!
	Unload function for level select
*/
/******************************************************************************/
void LevelSelect_Unload()
{
	if (!pauseGame || (pauseGame && quitGame == YES) || (AESysDoesWindowExist() == false))
	{
		graphic_Unload();
		ParticleUnload();

		/*********
		Free the map data
		*********/
		free(sGameObjInstList);
		free(sGameObjList);

		// instruction texture and mesh
		AEGfxMeshFree(mmMesh);
		AEGfxTextureUnload(mmTex);
		AEGfxMeshFree(mmMesh2);
		AEGfxTextureUnload(mmTex2);
		AEGfxTextureUnload(mmTex3);

		Map_Free();
		mainMenuBG_Unload();
	}
}