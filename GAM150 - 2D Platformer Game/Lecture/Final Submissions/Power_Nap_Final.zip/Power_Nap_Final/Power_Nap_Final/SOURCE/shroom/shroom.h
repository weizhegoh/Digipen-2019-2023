/**********************************************************************************
* \File name     Shroom.h
* \Project name  Jump!Shroom!

* \Author(s)	 Wei Zhe, Goh	40 Lines x 80% Code Contribution
				 Yan Han, Dong  40 Lines x 20% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#ifndef SHROOM_H_
#define SHROOM_H_

extern float	g_dt;
extern double	g_appTime;
extern bool		fullscreen;

#include "resource.h"
#include "AEEngine.h"

#include "GameStateList.h"
#include "GameStateManager.h"
#include "Audio.h"
#include "Collision.h"
#include "framework.h"
#include "Graphic.h"
#include "MainMenu.h"
#include "LevelSelect.h"
#include "level1.h"
#include "level2.h"
#include "level3.h"
#include "Object.h"
#include "ParticleSystem.h"
#include "targetver.h"
#include <SDKDDKVer.h>
#include "Map.h"
#include "Enemy.h"
#include "Splash.h"
#include "Win.h"
#include "PowerUp.h"
#include "CutScene.h"
#include "pauseMenu.h"

#include <iostream>
#include <memory>
#include <crtdbg.h>
#include <fmod.hpp>
#include <vector>

//C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

//Windows Header Files
#include <windows.h>
#endif 