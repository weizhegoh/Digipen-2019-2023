/**********************************************************************************
* \File name	 Level1.cpp
* \Project name  Jump!Shroom!

* \Author(s)     Hong Fu, Wong			682 lines x 57% Code Contribution
				 Benjamin Liew			682 lines x 32.5% Code Contribution
				 Wei Zhe, Goh			682 lines x 10% Code Contribution
				 Dong Han, Yan			682 lines x 0.5% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#include <iostream>
#include "shroom.h"

/******************************************************************************/
/*!
	Defines
*/
/******************************************************************************/
// The total number of different objects (Shapes)
// The total number of different game object instances
const unsigned int			GAME_OBJ_NUM_MAX = 32;
const unsigned int			GAME_OBJ_INST_NUM_MAX = 2048;

//Flags
extern const unsigned int	FLAG_ACTIVE = 0x00000001;
extern const unsigned int	FLAG_VISIBLE = 0x00000002;
extern const unsigned int	FLAG_NON_COLLIDABLE = 0x00000004;

/******************************************************************************/
/*!
	File globals
*/
/******************************************************************************/

// list of original objects
extern GameObj				* sGameObjList;
extern unsigned int			sGameObjNum;

// list of object instances
extern GameObjInst			* sGameObjInstList;

//Binary map data
extern GameObjInst			* pBlackInstance;
extern GameObjInst			* pWhiteInstance;

extern AEMtx33				MapTransform;

extern GameObjInst			* pHero;
extern GameObj				* pObj;

/******************************************************************************/
/*!
	My own variables
*/
/******************************************************************************/

// Coins
bool						updateScore = false;			//Check for lives and score update
bool						updateLives = false;			//Check for lives and score update
int							coinCounter;					//Total Coin Count

// Particles
extern Particle				myParticle1[MAX_PARTICLES_NUM];
extern Particle				myParticle1Jump[MAX_PARTICLES_NUM];

// Camera Code
AEVec2						camPos;
AEVec2						lerpHeroPos;
AEVec2						oldHeroPos;

// Death message
extern s8					Font;
bool						displayDeath = false;

float						TIMER = 0.0f;
const float					TIME = 0.0f;

// Particle Timer
extern float				pTIMER;
extern const float			pTIME;

//PowerUp Class
extern PowerUp				Blue;
extern PowerUp				Green;

//UI Class
extern UI					UIGreen;
extern UI					UIBlue;
extern UI					UIRedDecreaseLife;
extern UI					UIRedDecreaseBluepowerup;

//Instructions
static AEGfxTexture			* mmTex, * mmTex2;
static AEGfxVertexList		* mmMesh, * mmMesh2;

/******************************************************************************/
/*!
	Load function of level 1
*/
/******************************************************************************/
void Level1_Load(void)
{
	if (pauseGame)
	{
		pauseMenu_Load();
	}

	if (!pauseGame)
	{
		sGameObjList = (GameObj*)calloc(GAME_OBJ_NUM_MAX, sizeof(GameObj));
		sGameObjInstList = (GameObjInst*)calloc(GAME_OBJ_INST_NUM_MAX, sizeof(GameObjInst));
		sGameObjNum = 0;

		if (!sGameObjList || !sGameObjInstList)
		{
			return;
		}

		blackObject_Load();					//Load black object
		whiteObject_Load();					//Load white object

		characterTexture_Load();			//Load character texture
		enemyTexture_Load();				//Load basic enemy texture
		coinTexture_Load();					//Load coin texture
		greenPowerUpTexture_Load();			//Load green power up texture
		bluePowerUpTexture_Load();			//Load blue power up texture 

		level1Object_Load();
		level2Object_Load();
		level3Object_Load();

		spawnMushroomTexture_Load();		//Load spawned mushroom texture
		level1Background_Load();			//Load level 1 background texture	

		//Setting intital binary map values
		MapData = 0;
		BinaryCollisionArray = 0;
		BINARY_MAP_WIDTH = 0;
		BINARY_MAP_HEIGHT = 0;

		// Importing map data
		if (!ImportMapDataFromFile("assert\\text_files\\Level1.1.txt"))
			next = GS_QUIT;

		// Camera 'zoom'
		AEMtx33 scale, trans;

		float x = static_cast<float>(BINARY_MAP_WIDTH) / 2;
		float y = static_cast<float>(BINARY_MAP_HEIGHT) / 2;

		AEMtx33Trans(&trans, -x, -y);
		AEMtx33Scale(&scale, static_cast<float>(AEGetWindowWidth() / BINARY_MAP_WIDTH), static_cast<float>(AEGetWindowHeight() / BINARY_MAP_HEIGHT));
		AEMtx33Concat(&MapTransform, &scale, &trans);

		// Particle
		ParticleSystemLoad();
		level1BG_Load();

		// Instruction
		AEGfxMeshStart();
		AEGfxTriAdd(
			-40.5f, -40.5f, 0xFFFFFFFF, 0.0f, 1.f,
			40.5f, -40.5f, 0xFFFFFFFF, 1.f, 1.f,
			-40.5f, 40.5f, 0xFFFFFFFF, 0.0f, 0.0f);

		AEGfxTriAdd(
			40.5f, -40.5f, 0xFFFFFFFF, 1.f, 1.f,
			40.5f, 40.5f, 0xFFFFFFFF, 1.f, 0.0f,
			-40.5f, 40.5f, 0xFFFFFFFF, 0.0f, 0.0f);

		mmMesh = AEGfxMeshEnd();
		AE_ASSERT_MESG(mmMesh, "fail to create Hero object!!");
		mmTex = AEGfxTextureLoad("assert\\art\\FreezeTut.png");
		AE_ASSERT_MESG(mmTex, "fail to create Hero texture!!");

		// Banner
		AEGfxMeshStart();
		AEGfxTriAdd(
			-60.5f, -30.5f, 0xFFFFFFFF, 0.0f, 1.f,
			60.5f, -30.5f, 0xFFFFFFFF, 1.f, 1.f,
			-60.5f, 30.5f, 0xFFFFFFFF, 0.0f, 0.0f);

		AEGfxTriAdd(
			60.5f, -30.5f, 0xFFFFFFFF, 1.f, 1.f,
			60.5f, 30.5f, 0xFFFFFFFF, 1.f, 0.0f,
			-60.5f, 30.5f, 0xFFFFFFFF, 0.0f, 0.0f);

		mmMesh2 = AEGfxMeshEnd();
		AE_ASSERT_MESG(mmMesh2, "fail to create Hero object!!");
		mmTex2 = AEGfxTextureLoad("assert\\art\\backgroundbannerwhite.png");
		AE_ASSERT_MESG(mmTex2, "fail to create Hero texture!!");
	}
}

/******************************************************************************/
/*!
	Initialize function of Level 1
*/
/******************************************************************************/
void Level1_Initialize(void)
{
	int i, j;
	pHero = 0;
	TotalCoins = 0;
	coinCounter = 0;
	pBlackInstance = 0;
	pWhiteInstance = 0;
	Blue.powerupCounter = 0;
	displayDeath = false;

	// Timer
	iTimer = iTime;
	iBool = false;

	Map_Init();
	pauseMenu_Init();
	AudioEngine_Initialize();
	BluePowerUpDeactivation();
	SetWindowPos(AESysGetWindowHandle(), HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_DRAWFRAME | SWP_NOSIZE);

	AEVec2 Pos;
	AEVec2 LevelPos = { 12,12 };

	GameObjInst* pInst;

	//Create an object instance representing the black cell.
	pBlackInstance = gameObjInstCreate(TYPE_OBJECT_EMPTY, 1.0f, 0, 0, 0.0f, STATE::STATE_NONE);
	pBlackInstance->flag ^= FLAG_VISIBLE;
	pBlackInstance->flag |= FLAG_NON_COLLIDABLE;

	//Create an object instance representing the white cell.
	pWhiteInstance = gameObjInstCreate(TYPE_OBJECT_COLLISION, 1.0f, 0, 0, 0.0f, STATE::STATE_NONE);
	pWhiteInstance->flag ^= FLAG_VISIBLE;
	pWhiteInstance->flag |= FLAG_NON_COLLIDABLE;

	//Setting the inital number of hero lives
	HeroLives = HERO_LIVES;

	graphic_Initialize();

	// Create game objects
	for (i = 0; i < BINARY_MAP_WIDTH; ++i)
	{
		for (j = 0; j < BINARY_MAP_HEIGHT; ++j)
		{
			Pos.x = j + 0.5f;
			Pos.y = i + 0.5f;

			if (MapData[i][j] == 2) // Create Hero
			{
				pHero = gameObjInstCreate(TYPE_OBJECT_HERO, 1.0f, &Pos, 0, 0.0f, STATE::STATE_NONE);
				Hero_Initial_X = static_cast<int>(Pos.x);
				Hero_Initial_Y = static_cast<int>(Pos.y);
			}
			else if (MapData[i][j] == 3) // Create Enemy
			{
				pInst = gameObjInstCreate(TYPE_OBJECT_ENEMY1, 1.0f, &Pos, 0, 0.0f, STATE::STATE_GOING_LEFT);
			}
			else if (MapData[i][j] == 4) // Create Coin
			{
				++coinCounter;
				pInst = gameObjInstCreate(TYPE_OBJECT_COIN, 1.0f, &Pos, 0, 0.0f, STATE::STATE_NONE);
			}
			else if (MapData[i][j] == 5) // Create GREEN Powerup
			{
				pInst = gameObjInstCreate(TYPE_OBJECT_POWERUP_GREEN, 1.0f, &Pos, 0, 0.0f, STATE::STATE_NONE);
			}
			else if (MapData[i][j] == 6) // Create BLUE Powerup
			{
				pInst = gameObjInstCreate(TYPE_OBJECT_POWERUP_BLUE, 1.0f, &Pos, 0, 0.0f, STATE::STATE_NONE);
			}
		}
	}
}

/******************************************************************************/
/*!
	Update function of level 1
*/
/******************************************************************************/
void Level1_Update(void)
{
	if (GetFocus() == 0)
	{
		pauseGame = true;
	}

	if (AEInputCheckReleased(AEVK_ESCAPE))
	{
		Green.levelProgress = 0;
		pauseGame = true;
	}

	if (pauseGame)
	{
		pauseMenu_Update();
		AudioEngine_Update();
	}

	if (!pauseGame)
	{
		int i;
		GameObjInst* pInst;

		Map_Update();

		if (AEInputCheckCurr(AEVK_RIGHT) && HeroLives > 0) // Moving Right
		{
			pHero->velCurr.x = MOVE_VELOCITY_HERO;
			pHero->directioncheck = 1;

			if (pHero->gridCollisionFlag & COLLISION_BOTTOM)
			{
				if (pTIMER >= 0.10f)
				{
					ParticleSpawn(myParticle1, (float)(pHero->posCurr.x), (float)(pHero->posCurr.y - 0.35));
					pTIMER = pTIME;
				}
				else
					pTIMER += g_dt;
			}
		}

		else if (AEInputCheckCurr(AEVK_LEFT) && HeroLives > 0) // Moving Left
		{
			pHero->velCurr.x = -MOVE_VELOCITY_HERO;
			pHero->directioncheck = 0;

			if (pHero->gridCollisionFlag & COLLISION_BOTTOM)
				if (pTIMER >= 0.10f)
				{
					ParticleSpawn(myParticle1, (float)(pHero->posCurr.x), (float)(pHero->posCurr.y - 0.35));
					pTIMER = pTIME;
				}
				else
					pTIMER += g_dt;
		}
		else
		{
			pHero->velCurr.x = 0;
		}

		if (AEInputCheckTriggered(AEVK_SPACE) && pHero->gridCollisionFlag >= COLLISION_BOTTOM && HeroLives > 0) // Jumping
		{
			JumpAndOnGround = true;
			pHero->velCurr.y = JUMP_VELOCITY;
			ParticleSpawn(myParticle1, pHero->posCurr.x, pHero->posCurr.y);
		}

		//Spawning of Mushroom if there is enough Player Life
		if (AEInputCheckTriggered(AEVK_D) && HeroLives > 1)
		{
			if (pHero->directioncheck == 0) //pHero facing LEFT
			{
				if (!GetCellValue(int(pHero->posCurr.x - 1.0f), int(pHero->posCurr.y))) //Checking if the LEFT side is a block
				{
					UIRedDecreaseLife.UIFlash = true;	//Activate the flash
					spawnMushrooM = true;
					pHero->velCurr.x = 0;
					float positionX = pHero->posCurr.x;
					positionX -= 1.0f;
					AEVec2 newPos{ positionX, pHero->posCurr.y };
					pInst = gameObjInstCreate(TYPE_OBJECT_MUSHROOM, 1.f, &newPos, nullptr, 0.0f, STATE::STATE_NONE);
					--HeroLives;
				}
			}
			else if (pHero->directioncheck == 1) //pHero facing RIGHT
			{
				if (!GetCellValue(int(pHero->posCurr.x + 1.0f), int(pHero->posCurr.y))) //Checking if the RIGHT side is a block
				{
					UIRedDecreaseLife.UIFlash = true;	//Activate the flash
					spawnMushrooM = true;
					pHero->velCurr.x = 0;
					float positionX = pHero->posCurr.x;
					positionX += 1.0f;
					AEVec2 newPos{ positionX, pHero->posCurr.y };
					pInst = gameObjInstCreate(TYPE_OBJECT_MUSHROOM, 1.f, &newPos, nullptr, 0.0f, STATE::STATE_NONE);
					--HeroLives;
				}
			}
		}

		//Activation of Player ability if it is not activated
		try
		{
			if (AEInputCheckTriggered(AEVK_S) && !Blue.activation)
			{
				BluePowerUpActivation();
				Blue.invincibility = true;
				Blue.freeze = true;
			}
		}

		catch (const char* str)
		{
			std::cout << str << std::endl;
		}

		graphic_Update();

		for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
		{
			pInst = sGameObjInstList + i;

			// skip non-active object
			if (0 == (pInst->flag & FLAG_ACTIVE))
				continue;

			// Add gravity to every object except coins and mushrooms that are spawned in mid-air
			if (pInst->pObject->type != TYPE_OBJECT_COIN)
			{
				//If spawned mushroom are in mid-air, no gravity will be implemented on it
				if (pInst->pObject->type == TYPE_OBJECT_MUSHROOM && !(pInst->gridCollisionFlag & COLLISION_BOTTOM))
				{
					pInst->velCurr.y = 0;
					continue;
				}
				pInst->velCurr.y = GRAVITY * g_dt + pInst->velCurr.y;
				if (pInst->pObject->type == TYPE_OBJECT_HERO && pInst->velCurr.y < 0)
				{
					pInst->velCurr.y = GRAVITY * 2 * g_dt + pInst->velCurr.y;
				}
				if (pInst->velCurr.y <= -30.0f)
				{
					pInst->velCurr.y = -30.0f;
				}
			}

			// Enemy State Machine
			if (pInst->pObject->type == TYPE_OBJECT_ENEMY1)
			{
				EnemyStateMachine(pInst);
			}

		}

		//Update object instances positions
		for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
		{
			pInst = sGameObjInstList + i;

			// skip non-active object
			if (0 == (pInst->flag & FLAG_ACTIVE))
				continue;

			pInst->posCurr.x = pInst->velCurr.x * g_dt + pInst->posCurr.x;
			pInst->posCurr.y = pInst->velCurr.y * g_dt + pInst->posCurr.y;

			// Setting Bounding Box
			AEVec2Set(&pInst->boundingBox.min, -0.5f * pInst->scale + pInst->posCurr.x, -0.5f * pInst->scale + pInst->posCurr.y);
			AEVec2Set(&pInst->boundingBox.max, 0.5f * pInst->scale + pInst->posCurr.x, 0.5f * pInst->scale + pInst->posCurr.y);

		}

		//Check for grid collision
		for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
		{
			pInst = sGameObjInstList + i;

			// skip non-active object instances
			if (0 == (pInst->flag & FLAG_ACTIVE))
				continue;

			pInst->gridCollisionFlag = CheckInstanceBinaryMapCollision(pInst->posCurr.x, pInst->posCurr.y, 1, 1);

			if (pInst->gridCollisionFlag & COLLISION_LEFT) // Checking for Left Collision
			{
				SnapToCell(&pInst->posCurr.x);

				pInst->velCurr.x = 0;
			}

			if (pInst->gridCollisionFlag & COLLISION_RIGHT)  // Checking for Right Collision
			{
				SnapToCell(&pInst->posCurr.x);

				pInst->velCurr.x = 0;
			}

			if (pInst->gridCollisionFlag & COLLISION_TOP)  // Checking for Top Collision
			{
				SnapToCell(&pInst->posCurr.y);

				pInst->velCurr.y = 0;
			}

			if (pInst->gridCollisionFlag & COLLISION_BOTTOM)  // Checking for Bottom Collision
			{
				SnapToCell(&pInst->posCurr.y);

				pInst->velCurr.y = 0;
			}
		}

		for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
		{
			pInst = sGameObjInstList + i;

			if (0 == (pInst->flag & FLAG_ACTIVE))
				continue;

			if (pInst->pObject->type == TYPE_OBJECT_COIN) // Collision with Coin
			{
				if (CollisionIntersection_RectRect(pInst->boundingBox, pInst->velCurr,
					pHero->boundingBox, pHero->velCurr) == true)
				{
					++TotalCoins; //Add Score
					gameObjInstDestroy(pInst);

					updateScore = true;
					coinCollision = true;

					if (TotalCoins == coinCounter) // All coins collected, move to next level.
					{
						++Green.levelProgress;
						levelCleared = true;
						changeGameState = true;
						next = GS_CUTSCENE;
						level = 2;
					}
				}
			}
			else if (pInst->pObject->type == TYPE_OBJECT_ENEMY1 && HeroLives > 0) // Collision with Enemy
			{
				if (CollisionIntersection_RectRect(pInst->boundingBox, pInst->velCurr,
					pHero->boundingBox, pHero->velCurr) == true)
				{
					if (Blue.invincibility || Blue.freeze) //If INVINCIBILITY / FREEZE ability is used
					{
						continue;
					}
					//Check when Player if on a platform
					else if (GetCellValue(static_cast<int>(pHero->posCurr.x - 0.5), static_cast<int>(pHero->posCurr.y - 1)) || GetCellValue(static_cast<int>(pHero->posCurr.x + 0.5), static_cast<int>(pHero->posCurr.y - 1)))
					{
						f32 checkEnemyTopSideCollision = pInst->boundingBox.max.y - pHero->boundingBox.min.y;
						if (checkEnemyTopSideCollision < 0.3f)
						{
							continue;
						}
						else
						{
							if (HeroLives > 0)
							{
								playerLose = true;

								--HeroLives;

								UIRedDecreaseLife.UIFlash = true;	//Activate the Red flash whenever life is decreased
								UIRedDecreaseLife.UIFlashTimerRed = UIRedDecreaseLife.getUIFlashTimer();
								UIFlashRedDecreaseLife();			//UI will flash RED to indicate that Player has lose a life

								updateLives = true;
								if (HeroLives > 0)
								{
									pHero->velCurr.x = 0;
									pHero->velCurr.y = 0;
									pHero->posCurr.x = static_cast<float>(Hero_Initial_X);
									pHero->posCurr.y = static_cast<float>(Hero_Initial_Y);
								}
							}
							if (HeroLives <= 0)
							{
								displayDeath = true;
								playerGameOver = true;
								levelProgressReset();
							}
						}
					}
					//Check when Player is falling
					else if (!GetCellValue(static_cast<int>(pHero->posCurr.x - 0.5), static_cast<int>(pHero->posCurr.y - 1)) || !GetCellValue(static_cast<int>(pHero->posCurr.x + 0.5), static_cast<int>(pHero->posCurr.y - 1)))
					{
						if (HeroLives > 0)
						{
							playerLose = true;

							--HeroLives;

							UIRedDecreaseLife.UIFlash = true;	//Activate the Red flash whenever life is decreased
							UIRedDecreaseLife.UIFlashTimerRed = UIRedDecreaseLife.getUIFlashTimer();
							UIFlashRedDecreaseLife();			//UI will flash RED to indicate that Player has lose a life

							updateLives = true;
							if (HeroLives > 0)
							{
								pHero->velCurr.x = 0;
								pHero->velCurr.y = 0;
								pHero->posCurr.x = static_cast<float>(Hero_Initial_X);
								pHero->posCurr.y = static_cast<float>(Hero_Initial_Y);
							}
						}
						if (HeroLives <= 0)
						{
							displayDeath = true;
							playerGameOver = true;
							levelProgressReset();
						}
					}
				}
			}
			else if (pInst->pObject->type == TYPE_OBJECT_POWERUP_GREEN) // Collision with GREEN Powerup
			{
				if (CollisionIntersection_RectRect(pInst->boundingBox, pInst->velCurr,
					pHero->boundingBox, pHero->velCurr) == true)
				{
					gameObjInstDestroy(pInst);
					std::cout << "You have collected the GREEN power" << std::endl;

					increaseLife = true;
					UIGreen.UIFlash = true;

					++HeroLives;
				}
			}
			else if (pInst->pObject->type == TYPE_OBJECT_POWERUP_BLUE) // Collision with BLUE Powerup
			{
				if (CollisionIntersection_RectRect(pInst->boundingBox, pInst->velCurr,
					pHero->boundingBox, pHero->velCurr) == true)
				{
					gameObjInstDestroy(pInst);
					std::cout << "You have collected the BLUE power" << std::endl;

					powerUpCanCollision = true;
					UIBlue.UIFlash = true;
					BluePowerUpCounter();
				}
			}
			else if (pInst->pObject->type == TYPE_OBJECT_MUSHROOM) // Collision with Mushroom
			{
				if (CollisionIntersection_RectRect(pInst->boundingBox, pInst->velCurr,
					pHero->boundingBox, pHero->velCurr))
				{
					f32 collisionHeightDifference = pInst->boundingBox.max.y - pHero->boundingBox.min.y;

					if (pHero->velCurr.x < 0) //Character moving to the LEFT
					{
						if (pHero->boundingBox.min.x < pInst->boundingBox.max.x)
						{
							pInst->velCurr.x = -MOVE_VELOCITY_HERO;
						}
					}

					else if (pHero->velCurr.x > 0) //Character moving to the RIGHT
					{
						if (pHero->boundingBox.max.x > pInst->boundingBox.min.x)
						{
							pInst->velCurr.x = MOVE_VELOCITY_HERO;
						}
					}

					if (collisionHeightDifference < 0.2f) //If Charcter is on top of spawned mushroom
					{
						f32 collisionLeftWidthDifference = pHero->boundingBox.max.x - pInst->boundingBox.min.x;
						f32 collisionRightWidthDifference = pInst->boundingBox.min.x - pHero->boundingBox.max.x;

						//Checking if Character's bottom is touching the tip of the mushroom
						if (collisionLeftWidthDifference > 0.0f && collisionLeftWidthDifference < 1.7f || collisionRightWidthDifference > 0.0f && collisionRightWidthDifference < 1.7f)
						{
							sMushroomCollisionJump = true;
							pHero->velCurr.y = 15;	//Character will bounce off spawned mushroom
							pInst->velCurr.x = 0;
						}
						else
						{
							continue;
						}
					}
				}
				else //Not Colliding
				{
					pInst->velCurr.x = 0;
					pInst->velCurr.y = 0;
				}
			}
		}

		//Blue Power Up countdown timer
		if (Blue.activation)
		{
			BluePowerUpCountDown(Blue.durationCounter);
			if (Blue.durationCounter <= 0.0f)
			{
				BluePowerUpDeactivation();
			}
		}

		//Green UI countdown timer
		if (UIGreen.UIFlash)
		{
			UIGreen.UIFlashTimerGreen -= g_dt;
			if (UIGreen.UIFlashTimerGreen <= 0.0f)
			{
				//Resets the Green flashing UI when timer runs out
				UIGreen.UIFlash = false;
				UIGreen.greenColor = 0.0f;
				UIGreen.UIFlashTimerGreen = 2.0f;
			}
		}

		//Blue UI countdown timer
		if (UIBlue.UIFlash)
		{
			UIBlue.UIFlashTimerBlue -= g_dt;
			if (UIBlue.UIFlashTimerBlue <= 0.0f)
			{
				//Resets the Blue flashing UI when timer runs out
				UIBlue.UIFlash = false;
				UIBlue.blueColor = 0.0f;
				UIBlue.UIFlashTimerBlue = 2.0f;
			}
		}

		//Red(Life) UI countdown timer
		if (UIRedDecreaseLife.UIFlash)
		{
			UIRedDecreaseLife.UIFlashTimerRed -= g_dt;
			if (UIRedDecreaseLife.UIFlashTimerRed <= 0.0f)
			{
				//Resets the Blue flashing UI when timer runs out
				UIRedDecreaseLife.UIFlash = false;
				UIRedDecreaseLife.redColor = 0.0f;
				UIRedDecreaseLife.UIFlashTimerRed = 2.0f;
			}
		}

		//Red(Blue Powerup) UI countdown timer
		if (UIRedDecreaseBluepowerup.UIFlash)
		{
			UIRedDecreaseBluepowerup.UIFlashTimerRed -= g_dt;
			if (UIRedDecreaseBluepowerup.UIFlashTimerRed <= 0.0f)
			{
				//Resets the Blue flashing UI when timer runs out
				UIRedDecreaseBluepowerup.UIFlash = false;
				UIRedDecreaseBluepowerup.redColor = 0.0f;
				UIRedDecreaseBluepowerup.UIFlashTimerRed = 2.0f;
			}
		}

		//Computing the transformation matrices of the game object instances
		for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
		{
			AEMtx33 scale, rot, trans;
			pInst = sGameObjInstList + i;

			// skip non-active object
			if (0 == (pInst->flag & FLAG_ACTIVE))
				continue;

			if (pInst->pObject->type == TYPE_OBJECT_HERO && HeroLives <= 0)
			{
				AEMtx33Scale(&scale, pInst->scale - (TIMER / 4), pInst->scale - (TIMER / 4));
				AEMtx33Rot(&rot, pInst->dirCurr - TIMER);
				AEMtx33Trans(&trans, pInst->posCurr.x, pInst->posCurr.y - (TIMER / 4));
			}
			else
			{
				AEMtx33Scale(&scale, pInst->scale, pInst->scale);
				AEMtx33Rot(&rot, pInst->dirCurr);
				AEMtx33Trans(&trans, pInst->posCurr.x, pInst->posCurr.y);
			}
			AEMtx33Concat(&pInst->transform, &rot, &scale);
			AEMtx33Concat(&pInst->transform, &trans, &pInst->transform);
		}

		for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
		{
			pInst = sGameObjInstList + i;

			// skip non-active object
			if (0 == (pInst->flag & FLAG_ACTIVE))
				continue;

		}

		ParticleUpdate(myParticle1);

		//Lerp Camera Code 
		lerpHeroPos.x = pHero->posCurr.x;
		lerpHeroPos.y = pHero->posCurr.y;
		AEVec2Lerp(&oldHeroPos, &oldHeroPos, &lerpHeroPos, 0.06f);
		AEVec2Set(&camPos, oldHeroPos.x, oldHeroPos.y);

		AEMtx33MultVec(&camPos, &MapTransform, &camPos);
		AEGfxSetCamPosition(camPos.x, camPos.y);
	}
}

/******************************************************************************/
/*!
	Draw function for level 1
*/
/******************************************************************************/
void Level1_Draw(void)
{
	if (pauseGame)
	{
		pauseMenu_Draw();
	}

	if (!pauseGame)
	{
		//Drawing the tile map (the grid)
		int i, j;
		AEMtx33 cellTranslation, cellFinalTransformation;

		AEGfxSetBackgroundColor(0.6f, 0.3f, 0.1f);

		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_COLOR);
		AEGfxTextureSet(nullptr, 0, 0);

		graphic_Draw();

		for (i = 0; i < BINARY_MAP_WIDTH; ++i)
		{
			for (j = 0; j < BINARY_MAP_HEIGHT; ++j)
			{
				float xPos = i + 0.5f;
				float yPos = j + 0.5f;

				AEMtx33Trans(&cellTranslation, xPos, yPos);

				AEMtx33Concat(&cellFinalTransformation, &MapTransform, &cellTranslation);

				AEGfxSetTransform(cellFinalTransformation.m);

				if (GetCellValue(i, j) == TYPE_OBJECT_COLLISION)
				{
					AEGfxTextureSet(pWhiteInstance->pObject->pTex, 0.6f, 0.0f);
					AEGfxSetTintColor(1.f, 1.f, 1.0f, 1.0f);
					AEGfxSetTransparency(1.0f);
					AEGfxMeshDraw(pWhiteInstance->pObject->pMesh, AE_GFX_MDM_TRIANGLES);
				}
			}
		}

		char strBuffer[100];

		if (updateScore) // Update Score
		{
			memset(strBuffer, 0, 100 * sizeof(char));
			sprintf_s(strBuffer, "Total Coins Collected:  %i / %i", TotalCoins, coinCounter);
			printf("%s \n", strBuffer);

			updateScore = false;
		}

		if (updateLives) // Update Lives
		{
			memset(strBuffer, 0, 100 * sizeof(char));
			sprintf_s(strBuffer, "Lives Remaining:  %i", HeroLives);
			printf("%s \n", strBuffer);

			updateLives = false;
		}

		if (displayDeath)
		{
			if (TIMER >= 3.f)
			{
				TIMER = TIME;
				displayDeath = false;
				next = GS_RESTART;
			}
			else
			{
				sprintf_s(strBuffer, "You died! Try again!");
				AEGfxPrint(Font, strBuffer, -0.35f, 0.7f, 0.6f, 1.f, 1.f, 1.f);
				TIMER += g_dt;
			}
		}

		Map_Draw();
		ParticleDraw(myParticle1);

		//Banner
		AEGfxSetBlendMode(AE_GFX_BM_ADD);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(200.f, 22.f);
		AEGfxTextureSet(mmTex2, 0.f, 0.f);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 0.2f);
		AEGfxSetTransparency(1.0f);
		AEGfxMeshDraw(mmMesh2, AE_GFX_MDM_TRIANGLES);

		//Instruction
		AEGfxSetBlendMode(AE_GFX_BM_ADD);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(200.f, 30.f);
		AEGfxTextureSet(mmTex, 0.f, 0.f);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
		AEGfxSetTransparency(1.0f);
		AEGfxMeshDraw(mmMesh, AE_GFX_MDM_TRIANGLES);
	}
}

/******************************************************************************/
/*!
	Free function of level 1
*/
/******************************************************************************/
void Level1_Free(void)
{
	if (!pauseGame || (pauseGame && quitGame == YES))
	{
		graphic_Free();
	}
}

/******************************************************************************/
/*!
	Unload function of level 1
*/
/******************************************************************************/
void Level1_Unload(void)
{
	if (!pauseGame || (pauseGame && quitGame == YES) || (AESysDoesWindowExist() == false))
	{
		ParticleUnload();

		graphic_Unload();

		/*********
		Free the map data
		*********/
		free(sGameObjInstList);
		free(sGameObjList);

		AEGfxMeshFree(mmMesh);
		AEGfxTextureUnload(mmTex);
		AEGfxMeshFree(mmMesh2);
		AEGfxTextureUnload(mmTex2);

		Map_Free();
		level1BG_Unload();
	}
}
