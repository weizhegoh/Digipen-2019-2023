/**********************************************************************************
* \File name	 Object.h
* \Project name  Jump!Shroom!

* \Author(s)	  Yan Han, Dong 79 lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#pragma once

enum TYPE_OBJECT
{
	TYPE_OBJECT_EMPTY,				//0
	TYPE_OBJECT_COLLISION,			//1
	TYPE_OBJECT_HERO,				//2
	TYPE_OBJECT_ENEMY1,				//3
	TYPE_OBJECT_COIN,				//4
	TYPE_OBJECT_POWERUP_GREEN,		//5
	TYPE_OBJECT_POWERUP_BLUE,		//6
	TYPE_OBJECT_LEVEL1,				//7
	TYPE_OBJECT_LEVEL2,				//8
	TYPE_OBJECT_LEVEL3,				//9
	TYPE_OBJECT_MUSHROOM,			//10
	TYPE_OBJECT_LEVEL1_BG,			//11
	TYPE_OBJECT_LEVEL2_BG,			//12
	TYPE_OBJECT_LEVEL3_BG			//13
};
enum class STATE
{
	STATE_NONE,
	STATE_GOING_LEFT,
	STATE_GOING_RIGHT
};

//State machine inner states
enum class INNER_STATE
{
	INNER_STATE_ON_ENTER,
	INNER_STATE_ON_UPDATE,
	INNER_STATE_ON_PAUSE,
	INNER_STATE_ON_EXIT
};

enum animationName
{
	JUMP = 0,
	COUNT,
	DEFAULT							//static image
};

struct GameObj
{
	unsigned int	 type;			// object type
	AEGfxVertexList	* pMesh;		// pbject
	AEGfxTexture	* pTex;
};

struct GameObjInst
{
	GameObj			* pObject;		// pointer to the 'original'
	unsigned int	flag;			// bit flag or-ed together
	float			scale;
	AEVec2			posCurr;		// object current position
	AEVec2			velCurr;		// object current velocity
	float			dirCurr;		// object current direction

	AEMtx33			transform;		// object drawing matrix

	AABB			boundingBox;	// object bouding box that encapsulates the object

	//Used to hold the current 
	int				gridCollisionFlag;

	// pointer to custom data specific for each object type
	void* pUserData;

	//State of the object instance
	enum			STATE state;
	enum			INNER_STATE innerState;

	//animationName	name;
	//General purpose counter (This variable will be used for the enemy state machine)
	double			counter;
	int				scaleCounter;

	bool			directioncheck; // Facing Left = 0, Facing Right = 1;
};

extern GameObjInst  * sGameObjInstList;
extern GameObjInst	* pHero;
extern unsigned int	sGameObjInstNum;

extern GameObj		* sGameObjList;
extern GameObj		* pObj;

extern AEMtx33		MapTransform;
extern unsigned int sGameObjNum;

extern GameObjInst	* pBlackInstance;
extern GameObjInst	* pWhiteInstance;


extern const unsigned int	GAME_OBJ_NUM_MAX;
extern const unsigned int	GAME_OBJ_INST_NUM_MAX;

extern const unsigned int	FLAG_ACTIVE;
extern const unsigned int	FLAG_VISIBLE;
extern const unsigned int	FLAG_NON_COLLIDABLE;

GameObjInst* gameObjInstCreate(unsigned int type, float scale,
								AEVec2* pPos, AEVec2* pVel,
								float dir, enum STATE startState);
void		 gameObjInstDestroy(GameObjInst* pInst);


