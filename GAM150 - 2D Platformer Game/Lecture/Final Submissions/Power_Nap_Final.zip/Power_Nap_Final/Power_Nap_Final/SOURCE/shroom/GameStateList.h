/**********************************************************************************
* \File name	 GameStateList.h
* \Project name  Jump!Shroom!

* \Author(s)	 Yan Han, Dong	14 lines x 71.5% Code Contribution
				 Hong Fu, Wong  14 lines x 21.5% Code Contribution
				 Wei Zhe, Goh	14 lines x 7% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#pragma once

// list of game state
enum GS_STATES
{
	GS_Splash = 0,
	GS_MainMenu,
	GS_LevelSelect,
	GS_LEVEL1,
	GS_LEVEL2,
	GS_LEVEL3,
	GS_Win,
	GS_CUTSCENE,

	GS_QUIT,
	GS_RESTART
};
