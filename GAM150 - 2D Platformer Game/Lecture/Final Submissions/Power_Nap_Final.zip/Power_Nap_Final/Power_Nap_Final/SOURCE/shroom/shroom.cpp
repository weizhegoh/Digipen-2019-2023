/**********************************************************************************
* \File name     Shroom.cpp
* \Project name  Jump!Shroom!

* \Author(s)	 Yan Han, Dong     65 Lines x 81.5% Code Contribution
                 Hong Fu, Wong     65 Lines x 10.75% Code Contribution
                 Wei Zhe, Goh      65 Lines x 7.75% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#include "shroom.h"

#define _CRTDBG_MAP_ALLOC
#define MAX_LOADSTRING 100

s8      Font = 0;
float	g_dt;
double	g_appTime;
bool    fullscreen = true; // global

#pragma warning( push )
#pragma warning( disable :28251 )
int WINAPI WinMain(HINSTANCE instanceH, HINSTANCE prevInstanceH, LPSTR command_line, int show)
{
    
#if defined(DEBUG) | defined(_DEBUG)
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif
    UNREFERENCED_PARAMETER(prevInstanceH);
    UNREFERENCED_PARAMETER(command_line);

    AESysInit(instanceH, show, 800, 600, 0, 60, false, NULL);
    SetWindowPos(AESysGetWindowHandle(), HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_DRAWFRAME | SWP_NOSIZE);

    //add custom icon
    HICON hWindowIcon = 0;
    hWindowIcon = LoadIcon(instanceH, MAKEINTRESOURCEA(IDI_ICON1));
    SendMessage(AESysGetWindowHandle(), WM_SETICON, ICON_SMALL, (LPARAM)hWindowIcon);

    Font = AEGfxCreateFont("assert\\text_files\\BubblegumSans-Regular.ttf", 60); // Create Font

    AESysSetWindowTitle("Jump! Shroom!");

    AEToogleFullScreen(fullscreen); // after AESysInit(instanceH, show, 800, 600, 1, 60, false, NULL);

    GSM_Initialize(GS_Splash);
    AudioEngine_Load();

    while (current != GS_QUIT)
    {
      AESysReset();

        if (current != GS_RESTART)
        {
            GSM_Update();
            fpLoad();
        }
        else
        {
            current = previous;
            next = previous;
        }

        fpInitialize();

        while (current == next)
        {
          AESysFrameStart();
          AEInputUpdate();
          fpUpdate();
          AudioEngine_Update();
          fpDraw();
          AESysFrameEnd();
          // check if forcing the application to quit
          if ((AESysDoesWindowExist() == false))
            next = GS_QUIT;

          g_dt = (f32)AEFrameRateControllerGetFrameTime();
          g_appTime += g_dt;
        }

        fpFree();

        if (next != GS_RESTART)
        {
          fpUnload();
        }

        previous = current;
        current = next;
    }
    AudioEngine_Unload();
    AEGfxDestroyFont(Font);
    AESysExit();
    //System exit (terminate)
    //_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
}
