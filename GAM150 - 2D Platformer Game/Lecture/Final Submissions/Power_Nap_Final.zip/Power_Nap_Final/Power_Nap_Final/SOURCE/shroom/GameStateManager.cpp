/**********************************************************************************
* \File name	 GameStateManager.cpp
* \Project name  Jump!Shroom!

* \Author(s)	 Yan Han, Dong		83 Lines x 51% Code Contribution
				 Hong Fu, Wong		83 Lines x 29% Code Contribution
				 Benjamin Liew		83 Lines x 9.75% Code Contribution
				 Wei Zhe , Goh      83 Lines x 9.75% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#include "shroom.h"

// game state 
int current = 0, previous = 0, next = 0; 

// function pointer
FP fpLoad = nullptr, fpInitialize = nullptr, fpUpdate = nullptr, fpDraw = nullptr, fpFree = nullptr, fpUnload = nullptr; 

// inits game state manager 
void GSM_Initialize(int startingState)
{
	current = previous = next = startingState;
}

// updates game state manger
void GSM_Update() 
{

	switch (current)
	{
	case GS_Splash:
		fpLoad = Splash_Load;
		fpInitialize = Splash_Init;
		fpUpdate = Splash_Update;
		fpDraw = Splash_Draw;
		fpFree = Splash_Free;
		fpUnload = Splash_Unload;
		break;
	case GS_MainMenu:
		fpLoad = MainMenu_Load;
		fpInitialize = MainMenu_Init;
		fpUpdate = MainMenu_Update;
		fpDraw = MainMenu_Draw;
		fpFree = MainMenu_Free;
		fpUnload = MainMenu_Unload;
		break;
	case GS_LevelSelect:
		fpLoad = LevelSelect_Load;
		fpInitialize = LevelSelect_Init;
		fpUpdate = LevelSelect_Update;
		fpDraw = LevelSelect_Draw;
		fpFree = LevelSelect_Free;
		fpUnload = LevelSelect_Unload;
		break;
	case GS_CUTSCENE:
		fpLoad = CutScene_Load;
		fpInitialize = CutScene_Init;
		fpUpdate = CutScene_Update;
		fpDraw = CutScene_Draw;
		fpFree = CutScene_Free;
		fpUnload = CutScene_Unload;
		break;
	case GS_LEVEL1: 
		fpLoad = Level1_Load;
		fpInitialize = Level1_Initialize;
		fpUpdate = Level1_Update;
		fpDraw = Level1_Draw;
		fpFree = Level1_Free;
		fpUnload = Level1_Unload;
		break;
	case GS_LEVEL2: 
		fpLoad = Level2_Load;
		fpInitialize = Level2_Initialize;
		fpUpdate = Leve12_Update;
		fpDraw = Leve12_Draw;
		fpFree = Leve12_Free;
		fpUnload = Leve12_Unload;
		break;
	case GS_LEVEL3:
		fpLoad = Level3_Load;
		fpInitialize = Level3_Initialize;
		fpUpdate = Leve13_Update;
		fpDraw = Leve13_Draw;
		fpFree = Leve13_Free;
		fpUnload = Leve13_Unload;
		break;
	case GS_Win:
		fpLoad = Win_Load;
		fpInitialize = Win_Init;
		fpUpdate = Win_Update;
		fpDraw = Win_Draw;
		fpFree = Win_Free;
		fpUnload = Win_Unload;
		break;
	case GS_RESTART:
		break;
	case GS_QUIT:
		break;
	default:
		break;
	}
}
