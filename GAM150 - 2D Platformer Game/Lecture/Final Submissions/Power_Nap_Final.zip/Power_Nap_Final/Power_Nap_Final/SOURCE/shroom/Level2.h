/**********************************************************************************
* \File name     Level2.h
* \Project name  Jump!Shroom!

* \Author(s)	 Benjamin Liew	7 Lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#pragma once

void Level2_Load();					// Loads level 2
void Level2_Initialize();			// Inits level 2
void Leve12_Update();				// Update level 2 
void Leve12_Draw();					// Draws level 2 
void Leve12_Free();					// Free level 2
void Leve12_Unload();				// Unloads level 2

