/**********************************************************************************
* \File name     Splash.h
* \Project name  Jump!Shroom!

* \Author(s)     Hong Fu, Wong   7 lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#pragma once

void Splash_Load();
void Splash_Init();
void Splash_Update();
void Splash_Draw();
void Splash_Free();
void Splash_Unload();