/**********************************************************************************
* \File name		PowerUp.cpp
* \Project name		Jump!Shroom!

* \Author(s)		Benjamin Liew       39 lines x 100% Code Contribution

* \Copyright information
All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#include "PowerUp.h"

PowerUp Blue;
PowerUp Green;

/******************************************************************************/
/*!
	This function is called when you use blue power up
*/
/******************************************************************************/
void BluePowerUpActivation()
{
	if (Blue.powerupCounter)
	{
		--Blue.powerupCounter;
		Blue.activation = true;
		Blue.durationCounter = Blue.getPowerUpDuration();
		freezeAndInvicible = true;
	}
	else
	{
		throw "There is no Blue Power Up to use";
	}
}

/******************************************************************************/
/*!
	This function is called when the blue power up duration is over
*/
/******************************************************************************/
void BluePowerUpDeactivation()
{
	Blue.activation = false;
	Blue.freeze = false;
	Blue.invincibility = false;
}

/******************************************************************************/
/*!
	This function is the timer for the blue power up
*/
/******************************************************************************/
void BluePowerUpCountDown(float& durationCounter)
{
	if (durationCounter > 0.0f)
	{
		durationCounter -= g_dt;
	}
}

/******************************************************************************/
/*!
	This function adds the amount of blue powerup the player has, call when
	picking up powerup
*/
/******************************************************************************/
void BluePowerUpCounter()
{
	++Blue.powerupCounter;
}

/******************************************************************************/
/*!
	This function resets the life and blue powerup to their default value
*/
/******************************************************************************/
void levelProgressReset()
{
	Green.levelProgress = 0;
	Blue.levelProgress = 0;
}