/**********************************************************************************
* \File name     CutSene.cpp
* \Project name  Jump!Shroom!

* \Author(s)     Dong Yanhan       811 Lines x 93.75% Code Contribution
				 Wei Zhe, Goh	   811 Lines x 6.25% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#include "shroom.h"
#include <iostream>

/******************************************************************************/
/*!
	File globals
*/
/******************************************************************************/

extern GameObjInst* pBlackInstance;
extern GameObjInst* pWhiteInstance;

// Font
extern s8 Font;

//AE
static AEGfxVertexList		*mmMesh, *mmMesh2, *mmMesh3, *mmMesh4, *mmMesh5, *mmMesh6;
static AEGfxTexture			*mmTex, *mmTex3, *mmTex4, *mmTex5, *mmTex6, *mmTex7, *mmTex8, *mmTex9,
							*mmTex10, *mmTex11, *mmTex12, *mmTex13;
static AEMtx33				mmTransform;

//local variable
int					     	dialogue = 0;
const float					CTimer = 0.5f;
float						cTIMER = CTimer;
float						ctimer = CTimer;
bool						bigArrowRight = false;
bool						bigArrowLeft = false;

/******************************************************************************/
/*!
	"Load" function of state cut scene
*/
/******************************************************************************/
void CutScene_Load()
{
	if (pauseGame)
	{
		pauseMenu_Load();
	}
	if (!pauseGame)
	{
		sGameObjList = (GameObj*)calloc(GAME_OBJ_NUM_MAX, sizeof(GameObj));
		sGameObjInstList = (GameObjInst*)calloc(GAME_OBJ_INST_NUM_MAX, sizeof(GameObjInst));
		sGameObjNum = 0;

		if (!sGameObjList || !sGameObjInstList)
		{
			return;
		}
		blackObject_Load();					//Load black object
		whiteObject_Load();					//Load white object

		characterTexture_Load();			//Load character texture
		enemyTexture_Load();				//Load basic enemy texture
		coinTexture_Load();					//Load coin texture
		greenPowerUpTexture_Load();			//Load green power up texture
		bluePowerUpTexture_Load();			//Load blue power up texture 

		level1Object_Load();
		level2Object_Load();
		level3Object_Load();

		spawnMushroomTexture_Load();		//Load spawned mushroom texture
		level1Background_Load();

		cutSceneBG_Load();

		AEGfxSetCamPosition(0, 0);

		AEGfxMeshStart();
		AEGfxTriAdd(
			-95.5f, -95.5f, 0xFFFFFFFF, 0.0f, 0.5f,
			95.5f, -95.5f, 0xFFFFFFFF, 0.2f, 0.5f,
			-95.5f, 95.5f, 0xFFFFFFFF, 0.0f, 0.0f);

		AEGfxTriAdd(
			95.5f, -95.5f, 0xFFFFFFFF, 0.20f, 0.5f,
			95.5f, 95.5f, 0xFFFFFFFF, 0.20f, 0.0f,
			-95.5f, 95.5f, 0xFFFFFFFF, 0.0f, 0.0f);

		mmMesh = AEGfxMeshEnd();
		AE_ASSERT_MESG(mmMesh, "fail to create Hero object!!");
		mmTex = AEGfxTextureLoad("assert\\art\\Shroom.png");
		AE_ASSERT_MESG(mmTex, "fail to create Hero texture!!");

		AEGfxMeshStart();
		AEGfxTriAdd(
			-20.5f, -20.5f, 0xFFFFFFFF, 0.0f, 1.0f,
			20.5f, -20.5f, 0xFFFFFFFF, 1.0f, 1.0f,
			-20.5f, 20.5f, 0xFFFFFFFF, 0.0f, 0.0f);

		AEGfxTriAdd(
			20.5f, -20.5f, 0xFFFFFFFF, 1.0f, 1.0f,
			20.5f, 20.5f, 0xFFFFFFFF, 1.0f, 0.0f,
			-20.5f, 20.5f, 0xFFFFFFFF, 0.0f, 0.0f);
		mmMesh2 = AEGfxMeshEnd();
		AE_ASSERT_MESG(mmMesh2, "fail to create instruction object!!");
		mmTex3 = AEGfxTextureLoad("assert\\art\\DialoguePointer.png");
		AE_ASSERT_MESG(mmTex3, "fail to create Hero texture!!");
		mmTex4 = AEGfxTextureLoad("assert\\art\\DialoguePointerRight.png");
		AE_ASSERT_MESG(mmTex4, "fail to create Hero texture!!");
		mmTex6 = AEGfxTextureLoad("assert\\art\\ArrowRight.png");
		AE_ASSERT_MESG(mmTex6, "fail to create arrow right texture!!");
		mmTex7 = AEGfxTextureLoad("assert\\art\\ArrowLeft.png");
		AE_ASSERT_MESG(mmTex7, "fail to create Arrow Left texture!!");

		AEGfxMeshStart();
		AEGfxTriAdd(
			-400.0f, -300.0f, 0xFFFFFFFF, 0.0f, 1.f,
			400.0f, -300.0f, 0xFFFFFFFF, 1.0f, 1.f,
			-400.0f, 300.0f, 0xFFFFFFFF, 0.0f, 0.0f);

		AEGfxTriAdd(
			400.0f, -300.0f, 0xFFFFFFFF, 1.0f, 1.f,
			400.0f, 300.0f, 0xFFFFFFFF, 1.0f, 0.0f,
			-400.0f, 300.0f, 0xFFFFFFFF, 0.0f, 0.0f);
		mmMesh3 = AEGfxMeshEnd();
		AE_ASSERT_MESG(mmMesh3, "fail to create object!!");
		mmTex5 = AEGfxTextureLoad("assert\\art\\CutSceneBackground.png");
		AE_ASSERT_MESG(mmTex5, "Failed to create Cut scene background texture!!");
		mmTex12 = AEGfxTextureLoad("assert\\art\\WhiteBackground.png");
		AE_ASSERT_MESG(mmTex12, "Failed to create Cut scene white background texture!!");
		mmTex13 = AEGfxTextureLoad("assert\\art\\PartyBackground.png");
		AE_ASSERT_MESG(mmTex13, "Failed to create Cut scene white background texture!!");

		AEGfxMeshStart();
		AEGfxTriAdd(
			-30.5f, -30.5f, 0xFFFFFFFF, 0.0f, 1.0f,
			30.5f, -30.5f, 0xFFFFFFFF, 1.0f, 1.0f,
			-30.5f, 30.5f, 0xFFFFFFFF, 0.0f, 0.0f);

		AEGfxTriAdd(
			30.5f, -30.5f, 0xFFFFFFFF, 1.0f, 1.0f,
			30.5f, 30.5f, 0xFFFFFFFF, 1.0f, 0.0f,
			-30.5f, 30.5f, 0xFFFFFFFF, 0.0f, 0.0f);
		mmMesh4 = AEGfxMeshEnd();
		AE_ASSERT_MESG(mmMesh4, "fail to create Arrow right object!!");
		mmTex8 = AEGfxTextureLoad("assert\\art\\ArrowRight.png");
		AE_ASSERT_MESG(mmTex8, "fail to create arrow right texture!!");
		mmTex9 = AEGfxTextureLoad("assert\\art\\ArrowLeft.png");
		AE_ASSERT_MESG(mmTex9, "fail to create Arrow Left texture!!");

		AEGfxMeshStart();
		AEGfxTriAdd(
			-30.5f, -30.5f, 0xFFFFFFFF, 0.0f, 0.5f,
			30.5f, -30.5f, 0xFFFFFFFF, 0.2f, 0.5f,
			-30.5f, 30.5f, 0xFFFFFFFF, 0.0f, 0.0f);

		AEGfxTriAdd(
			30.5f, -30.5f, 0xFFFFFFFF, 0.2f, 0.5f,
			30.5f, 30.5f, 0xFFFFFFFF, 0.2f, 0.0f,
			-30.5f, 30.5f, 0xFFFFFFFF, 0.0f, 0.0f);
		mmMesh5 = AEGfxMeshEnd();
		AE_ASSERT_MESG(mmMesh5, "fail to create Arrow left object!!");
		mmTex10 = AEGfxTextureLoad("assert\\art\\Shroom.png");
		AE_ASSERT_MESG(mmTex10, "fail to create Arrow Left texture!!");

		AEGfxMeshStart();
		AEGfxTriAdd(
			-30.5f, -30.5f, 0xFFFFFFFF, 0.0f, 1.0f,
			30.5f, -30.5f, 0xFFFFFFFF, 1.0f, 1.0f,
			-30.5f, 30.5f, 0xFFFFFFFF, 0.0f, 0.0f);

		AEGfxTriAdd(
			30.5f, -30.5f, 0xFFFFFFFF, 1.0f, 1.0f,
			30.5f, 30.5f, 0xFFFFFFFF, 1.0f, 0.0f,
			-30.5f, 30.5f, 0xFFFFFFFF, 0.0f, 0.0f);
		mmMesh6 = AEGfxMeshEnd();
		AE_ASSERT_MESG(mmMesh6, "fail to create Arrow left object!!");
		mmTex11 = AEGfxTextureLoad("assert\\art\\Keys.png");
		AE_ASSERT_MESG(mmTex11, "fail to create Arrow Left texture!!");
		MapData = 0;
		BinaryCollisionArray = 0;
		BINARY_MAP_WIDTH = 0;
		BINARY_MAP_HEIGHT = 0;

		//Importing Data
		if (!ImportMapDataFromFile("assert\\text_files\\CutScene.txt"))
			next = GS_QUIT;
		AEMtx33 scale, trans;

		float x = static_cast<float>(BINARY_MAP_WIDTH) / 2;
		float y = static_cast<float>(BINARY_MAP_HEIGHT) / 2;

		AEMtx33Trans(&trans, -x, -y);
		AEMtx33Scale(&scale, static_cast<float>(AEGetWindowWidth() / BINARY_MAP_WIDTH), static_cast<float>(AEGetWindowHeight() / BINARY_MAP_HEIGHT));
		AEMtx33Concat(&MapTransform, &scale, &trans);
	}
}

/******************************************************************************/
/*!
	"Initialize" function of state cut scene
*/
/******************************************************************************/
void CutScene_Init()
{
	pauseMenu_Init();

	SetWindowPos(AESysGetWindowHandle(), HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_DRAWFRAME | SWP_NOSIZE);

	AudioEngine_Initialize();

	pHero = 0;
	pBlackInstance = 0;
	pWhiteInstance = 0;
	TotalCoins = 0;
	dialogue = 0;
	cTIMER = CTimer;
	ctimer = CTimer;

	pBlackInstance = gameObjInstCreate(TYPE_OBJECT_EMPTY, 1.0f, 0, 0, 0.0f, STATE::STATE_NONE);
	pBlackInstance->flag ^= FLAG_VISIBLE;
	pBlackInstance->flag |= FLAG_NON_COLLIDABLE;

	pWhiteInstance = gameObjInstCreate(TYPE_OBJECT_COLLISION, 1.0f, 0, 0, 0.0f, STATE::STATE_NONE);
	pWhiteInstance->flag ^= FLAG_VISIBLE;
	pWhiteInstance->flag |= FLAG_NON_COLLIDABLE;
	
}

/******************************************************************************/
/*!
	"Update" function of state cut scene
*/
/******************************************************************************/
void CutScene_Update()
{
	if (GetFocus() == 0)
	{
		pauseGame = true;
	}
	if (AEInputCheckReleased(AEVK_ESCAPE))
	{
		pauseGame = true;
	}
	if (pauseGame)
	{
		pauseMenu_Update();
		AudioEngine_Update();
	}

	if (!pauseGame)
	{
		unsigned int i;
		GameObjInst* pInst;

		if (AEInputCheckTriggered(AEVK_F))					//Press F key to full screen
		{
			if (fullscreen)
				fullscreen = false;
			else
				fullscreen = true;
			AEToogleFullScreen(fullscreen);
		}
		if (AEInputCheckTriggered(AEVK_3))
		{
			coinCounter = 0;
			TotalCoins = 0;
			level = 4; 
		}

		if (AEInputCheckTriggered(AEVK_RETURN))
		{
			switch (level)
			{
			case 1:
				coinCounter = 0;
				TotalCoins = 0;
				next = GS_LEVEL1;
				break;
			case 2:
				coinCounter = 0;
				TotalCoins = 0;
				next = GS_LEVEL2;
				break;
			case 3:
				coinCounter = 0;
				TotalCoins = 0;
				next = GS_LEVEL3;
				break;
			case 4:
				coinCounter = 0;
				TotalCoins = 0;
				next = GS_MainMenu;
				break;
			default:
				level = 0;
				break;
			}
		}

		if (AEInputCheckTriggered(AEVK_RIGHT))
		{
			++dialogue;
			bigArrowRight = true;
			cTIMER = CTimer;
		}

		if (AEInputCheckTriggered(AEVK_LEFT))
		{
			--dialogue;
			if (dialogue < 0)
			{
				dialogue = 0;
			}
			bigArrowLeft = true;
			ctimer = CTimer;
		}

		if (bigArrowLeft)
		{
			if (cTIMER >= 0.0f)
			{
				cTIMER -= g_dt;
				bigArrowLeft = true;
			}
			else
			{
				cTIMER = CTimer;
				bigArrowLeft = false;
			}
		}

		if (bigArrowRight)
		{
			if (ctimer >= 0.0f)
			{
				ctimer -= g_dt;
				bigArrowRight = true;;
			}
			else
			{
				ctimer = CTimer;
				bigArrowRight = false;
			}
		}

		if (AEInputCheckReleased(AEVK_ESCAPE))
		{
			changeGameState = true;
			next = GS_MainMenu;
		}
		if ((dialogue > 6 && level == 1) ||
			(dialogue > 3 && level == 2) ||
			(dialogue > 4 && level == 3) ||
			(dialogue > 2 && level == 4))
		{
			switch (level)
			{
			case 1:
				coinCounter = 0;
				TotalCoins = 0;
				next = GS_LEVEL1;
				level = 0;
				break;
			case 2:
				coinCounter = 0;
				TotalCoins = 0;
				next = GS_LEVEL2;
				level = 0;
				break;
			case 3:
				coinCounter = 0;
				TotalCoins = 0;
				next = GS_LEVEL3;
				level = 0;
				break;
			case 4:
				coinCounter = 0;
				TotalCoins = 0;
				next = GS_MainMenu;
				level = 0;
				break;
			default:
				break;
			}
		}

		for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
		{
			AEMtx33 scale, rot, trans;
			pInst = sGameObjInstList + i;

			// skip non-active object
			if (0 == (pInst->flag & FLAG_ACTIVE))
				continue;

			AEMtx33Scale(&scale, pInst->scale, pInst->scale);
			AEMtx33Rot(&rot, pInst->dirCurr);
			AEMtx33Trans(&trans, pInst->posCurr.x, pInst->posCurr.y);

			AEMtx33Concat(&pInst->transform, &rot, &scale);
			AEMtx33Concat(&pInst->transform, &trans, &pInst->transform);

		}
	}
}

/******************************************************************************/
/*!
	"Draw" function of state cut scene
*/
/******************************************************************************/
void CutScene_Draw()
{
	if (pauseGame)
	{
		pauseMenu_Draw();
	}

	if (!pauseGame)
	{
		// graphics
		// shroom
		int i, j;
		float transparency = 1.0f;
		float transparencyMushroom = 1.0f;
		//float transparency = 0.0f;
		AEMtx33 cellTranslation, cellFinalTransformation;

		AEGfxSetBackgroundColor(0.6f, 0.3f, 0.1f);
		AEGfxSetBlendMode(AE_GFX_BM_NONE);
		AEGfxSetRenderMode(AE_GFX_RM_COLOR);
		AEGfxTextureSet(nullptr, 0, 0);

		//bg
		if (level != 4)
		{
			AEGfxSetBlendMode(AE_GFX_BM_BLEND);
			AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
			AEGfxSetPosition(0.0f, 0.0f);
			AEGfxTextureSet(mmTex5, 1, 1);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxSetTransparency(1.0f);
			AEGfxMeshDraw(mmMesh3, AE_GFX_MDM_TRIANGLES);

			AEGfxSetBlendMode(AE_GFX_BM_BLEND);
			AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
			AEGfxSetPosition(0.0f, 0.0f);
			AEGfxTextureSet(mmTex12, 1, 1);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxSetTransparency(0.2f);
			AEGfxMeshDraw(mmMesh3, AE_GFX_MDM_TRIANGLES);
		}
		else
		{
			AEGfxSetBlendMode(AE_GFX_BM_BLEND);
			AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
			AEGfxSetPosition(0.0f, 0.0f);
			AEGfxTextureSet(mmTex13, 1, 1);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxSetTransparency(0.6f);
			AEGfxMeshDraw(mmMesh3, AE_GFX_MDM_TRIANGLES);
		}
		char strBuffer[1024];

		AEGfxSetRenderMode(AE_GFX_RM_COLOR);
		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		for (i = 0; i < BINARY_MAP_WIDTH; ++i)
		{
			for (j = 0; j < BINARY_MAP_HEIGHT; ++j)
			{
				float xPos = i + 0.5f;
				float yPos = j + 0.5f;

				AEMtx33Trans(&cellTranslation, xPos, yPos);

				AEMtx33Concat(&cellFinalTransformation, &MapTransform, &cellTranslation);

				AEGfxSetTransform(cellFinalTransformation.m);

				AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
				if (GetCellValue(i, j) == TYPE_OBJECT_COLLISION)
				{
					AEGfxTextureSet(pWhiteInstance->pObject->pTex, 0.6f, 0.0f);
					AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
					AEGfxSetTransparency(1.0f);
					AEGfxMeshDraw(pWhiteInstance->pObject->pMesh, AE_GFX_MDM_TRIANGLES);
				}
			}
		}

		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(-250.f, -190.f);
		AEGfxTextureSet(mmTex, 0.f, 0.f);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
		AEGfxSetTransparency(1.0f);
		AEGfxMeshDraw(mmMesh, AE_GFX_MDM_TRIANGLES);

		// enemy
		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(250.f, -200.f);
		AEGfxTextureSet(mmTex, 0.f, 0.5f);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
		if ((dialogue > 4 && level == 1) ||
			(dialogue > 0 && level == 2) ||
			(dialogue > 4 && level == 3) ||
			(dialogue > 0 && level == 4))
		{
			transparency = 0.0f;
		}
		AEGfxSetTransparency(transparency);
		AEGfxMeshDraw(mmMesh, AE_GFX_MDM_TRIANGLES);

		sprintf_s(strBuffer, "Press 'RIGHT'and 'LEFT' key to proceed through cut scene. ");
		AEGfxPrint(Font, strBuffer, -0.45f, 0.85f, 0.3f, 1.0f, 1.0f, 1.0f);
		sprintf_s(strBuffer, "Press 'ENTER' to skip the story. ");
		AEGfxPrint(Font, strBuffer, -0.30f, 0.80f, 0.3f, 1.0f, 1.0f, 1.0f);

		// Render the dialogue
		switch (level)
		{
		case 1:
			switch (dialogue)
			{
			case 0:
				sprintf_s(strBuffer, "Brother! There is a party held at");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "the Moonlight Forest tonight~");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Don't tell me...");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 1.0f;
				transparencyMushroom = 1.0f;
				break;
			case 1:
				sprintf_s(strBuffer, "Yep! I am going to");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "the party!");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "You are planning to");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "go to the party!!");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 1.0f;
				transparencyMushroom = 1.0f;
				break;
			case 2:
				sprintf_s(strBuffer, "What are you thinking?!");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.20f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "You got an exam");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "coming up!!");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 1.0f;
				transparencyMushroom = 0.0f;
				break;
			case 3:
				sprintf_s(strBuffer, "No, you're not allowed");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "to go to the party!!");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 1.0f;
				transparencyMushroom = 0.0f;
				break;
			case 4:
				sprintf_s(strBuffer, "No matter what, I must");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "go to the party!!");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Then, I will stop you");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.20f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "from going to");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "the party.");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 1.0f;
				transparencyMushroom = 1.0f;
				break;
			case 5:
				sprintf_s(strBuffer, "Use arrow keys to help me get through the map.");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.40f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Use space key to help me jump.");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.30f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Collect the coins along the way,");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "I need coins for the party!");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);

				//keys
				AEGfxSetBlendMode(AE_GFX_BM_BLEND);
				AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
				AEGfxSetPosition(250.f, 140.f);
				AEGfxTextureSet(mmTex11, 0.f, 0.f);
				AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
				AEGfxSetTransparency(1.0f);
				AEGfxMeshDraw(mmMesh6, AE_GFX_MDM_TRIANGLES);

				//shroom
				AEGfxSetBlendMode(AE_GFX_BM_BLEND);
				AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
				AEGfxSetPosition(90.f, 20.f);
				AEGfxTextureSet(mmTex10, 0.2f, 0.5f);
				AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
				AEGfxSetTransparency(1.0f);
				AEGfxMeshDraw(mmMesh5, AE_GFX_MDM_TRIANGLES);
				transparency = 0.0f;
				transparencyMushroom = 1.0f;
				break;

			case 6:
				sprintf_s(strBuffer, "Oh, another tip from me.");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.30f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Don't forget to collect the blue soda cans too");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.20f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "To use them, press 'S'. ");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Then, I can stop my brother in his path~");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);

				//shroom
				AEGfxSetBlendMode(AE_GFX_BM_BLEND);
				AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
				AEGfxSetPosition(200.f, 50.f);
				AEGfxTextureSet(mmTex10, 0.4f, 0.5f);
				AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
				AEGfxSetTransparency(1.0f);
				AEGfxMeshDraw(mmMesh5, AE_GFX_MDM_TRIANGLES);

				transparency = 0.0f;
				transparencyMushroom = 1.0f;
				break;
			default:
				transparency = 0.0f;
				transparencyMushroom = 0.0f;
				break;
			}
			break;
		case 2:
			switch (dialogue)
			{
			case 0:
				sprintf_s(strBuffer, "Thanks~ We made it pass");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Level 1. ");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Argh, I definitely will");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "make it harder...");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 1.0f;
				transparencyMushroom = 1.0f;
				break;
			case 1:
				sprintf_s(strBuffer, "Tip Time! ");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.30f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Collect the green soda cans!! ");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.20f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "It will increase");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "the numbers of lives I have~ ");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);

				//shroom
				AEGfxSetBlendMode(AE_GFX_BM_BLEND);
				AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
				AEGfxSetPosition(70.f, 40.f);
				AEGfxTextureSet(mmTex10, 0.6f, 0.5f);
				AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
				AEGfxSetTransparency(1.0f);
				AEGfxMeshDraw(mmMesh5, AE_GFX_MDM_TRIANGLES);

				transparency = 0.0f;
				transparencyMushroom = 1.0f;
				break;
			case 2:
				sprintf_s(strBuffer, "If you need extra boost to jump. ");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.40f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Press 'D' for trampoline mushroom platform.");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.30f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "The trampoline is summoned");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.20f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "at the cost of my life. ");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "So, summon them with caution~ ");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);

				//shroom
				AEGfxSetBlendMode(AE_GFX_BM_BLEND);
				AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
				AEGfxSetPosition(80.f, 50.f);
				AEGfxTextureSet(mmTex10, 0.81f, 0.0f);
				AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
				AEGfxSetTransparency(1.0f);
				AEGfxMeshDraw(mmMesh5, AE_GFX_MDM_TRIANGLES);

				transparency = 0.0f;
				transparencyMushroom = 1.0f;
				break;
			case 3:
				sprintf_s(strBuffer, "Be warned this level is");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.30f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "much HARDER than the last level. ");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.20f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Try your best to make it past it~");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Good Luck~~");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 0.0f;
				transparencyMushroom = 1.0f;
				break;
			default:
				transparency = 0.0f;
				transparencyMushroom = 0.0f;
				break;
			}
			break;
		case 3:
			switch (dialogue)
			{
			case 0:
				sprintf_s(strBuffer, "The last stage!!");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Yay!! We can do this~");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Urgh, why are you");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.30f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "so hard to catch?!");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.20f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "No, I mustn't give up!!");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 1.0f;
				transparencyMushroom = 1.0f;
				break;
			case 1:
				sprintf_s(strBuffer, "I must take you home!!");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.20f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "You need to study");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "for your exam!!");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 1.0f;
				transparencyMushroom = 0.0f;
				break;
			case 2:
				sprintf_s(strBuffer, "No, I want to go to the party");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.20f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "I absoutely don't want");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "to study!!");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 0.0f;
				transparencyMushroom = 1.0f;
				break;
			case 3:
				sprintf_s(strBuffer, "We will see how");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.20f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "this goes!!");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "I swear to catch you!!");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 1.0f;
				transparencyMushroom = 0.0f;
				break;
			case 4:
				sprintf_s(strBuffer, "Hmph! Catch me if you can!");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.20f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "I doubt you can catch me!!");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Good luck with that wish~~");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 0.0f;
				transparencyMushroom = 1.0f;
				break;
			default:
				transparency = 0.0f;
				transparencyMushroom = 0.0f;
				break;
			}
			break;
		case 4:
			switch (dialogue)
			{
			case 0:
				sprintf_s(strBuffer, "Yay!! Finally, we finished");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "the challenge!!");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Oh no!! What should I do?");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.30f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Mom, told me to never let");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.20f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "him go to that party!!");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "He needs to buck up ");
				AEGfxPrint(Font, strBuffer, 0.25f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "on his studies!!");
				AEGfxPrint(Font, strBuffer, 0.25f, -0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 1.0f;
				transparencyMushroom = 1.0f;
				break;
			case 1:
				sprintf_s(strBuffer, "Thank you so much for your help!!");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.30f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "I have been looking forward to it");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.20f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "ever since I've know of it.");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "I've had enough of studying");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "for exams. ");
				AEGfxPrint(Font, strBuffer, -0.80f, -0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 0.0f;
				transparencyMushroom = 1.0f;
				break;
			case 2:
				sprintf_s(strBuffer, "I don't get why must I");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.30f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "study for such an unimportant thing");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.20f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "When I could be having fun. ");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.10f, 0.5f, 1.0f, 1.0f, 1.0f);
				sprintf_s(strBuffer, "Thank you for getting me to the party!!!");
				AEGfxPrint(Font, strBuffer, -0.80f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
				transparency = 0.0f;
				transparencyMushroom = 1.0f;
				break;
			default:
				transparency = 0.0f;
				transparencyMushroom = 0.0f;
				break;
			}
			break;
		default:
			transparency = 0.0f;
			transparencyMushroom = 0.0f;
			break;
		}

		// dialogue pointer mushroom
		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(-130.f, -65.f);
		AEGfxTextureSet(mmTex3, 0.f, 0.f);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
		AEGfxSetTransparency(transparencyMushroom);
		AEGfxMeshDraw(mmMesh2, AE_GFX_MDM_TRIANGLES);

		//dialogue pointer enemy
		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(130.f, -60.f);
		AEGfxTextureSet(mmTex4, 0.f, 0.0f);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
		AEGfxSetTransparency(transparency);
		AEGfxMeshDraw(mmMesh2, AE_GFX_MDM_TRIANGLES);

		//right
		if (bigArrowRight)
		{
			AEGfxSetBlendMode(AE_GFX_BM_BLEND);
			AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
			AEGfxSetPosition(250.f, 250.f);
			AEGfxTextureSet(mmTex8, 0.f, 0.f);
			AEGfxSetTransparency(1.0f);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxMeshDraw(mmMesh4, AE_GFX_MDM_TRIANGLES);
		}
		else
		{
			AEGfxSetBlendMode(AE_GFX_BM_BLEND);
			AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
			AEGfxSetPosition(250.f, 250.f);
			AEGfxTextureSet(mmTex6, 0.f, 0.f);
			AEGfxSetTransparency(1.0f);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxMeshDraw(mmMesh2, AE_GFX_MDM_TRIANGLES);
		}

		//left
		if (bigArrowLeft)
		{
			AEGfxSetBlendMode(AE_GFX_BM_BLEND);
			AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
			AEGfxSetPosition(-250.f, 250.f);
			AEGfxTextureSet(mmTex9, 0.f, 0.f);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxSetTransparency(1.0f);
			AEGfxMeshDraw(mmMesh4, AE_GFX_MDM_TRIANGLES);
		}
		else
		{
			AEGfxSetBlendMode(AE_GFX_BM_BLEND);
			AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
			AEGfxSetPosition(-250.f, 250.f);
			AEGfxTextureSet(mmTex7, 0.f, 0.f);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxSetTransparency(1.0f);
			AEGfxMeshDraw(mmMesh2, AE_GFX_MDM_TRIANGLES);
		}
	}
}

/******************************************************************************/
/*!
	"Free" function of state cut scene
*/
/******************************************************************************/
void CutScene_Free()
{
	if (!pauseGame || (pauseGame && quitGame == YES))
	{
		graphic_Free();
	}
}

/******************************************************************************/
/*!
	"Unload" function of state cut scene
*/
/******************************************************************************/
void CutScene_Unload()
{
	if (!pauseGame || (pauseGame && quitGame == YES) || (AESysDoesWindowExist() == false))
	{
		AEGfxMeshFree(mmMesh);
		AEGfxMeshFree(mmMesh2);
		AEGfxMeshFree(mmMesh3);
		AEGfxMeshFree(mmMesh4);
		AEGfxMeshFree(mmMesh5);
		AEGfxMeshFree(mmMesh6);
		AEGfxTextureUnload(mmTex13);
		AEGfxTextureUnload(mmTex12);
		AEGfxTextureUnload(mmTex11);
		AEGfxTextureUnload(mmTex10);
		AEGfxTextureUnload(mmTex9);
		AEGfxTextureUnload(mmTex8);
		AEGfxTextureUnload(mmTex7);
		AEGfxTextureUnload(mmTex6);
		AEGfxTextureUnload(mmTex5);
		AEGfxTextureUnload(mmTex4);
		AEGfxTextureUnload(mmTex3);
		AEGfxTextureUnload(mmTex);

		Map_Free();
		graphic_Unload();
		cutSceneBG_Unload();
		free(sGameObjInstList);
		free(sGameObjList);
	}
}