/**********************************************************************************
* \File name		Graphic.cpp
* \Project name		Jump!Shroom!

* \Author(s)		Wei Zhe, Goh       417 Lines x 84.5% Code Contribution
					Hongfu, Wong	   417 Lines x 15.5% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#include "shroom.h"

/******************************************************************************/
/*!
	File globals
*/
/******************************************************************************/
extern PowerUp Blue;
float U = 0.0f, V = 0.0f;
float animationTimer = 0.0f, animationTimer2 = 0.0f;

/******************************************************************************/
/*!
	"Load" black object mesh and texture function
*/
/******************************************************************************/
void blackObject_Load()
{
	pObj = sGameObjList + sGameObjNum++;
	pObj->type = TYPE_OBJECT_EMPTY;

	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFF000000, 0.0f, 0.0f,
		0.5f, -0.5f, 0xFF000000, 0.0f, 0.0f,
		-0.5f, 0.5f, 0xFF000000, 0.0f, 0.0f);

	AEGfxTriAdd(
		-0.5f, 0.5f, 0xFF000000, 0.0f, 0.0f,
		0.5f, -0.5f, 0xFF000000, 0.0f, 0.0f,
		0.5f, 0.5f, 0xFF000000, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create object!!");
	pObj->pTex = nullptr;
}

/******************************************************************************/
/*!
	"Load" tile object mesh and texture function
*/
/******************************************************************************/
void whiteObject_Load()
{
	pObj = sGameObjList + sGameObjNum++;
	pObj->type = TYPE_OBJECT_COLLISION;


	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFFFFFFFF, 0.0f, 0.5f,
		0.5f, -0.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		0.5f, -0.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		0.5f, 0.5f, 0xFFFFFFFF, 0.20f, 0.0f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create object!!");
	pObj->pTex = AEGfxTextureLoad("assert\\art\\Shroom.png");
	AE_ASSERT_MESG(pObj->pTex, "fail to create texture!!");
}

/******************************************************************************/
/*!
	"Load" character mesh and texture function
*/
/******************************************************************************/
void characterTexture_Load()
{
	pObj = sGameObjList + sGameObjNum++;
	pObj->type = TYPE_OBJECT_HERO;

	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFFFFFFFF, 0.0f, 0.5f,
		0.5f, -0.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		0.5f, -0.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		0.5f, 0.5f, 0xFFFFFFFF, 0.20f, 0.0f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create Hero object!!");
	pObj->pTex = AEGfxTextureLoad("assert\\art\\Shroom.png");
	AE_ASSERT_MESG(pObj->pTex, "fail to create Hero texture!!");;
}

/******************************************************************************/
/*!
	"Load" enemy mesh and texture function
*/
/******************************************************************************/
void enemyTexture_Load()
{
	pObj = sGameObjList + sGameObjNum++;
	pObj->type = TYPE_OBJECT_ENEMY1;

	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFFFFFFFF, 0.0f, 0.5f,
		0.5f, -0.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		0.5f, -0.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		0.5f, 0.5f, 0xFFFFFFFF, 0.20f, 0.0f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create enemy1 object!!");
	pObj->pTex = AEGfxTextureLoad("assert\\art\\Shroom.png");
	AE_ASSERT_MESG(pObj->pTex, "fail to create enemy1 texture!!");
}

/******************************************************************************/
/*!
	"Load" coin mesh and texture function
*/
/******************************************************************************/
void coinTexture_Load()
{
	pObj = sGameObjList + sGameObjNum++;
	pObj->type = TYPE_OBJECT_COIN;

	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFFFFFFFF, 0.0f, 0.5f,
		0.5f, -0.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		0.5f, -0.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		0.5f, 0.5f, 0xFFFFFFFF, 0.20f, 0.0f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "Failed to create red power up object !!");

	pObj->pTex = AEGfxTextureLoad("assert\\art\\Shroom.png");
	AE_ASSERT_MESG(pObj->pTex, "Failed to create red power up texture!!");
}

/******************************************************************************/
/*!
	"Load" blue power up mesh and texture function
*/
/******************************************************************************/
void bluePowerUpTexture_Load()
{
	pObj = sGameObjList + sGameObjNum++;
	pObj->type = TYPE_OBJECT_POWERUP_BLUE;

	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFFFFFFFF, 0.0f, 0.5f,
		0.5f, -0.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		0.5f, -0.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		0.5f, 0.5f, 0xFFFFFFFF, 0.20f, 0.0f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "Failed to create blue power up object !!");

	pObj->pTex = AEGfxTextureLoad("assert\\art\\Shroom.png");
	AE_ASSERT_MESG(pObj->pTex, "Failed to create blue power up texture!!");
}

/******************************************************************************/
/*!
	"Load" green power up mesh and texture function
*/
/******************************************************************************/
void greenPowerUpTexture_Load()
{
	pObj = sGameObjList + sGameObjNum++;
	pObj->type = TYPE_OBJECT_POWERUP_GREEN;

	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFFFFFFFF, 0.0f, 0.5f,
		0.5f, -0.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		0.5f, -0.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		0.5f, 0.5f, 0xFFFFFFFF, 0.20f, 0.0f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "Failed to create green power up object !!");

	pObj->pTex = AEGfxTextureLoad("assert\\art\\Shroom.png");
	AE_ASSERT_MESG(pObj->pTex, "Failed to create green power up texture!!");
}

/******************************************************************************/
/*!
	"Load" spawn mushroom mesh and texture function
*/
/******************************************************************************/
void spawnMushroomTexture_Load()
{
	pObj = sGameObjList + sGameObjNum++;
	pObj->type = TYPE_OBJECT_MUSHROOM;

	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFFFFFFFF, 0.0f, 0.5f,
		0.5f, -0.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		0.5f, -0.5f, 0xFFFFFFFF, 0.20f, 0.5f,
		0.5f, 0.5f, 0xFFFFFFFF, 0.20f, 0.0f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create object!!");

	pObj->pTex = AEGfxTextureLoad("assert\\art\\Shroom.png");
	AE_ASSERT_MESG(pObj->pTex, "Failed to create spawnMushroom texture!!");
}

/******************************************************************************/
/*!
	"Load" level 1 background mesh and texture function for game state level select
*/
/******************************************************************************/
void level1Object_Load()
{
	pObj = sGameObjList + sGameObjNum++;
	pObj->type = TYPE_OBJECT_LEVEL1;
	
	float tempadjustx = 3.f;
	float tempadjusty = 9.0f;
	//0xFFFFFFFF //white
	//0x00000000 //black
	//0xCCCCCCCC 
	AEGfxMeshStart();
	AEGfxTriAdd(
		-tempadjustx, -tempadjusty, 0xCCCCCCCC, 0.0f, 1.f,
		tempadjustx, -tempadjusty, 0xCCCCCCCC, .35f, 1.f,
		-tempadjustx, tempadjusty, 0xCCCCCCCC, 0.0f, 0.0f);

	AEGfxTriAdd(
		tempadjustx, -tempadjusty, 0xCCCCCCCC, .35f, 1.f,
		tempadjustx, tempadjusty, 0xCCCCCCCC, .35f, 0.0f,
		-tempadjustx, tempadjusty, 0xCCCCCCCC, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create object!!");

	pObj->pTex = AEGfxTextureLoad("assert\\art\\background1.png");
	AE_ASSERT_MESG(pObj->pTex, "Failed to create level 1 background texture!!");
}

/******************************************************************************/
/*!
	"Load" level 2 background mesh and texture function for game state level select
*/
/******************************************************************************/
void level2Object_Load()
{
	pObj = sGameObjList + sGameObjNum++;
	pObj->type = TYPE_OBJECT_LEVEL2;

	float tempadjustx = 3.f;
	float tempadjusty = 9.0f;
	//0xFFFFFFFF //white
	//0x00000000 //black
	//0xCCCCCCCC 
	AEGfxMeshStart();
	AEGfxTriAdd(
		-tempadjustx, -tempadjusty, 0xCCCCCCCC, 0.0f, 1.f,
		tempadjustx, -tempadjusty, 0xCCCCCCCC, 0.35f, 1.f,
		-tempadjustx, tempadjusty, 0xCCCCCCCC, 0.0f, 0.0f);

	AEGfxTriAdd(
		tempadjustx, -tempadjusty, 0xCCCCCCCC, .35f, 1.f,
		tempadjustx, tempadjusty, 0xCCCCCCCC, .35f, 0.0f,
		-tempadjustx, tempadjusty, 0xCCCCCCCC, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create object!!");

	pObj->pTex = AEGfxTextureLoad("assert\\art\\background2.png");
	AE_ASSERT_MESG(pObj->pTex, "Failed to create level 2 background texture!!");
}

/******************************************************************************/
/*!
	"Load" level 3 background mesh and texture function for game state level select
*/
/******************************************************************************/
void level3Object_Load()
{
	pObj = sGameObjList + sGameObjNum++;
	pObj->type = TYPE_OBJECT_LEVEL3;

	float tempadjustx = 3.f;
	float tempadjusty = 9.0f;
	//0xFFFFFFFF //white
	//0x00000000 //black
	//0xCCCCCCCC 
	AEGfxMeshStart();
	AEGfxTriAdd(
		-tempadjustx, -tempadjusty, 0xCCCCCCCC, 0.0f, 1.f,
		tempadjustx, -tempadjusty, 0xCCCCCCCC, 0.35f, 1.f,
		-tempadjustx, tempadjusty, 0xCCCCCCCC, 0.0f, 0.0f);

	AEGfxTriAdd(
		tempadjustx, -tempadjusty, 0xCCCCCCCC, .35f, 1.f,
		tempadjustx, tempadjusty, 0xCCCCCCCC, .35f, 0.0f,
		-tempadjustx, tempadjusty, 0xCCCCCCCC, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create object!!");

	pObj->pTex = AEGfxTextureLoad("assert\\art\\background3.png");
	AE_ASSERT_MESG(pObj->pTex, "Failed to create level 3 background texture!!");
}

/******************************************************************************/
/*!
	"Load" level 1 background mesh and texture function for game state level 1
*/
/******************************************************************************/
void level1Background_Load()
{
	pObj = sGameObjList + sGameObjNum++;
	pObj->type = TYPE_OBJECT_LEVEL1_BG;

	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFFFFFFFF, 0.0f, 1.f,
		0.5f, -0.5f, 0xFFFFFFFF, 0.5f, 1.f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		0.5f, -0.5f, 0xFFFFFFFF, 0.5f, 1.f,
		0.5f, 0.5f, 0xFFFFFFFF, 0.5f, 0.0f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create object!!");

	pObj->pTex = AEGfxTextureLoad("assert\\art\\background1.png");
	AE_ASSERT_MESG(pObj->pTex, "Failed to create level 1 background texture!!");
}

/******************************************************************************/
/*!
	"Load" level 2 background mesh and texture function for game state level 2
*/
/******************************************************************************/
void level2Background_Load()
{
	pObj = sGameObjList + sGameObjNum++;
	pObj->type = TYPE_OBJECT_LEVEL2_BG;

	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFFFFFFFF, 0.0f, 1.f,
		0.5f, -0.5f, 0xFFFFFFFF, 0.5f, 1.f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		0.5f, -0.5f, 0xFFFFFFFF, 0.5f, 1.f,
		0.5f, 0.5f, 0xFFFFFFFF, 0.5f, 0.0f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create object!!");

	pObj->pTex = AEGfxTextureLoad("assert\\art\\background2.png");
	AE_ASSERT_MESG(pObj->pTex, "Failed to create level 2 background texture!!");
}

/******************************************************************************/
/*!
	"Load" level 3 background mesh and texture function for game state level 3
*/
/******************************************************************************/
void level3Background_Load()
{
	pObj = sGameObjList + sGameObjNum++;
	pObj->type = TYPE_OBJECT_LEVEL3_BG;

	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFFFFFFFF, 0.0f, 1.f,
		0.5f, -0.5f, 0xFFFFFFFF, 0.5f, 1.f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		0.5f, -0.5f, 0xFFFFFFFF, 0.5f, 1.f,
		0.5f, 0.5f, 0xFFFFFFFF, 0.5f, 0.0f,
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create object!!");

	pObj->pTex = AEGfxTextureLoad("assert\\art\\background3.png");
	AE_ASSERT_MESG(pObj->pTex, "Failed to create level 3 background texture!!");
}

/******************************************************************************/
/*!
	"Initialize" function for graphics and animation
*/
/******************************************************************************/
void graphic_Initialize()
{
	AEVec2 newPos = { 0,0 };
	gameObjInstCreate(TYPE_OBJECT_LEVEL1_BG, 1.f, &newPos, nullptr, 0.0f, STATE::STATE_NONE);
}

/******************************************************************************/
/*!
	"Update" function for graphics and animation
*/
/******************************************************************************/
void graphic_Update()
{
	if (AEInputCheckTriggered(AEVK_SPACE))
	{
		U = 0.4f;
	}

	if (animationTimer > 0)
	{
		animationTimer -= g_dt;
	}
	else
	{
		U = 0.0f;
	}

	if (pHero->gridCollisionFlag && COLLISION_BOTTOM)
	{
		U = 0.2f;
		animationTimer2 = 0.5f;
	}

	if (animationTimer2 > 0)
	{
		animationTimer2 -= g_dt;
	}
	else
	{
		U = 0.0f;
	}
}

/******************************************************************************/
/*!
	"Draw" all object instances function

	For each active and visible object instance
		Concatenate MapTransform with its transformation matrix
		Send the resultant matrix to the graphics manager using "AEGfxSetTransform"
		Draw the instance's shape using "AEGfxMeshDraw"
*/
/******************************************************************************/
void graphic_Draw()
{
	for (unsigned int i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
	{
		GameObjInst* pInst = sGameObjInstList +i;

		// skip non-active object
		if (0 == (pInst->flag & FLAG_ACTIVE) || 0 == (pInst->flag & FLAG_VISIBLE))
			continue;

		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);

		if (pInst->pObject->type == TYPE_OBJECT_LEVEL1_BG)
		{
			AEMtx33 transBG, scaleBG, transformBG;

			_Unreferenced_parameter_(transformBG);

			AEGfxTextureSet(pObj->pTex, (float)(pHero->posCurr.x)/ 75, 1);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxSetTransparency(1.0f);

			AEMtx33Trans(&transBG, 0, 0);
			
			if (isLevel2)
				AEMtx33Scale(&scaleBG, (f32)AEGetWindowWidth() * 2.5f, (f32)AEGetWindowHeight() * 2.5f);
			else
				AEMtx33Scale(&scaleBG, (f32)AEGetWindowWidth(), (f32)AEGetWindowHeight());
			
			AEMtx33Concat(&pInst->transform, &transBG, &scaleBG);
			AEGfxSetTransform(pInst->transform.m);
			AEGfxMeshDraw(pInst->pObject->pMesh, AE_GFX_MDM_TRIANGLES);
			
			continue;
		}
		else if (pInst->pObject->type == TYPE_OBJECT_LEVEL2_BG)
		{
			AEMtx33 transBG, scaleBG, transformBG;

			_Unreferenced_parameter_(transformBG);

			AEGfxTextureSet(pObj->pTex, (float)(pHero->posCurr.x) / 75, 1);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxSetTransparency(1.0f);

			AEMtx33Trans(&transBG, 0, 0);
			
			if (isLevel2)
				AEMtx33Scale(&scaleBG, (f32)AEGetWindowWidth() * 1.0f, (f32)AEGetWindowHeight() * 1.0f);
			else
				AEMtx33Scale(&scaleBG, (f32)AEGetWindowWidth(), (f32)AEGetWindowHeight());
			
			AEMtx33Concat(&pInst->transform, &transBG, &scaleBG);
			AEGfxSetTransform(pInst->transform.m);
			AEGfxMeshDraw(pInst->pObject->pMesh, AE_GFX_MDM_TRIANGLES);
			
			continue;
		}
		else if (pInst->pObject->type == TYPE_OBJECT_LEVEL3_BG)
		{
			AEMtx33 transBG, scaleBG, transformBG;

			_Unreferenced_parameter_(transformBG);

			AEGfxTextureSet(pObj->pTex, (float)(pHero->posCurr.x) / 75, 1);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxSetTransparency(1.0f);

			AEMtx33Trans(&transBG, 0, 0);
			
			if (isLevel3)
				AEMtx33Scale(&scaleBG, (f32)AEGetWindowWidth() * 1.5f, (f32)AEGetWindowHeight() * 1.5f);
			if (isLevel4)
				AEMtx33Scale(&scaleBG, (f32)AEGetWindowWidth() * 2.f, (f32)AEGetWindowHeight() * 2.f);
			if (!isLevel3 && !isLevel4)
				AEMtx33Scale(&scaleBG, (f32)AEGetWindowWidth(), (f32)AEGetWindowHeight());
			
			AEMtx33Concat(&pInst->transform, &transBG, &scaleBG);
			AEGfxSetTransform(pInst->transform.m);
			AEGfxMeshDraw(pInst->pObject->pMesh, AE_GFX_MDM_TRIANGLES);
			continue;
		}
		else if (pInst->pObject->type == TYPE_OBJECT_HERO)
		{
			AEGfxTextureSet(pInst->pObject->pTex, U, V);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxSetTransparency(1.0f);
		}
		else if (pInst->pObject->type == TYPE_OBJECT_ENEMY1)
		{
			AEGfxTextureSet(pInst->pObject->pTex, 0.0f, 0.5f);
			
			if (Blue.freeze)
				AEGfxSetTintColor(0.f, 0.f, 1.0f, 1.0f);
			else
				AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			
			AEGfxSetTransparency(1.0f);
		}
		else if (pInst->pObject->type == TYPE_OBJECT_COIN)
		{
			AEGfxTextureSet(pInst->pObject->pTex, 0.2f, 0.5f);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxSetTransparency(1.0f);
		}
		else if (pInst->pObject->type == TYPE_OBJECT_POWERUP_GREEN)
		{
			AEGfxTextureSet(pInst->pObject->pTex, 0.6f, 0.5f);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxSetTransparency(1.0f);
		}
		else if (pInst->pObject->type == TYPE_OBJECT_POWERUP_BLUE)
		{
			AEGfxTextureSet(pInst->pObject->pTex, 0.4f, 0.5f);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxSetTransparency(1.0f);
		}
		else if (pInst->pObject->type == TYPE_OBJECT_MUSHROOM)
		{
			AEGfxTextureSet(pInst->pObject->pTex, 0.8f, 0.0f);
			AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
			AEGfxSetTransparency(1.0f);
		}
		AEMtx33Concat(&pInst->transform, &MapTransform, &pInst->transform);
		AEGfxSetTransform(pInst->transform.m);
		AEGfxMeshDraw(pInst->pObject->pMesh, AE_GFX_MDM_TRIANGLES);
		//Don't forget to concatenate the MapTransform matrix with the transformation of each game object instance
	}
}

/******************************************************************************/
/*!
	Free all game object instances at the end of the game
*/
/******************************************************************************/
void graphic_Free()
{
	// kill all object instances in the array using "gameObjInstDestroy"

	for (unsigned int i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
	{
		GameObjInst* pInst = sGameObjInstList + i;
		gameObjInstDestroy(pInst);
	}
}

/******************************************************************************/
/*!
	Unload all game object before termination or to be reinitialized
*/
/******************************************************************************/
void graphic_Unload()
{
	for (u32 i = 0; i < sGameObjNum; i++)
	{
		AEGfxMeshFree(sGameObjList[i].pMesh);
		if (sGameObjList[i].pTex)
			AEGfxTextureUnload(sGameObjList[i].pTex);
	}
}