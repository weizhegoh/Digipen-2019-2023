/**********************************************************************************
* \File name		pauseMenu.h
* \Project name		Jump!Shroom!

* \Author(s)		Wei Zhe, Goh 30 lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#pragma once

enum pauseMenu
{
	RESUME = 0,		//0
	RESTART,		//1
	OPTION,			//2
	QUIT		    //3
};

enum QuitGame
{
	NO = 0,			//0
	YES				//1
};

enum OptionMenu
{
	FULLSCREEN = 0, //0
	MUTE			//1
};

extern int option;
extern int quitGame;
extern int restartGame;

extern bool enterRestartGameState;
extern bool enterOptionMenuState;
extern bool pauseGame;

void pauseMenu_Load();
void pauseMenu_Init();
void pauseMenu_Update();
void pauseMenu_Draw();
void pauseMenu_Free();
void pauseMenu_Unload();
