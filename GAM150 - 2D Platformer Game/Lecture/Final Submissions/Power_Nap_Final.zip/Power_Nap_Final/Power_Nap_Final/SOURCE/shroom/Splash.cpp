/**********************************************************************************
* \File name	 Splash.cpp
* \Project name  Jump!Shroom!

* \Author(s)	 Hong Fu, Wong       110 lines x 98.25% Code Contribution
				 Wei Zhe, Goh		 110 lines x 1.75% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#include "shroom.h"
#include <iostream>
//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
extern s8				Font;

static float			splash_Timer = 0.f;
static float			animation_Timer = 0.f;

static AEGfxTexture		* mmTex, * mmTex2;
static AEGfxVertexList	* mmMesh, * mmMesh2;


//*********************************************************************************
//								PUBLIC FUNCTIONS
//*********************************************************************************
/******************************************************************************/
/*!
	Load function for splash
*/
/******************************************************************************/
void Splash_Load()
{
	digipenLogoBG_Load();
	AEGfxSetCamPosition(0, 0);
	AEGfxSetBackgroundColor(0.f, 0.f, 0.f);

	AEGfxMeshStart();
	AEGfxTriAdd(
		-95.5f, -95.5f, 0xFFFFFFFF, 0.0f, 1.f,
		595.5f, -95.5f, 0xFFFFFFFF, 1.f, 1.f,
		-95.5f, 95.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		595.5f, -95.5f, 0xFFFFFFFF, 1.f, 1.f,
		595.5f, 95.5f, 0xFFFFFFFF, 1.f, 0.0f,
		-95.5f, 95.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	mmMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(mmMesh, "Failed to create Digipen logo mesh!!");

	AEGfxMeshStart();
	AEGfxTriAdd(
		-195.5f, -195.5f, 0xFFFFFFFF, 0.0f, 1.f,
		195.5f, -195.5f, 0xFFFFFFFF, 1.f, 1.f,
		-195.5f, 195.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	AEGfxTriAdd(
		195.5f, -195.5f, 0xFFFFFFFF, 1.f, 1.f,
		195.5f, 195.5f, 0xFFFFFFFF, 1.f, 0.0f,
		-195.5f, 195.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	mmMesh2 = AEGfxMeshEnd();
	AE_ASSERT_MESG(mmMesh2, "Failed to create team logo mesh!!");
	mmTex = AEGfxTextureLoad("assert\\art\\DigiPen_Singapore_WEB_WHITE.png");
	AE_ASSERT_MESG(mmTex, "fail to create Digipen Texture!!");
	mmTex2 = AEGfxTextureLoad("assert\\art\\Power_Nap_NOBG.png");
	AE_ASSERT_MESG(mmTex2, "fail to create team logo Texture!!");
}

/******************************************************************************/
/*!
	Initialize function for splash
*/
/******************************************************************************/
void Splash_Init()
{
	splash_Timer = 0.0f;
	animation_Timer = 0.0f;
}

/******************************************************************************/
/*!
	Update function for splash
*/
/******************************************************************************/
void Splash_Update()
{
	/* Updates timer using delta time */
	splash_Timer += g_dt;
	if ((AEInputCheckCurr(AEVK_ESCAPE) || AEInputCheckCurr(AEVK_SPACE) || AEInputCheckCurr(AEVK_RETURN)) && splash_Timer > 3.f)
	{
		next = GS_MainMenu;
	}
	if (splash_Timer > 4.5f)
	{
		next = GS_MainMenu;
	}
}

/******************************************************************************/
/*!
	Draw function for splash
*/
/******************************************************************************/
void Splash_Draw()
{
	if (splash_Timer <= 0.2)
	{
		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(-270.f, 0.f);
		AEGfxTextureSet(mmTex, 0.f, 0.f);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 0.5f);
		AEGfxSetTransparency(1.0f);

		AEGfxMeshDraw(mmMesh, AE_GFX_MDM_TRIANGLES);
	}
	else if (splash_Timer > 0.2f && splash_Timer <= 0.4f)
	{
		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(-270.f, 0.f);
		AEGfxTextureSet(mmTex, 0.f, 0.f);
		AEGfxSetTintColor(1.0f, 1.f, 1.f, 0.8f);
		AEGfxSetTransparency(1.0f);

		AEGfxMeshDraw(mmMesh, AE_GFX_MDM_TRIANGLES);
	}
	else if (splash_Timer > 0.4f && splash_Timer < 3.f)
	{
		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(-270.f, 0.f);
		AEGfxTextureSet(mmTex, 0.f, 0.f);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
		AEGfxSetTransparency(1.0f);

		AEGfxMeshDraw(mmMesh, AE_GFX_MDM_TRIANGLES);
	}
	else if (splash_Timer > 3.f)
	{
		// Team logo
		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(0.f, 0.f);
		AEGfxTextureSet(mmTex2, 0.f, 0.f);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
		AEGfxSetTransparency(1.0f);
		AEGfxMeshDraw(mmMesh2, AE_GFX_MDM_TRIANGLES);
	}

	// Ascii Splash // 
	/*
	float screenX = -1.f;
	float screenY = 1.f;
	float scale = 0.3f;
	float Rv = 1.f;
	float Gv = 1.f;
	float Bv = 1.f;

	char strBuffer[1024];

	AEGfxSetBlendMode(AE_GFX_BM_BLEND);
	AEGfxSetRenderMode(AE_GFX_RM_COLOR);
	AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
	AEGfxSetTransparency(1.0f);

	if (splash_Timer > 0.f)
	{
		sprintf_s(strBuffer, "          & &&&&&&&     &&&&&&&&&&      &&             &&  &&&&&&&                        ");
		AEGfxPrint(Font, strBuffer, screenX, screenY, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "          & &&&&&&&     &&&&&&&&&&      &&             &&  &&&&&&&                        ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.05f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "          & &&&&&&&&&   &&&&&&&&&&&&                      &&&&&&&&&&                      ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.1f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "          & &&&&&&&&&   &&&&&&&&&&&&                      &&&&&&&&&&                      ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.15f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "          & &&&&&&&&&&  &&&&    &&&&&  &&&    &&&&&&& &&& &&&&   &&&   &&&&&&    &&&&&&&& ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.2f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "          & &&&&&&&&&&  &&&&    &&&&&  &&&    &&&&&&& &&& &&&&   &&&   &&&&&&    &&&&&&&& ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.25f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "          & &&&&&&&&&&  &&&&     &&&&  &&&  &&&&&&&&& &&& &&&&&&&&&&  &&&&  &&&  &&&&&&&&&");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.3f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "          & &&&&&&&&&&  &&&&     &&&&  &&&  &&&&&&&&& &&& &&&&&&&&&&  &&&&  &&&  &&&&&&&&&");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.35f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "          & &&&&&&&&&   &&&&     &&&&  &&&  &&&   &&& &&& &&&&&&&&&   &&&&&&&&&  &&&&  &&&");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.4f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "          & &&&&&&&&&   &&&&     &&&&  &&&  &&&   &&& &&& &&&&&&&&&   &&&&&&&&&  &&&&  &&&");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.45f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "          & &&&&&&&     &&&&&&&&&&&&   &&&  &&&&&&&&& &&& &&&         &&&&       &&&&  &&&");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.5f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "          & &&&&&&&     &&&&&&&&&&&&   &&&  &&&&&&&&& &&& &&&         &&&&       &&&&  &&&");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.55f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "  &&&&&&& &             &&&&&&&&&&&    &&&   &&&&&&&& &&& &&&          &&&&&&&   &&&&  &&&");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.6f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "  &&&&&&& &             &&&&&&&&&&&    &&&   &&&&&&&& &&& &&&          &&&&&&&   &&&&  &&&");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.65f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "&&&&&&&&& &                                       &&&                                     ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.7f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "&&&&&&&&& &                                       &&&                                     ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.75f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "&&&&&&&&& &                                  &&&&&&&&                                     ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.8f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "&&&&&&&&& &                                  &&&&&&&&                                     ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.85f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "&&&&&&&&& &                                  &&&&&&                                       ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.9f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "&&&&&&&&& &                                  &&&&&&                                       ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 0.95f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "&&&&&&&&& &                                                                               ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 1.f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "&&&&&&&&& &                                                                               ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 1.05f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "&&&&&&&&& &                                                                               ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 1.1f, scale, Rv, Gv, Bv);
		sprintf_s(strBuffer, "  &&&&&&& &                             INSTITUTE OF TECHNOLOGY                           ");
		AEGfxPrint(Font, strBuffer, screenX, screenY - 1.15f, scale, Rv, Gv, Bv);
	}
	*/
}

/******************************************************************************/
/*!
	Free function for splash
*/
/******************************************************************************/
void Splash_Free()
{
}

/******************************************************************************/
/*!
	Unload function for splash
*/
/******************************************************************************/
void Splash_Unload()
{
	AEGfxMeshFree(mmMesh);
	AEGfxMeshFree(mmMesh2);
	AEGfxTextureUnload(mmTex);
	AEGfxTextureUnload(mmTex2);

	digipenLogoBG_Unload();
}
