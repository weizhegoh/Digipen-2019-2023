/**********************************************************************************
* \File name     CutScene.h
* \Project name  Jump!Shroom!

* \Author(s)	 Dong Yanhan       8 lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#pragma once

extern s8 Font;

void CutScene_Load();
void CutScene_Init();
void CutScene_Update();
void CutScene_Draw();
void CutScene_Free();
void CutScene_Unload();