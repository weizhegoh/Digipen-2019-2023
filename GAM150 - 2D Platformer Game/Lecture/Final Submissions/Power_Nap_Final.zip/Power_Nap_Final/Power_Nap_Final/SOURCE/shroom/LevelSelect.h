/**********************************************************************************
* \File name     LevelSelect.h
* \Project name  Jump!Shroom!

* \Author(s)     Hong Fu, Wong       21 Lines x 90% Code Contribution
				 Yan Han, Dong		 21 Lines x 5% Code Contribution 
				 Benjamin, Liew	     21 Lines x 5% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#pragma once

extern const float		GRAVITY;
extern const float		JUMP_VELOCITY;
extern const float		MOVE_VELOCITY_HERO;
extern const int		HERO_LIVES;
extern int				HeroLives;
extern int				Hero_Initial_X;
extern int				Hero_Initial_Y;
extern int				TotalCoins;
extern const float		pTIME;
extern float			pTIMER;
extern const float		iTime;
extern float			iTimer;
extern bool				iBool;
extern int				level;


void LevelSelect_Load();
void LevelSelect_Init();
void LevelSelect_Update();
void LevelSelect_Draw();
void LevelSelect_Free();
void LevelSelect_Unload();