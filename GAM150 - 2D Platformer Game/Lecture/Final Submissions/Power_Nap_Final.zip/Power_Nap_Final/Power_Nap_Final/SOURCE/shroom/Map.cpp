/**********************************************************************************
* \File name		Map.cpp
* \Project name		Jump!Shroom!

* \Author(s)		Benjamin Liew       254 lines x 100% Code Contribution

* \Copyright information
All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#include "shroom.h"
#include "PowerUp.h"
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>

/*The number of horizontal elements*/
int BINARY_MAP_WIDTH;

/*The number of vertical elements*/
int BINARY_MAP_HEIGHT;

/*This will contain all the data of the map, which will be retreived from a file
when the "ImportMapDataFromFile" function is called*/
int** MapData;

/*This will contain the collision data of the binary map. It will be filled in the
"ImportMapDataFromFile" after filling "MapData". Basically, if an array element
in MapData is 1, it represents a collision cell, any other value is a non-collision
cell*/
int** BinaryCollisionArray;

AEMtx33			MapTransform;

//int TotalCoins = 0; 

extern s8 Font;
extern PowerUp Blue;

UI UIGreen;
UI UIBlue;
UI UIRedDecreaseLife;
UI UIRedDecreaseBluepowerup;

Map mapRandomizer;

/******************************************************************************/
/*!
	This function opens the file name "FileName" and retrieves all the map data.
	It allocates memory for the 2 arrays: MapData & BinaryCollisionArray
	The first line in this file is the width of the map.
	The second line in this file is the height of the map.
	The remaining part of the file is a series of numbers
	Each number represents the ID (or value) of a different element in the
	double dimensionaly array.

	Example:

	Width 5
	Height 5
	1 1 1 1 1
	1 1 1 3 1
	1 4 2 0 1
	1 0 0 0 1
	1 1 1 1 1


	After importing the above data, "MapData" and " BinaryCollisionArray"
	should be

	1 1 1 1 1
	1 1 1 3 1
	1 4 2 0 1
	1 0 0 0 1
	1 1 1 1 1

	and

	1 1 1 1 1
	1 1 1 0 1
	1 0 0 0 1
	1 0 0 0 1
	1 1 1 1 1

	respectively.

	Finally, the function returns 1 if the file named "FileName" exists,
	otherwise it returns 0
 */
 /******************************************************************************/
int ImportMapDataFromFile(const char* FileName)
{
	FILE* pFile;

	fopen_s(&pFile, FileName, "r"); // Open file for reading

	if (pFile != NULL) //File exist, start reading from file
	{
		fscanf_s(pFile, "Width  %d\n", &BINARY_MAP_WIDTH); // Read Map Width
		fscanf_s(pFile, "Height %d\n", &BINARY_MAP_HEIGHT); // Read Map Height
	}
	else // Check if file exist
	{
		std::cout << "No file found to read from" << std::endl;
		return 0; //Return 0 if file does not exist
	}

	if (BINARY_MAP_HEIGHT == 0 || BINARY_MAP_WIDTH == 0)
	{
		return 0;
	}

	// Allocating Memory for MapData
	MapData = new int* [BINARY_MAP_HEIGHT];
	for (int i = 0; i < BINARY_MAP_HEIGHT; ++i)
	{
		MapData[i] = new int[BINARY_MAP_WIDTH];
	}

	// Allocating Memory for MapData
	BinaryCollisionArray = new int* [BINARY_MAP_HEIGHT];
	for (int i = 0; i < BINARY_MAP_HEIGHT; ++i)
	{
		BinaryCollisionArray[i] = new int[BINARY_MAP_WIDTH];
	}

	// Reading in MapData and BinaryCollisionArray
	for (int i = 0; i < BINARY_MAP_HEIGHT; ++i)
	{
		for (int j = 0; j < BINARY_MAP_WIDTH; ++j)
		{
			fscanf_s(pFile, "%d ", &MapData[i][j]);

			if (MapData[i][j] != 1)
			{
				BinaryCollisionArray[i][j] = 0;
			}
			else
			{
				BinaryCollisionArray[i][j] = 1;
			}

		}
	}

	fclose(pFile); // Close file

	return 1;
}

/******************************************************************************/
/*!
	This function prints out the content of the 2D array appData.
	Add spaces and end lines at convenient places
 */
 /******************************************************************************/
void PrintRetrievedInformation(void)
{
	for (int row = 0; row < BINARY_MAP_HEIGHT; ++row)
	{
		for (int column = 0; column < BINARY_MAP_WIDTH; ++column)
		{
			std::cout << MapData[row][column];
			std::cout << " ";
		}
		std::cout << std::endl;
	}
}

/******************************************************************************/
/*!
	This function retrieves the value of the element (X;Y) in BinaryCollisionArray.
	Before retrieving the value, it should check that the supplied X and Y values
	are not out of bounds (in that case return 0)
 */
 /******************************************************************************/
int GetCellValue(int X, int Y)
{
	if (X >= BINARY_MAP_WIDTH || Y >= BINARY_MAP_HEIGHT || X < 0 || Y < 0)
	{
		return 0;
	}
	return BinaryCollisionArray[Y][X];
}

/******************************************************************************/
/*!
	This function snaps the value sent as parameter to the center of the cell.
	It is used when a sprite is colliding with a collision area from one
	or more side.
	To snap the value sent by "Coordinate", find its integral part by type
	casting it to an integer, then add 0.5 (which is half the cell's width
	or height)
 */
 /******************************************************************************/
void SnapToCell(float* Coordinate)
{
	*Coordinate = (int)*Coordinate + 0.5f;
}

/******************************************************************************/
/*!
	This function creates 2 hot spots on each side of the object instance,
	and checks if each of these hot spots is in a collision area (which means
	the cell if falls in has a value of 1).
	At the beginning of the function, a "Flag" integer should be initialized to 0.
	Each time a hot spot is in a collision area, its corresponding bit
	in "Flag" is set to 1.
	Finally, the function returns the integer "Flag"
	The position of the object instance is received as PosX and PosY
	The size of the object instance is received as scaleX and scaleY

	Note: This function assume the object instance's size is 1 by 1
		  (the size of 1 tile)

	Creating the hotspots:
		-Handle each side separately.
		-2 hot spots are needed for each collision side.
		-These 2 hot spots should be positioned on 1/4 above the center
		and 1/4 below the center

	Example: Finding the hots spots on the left side of the object instance

	float x1, y1, x2, y2;

	-hotspot 1
	x1 = PosX + scaleX/2	To reach the right side
	y1 = PosY + scaleY/4	To go up 1/4 of the height

	-hotspot 2
	x2 = PosX + scaleX/2	To reach the right side
	y2 = PosY - scaleY/4	To go down 1/4 of the height
 */
 /******************************************************************************/
int CheckInstanceBinaryMapCollision(float PosX, float PosY,
	float scaleX, float scaleY)
{
	int flag = 0;

	float x1 = 0.0f, y1 = 0.0f, x2 = 0.0f, y2 = 0.0f;

	x1 = PosX + scaleX / 2;
	y1 = PosY + scaleY / 4;

	x2 = PosX + scaleX / 2;
	y2 = PosY - scaleY / 4;

	if (GetCellValue(int(x1), int(y1)) || GetCellValue(int(x2), int(y2)))
	{
		flag |= COLLISION_RIGHT;
	}

	x1 = PosX - scaleX / 2;
	y1 = PosY + scaleY / 4;

	x2 = PosX - scaleX / 2;
	y2 = PosY - scaleY / 4;

	if (GetCellValue(int(x1), int(y1)) || GetCellValue(int(x2), int(y2)))
	{
		flag |= COLLISION_LEFT;
	}

	x1 = PosX - scaleX / 4;
	y1 = PosY + scaleY / 2;

	x2 = PosX + scaleX / 4;
	y2 = PosY + scaleY / 2;

	if (GetCellValue(int(x1), int(y1)) || GetCellValue(int(x2), int(y2)))
	{
		flag |= COLLISION_TOP;
	}

	x1 = PosX - scaleX / 4;
	y1 = PosY - scaleY / 2;

	x2 = PosX + scaleX / 4;
	y2 = PosY - scaleY / 2;

	if (GetCellValue(int(x1), int(y1)) || GetCellValue(int(x2), int(y2)))
	{
		flag |= COLLISION_BOTTOM;
	}

	return flag;
}

/*****************************************************************************
*                                                                            *
*                        UI FLASHING ACTIVATION                              *
*                                                                            *
*****************************************************************************/

/******************************************************************************/
/*!
	This function makes the game UI flash green whenever health is collected
*/
/******************************************************************************/
void	UIFlashGreen()
{
	if (UIGreen.UIFlash)
	{
		UIRedDecreaseLife.UIFlash = false;			//Off so colours don't mix
		UIGreen.greenColor = 1.f;	//Shows the color Green
		UIGreen.UIFlashTimerGreen -= g_dt;
		if (UIGreen.UIFlashTimerGreen <= 0.0f)
		{
			//Resets the Green flashing UI when timer runs out
			UIGreen.UIFlash = false;
			UIGreen.greenColor = 0.0f;
			UIGreen.UIFlashTimerGreen = 2.0f;
		}
	}
}

/******************************************************************************/
/*!
	This function flashes the game UI blue whenever the Blue powerup is
	collected
*/
/******************************************************************************/
void	UIFlashBlue()
{
	if (UIBlue.UIFlash)
	{
		UIRedDecreaseBluepowerup.UIFlash = false;		//Off so the colours don't mix
		UIBlue.blueColor = 1.f;		//Shows the color Blue
		UIBlue.UIFlashTimerBlue -= g_dt;
		if (UIBlue.UIFlashTimerBlue <= 0.0f)
		{
			//Resets the Blue flashing UI when timer runs out
			UIBlue.UIFlash = false;
			UIBlue.blueColor = 0.0f;
			UIBlue.UIFlashTimerBlue = 2.0f;
		}
	}
}

/******************************************************************************/
/*!
	This function makes the game UI(Life) flash red whenever life decreases
*/
/******************************************************************************/
void	UIFlashRedDecreaseLife()
{
	if (UIRedDecreaseLife.UIFlash)
	{
		UIGreen.UIFlash = false;										//Off so the colours don't mix 
		UIRedDecreaseLife.redColor = !UIRedDecreaseLife.redColor;		//Shows the color Red
		UIRedDecreaseLife.UIFlashTimerRed -= g_dt;
		if (UIRedDecreaseLife.UIFlashTimerRed <= 0.0f)
		{
			//Resets the Blue flashing UI when timer runs out
			UIRedDecreaseLife.UIFlash = false;
			UIRedDecreaseLife.redColor = 0.0f;
			UIRedDecreaseLife.UIFlashTimerRed = 2.0f;
		}
	}
}

/******************************************************************************/
/*!
	This function makes the game UI(Blue powerup) flash red when it is used
	or if there is no more powerup to use
*/
/******************************************************************************/
void	UIFlashRedDecreaseBluepowerup()
{
	if (UIRedDecreaseBluepowerup.UIFlash)
	{
		UIBlue.UIFlash = false;														//Off so the colours don't mix ==> Red + Blue = Violet 
		UIRedDecreaseBluepowerup.redColor = 1.f;		//Shows the color Red
		UIRedDecreaseBluepowerup.UIFlashTimerRed -= g_dt;
		if (UIRedDecreaseBluepowerup.UIFlashTimerRed <= 0.0f)
		{
			//Resets the Blue flashing UI when timer runs out
			UIRedDecreaseBluepowerup.UIFlash = false;
			UIRedDecreaseBluepowerup.redColor = 0.0f;
			UIRedDecreaseBluepowerup.UIFlashTimerRed = 2.0f;
		}
	}
}

/******************************************************************************/
/*!
	This function loads textures needed for game UI
*/
/******************************************************************************/
void Map_Load() {}

/******************************************************************************/
/*!
	This function initialises bools and values for game UI
*/
/******************************************************************************/
void Map_Init() 
{
	//Resets Green flashng UI
	UIGreen.UIFlash = false;
	UIGreen.greenColor = 0.0f;
	UIGreen.UIFlashTimerGreen = 1.0f;

	//Resets Blue flashng UI
	UIBlue.UIFlash = false;
	UIBlue.blueColor = 0.0f;
	UIBlue.UIFlashTimerBlue = 1.0f;

	//Resets Red flashng UI for Life
	UIRedDecreaseLife.UIFlash = false;
	UIRedDecreaseLife.redColor = 0.0f;
	UIRedDecreaseLife.UIFlashTimerRed = 1.0f;

	//Resets Red flashng UI for Blue Power Up
	UIRedDecreaseBluepowerup.UIFlash = false;
	UIRedDecreaseBluepowerup.redColor = 0.0f;
	UIRedDecreaseBluepowerup.UIFlashTimerRed = 1.0f;
}

/******************************************************************************/
/*!
	This function updates the game UI
*/
/******************************************************************************/
void Map_Update()
{
	//If it is activated from the levels then will it start flashing
	if (UIRedDecreaseLife.UIFlash)
	{
		if (AEInputCheckTriggered(AEVK_D) && HeroLives > 1)
		{
				UIRedDecreaseLife.UIFlashTimerRed = 2.0f;
		}
	}

	if (AEInputCheckTriggered(AEVK_S) && !Blue.activation)
	{
		UIRedDecreaseBluepowerup.UIFlashTimerRed = 2.0f;
		UIRedDecreaseBluepowerup.UIFlash = true;
	}

	UIFlashGreen();
	UIFlashBlue();
	UIFlashRedDecreaseLife();
	UIFlashRedDecreaseBluepowerup();
}

/******************************************************************************/
/*!
	This function draws the UI for the game
*/
/******************************************************************************/
void Map_Draw()
{
	char strBuffer[100];

	f32 LiveCamX = -0.88f;	//x-coordinate for the live counter
	f32 bluePowerUpCamX = -0.4f; //x-coordinate for the blue power up counter
	f32 totalCoinCamX = 0.25f;	//x-coordinate for the coin counter
	f32 CamY = 0.81f;	//y-coordinate for both counter above

	// Printing lives
	memset(strBuffer, 0, 100 * sizeof(char));
	sprintf_s(strBuffer, "Lives:  %i", HeroLives);
	AEGfxPrint(Font, strBuffer, LiveCamX, CamY, 0.52f, UIRedDecreaseLife.redColor, UIGreen.greenColor, 0.0f);

	// hf
	sprintf_s(strBuffer, "______");
	AEGfxPrint(Font, strBuffer, LiveCamX, CamY - 0.02f, 0.52f, UIRedDecreaseLife.redColor, UIGreen.greenColor, 0.0f);
	// Printing Powerup
	sprintf_s(strBuffer, "Blue Power Ups:  %i", Blue.powerupCounter);
	AEGfxPrint(Font, strBuffer, bluePowerUpCamX, CamY, 0.45f, UIRedDecreaseBluepowerup.redColor, 0.0f, UIBlue.blueColor);
	// hf
	sprintf_s(strBuffer, "____________");
	AEGfxPrint(Font, strBuffer, bluePowerUpCamX, CamY-0.02f, 0.52f, UIRedDecreaseBluepowerup.redColor, 0.0f, UIBlue.blueColor);
	// Printing Coins
	sprintf_s(strBuffer, "Coins Collected:  %i / %i", TotalCoins, coinCounter);
	AEGfxPrint(Font, strBuffer, totalCoinCamX, CamY, 0.45f, 0.0f, 0.0f, 0.0f);
	// hf
	sprintf_s(strBuffer, "_______________");
	AEGfxPrint(Font, strBuffer, totalCoinCamX, CamY-0.02f, 0.52f, 0.0f, 0.0f, 0.0f);

}

/******************************************************************************/
/*!
	This function frees map data and binary collision array
*/
/******************************************************************************/
void Map_Free()
{
	//Frees MapData and BinaryCollisionArray
	for (int row = 0; row < BINARY_MAP_HEIGHT; ++row)
	{
		delete[] MapData[row];
		delete[] BinaryCollisionArray[row];
	}
	delete[] MapData;
	delete[] BinaryCollisionArray;
}

/******************************************************************************/
/*!
	This function unloads textures loaded for game UI
*/
/******************************************************************************/
void Map_Unload() {}