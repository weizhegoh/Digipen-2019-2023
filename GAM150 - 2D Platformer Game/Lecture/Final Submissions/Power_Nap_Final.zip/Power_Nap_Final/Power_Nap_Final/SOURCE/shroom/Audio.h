/**********************************************************************************
* \File name	 Audio.h
* \Project name  Jump!Shroom!

* \Author(s)     Wei Zhe, Goh       38 lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#pragma once
#ifndef  AUDIO_H
#define  AUDIO_H

extern bool creditsBool;
extern bool instBool;
extern bool optionsBool;
extern bool coinCollision;
extern bool powerUpCanCollision;
extern bool playerLose;
extern bool	playerGameOver;
extern bool sMushroomCollisionJump;
extern bool	increaseLife;
extern bool	freezeAndInvicible;
extern bool	levelCleared;
extern bool	JumpAndOnGround;
extern bool spawnMushrooM;
extern bool changeGameState;

void digipenLogoBG_Load();
void mainMenuBG_Load();
void cutSceneBG_Load();
void level1BG_Load();
void level2BG_Load();
void level3BG_Load();
void WinBG_Load();

void digipenLogoBG_Unload();
void mainMenuBG_Unload();
void cutSceneBG_Unload();
void level1BG_Unload();
void level2BG_Unload();
void level3BG_Unload();
void WinBG_Unload();

void AudioEngine_Load();
void AudioEngine_Initialize();
void AudioEngine_Update();
void AudioEngine_Draw();
void AudioEngine_Free();
void AudioEngine_Unload();

#endif