/**********************************************************************************
* \File name     MainMenu.h
* \Project name  Jump!Shroom!

* \Author(s)     Hong Fu, Wong       12 lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#pragma once

extern s8 Font;

// mainmenu options
extern bool		decreaseVolume;
extern bool		increaseVolume;
extern bool		setMute;
extern bool		setUnmute;

void MainMenu_Load();
void MainMenu_Init();
void MainMenu_Update();
void MainMenu_Draw();
void MainMenu_Free();
void MainMenu_Unload();