/**********************************************************************************
* \File name	 Audio.cpp
* \Project name  Jump!Shroom!

* \Author(s)	 Wei Zhe, Goh		369 Lines x 95% Code Contribution
				 Hong Fu, Wong		369 Lines x 5% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#include "shroom.h"

/******************************************************************************/
/*!
	File globals
*/
/******************************************************************************/

FMOD::System	* Syst;
FMOD::Sound		* digipenLogoBG, * mainMenuBG, * cutSceneBG, * level1BG, * level2BG, * level3BG, * gameWin, * Jump, * spawnMushroom,
				* coin,	* bluePowerUp, * playerLoseHealth, * keySelect, * enterLevel, * gameOver, * greenPowerUp, * Invisible;

FMOD::Channel	* channel1, * channel2, * channel3, *channel4;
FMOD_RESULT		result;
unsigned int	version;
void			* extradriverdata;

float			volume = 0.5f;
float			timer = 0.0f;

bool			mute = false;
bool			coinCollision = false;
bool			powerUpCanCollision = false;
bool			playerLose = false;
bool			playerGameOver = false;
bool			sMushroomCollisionJump = false;
bool			increaseLife = false;
bool			freezeAndInvicible = false;
bool			levelCleared = false;
bool			JumpAndOnGround = false;
bool			spawnMushrooM = false;
bool			changeGameState = false;

/******************************************************************************/
/*!
	"Load" audio engine function
*/
/******************************************************************************/
void AudioEngine_Load()
{
	result = FMOD::System_Create(&Syst);
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = Syst->init(32, FMOD_INIT_NORMAL, extradriverdata);
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = Syst->createSound("assert/audio/Jump.wav", FMOD_LOOP_OFF, 0, &Jump);
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = Syst->createSound("assert/audio/spawnMushroom.mp3", FMOD_LOOP_OFF, 0, &spawnMushroom);
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = Syst->createSound("assert/audio/coin.mp3", FMOD_LOOP_OFF, 0, &coin);
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = Syst->createSound("assert/audio/powerUp.mp3", FMOD_LOOP_OFF, 0, &bluePowerUp);
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = Syst->createSound("assert/audio/playerLoseHealth.wav", FMOD_LOOP_OFF, 0, &playerLoseHealth);
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = Syst->createSound("assert/audio/keySelect.wav", FMOD_LOOP_OFF, 0, &keySelect);
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = Syst->createSound("assert/audio/enterLevel.wav", FMOD_LOOP_OFF, 0, &enterLevel);
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = Syst->createSound("assert/audio/gameOver.wav", FMOD_LOOP_OFF, 0, &gameOver);
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = Syst->createSound("assert/audio/greenPowerUp.wav", FMOD_LOOP_OFF, 0, &greenPowerUp);
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = Syst->createSound("assert/audio/Invisible.wav", FMOD_LOOP_OFF, 0, &Invisible);
	if (result != FMOD_RESULT::FMOD_OK) return;
}
/******************************************************************************/
/*!
	"Load" background music function for game state splash
*/
/******************************************************************************/
void digipenLogoBG_Load()
{
	result = Syst->createSound("assert/audio/digipenLogo.wav", FMOD_LOOP_OFF, 0, &digipenLogoBG);
	if (result != FMOD_RESULT::FMOD_OK) return;

	channel1->setVolume(volume);
	result = Syst->playSound(digipenLogoBG, 0, false, &channel1);
	if (result != FMOD_RESULT::FMOD_OK) return;
}

/******************************************************************************/
/*!
	"Load" background music function for game state main menu
*/
/******************************************************************************/
void mainMenuBG_Load()
{
	result = Syst->createSound("assert/audio/mainMenuBG.flac", FMOD_LOOP_NORMAL, 0, &mainMenuBG);
	if (result != FMOD_RESULT::FMOD_OK) return;
	
	if (!setMute)
	{
		channel1->setVolume(volume);
		result = Syst->playSound(mainMenuBG, 0, false, &channel1);
		if (result != FMOD_RESULT::FMOD_OK) return;
	}
}

/******************************************************************************/
/*!
	"Load" background music function for game state cut Scene
*/
/******************************************************************************/
void cutSceneBG_Load()
{
	result = Syst->createSound("assert/audio/cutScene.wav", FMOD_LOOP_NORMAL, 0, &cutSceneBG);
	if (result != FMOD_RESULT::FMOD_OK) return;

	if (!setMute)
	{
		channel1->setVolume(volume);
		result = Syst->playSound(cutSceneBG, 0, false, &channel1);
		if (result != FMOD_RESULT::FMOD_OK) return;
	}
}

/******************************************************************************/
/*!
	"Load" background music function for game state level 1
*/
/******************************************************************************/
void level1BG_Load()
{
	result = Syst->createSound("assert/audio/level1BG.wav", FMOD_LOOP_NORMAL, 0, &level1BG);
	if (result != FMOD_RESULT::FMOD_OK) return;

	if (!setMute)
	{
		channel1->setVolume(volume);
		result = Syst->playSound(level1BG, 0, false, &channel1);
		if (result != FMOD_RESULT::FMOD_OK) return;
	}
}

/******************************************************************************/
/*!
	"Load" background music function for game state level 2
*/
/******************************************************************************/
void level2BG_Load()
{
	result = Syst->createSound("assert/audio/level2BG.mp3", FMOD_LOOP_NORMAL, 0, &level2BG);
	if (result != FMOD_RESULT::FMOD_OK) return;

	if (!setMute)
	{
		channel1->setVolume(volume);
		result = Syst->playSound(level2BG, 0, false, &channel1);
		if (result != FMOD_RESULT::FMOD_OK) return;
	}
}

/******************************************************************************/
/*!
	"Load" background music function for game state level 3
*/
/******************************************************************************/
void level3BG_Load()
{
	result = Syst->createSound("assert/audio/level3BG.mp3", FMOD_LOOP_NORMAL, 0, &level3BG);
	if (result != FMOD_RESULT::FMOD_OK) return;

	if (!setMute)
	{
		channel1->setVolume(volume);
		result = Syst->playSound(level3BG, 0, false, &channel1);
		if (result != FMOD_RESULT::FMOD_OK) return;
	}
}

/******************************************************************************/
/*!
	"Load" background music function for game state Win
*/
/******************************************************************************/
void WinBG_Load()
{
	result = Syst->createSound("assert/audio/gameWin.mp3", FMOD_LOOP_NORMAL, 0, &gameWin);
	if (result != FMOD_RESULT::FMOD_OK) return;

	if (!setMute)
	{
		channel1->setVolume(volume);
		result = Syst->playSound(gameWin, 0, false, &channel1);
		if (result != FMOD_RESULT::FMOD_OK) return;
	}
}

/******************************************************************************/
/*!
	"Initialize" audio engine function
*/
/******************************************************************************/
void AudioEngine_Initialize() 
{
	//timer = 0.0f;

	mute = false;
	coinCollision = false;
	powerUpCanCollision = false;
	playerLose = false;
	playerGameOver = false;
	sMushroomCollisionJump = false;
	increaseLife = false;
	freezeAndInvicible = false;
	levelCleared = false;
	JumpAndOnGround = false;
	spawnMushrooM = false;
	changeGameState = false;

	setUnmute = false;
}

/******************************************************************************/
/*!
	"Update" audio engine function
*/
/******************************************************************************/
void AudioEngine_Update()
{
	if (setMute)													//Press 1 to mute background music
	{
		channel1->setMute(true);
		channel2->setMute(true);
		channel3->setMute(true);
		channel4->setMute(true);
	}

	if (setUnmute)													//Press 2 to unmute background music
	{
		channel1->setMute(false);
		channel2->setMute(false);
		channel3->setMute(false);
		channel4->setMute(false);
	}

	if (decreaseVolume)												//Press 9 to decrease background music volume
	{
		channel1->getVolume(&volume);

		volume -= 0.01f;

		if (volume < 0)
		{
			volume = 0;
		}

		channel1->setVolume(volume);
	}

	if (increaseVolume)												//Press 0 to increase background music volume
	{
		channel1->getVolume(&volume);
		volume += 0.01f;

		if (volume > 1)
		{
			volume = 1;
		}

		channel1->setVolume(volume);
	}

	if (current == GS_MainMenu && !instBool && !creditsBool || pauseGame)
	{
		if ((AEInputCheckTriggered(AEVK_UP) || AEInputCheckTriggered(AEVK_DOWN)) && !setMute)
		{
			result = channel4->setVolume(volume);
			result = Syst->playSound(keySelect, 0, false, &channel4);
			if (result != FMOD_RESULT::FMOD_OK) return;
		}
	}

	if (changeGameState == true)									//if change game state, mute power up music
	{
		timer = 0;
		channel3->setMute(true);
		changeGameState = false;
	}

	if (current != GS_MainMenu && !setMute)
	{
		if (JumpAndOnGround)										//if Jump, play sound effect
		{
			result = channel2->setVolume(volume);

			if (current == GS_LevelSelect)
			{
				result = Syst->playSound(enterLevel, 0, false, &channel2);
				if (result != FMOD_RESULT::FMOD_OK) return;
				JumpAndOnGround = false;
			}
			else
			{
				result = Syst->playSound(Jump, 0, false, &channel2);
				if (result != FMOD_RESULT::FMOD_OK) return;
				JumpAndOnGround = false;
			}
		}

		if (current != GS_LevelSelect)
		{

			if (spawnMushrooM)										//if spawn mushroom, play sound effect
			{
				result = channel2->setVolume(volume);
				result = Syst->playSound(spawnMushroom, 0, false, &channel2);
				if (result != FMOD_RESULT::FMOD_OK) return;
				spawnMushrooM = false;
			}
		}
	}

	if (coinCollision && !setMute)									//if collision with coin, play sound effect
	{
		result = channel2->setVolume(volume);
		result = Syst->playSound(coin, 0, false, &channel2);

		if (result != FMOD_RESULT::FMOD_OK) return;
		coinCollision = false;
	}

	if (powerUpCanCollision && !setMute)				 			//if collision with blue power up can, play sound effect
	{
		result = channel2->setVolume(volume);
		result = Syst->playSound(bluePowerUp, 0, false, &channel2);
		if (result != FMOD_RESULT::FMOD_OK) return;
		powerUpCanCollision = false;
	}

	if (playerLose && !setMute)										//if player loses health, play sound effect
	{
		result = channel2->setVolume(volume);
		result = Syst->playSound(playerLoseHealth, 0, false, &channel2);
		if (result != FMOD_RESULT::FMOD_OK) return;
		playerLose = false;
	}

	if (playerGameOver && !setMute)									//if player loses 3 health and game over. Play Sound effect
	{
		result = channel2->setVolume(volume);
		result = Syst->playSound(gameOver, 0, false, &channel2);
		if (result != FMOD_RESULT::FMOD_OK) return;
		playerGameOver = false;
	}

	if (sMushroomCollisionJump && !setMute)							//if player is on top spawned mushroom, play jump sound effect.
	{
		result = channel2->setVolume(volume);
		result = Syst->playSound(Jump, 0, false, &channel2);
		if (result != FMOD_RESULT::FMOD_OK) return;
		sMushroomCollisionJump = false;
	}

	if (increaseLife && !setMute)									//if collide with green power, play sound effect
	{
		result = channel2->setVolume(volume);
		result = Syst->playSound(greenPowerUp, 0, false, &channel2);
		if (result != FMOD_RESULT::FMOD_OK) return;
		increaseLife = false;
	}

	if (freezeAndInvicible && !setMute)								//if pressed A or S, play power up music for a period of time
	{
		timer = 10.0f;

		result = channel3->setVolume(volume);
		result = Syst->playSound(Invisible, 0, false, &channel3);
		if (result != FMOD_RESULT::FMOD_OK) return;
		freezeAndInvicible = false;
	}

	if (levelCleared && !setMute)									//if level cleared, play sound effect
	{
		result = channel2->setVolume(volume);
		result = Syst->playSound(enterLevel, 0, false, &channel2);
		if (result != FMOD_RESULT::FMOD_OK) return;
		levelCleared = false;
	}
	
	if (pauseGame)
	{
		channel1->setPaused(true);
		channel3->setPaused(true);

		channel2->setPaused(true);
	}
	else if(!pauseGame)
	{
		channel3->setPaused(false);

		if (timer > 0)												//when timer is triggered, mute all background music
		{
			timer -= g_dt;
			channel1->setPaused(true);
		}
		else														//when timer is not triggered, play background music
		{
			channel1->setPaused(false);
			
			channel2->setPaused(false);
		}
	}
	
	if (!pauseGame && restartGame == YES)
	{
		timer = 0.0f;
		channel3->setMute(true);
		channel3->setPaused(false);
	}

	result = Syst->update();										//update audio system
	if (result != FMOD_RESULT::FMOD_OK) return;
}

/******************************************************************************/
/*!
	"Update" audio engine function
*/
/******************************************************************************/
void AudioEngine_Draw() {}

/******************************************************************************/
/*!
	"Free" audio engine function
*/
/******************************************************************************/
void AudioEngine_Free() {}

/******************************************************************************/
/*!
	"Unload" audio engine function
*/
/******************************************************************************/
void AudioEngine_Unload()
{
	result = Jump->release();
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = spawnMushroom->release();
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = coin->release();
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = bluePowerUp->release();
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = playerLoseHealth->release();
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = keySelect->release();
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = enterLevel->release();
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = gameOver->release();
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = greenPowerUp->release();
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = Invisible->release();
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = Syst->close();
	if (result != FMOD_RESULT::FMOD_OK) return;

	result = Syst->release();
	if (result != FMOD_RESULT::FMOD_OK) return;
}

/******************************************************************************/
/*!
	"Unload" background music for game state splash
*/
/******************************************************************************/
void digipenLogoBG_Unload()
{
	result = digipenLogoBG->release();
	if (result != FMOD_RESULT::FMOD_OK) return;
}

/******************************************************************************/
/*!
	"Unload" background music for game state main menu
*/
/******************************************************************************/
void mainMenuBG_Unload()
{
	result = mainMenuBG->release();
	if (result != FMOD_RESULT::FMOD_OK) return;
}

/******************************************************************************/
/*!
	"Unload" background music for game state cut scene
*/
/******************************************************************************/
void cutSceneBG_Unload()
{
	result = cutSceneBG->release();
	if (result != FMOD_RESULT::FMOD_OK) return;
}


/******************************************************************************/
/*!
	"Unload" background music for game state level 1
*/
/******************************************************************************/
void level1BG_Unload()
{
	result = level1BG->release();
	if (result != FMOD_RESULT::FMOD_OK) return;
}

/******************************************************************************/
/*!
	"Unload" background music for game state level 2
*/
/******************************************************************************/
void level2BG_Unload()
{
	result = level2BG->release();
	if (result != FMOD_RESULT::FMOD_OK) return;
}

/******************************************************************************/
/*!
	"Unload" background music for game state level 3
*/
/******************************************************************************/
void level3BG_Unload()
{
	result = level3BG->release();
	if (result != FMOD_RESULT::FMOD_OK) return;
}

/******************************************************************************/
/*!
	"Unload" background music for game state Win
*/
/******************************************************************************/
void WinBG_Unload()
{
	result = gameWin->release();
	if (result != FMOD_RESULT::FMOD_OK) return;
}