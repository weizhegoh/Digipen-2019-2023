/**********************************************************************************
* \File name		Enemy.cpp
* \Project name		Jump!Shroom!

* \Author(s)		Yan Han, Dong		91 Lines x 60.5% Code Contribution
					Benjamin Liew       91 Lines x 36.25% Code Contribution
					Wei Zhe, Goh		91 Lines x 3.25% Code Contribution 

* \Copyright information
	All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#include "shroom.h"
#include "PowerUp.h"

const float			MOVE_VELOCITY_ENEMY = 7.5f;
const double		ENEMY_IDLE_TIME = 2.0;
const float			ENEMY_ROT_SPEED = (2.0f * PI);	// enemy rotation speed (degree/second)

extern				PowerUp Blue;

/******************************************************************************/
/*!
	Call this function for AI
*/
/******************************************************************************/
void EnemyStateMachine(GameObjInst* pInst)
{

	switch (pInst->state)
	{

	case STATE::STATE_GOING_LEFT: // ENEMY GOING LEFT

		pInst->dirCurr += ENEMY_ROT_SPEED * g_dt;

		switch (pInst->innerState)
		{
		case INNER_STATE::INNER_STATE_ON_ENTER:
			pInst->velCurr.x = -MOVE_VELOCITY_ENEMY;
			pInst->innerState = INNER_STATE::INNER_STATE_ON_UPDATE;
			//pInst->dirCurr = ENEMY_ROT_SPEED * g_dt;

			break;
		case INNER_STATE::INNER_STATE_ON_UPDATE: //ENEMY BOUNDARY CHECK

			if (Blue.freeze)
			{
				pInst->velCurr.x = 0;
				pInst->counter = Blue.durationCounter;
				pInst->innerState = INNER_STATE::INNER_STATE_ON_PAUSE;
			}

			if (pInst->gridCollisionFlag & COLLISION_LEFT
				|| GetCellValue(static_cast<int>(pInst->posCurr.x - 0.5), static_cast<int>(pInst->posCurr.y - 1)) != 1)
			{
				pInst->velCurr.x = 0;
				pInst->counter = ENEMY_IDLE_TIME;
				pInst->innerState = INNER_STATE::INNER_STATE_ON_EXIT;
			}

			break;
		case INNER_STATE::INNER_STATE_ON_PAUSE: //If FREEZE ability is activated, ALL enemy stop it's movement
			if (Blue.durationCounter <= 0.0f)
			{
				//pInst->dirCurr += ENEMY_ROT_SPEED * g_dt;
				pInst->velCurr.x = -MOVE_VELOCITY_ENEMY;
				pInst->innerState = INNER_STATE::INNER_STATE_ON_UPDATE;
			}
			break;
		case INNER_STATE::INNER_STATE_ON_EXIT: //REACH THE END OF THE PLATFORM, CHANGE DIRECTION
			pInst->counter -= g_dt;
			if (pInst->counter <= 0)
			{
				pInst->state = STATE::STATE_GOING_RIGHT;
				pInst->innerState = INNER_STATE::INNER_STATE_ON_ENTER;
			}
			break;
		}
		break;

	case STATE::STATE_GOING_RIGHT: // ENEMY GOING RIGHT

		pInst->dirCurr -= ENEMY_ROT_SPEED * g_dt;

		switch (pInst->innerState)
		{
		case INNER_STATE::INNER_STATE_ON_ENTER:
			pInst->velCurr.x += MOVE_VELOCITY_ENEMY;
			pInst->innerState = INNER_STATE::INNER_STATE_ON_UPDATE;
			break;
		case INNER_STATE::INNER_STATE_ON_UPDATE: //ENEMY BOUNDARY CHECK
			if (Blue.freeze)
			{
				pInst->velCurr.x = 0;
				pInst->counter = Blue.durationCounter;
				pInst->innerState = INNER_STATE::INNER_STATE_ON_PAUSE;
			}
			if (pInst->gridCollisionFlag & COLLISION_RIGHT
				|| GetCellValue(static_cast<int>(pInst->posCurr.x + 0.5), static_cast<int>(pInst->posCurr.y - 1)) != 1)
			{
				pInst->velCurr.x = 0;
				pInst->counter = ENEMY_IDLE_TIME;
				pInst->innerState = INNER_STATE::INNER_STATE_ON_EXIT;
			}
			break;
		case INNER_STATE::INNER_STATE_ON_PAUSE: //If FREEZE ability is activated, ALL enemy stop it's movement
			if (Blue.durationCounter <= 0.0f)
			{
				//pInst->dirCurr -= ENEMY_ROT_SPEED * g_dt;
				pInst->velCurr.x = MOVE_VELOCITY_ENEMY;
				pInst->innerState = INNER_STATE::INNER_STATE_ON_UPDATE;
			}
			break;
		case INNER_STATE::INNER_STATE_ON_EXIT: //REACH THE END OF THE PLATFORM, CHANGE DIRECTION
			pInst->counter -= g_dt;
			if (pInst->counter <= 0)
			{
				pInst->state = STATE::STATE_GOING_LEFT;
				pInst->innerState = INNER_STATE::INNER_STATE_ON_ENTER;
			}
			break;
		}
	}
}