/**********************************************************************************
* \File name	 Graphic.h
* \Project name  Jump!Shroom!

* \Author(s)     Wei Zhe, Goh  24 lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#pragma once

extern bool isLevel2;
extern bool isLevel3;
extern bool isLevel4;
extern float U, V;

void blackObject_Load();
void whiteObject_Load();

void characterTexture_Load();
void enemyTexture_Load();
void coinTexture_Load();
void bluePowerUpTexture_Load();
void greenPowerUpTexture_Load();
void spawnMushroomTexture_Load();

void level1Object_Load();
void level2Object_Load();
void level3Object_Load();

void level1Background_Load();
void level2Background_Load();
void level3Background_Load();

void graphic_Initialize();
void graphic_Update();
void graphic_Draw();
void graphic_Free();
void graphic_Unload();