/**********************************************************************************
* \File name     Collision.cpp
* \Project name  Jump!Shroom!

* \Author(s)	 Yan Han, Dong				97 lines x 82.5% Code Contribution
				 Hong Fu, Wong				97 lines x 17.5% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/
#include "shroom.h"
/****************************************************************************/
/*!
\fn CollisionIntersection_RectRect(const AABB& aabb1, const AEVec2& Vecl1,
									const AABB& aabb2, const AEVec2& vel2)

\brief AABB collision check

\param const AABB& aabb1

\param const AEVec2& Vecl1

\param const AABB& aabb2

\param const AEVec2& vel2

\returns boolen
*/
/****************************************************************************/

bool CollisionIntersection_RectRect(const AABB& aabb1, const AEVec2& vel1,
	const AABB& aabb2, const AEVec2& vel2)
{
	/*
		Implement the collision intersection over here.

		The steps are:
		Step 1: Check for static collision detection between rectangles (before moving).

		*/
	bool collisionBool = false;

	if (aabb1.max.x <= aabb2.min.x || aabb1.min.x >= aabb2.max.x
		|| aabb1.max.y <= aabb2.min.y || aabb1.min.y >= aabb2.max.y)
	{
		AEVec2 rVel{ vel2.x - vel1.x, vel2.y - vel1.y };

		// Check for relative velocity 0
		if (fabsf(rVel.x) < FLT_EPSILON)
		{
			if ((aabb1.min.x > aabb2.max.x) || (aabb2.min.x > aabb1.max.x))
				return false;
		}
		if (fabsf(rVel.y) < FLT_EPSILON)
		{
			if ((aabb1.min.y > aabb2.max.y) || (aabb2.min.y > aabb1.max.y))
				return false;
		}
		collisionBool = true;
	}
	/*
	If the check returns no overlap you continue with the following next steps (dynamics).
	Otherwise you return collision true
	*/

	/*
	Step 2: Initialize and calculate the new velocity of Vb
			tFirst = 0
			tLast = dt
	*/
	if (collisionBool)
	{
		float tFirst = 0;
		float tLast = g_dt;
		AEVec2 vB{ vel2.x - vel1.x, vel2.y - vel1.y };
		//Step 3: Working with one dimension (x-axis).

		/*
		if (Vb < 0)
			case 1
			case 4
		*/
		if (vB.x < 0)
		{
			//case 1
			if (aabb1.min.x > aabb2.max.x)
			{
				return false;
			}

			//case 4
			if (aabb1.max.x < aabb2.min.x)
			{
				tFirst = max((aabb1.max.x - aabb2.min.x) / vB.x, tFirst);
			}
			if (aabb1.min.x < aabb2.max.x)
			{
				tLast = min((aabb1.min.x - aabb2.max.x) / vB.x, tLast);
			}
		}
		/*
		if(Vb > 0)
				case 2
				case 3
		*/
		if (vB.x > 0)
		{
			//case 2
			if (aabb1.min.x > aabb2.max.x)
			{
				tFirst = max((aabb1.min.x - aabb2.max.x) / vB.x, tFirst);
			}
			if (aabb1.max.x > aabb2.min.x)
			{
				tLast = min((aabb1.max.x - aabb2.min.x) / vB.x, tLast);
			}
			//case 3
			if (aabb1.max.x < aabb2.min.x)
			{
				return false;
			}
		}
		//case 5
		if (tFirst > tLast)
		{
			return false;
		}

		//Step 4: Repeat step 3 on the y - axis
		if (vB.y < 0)
		{
			//case 1
			if (aabb1.min.y > aabb2.max.y)
			{
				return false;
			}

			//case 4
			if (aabb1.max.y < aabb2.min.y)
			{
				tFirst = max((aabb1.max.y - aabb2.min.y) / vB.y, tFirst);
			}
			if (aabb1.min.x < aabb2.max.x)
			{
				tLast = min((aabb1.min.y - aabb2.max.y) / vB.y, tLast);
			}
		}
		if (vB.y > 0)
		{
			//case 2
			if (aabb1.min.y > aabb2.max.y)
			{
				tFirst = max((aabb1.min.y - aabb2.max.y) / vB.y, tFirst);
			}
			if (aabb1.max.y > aabb2.min.x)
			{
				tLast = min((aabb1.max.y - aabb2.min.y) / vB.y, tLast);
			}
			//case 3
			if (aabb1.max.y < aabb2.min.y)
			{
				return false;
			}
		}
		//case 5
		if (tFirst > tLast)
		{
			return false;
		}

	}
	//Step 5: Otherwise the rectangles intersect
	return true;

}