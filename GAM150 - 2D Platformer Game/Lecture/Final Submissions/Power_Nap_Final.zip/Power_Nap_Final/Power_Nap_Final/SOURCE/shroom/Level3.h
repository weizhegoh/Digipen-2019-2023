/**********************************************************************************
* \File name	 Level3.h
* \Project name  Jump!Shroom!

* \Author(s)	 Benjamin Liew		7 Lines x 100% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#pragma once

void Level3_Load();			// Loads level 3
void Level3_Initialize();	// Inits level 3
void Leve13_Update();		// Update level 3
void Leve13_Draw();			// Draws level 3
void Leve13_Free();			// Free level 3
void Leve13_Unload();		// Unloads level 3

