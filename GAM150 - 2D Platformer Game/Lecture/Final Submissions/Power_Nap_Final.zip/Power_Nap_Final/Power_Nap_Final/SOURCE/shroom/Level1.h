/**********************************************************************************
* \File name	 Level1.h
* \Project name  Jump!Shroom!

* \Author(s)	 Hong Fu, Wong       17 lines x 88% Code Contribution
				 Benjamin Liew	     17 lines x 12% Code Contribution

* \Copyright information
 All content � 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.
**********************************************************************************/

#pragma once
#include "Object.h"

extern const unsigned int	GAME_OBJ_NUM_MAX;		//The total number of different objects (Shapes)
extern const unsigned int	GAME_OBJ_INST_NUM_MAX;	//The total number of different game object instances
extern bool					updateScore;			//Check for lives and score update
extern bool					updateLives;			//Check for lives and score update
extern int					coinCounter;			//Total Coin Count
extern float				powerUp;				//Power up duration
extern bool					displayDeath;			//Death message
extern const float			TIME;					//Default time
extern float				TIMER;					//timer

void Level1_Load();									// Loads level 1
void Level1_Initialize();							// Init level 1
void Level1_Update();								// Updates level 1
void Level1_Draw();									// Draws level 1
void Level1_Free();									// Frees level 1
void Level1_Unload();								// Unloads level 1
