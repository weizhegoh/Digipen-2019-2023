*******
Summary
*******
Game name: Jump! Shroom!
Team name: Power_Nap!

GAM150Su20-a

High Concept: We play as a jumping mushroom trying to collect coins to reach 
	      the next stage. You can create mushrooms to use as jumppads and 
              collect powerups to use skills. 

All content © 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.

************************
Installation Instruction
************************

1. Click into Power_Nap_Final folder.
2. Click into INSTALLATION folder. 
3. Click into INSTALLER folder. 
4. Double click on Jump! Shroom!_Setup.exe and run it. 

***********
How To Play
***********
Press "Enter" to select in main menu
Press "Esc" to return to main menu
Press "F" to fullscreen

Press < or > key to move
Press "Space" to jump
Press "D" to spawn mushroom
Press "S" to use freeze power up (collect blue can)

***********
Cheat codes
***********
 - None

*******
Credits
*******

Digipen Institute of Technology
All content © 2020 DigiPen (SINGAPORE) Corporation, all rights reserved.

Developed by team Power_Nap:

Members (roles): 
- Benjamin Liew (Game Designer)
- Dong Yan Han  (Technical Director)
- Goh Wei Zhe   (Producer)
- Wong Hong Fu  (Product & Playtest Manager)

Instructors: 
- Yannick Gerber
- Elie Hosry

President:
- Claude Comair

Executives:
- Jason Chu 
- John Bauer
- Samir Abou Samra
- Raymond Yan
- Prasanna Ghali 
- Michele Comair
- Xin Li 
- Angela Kugler 
- Melvin Gonsalvez
- Meighan Mckelvey
