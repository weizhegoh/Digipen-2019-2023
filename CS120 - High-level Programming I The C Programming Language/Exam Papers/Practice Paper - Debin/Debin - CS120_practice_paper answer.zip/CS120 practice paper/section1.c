#include <stdio.h>

//#define Q1
//#define Q3
//#define Q4
//#define Q7
//#define Q8
//#define Q9
//#define Q10
//#define Q11
//#define Q12
//#define Q13
//#define Q14

#ifdef Q11
typedef struct s
{
  int   i[10];
  char  c;
  short s;
  float f;
};
#endif

#ifdef Q12
typedef struct s
{
  char   c[5];
  int    i[10];
  float  s;
  double d;
};
#endif

int main()
{
#ifdef Q9
  int i, j;
  int a[] = { 1, 2, 3, 4, 5 };
  
  for(i = 0; i < sizeof(a)/sizeof(a[0]); ++i)
  {
    int result = a[i];
    
    for(j = i + 1; j < sizeof(a)/sizeof(a[0]); ++j)
      result += a[j];
    
    printf("%d", result);
  }
#endif

#ifdef Q10
  int val = 100;
  int i = 0;
  
  while(val)
  {
    val /= 3;
    if(val%2)
      val += 12;
    ++i;
  }
  
  printf("%d|%d",i,val);
#endif

#ifdef Q11
  printf("sizeof(s) = %d", sizeof(struct s));
#endif

#ifdef Q12
  printf("sizeof(s) = %d", sizeof(struct s));
#endif

#ifdef Q13
  int i,j,k;
  int * pj = &j;
  int * pk = &k;
  const int ci = 5;
  
  ci = 10
  ci = i;
  i = ci;
  pj = k;
  *pj = *pk;
  pj = pk;
#endif

#ifdef Q14
  double a[] = { 100.0, 200.0, 300.0, 400.0, 500.0 };
  
  printf("address of &a = %p\n", &a);
  printf("address of &a[0] = %p\n", &a[0]);
  printf("address of *(a+2) = %p\n", *(a+2));
  printf("address of *(a+8) = %p\n", *(a+8));
  printf("address of *(a+10-5) = %p\n", *(a+10-5));
  printf("address of -5+a = %p\n", -5+a);
#endif
  
  return 0;
}