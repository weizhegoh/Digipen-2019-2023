#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>

//#define Q15
//#define Q16
//#define Q17
#define Q18

#ifdef Q15
void flipfile(const char* filename)
{
  FILE * file;
  file = fopen(filename, "r+"); // r+ - read and update the file
  char * filedata = NULL;
  int i,j, length = 0;
  
  if(file)
  {
    fseek(file, 0, SEEK_END);
    length = ftell(file);
    rewind(file);
    filedata = (char*)malloc(length);
    
    if (filedata)
    {
      // the whole file into filedata
      // the seek is at the end of the file
      fread(filedata, 1, length, file);
      
      // flip the content being read in
      for(i = 0, j = length-1; i < j; ++i, --j)
      {
        char tmp = *(filedata + i);
        *(filedata + i) = *(filedata + j);
        *(filedata + j) = tmp;
      }
      
      // move the seek back to the start of the file
      rewind(file);
      fwrite(filedata, 1, length, file);
      free(filedata);
    }
    
    fclose(file);
  }
  else
  {
    printf("fail to open file!\n");
    printf("error: %d\n", errno);
  }
}
#endif

#ifdef Q16
size_t my_strlen(const char * a)
{
  size_t len = 0;
  
  while(*(a++) != '\0')
    ++len;
  
  return len;
}
#endif

#ifdef Q17
unsigned highestElemCount(int * a, unsigned sz)
{
  unsigned** table = malloc(sz*sizeof(unsigned*));
  unsigned i, j, tableSz = 0, highest;
  int inTable = 0;
  
  // check if the current integer is in the table
  // if it is in the table then increment the count
  // else add the integer to the table, set the count as 1
  // and increament the table count
  for(i = 0; i < sz; ++i)
  {
    inTable = 0;
    for(j = 0; j < tableSz; ++j)
    {
      if(table[j][0] == a[i])
      {
        ++table[j][1];
        inTable = 1;
        break;
      }
    }
    
    if(!inTable)
    {
      table[tableSz] = malloc(2*sizeof(unsigned));
      table[tableSz][0] = a[i];
      table[tableSz][1] = 1;
      ++tableSz;
    }
  }
  
  // get the highest count in the table
  highest = table[0][1];
  for(i = 1; i < tableSz; ++i)
  {
    if(table[i][1] > highest)
      highest = table[i][1];
  }
  
  // free all the memory allocation
  for(i = 0; i < tableSz; ++i)
    free(table[i]);
  free(table);
  
  return highest;
}
#endif

#ifdef Q18
  typedef struct
  {
    int x;
    int y;
  }vec2;
  
  typedef enum
  {
    PISTOL,
    RIFLE
  }WEAPONS;
  
  typedef struct
  {
    vec2 pos;
    vec2 m_dir;            // movement direction
    vec2 f_dir;            // facing direction
    int speed;
    int health;
    WEAPONS weapon;
  }Player, Enemy, P_or_E;
  
  typedef struct
  {
    vec2 pos;
    vec2 dir;
    int speed;
  }Bullet;
  
  P_or_E* SpawnPlayerEnemy()
  {
    P_or_E* p_or_e = (P_or_E*)malloc(sizeof(P_or_E));
    
    p_or_e->pos.x = rand()%100;
    p_or_e->pos.y = rand()%100;
    p_or_e->m_dir.x = 0;
    p_or_e->m_dir.y = 0;
    p_or_e->f_dir.x = rand()%2;
    p_or_e->f_dir.y = rand()%2;
    p_or_e->speed = 0;
    p_or_e->health = 1000;
    p_or_e->weapon = rand()%2;
    
    return p_or_e;
  }
  
  void UpdatePos(vec2* pos, const vec2 dir, int speed)
  {
    pos->x += dir.x * speed;
    pos->y += dir.y * speed;
  }
#endif

int main(int argc, char ** argv)
{
  #ifdef Q15
    flipfile("test.txt");
  #endif
  
  #ifdef Q16
    size_t len = 0;
    len = my_strlen("string");
    printf("len of 'string' = %d", len);
  #endif
  
  #ifdef Q17
    unsigned count = 0;
    int a[10] = { 1, 2, 3, 1, 1, 3, 4, 1, 5, 2 };
    count = highestElemCount(a,10);
    printf("count: %u", count);
  #endif
  
  #ifdef Q18
  int i = 0;
  srand(time(0));
  
  Player* player = SpawnPlayerEnemy();
  Enemy* enemy = SpawnPlayerEnemy();
  
  for(i = 1; i <= 10; ++i)
  {
    printf("frame %d:\n", i);
    printf("player curr pos: {%d, %d}\n", player->pos.x, player->pos.y);
    printf("enemy curr pos: {%d, %d}\n", enemy->pos.x, enemy->pos.y);
    
    printf("\n");
    
    player->speed = rand()%11+1;  // ranged from [1,10)
    player->m_dir.x = rand()%3-1; // ranged from [-1,1]
    player->m_dir.y = rand()%3-1;
    
    enemy->speed = rand()%11+1;
    enemy->m_dir.x = rand()%3-1;
    enemy->m_dir.y = rand()%3-1;
    
    UpdatePos(&(player->pos), player->m_dir, player->speed);
    printf("player new pos: {%d, %d}\n", player->pos.x, player->pos.y);
    printf("player dir: {%d, %d}\n", player->m_dir.x, player->m_dir.y);
    printf("player speed: %d\n", player->speed);
    
    UpdatePos(&(enemy->pos), enemy->m_dir, enemy->speed);
    printf("enemy new pos: {%d, %d}\n", enemy->pos.x, enemy->pos.y);
    printf("enemy dir: {%d, %d}\n", enemy->m_dir.x, enemy->m_dir.y);
    printf("enemy speed: %d\n", enemy->speed);
    
    printf("\n");
  }
  
  free(player);
  free(enemy);
  #endif
  
  return 0;
}