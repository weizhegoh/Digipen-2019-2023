#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <time.h>

#define min(a, b) ((a < b) ? a : b)

#ifdef q1
void flipfile(const char* filename)
{
  FILE * file;
  file = fopen(filename, "r+"); /* r+ - read and update the file */
  char * filedata = NULL;
  int i,j, length = 0;
  
  if(file)
  {
    fseek(file, 0, SEEK_END);
    length = ftell(file);
    rewind(file);
    filedata = (char*)malloc(length);
    
    if (filedata)
    {
      /* read the whole file into filedata
         the seek is at the end of the file */
      fread(filedata, 1, length, file);
      
      /* flip the content being read in */
      for(i = 0, j = length-1; i < j; ++i, --j)
      {
        char tmp = *(filedata + i);
        *(filedata + i) = *(filedata + j);
        *(filedata + j) = tmp;
      }
      
      /* move the seek back to the start of the file */
      rewind(file);
      fwrite(filedata, 1, length, file);
      free(filedata);
    }
    
    fclose(file);
  }
  else
  {
    printf("fail to open file!\n");
    printf("error: %d\n", errno);
  }
}
#elif defined(q2)
unsigned highestElemCount(int * a, unsigned sz)
{
  unsigned** table = malloc(sz*sizeof(unsigned*));
  unsigned i, j, tableSz = 0, highest;
  int inTable = 0;
  
  /* check if the current integer is in the table
     if it is in the table then increment the count
     else add the integer to the table, set the count as 1
     and increament the table count */
  for(i = 0; i < sz; ++i)
  {
    inTable = 0;
    for(j = 0; j < tableSz; ++j)
    {
      if(table[j][0] == a[i])
      {
        ++table[j][1];
        inTable = 1;
        break;
      }
    }
    
    if(!inTable)
    {
      table[tableSz] = malloc(2*sizeof(unsigned));
      table[tableSz][0] = a[i];
      table[tableSz][1] = 1;
      ++tableSz;
    }
  }
  
  /* get the highest count in the table */
  highest = table[0][1];
  for(i = 1; i < tableSz; ++i)
  {
    if(table[i][1] > highest)
      highest = table[i][1];
  }
  
  /* free all the memory allocation */
  for(i = 0; i < tableSz; ++i)
    free(table[i]);
  free(table);
  
  return highest;
}
#elif defined(q3)
enum ACTION
{
  EAT,
  SLEEP,
  EXERCISE,
  WORK,
  CRY,
  NOTHING,
  NUMACTIONS
};

struct Human
{
  /* curr action */
  enum ACTION action;
  
  /* list of available actions to run */
  void (*bindedFuncs[NUMACTIONS])(); 
  
  int hunger, tiredness;
  int sadness, time;
};

void eat(){ printf("eating\n"); }
void sleep(){ printf("sleeping\n"); }
void exercise(){ printf("exercising\n"); }
void work(){ printf("working\n"); }
void cry(){ printf("crying\n"); }
void giveUpAndFlipTable(){ printf("flip table ┻━┻︵\\(°□°)/︵┻━┻\n"); }

int myrandom(int min, int max)
{
  return min + rand()%(max-min);
}

void think(struct Human* human)
{
  human->hunger = myrandom(human->hunger,100);
  human->tiredness = myrandom(human->tiredness,100);
  human->sadness = myrandom(human->sadness,100);
  human->time = myrandom(human->time,24);
  
  if(human->sadness >= 90)
    human->action = CRY;
  else if(human->hunger >= 90)
    human->action = EAT;
  else if(human->tiredness >= 80)
    human->action = SLEEP;
  else if(human->time >= 8 && human->time <= 10)
    human->action = WORK;
  else if(human->time >= 18)
    human->action = EXERCISE;
  else
    human->action = NOTHING;
}

void act(struct Human* human)
{
  human->bindedFuncs[human->action]();
  
  switch(human->action)
  {
    case EAT:
      human->hunger = 0;
      break;
    case SLEEP:
      human->tiredness = 0;
      human->time += 7;
      break;
    case EXERCISE:
      ++(human->time);
      break;
    case WORK:
      human->time += 8;
      break;
    case CRY:
      human->sadness = 0;
      break;
    case NOTHING:
      human->time += 2;
      break;
  }
  
  if(human->time >= 24)
    human->time -= 24;
}

void runhuman(struct Human* human)
{
  human->bindedFuncs[0] = eat;
  human->bindedFuncs[1] = sleep;
  human->bindedFuncs[2] = exercise;
  human->bindedFuncs[3] = work;
  human->bindedFuncs[4] = cry;
  human->bindedFuncs[5] = giveUpAndFlipTable;
  
  think(human);
  act(human);
  
  printf("hunger = %d\n", human->hunger);
  printf("tiredness = %d\n", human->tiredness);
  printf("sadness = %d\n", human->sadness);
  printf("time = %d\n\n", human->time);
}
#endif

int main(int argc, char ** argv)
{
  #ifdef q1
    flipfile("test.txt");
  #elif defined(q2)
    unsigned count = 0;
    int a[10] = { 1, 2, 3, 1, 1, 3, 4, 1, 5, 2 };
    count = highestElemCount(a,10);
    printf("count: %u", count);
  #elif defined(q3)
    srand(0);
    struct Human human;
    human.hunger = human.tiredness = human.sadness = human.time = 0;
    for(int i = 0; i < 10; ++i)
      runhuman(&human);
  #endif
  
  return 0;
}