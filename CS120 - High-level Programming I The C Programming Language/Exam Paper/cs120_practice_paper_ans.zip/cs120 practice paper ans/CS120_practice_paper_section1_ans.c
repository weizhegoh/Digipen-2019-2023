#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#ifdef q1
void Q1()
{
  printf("a. |5, %d|\n", 10);
  printf("b. |%i, %f|\n", 1, 3.0f);
  printf("c. |%c, %u|\n", 72, -1);
  printf("d. |%3d|\n", 10);
  printf("e. |%-3d|\n", 10);
  printf("f. |%2d|\n", 100.0f); 
  printf("g. |%*d|\n", 5, 20);
}
#elif defined(q2)
void q2_a()
{
  int x;
  scanf("%d", &x); /*input: 10*/
  printf("a. x = %d\n", x);
  while ((getchar()) != '\n');
}

void q2_b()
{
  int x,y;
  scanf("%d, %d", &x, &y); /*input: 3, 3*/
  printf("b. x = %d, y = %d\n", x,y);
  while ((getchar()) != '\n');
}

void q2_c()
{
  float x;
  char  y;
  int   z;
  
  scanf("%f %c %d", &x, &y, &z); /*input: 10 51 1*/
  printf("c. x = %f, y = %c, z = %d\n", x,y,z);
  while ((getchar()) != '\n');
}

void q2_de(int q)
{
  int    x;
  float  y;
  char   z;
  double w;
  
  scanf("%i, %f, %c, %lf", &x, &y, &z, &w); /*d. input: 4, 5.0f, ‘a’, 6.0*/
                                            /*e. input: 4 5.0f, ‘a’, 6.0*/
  if(q)
    printf("e. ");
  else
    printf("d. ");
  printf("x = %i, y = %f, z = %c, w = %lf\n", x,y,z,w);
  while ((getchar()) != '\n');
}

void Q2()
{
  int tmp;
  q2_a();
  q2_b();
  q2_c();
  q2_de(0);
  q2_de(1);
}
#elif defined(q3)
typedef enum vals
{
  ZERO,
  ONE
} vals;

void Q3()
{
  vals value = 0;
  
  switch(value)
  {
    case 0:
    case ZERO: /* should not compile at this line */
      break;
    case ONE:
      break;
    case e:    /* should not compile at this line */
      break;
    case 10*20:
      break;
  }
}
#elif defined(q4)
void Q4()
{
  int a = 0;
  if(++a, a/10)
    printf("condition passed");
  else
    printf("condition failed");
}
#elif defined(q7)
void Q7()
{
  int a = 0,b = 0,c = 0,d = 0,x = 0,y = 0;
  
  a * b -- + c * -- b;
  x + ++y * x - a + b;
  ---x * y + a -- b * c++;  /* should not compile for this line */
  a - -b * c / a + d++ - b;
}
#elif defined(q8)
void Q8()
{
  printf("a. 1<<2 = %d\n",1<<2);
  printf("b. 20>>1 = %d\n",20>>1);
  printf("c. 10>>3 = %d\n",10>>3);
  printf("d. (-1)<<1 = %d\n",(-1)<<1);
  printf("e. (-1)>>1 = %d\n",(-1)>>1);
  printf("f. (-5)>>1 = %d\n",(-5)>>1);
  printf("g. 10^8 = %d\n",10^8);
  printf("h. 4&5 = %d\n",4&5);
  printf("i. 9|12 = %d\n",9|12);
  printf("j. ~6 = %d\n",~6);
}
#elif defined(q14)
void Q14()
{
  int i = 10;
  const int ci = i;
  int* pi = &i;
  ++*pi--;
  ++*--pi;
  ++(*pi)--;  /* should not compile at this line */
  const int* cpi = &ci;
  ++cpi; /*potential R, undefined behaviour to be exact*/
  free(pi);   /* causes runtime error */
  free(cpi);  /* causes runtime error */
}
#elif defined(q16)
int func(int x)
{
  if(x > 3)
  {
    printf("%i\n",x);
    return x;
  }
  
  return func(x+func(x+1));
}

void Q16()
{
  printf("\nfunc(1) = %i", func(1));
}
#elif defined(q19)
struct S
{
  char c0[3];
  double d;
  short s;
  int i;
  char c1[10];
};

void Q19()
{
  struct S s;
  
  printf("a. &c0[0] = %d\n",1000 + ((void*)&s.c0[0]-(void*)&s));
  printf("a. &d = %d\n",1000 + ((void*)&s.d-(void*)&s));
  printf("a. &s = %d\n",1000 + ((void*)&s.s-(void*)&s));
  printf("a. &c1[5] = %d\n",1000 + ((void*)&s.c1[5]-(void*)&s));
  printf("a. &d + 10 = %d\n",1000 + ((void*)(&s.d + 10)-(void*)&s));
  printf("a. &i - 20 = %d\n",1000 + ((void*)(&s.i-20)-(void*)&s));
}
#elif defined(q23)
void Q23()
{
  int** arr;
  int i = 0;
  size_t leak = 0,sz = 0;
  
  /* create an array of 32 int* */
  leak = sz = sizeof(int*)*sizeof(int)*sizeof(long);
  arr = malloc(sz);
  
  /* malloc all 32 int* */
  for(i = 0; i < sizeof(long double)*2; ++i)
  {
    sz = sizeof(long double)+i*pow(-1,i);
    if(i > sizeof(double))
      leak += sz;
    arr[i] = malloc(sz);
  }
  
  /* #bytes leaked after the following lines */
  printf("leaked = %d bytes\n", leak);
  
  /* free the 1st 9 int* */
  for(i = 0; i < 5; ++i)
  {
    free(arr[i]);
    free(arr[sizeof(double)-i]);  /* made a mistake here, this will cause a undefined behaviour */
                                  /* exercise: find out why it causes undefined behaviour */
  }
}
#elif defined(q24)
struct S_a
{
  int   i[10];
  char  c;
  short s;
  float f;
};

struct S_b
{
  char   c[5];
  int    i[10];
  float  s;
  double d;
};

void Q24()
{
  printf("sizeof(S_a) = %d\n", sizeof(struct S_a));
  printf("sizeof(S_b) = %d\n", sizeof(struct S_b));
}
#elif defined(q28)
struct A
{
  int i;
  float f;
  char c[3];
};

struct B
{
  double d;
  struct A a;
  char* ptr;
};

void Q28()
{
  struct B b;
  b.d = 10.0;
  b.a.i = 20;
  b.a.f = 3.0f;
  b.a.c[0] = 'c';
  b.a.c[1] = '+';
  b.a.c[2] = '+';
  
  b.ptr = (char*)(&b.d)+18;
  *(b.ptr) = b.d + b.a.i + b.a.f;
  
  printf("d = %f\n",b.d);
  printf("a.i = %d\n",b.a.i);
  printf("a.f = %f\n",b.a.f);
  printf("a.c = (%c,%c,%c)\n",b.a.c[0],b.a.c[1],b.a.c[2]);
}
#endif

int main()
{
#ifdef q1
  Q1();
#elif defined(q2)
  Q2();
#elif defined(q3)
  Q3();
#elif defined(q4)
  Q4();
#elif defined(q7)
  Q7();
#elif defined(q8)
  Q8();
#elif defined(q14)
  Q14();
#elif defined(q16)
  Q16();
#elif defined(q19)
  Q19();
#elif defined(q23)
  Q23();
#elif defined(q24)
  Q24();
#elif defined(q28)
  Q28();
#endif
}