/****************************************************************************
filename [add_big_nums.c] 
author [Goh Wei Zhe] 
DP email [weizhe.goh@digipen.edu]
course CS120
section A 
date [9th November 2019]
Brief Description: This file contains the 2 functions
****************************************************************************/

/****************************************************************************
Function: AddBigSum()
Description: Takes in addresses of 2 BigNumber array and their respective
length and the address of the output array. Add 2 number arrays into sum array. 
Inputs: size_t and char variables 

size_t i = counter
size_t greatestLength - store the greater length among the 2 number array
unsigned char c - Pointer c   

Outputs: Return the number of significant digits in the resulting sum
****************************************************************************/
/****************************************************************************
Function: PrettyPrintSum()
Description: Takes in address of 3 BigNumber array and the number of their 
respective significant digits.
Inputs: size_t variables 

size_t i = counter
size_t greatestLength - store the greater length among the 3 number array

Outputs: Prints the sum in a prettified manner. 
****************************************************************************/

#include "add_digit.h"

extern size_t AddBigSum(BigNumber num1, size_t num1_len, BigNumber num2,
size_t num2_len, BigNumber sum)
{
  size_t i;
  size_t greatestLength=0;
  unsigned char c = 0;

  if(num1_len>=num2_len)
  {
    greatestLength = num1_len;
    
    for (i=0;i<=num2_len-1;i++)
    {
      sum[num1_len-1-i]= AddDigit(num1[num1_len-1-i],num2[num2_len-1-i],&c);
    }
    
    if(num1_len!=num2_len)
    {
      for(;i<=num1_len-1;i++)
      {
        sum[num1_len-1-i]= AddDigit(num1[num1_len-1-i],0,&c);
      }
    }
    
  }else
   if(num2_len>=num1_len)
     {
        greatestLength = num2_len;
    
        for (i=0;i<=num1_len-1;i++)
        {
          sum[num2_len-1-i]= 
          AddDigit(num1[num1_len-1-i],num2[num2_len-1-i],&c);
        }
        
        if(num1_len!=num2_len)
        {
          for(;i<=num2_len-1;i++)
          {
            sum[num2_len-1-i]= AddDigit(0,num2[num2_len-1-i],&c);
          }
        }
     }
     return greatestLength;
}

extern void PrettyPrintSum(BigNumber num1, size_t num1_len, BigNumber num2,
size_t num2_len, BigNumber sum,  size_t sum_len)
{
  size_t i;
  size_t greatestLength=0;
   
  if(num1_len>=num2_len && num1_len>=sum_len)
  {
    greatestLength=num1_len;
  }
   
  if (num2_len>=num1_len && num2_len>=sum_len)
  {
    greatestLength = num2_len;
  }
   
  if (sum_len>=num1_len && sum_len>=num2_len)
  {
    greatestLength=sum_len;
  }
     
  for (i=0; i<(greatestLength-(num1_len))+2;i++)
  {
    printf(" ");
  }
    
  for(i=0;i<num1_len;i++)
  {
    printf("%d",(int)(num1[i]));
  }
   
    printf("\n");
    printf("+ ");
  
  for (i=0; i<(greatestLength-(num2_len));i++)
  {
    printf(" ");
  }
    
  for(i=0;i<num2_len;i++)
  {
    printf("%d",(int)(num2[i]));
  }
   
  printf("\n");
   
  for (i=0;i<greatestLength+2;i++)
  {
    printf("-");
  }
    
  printf("\n");
   
  for (i=0; i<(greatestLength-(sum_len))+2;i++)
  {
    printf(" ");
  }
     
  for(i=0;i<sum_len;i++)
  {
    printf("%d",(int)(sum[i]));
  } 
  printf("\n");
 }
    
    
    
     
    
     
   

    