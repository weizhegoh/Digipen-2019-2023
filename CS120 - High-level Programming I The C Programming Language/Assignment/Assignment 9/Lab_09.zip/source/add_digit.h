#ifndef ADD_DIGIT_H
#define ADD_DIGIT_H

#define CRT_SECURE_NO_WARNINGS

#include <stdio.h>

typedef unsigned char BigDigit;
typedef BigDigit* BigNumber;

/******************************************************************************
 * You must define these functions.                                           *
 ******************************************************************************/

extern size_t AddBigSum(
	BigNumber num1, size_t num1_len,
	BigNumber num2, size_t num2_len,
	BigNumber sum
);

extern void PrettyPrintSum(
	BigNumber num1, size_t num1_len,
	BigNumber num2, size_t num2_len,
	BigNumber sum,  size_t sum_len
);

/******************************************************************************
 * You must use this function.                                                *
 ******************************************************************************/

BigDigit AddDigit(BigDigit digit1, BigDigit digit2, BigDigit *carry);

#endif
