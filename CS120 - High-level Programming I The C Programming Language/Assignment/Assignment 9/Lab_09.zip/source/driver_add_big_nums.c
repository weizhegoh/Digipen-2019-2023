#include <stdlib.h>

#include "add_digit.h"

unsigned int called = 0;

/******************************************************************************
 * These functions have been defined in this file after main().               *
 ******************************************************************************/

BigDigit AsciiToDigit(char character);
BigDigit AddDigit(BigDigit digit1, BigDigit digit2, BigDigit *carry);
size_t StringToBigNumber(const char* const string, BigNumber number);
void PrettyPrintStrings(const char* in1, const char* in2, const char* in3);
void AddBigStrings(const char* in1, const char* in2);

/******************************************************************************
 * Test driver.                                                               *
 ******************************************************************************/

void test_PrettyPrintSum(void)
{
	PrettyPrintStrings(
		"123",
		"456",
		"789345"
	);
	printf("\n");
	PrettyPrintStrings(
		"38942938588",
		"8092010461941764",
		"55057839278052"
	);
	printf("\n");
	PrettyPrintStrings(
		"0",
		"8960238801",
		"52272535417416149"
	);
	printf("\n");
	PrettyPrintStrings(
		"0546723737800550742",
		"4692129",
		"166389602636221390874025"
	);
	printf("\n");
	PrettyPrintStrings(
		"351767983670665905036068167",
		"6097194894",
		"71375289436108175532"
	);
}

void test_AddBigStrings(void)
{
	printf("\n");
	AddBigStrings("0", "0");
	printf("\n");
	AddBigStrings("0", "5");
	printf("\n");
	AddBigStrings("5", "0");
	printf("\n");
	AddBigStrings("10", "4");
	printf("\n");
	AddBigStrings("14", "4");
	printf("\n");
	AddBigStrings("10000", "1000");
	printf("\n");
	AddBigStrings("10000", "1234");
	printf("\n");
	AddBigStrings("2103304", "3557040");
	printf("\n");
	AddBigStrings(
		"492358267338223333628632935656",
		"6812538795997748941351275296794624212683611641315635972314764214943671\
3944989423391414"
	);
}

int main(void)
{
	test_PrettyPrintSum();
	test_AddBigStrings();
	return 0;
}

/******************************************************************************
 * Definitions of all the helper functions.                                   *
 ******************************************************************************/

BigDigit AsciiToDigit(char character)
{
	return (BigDigit)(character - '0');
}

size_t StringToBigNumber(const char* const string, BigNumber number)
{
	size_t i = 0;
	const char* character = string;

	while (*character != '\0')
	{
		number[i++] = AsciiToDigit(*(character++));
	}
	return i;
}

BigDigit AddDigit(BigDigit digit1, BigDigit digit2, BigDigit *carry)
{
	BigDigit sum = (BigDigit)(digit1 + digit2 + *carry);
	called++;
	*carry = (sum / 10);
	return (sum % 10);
}

void PrettyPrintStrings(const char* in1, const char* in2, const char* in3)
{
	BigDigit num1[100], num2[100], sum[100];
	size_t num1_len, num2_len, sum_len;

	num1_len = StringToBigNumber(in1, num1);
	num2_len = StringToBigNumber(in2, num2);
	sum_len  = StringToBigNumber(in3, sum);

	PrettyPrintSum(num1, num1_len, num2, num2_len, sum, sum_len);
}

void AddBigStrings(const char* in1, const char* in2)
{
	BigDigit num1[100], num2[100], sum[100] = {0};
	size_t num1_len, num2_len, sum_len;

	num1_len = StringToBigNumber(in1, num1);
	num2_len = StringToBigNumber(in2, num2);
	sum_len = AddBigSum(num1, num1_len, num2, num2_len, sum);
	
	PrettyPrintSum(num1, num1_len, num2, num2_len, sum, sum_len);

	if (called)
	{
		if (called > 1)
		{
			printf("AddDigit is called %d times\n", called);
		}
		else
		{
			printf("AddDigit is called %d time\n", called);
		}
		called = 0;
	}
}
