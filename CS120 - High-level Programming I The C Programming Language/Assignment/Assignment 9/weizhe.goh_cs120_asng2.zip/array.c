/****************************************************************************
filename [array.c] 
author [Goh Wei Zhe] 
DP email [weizhe.goh@digipen.edu]
course CS120
section A 
date [5th November 2019]
Brief Description: This file contains the 5 functions
****************************************************************************/

/****************************************************************************
Function: reverse_array()
Description: Reverse the order of elements in array A
Inputs: int and size_t variables 

int a[] - array A with N number of elements
size_t length - length of array
int i - counter
int b - store variables in array[i] temporarily

Outputs: Prints out array A in a reversed order.
****************************************************************************/

/****************************************************************************
Function: add_arrays()
Description: Add two arrays a and b with same given length into array c. 
Inputs: const int, int and size_t variables

const int a[] - array a with N number of elements
const int b[] - array b with N number of elements
int c[] - array c with N number of elements
size_t length - length of array

Outputs: Prints out array c which is the sum of array a and b
****************************************************************************/

/****************************************************************************
Function: scalar_multiply()
Description: Mutiply each element in array A by a value multiplier
Inputs: int and size_t variables 

int a[] - array a with N number of elements
size_t length - size of array 
int multiplier - value to be multiplied by 

Outputs: Prints out scaled or multiplied values of array a.
****************************************************************************/

/****************************************************************************
Function: dot_product()
Description: Determine the dot product value by multiplying corresponding 
elements and sum of all the products. 
Inputs: const int and size_t variables 

const int a[] - array a with N number of elements
const int b[] - array b with N number of elements
size_t length - length of array

Outputs: Prints out the dot product value of array a and b. 
****************************************************************************/

/****************************************************************************
Function: cross_product()
Description: Determine the cross product for array a and b and put results
in array c.  
Inputs: const int and int variables 

const int a[] - array a with N number of elements
const int b[] - array b with N number of elements
int c[] - array of 3 elements

Outputs: Prints out the cross product of array a and b into array c. 
****************************************************************************/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "functions.h"  

void reverse_array(int a[], size_t length)
{
 int b;
 int i;
 
 for (i=0;i<(int)(length)/2; i++)
 {
   b=a[i];
   a[i]=a[(int)length-1-i];
   a[(int)length-1-i]=b;
 }
}

void add_arrays(const int a[], const int b[], int c[], size_t length)
{
  int i;
  
  for (i=0;i<(int)length;i++)
  {
    c[i]=a[i]+b[i]; 
  }
}

void scalar_multiply(int a[], size_t length, int multiplier)
{
  int i;
  
  for(i=0;i<(int)length;i++)
  {
    a[i]=a[i]*multiplier;
  }
}

int dot_product(const int a[], const int b[], size_t length)
{
 int value=0;
 int i;
 
 for(i=0;i<(int)length;i++)
 {
   value+=a[i]*b[i];
 }
 return value;
}

void cross_product(const int a[], const int b[], int c[])
{
  c[0]= a[1]*b[2] - a[2]*b[1];
  c[1]= -(b[2]*a[0] - b[0]*a[2]);
  c[2] = a[0]*b[1] - a[1]*b[0];
}
