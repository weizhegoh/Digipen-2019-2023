#include <stdio.h>    /* printf */
#include <stdlib.h> /* rand, srand */

#include "functions.h"

/*******************************************************************************
 * HELPER FUNCTIONS                                                            *
 ******************************************************************************/

/* Generates a random number between low (inclusive) and high (inclusive). */
int generate_random_int(int low, int high)
{
    return rand() % (high - low + 1) + low;
}

/* Prints elements of the array. */
void print_array(const int* const a, size_t length)
{
    size_t i;
    for (i = 0; i < length; ++i)
    {
        printf("%5i", a[i]);
    }
    printf("\n");
}

/* Prints elements of two arrays with appropriate captions. */
void print_arrays(const int* const a, const int* const b, size_t length)
{
    printf("Array a:");
    print_array(a, length);
    printf("Array b:");
    print_array(b, length);
}

/*******************************************************************************
 * TEST CASES                                                                  *
 ******************************************************************************/

void reverse_test(void)
{
    #ifndef REV_SIZE
    #define REV_SIZE 100
    #endif

    int a[] = {8};
    int b[] = {1, 2, 3};
    int c[] = {1, 2, 3, 4};
    int d[REV_SIZE];
    size_t i;

    for (i = 0; i < REV_SIZE; ++i)
    {
        d[i] = generate_random_int(1, REV_SIZE);
    }

    printf("Reverse test =============================\n");

    printf("The original arrays:\n");
    print_array(a, 1);
    print_array(b, 3);
    print_array(c, 4);
    print_array(d, REV_SIZE);

    reverse_array(a, 1);
    reverse_array(b, 3);
    reverse_array(c, 4);
    reverse_array(d, REV_SIZE);

    printf("The reversed arrays:\n");
    print_array(a, 1);
    print_array(b, 3);
    print_array(c, 4);
    print_array(d, REV_SIZE);

    printf("\n");
}

void add_test(void)
{
    #ifndef ADD_SIZE
    #define ADD_SIZE 100
    #endif

    int a[ADD_SIZE];
    int b[ADD_SIZE];
    int c[ADD_SIZE];
    size_t i;

    for (i = 0; i < ADD_SIZE; ++i)
    {
        a[i] = generate_random_int(-100, 100);
        b[i] = generate_random_int(-100, 100);
    }

    printf("Add test =============================\n");

    printf("The original arrays:\n");
    print_arrays(a, b, ADD_SIZE);

    add_arrays(a, b, c, ADD_SIZE);

    printf("The sum of the two arrays:\n");
    print_array(c, ADD_SIZE);

    printf("\n");
}

void scalar_multiply_test(void)
{
    #ifndef SCALAR_SIZE
    #define SCALAR_SIZE 100
    #endif

    int a[SCALAR_SIZE];
    int multiplier;
    size_t i;

    for (i = 0; i < SCALAR_SIZE; i++)
    {
        a[i] = generate_random_int(-100, 100);
    }

    printf("Scalar multiply test =============================\n");

    printf("The original array:\n");
    print_array(a, SCALAR_SIZE);

    multiplier = 2;
    scalar_multiply(a, SCALAR_SIZE, multiplier);
    printf("The array multiplied by %i:\n", multiplier);
    print_array(a, SCALAR_SIZE);

    multiplier = 5;
    scalar_multiply(a, SCALAR_SIZE, multiplier);
    printf("And now multiplied by %i:\n", multiplier);
    print_array(a, SCALAR_SIZE);

    printf("\n");
}

void dot_product_test(void)
{
    #ifndef ARRAY_SIZE
    #define ARRAY_SIZE 100
    #endif

    int a[ARRAY_SIZE];
    int b[ARRAY_SIZE];
    size_t i;
    int product;

    for (i = 0; i < ARRAY_SIZE; ++i)
    {
        a[i] = generate_random_int(-10, 10);
        b[i] = generate_random_int(-10, 10);
    }

    printf("Dot product test =============================\n");

    printf("The original arrays:\n");
    print_arrays(a, b, ARRAY_SIZE);

    product = dot_product(a, b, ARRAY_SIZE);
    printf("The dot product of a and b is %i\n", product);

    product = dot_product(a, a, ARRAY_SIZE);
    printf("The dot product of a and a is %i\n", product);

    product = dot_product(b, b, ARRAY_SIZE);
    printf("The dot product of b and b is %i\n", product);

    printf("\n");
}

void cross_product_test(void)
{
    #define ITERATIONS   10
    #define ARRAY_SIZE_X 3
    typedef int array_int3[ARRAY_SIZE_X];
    array_int3 a;
    array_int3 b;
    array_int3 c;
    int i, j;

    printf("Cross product test =============================\n");

    for (i = 0; i < ITERATIONS; i++)
    {
        for (j = 0; j < ARRAY_SIZE_X; j++)
        {
            /* Fill arrays with random values */
            a[j] = generate_random_int(-10, 10);
            b[j] = generate_random_int(-10, 10);
        }

        printf("The original arrays:\n");
        print_arrays(a, b, ARRAY_SIZE_X);

        cross_product(a, b, c);
        printf("The cross product of a x b is:");
        print_array(c, ARRAY_SIZE_X);
    }
}

/*******************************************************************************
 * MAIN PROGRAM                                                                *
 ******************************************************************************/

int main(void)
{
    srand(5);

    reverse_test();
    add_test();
    scalar_multiply_test();
    dot_product_test();
    cross_product_test();

    return 0;
}
