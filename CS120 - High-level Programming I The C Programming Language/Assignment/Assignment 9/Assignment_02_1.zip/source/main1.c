#include <stdio.h>  /* printf */
#include <stdlib.h> /* rand, srand */

#include "functions.h"

/*******************************************************************************
 * HELPER FUNCTIONS                                                            *
 ******************************************************************************/

/* Generates a random number between low (inclusive) and high (inclusive). */
int generate_random_int(int low, int high)
{
    return rand() % (high - low + 1) + low;
}

/* Prints elements of the array. */
void print_array(const int* const a, size_t length)
{
    size_t i;
    for (i = 0; i < length; ++i)
    {
        printf("%5i", a[i]);
    }
    printf("\n");
}

/* Prints elements of two arrays with appropriate captions. */
void print_arrays(const int* const a, const int* const b, size_t length)
{
    printf("Array a:");
    print_array(a, length);
    printf("Array b:");
    print_array(b, length);
}

/*******************************************************************************
 * TEST CASES                                                                  *
 ******************************************************************************/

void test_reverse_array(int* const a, size_t length)
{
    printf("Array a:\n");
    print_array(a, length);
    reverse_array(a, length);
    printf("Array a after reversing:\n");
    print_array(a, length);
}

void test_add_arrays(int* const a, int* const b, int* c, size_t length)
{
    printf("Array b:\n");
    print_array(b, length);
    add_arrays(a, b, c, length);
    printf("Array c (sum of array a and array b):\n");
    print_array(c, length);
}

void test_scalar_multiply(int* c, size_t length)
{
    scalar_multiply(c, length, 10);
    printf("All values of c multiplied by 10:\n");
    print_array(c, length);
}

void test_dot_product(const int* a, const int* b, size_t length)
{
    print_arrays(a, b, length);
    printf("The dot product of (a * b) is %i\n", dot_product(a, b, length));
}

void test_cross_product(const int* a, const int* b)
{
    int c[3];
    print_arrays(a, b, 3);
    cross_product(a, b, c);
    printf("The cross product of (a x b) is:");
    print_array(c, 3);
}

/* Tests basic mathematic functions. */
void test1(void)
{
    int a[] = {1, 2, 3, 4, 5, 6, 7, 8};
    int b[] = {4, 6, 8, 2, 4, 3, 5, 8};
    size_t length = sizeof(a) / sizeof(a[0]);
    int c[sizeof(a) / sizeof(a[0])];

    test_reverse_array(a, length);
    test_add_arrays(a, b, c, length);
    test_scalar_multiply(c, length);
}

/* Tests the dot product and the cross product implementations. */
void test2(void)
{
    int a[] = {1, 2, 3};
    int b[] = {3, 4, 7};
    size_t length = sizeof(a) / sizeof(a[0]);

    test_dot_product(a, b, length);
    test_cross_product(a, b);
}

/* Tests the dot product on two slightly longer arrays. */
void test3(void)
{
    #ifndef SIZE1
    #define SIZE1 10
    #endif

    int a[SIZE1];
    int b[SIZE1];
    size_t i;

    srand(2);
    for (i = 0; i < SIZE1; ++i)
    {
        a[i] = generate_random_int(-5, 5);
        b[i] = generate_random_int(-5, 5);
    }

    print_arrays(a, b, SIZE1);

    printf("The dot product of (a * b) is %i\n", dot_product(a, b, SIZE1));
}

/* Tests the dot product on two long arrays. */
void test4(void)
{
    #ifndef SIZE2
    #define SIZE2 1000
    #endif

    int a[SIZE2];
    int b[SIZE2];
    size_t i;

    srand(2);
    for (i = 0; i < SIZE2; ++i)
    {
        a[i] = generate_random_int(-10, 10);
        b[i] = generate_random_int(-10, 10);
    }

    print_arrays(a, b, SIZE2);

    printf("The dot product of (a * b) is %i\n", dot_product(a, b, SIZE2));
}

/*******************************************************************************
 * MAIN PROGRAM                                                                *
 ******************************************************************************/

int main(void)
{
    test1();
    test2();
    test3();
    test4();
    return 0;
}
