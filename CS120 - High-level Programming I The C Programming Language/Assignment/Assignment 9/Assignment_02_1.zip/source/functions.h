#include <stdio.h>

#ifndef _FUNCTIONS_H_
#define _FUNCTIONS_H_

void reverse_array(
	int a[],
	size_t length);

void add_arrays(
	const int a[],
	const int b[],
	int c[],
	size_t length);

void scalar_multiply(
	int a[],
	size_t length,
	int multiplier);

int dot_product(
	const int a[],
	const int b[],
	size_t length);

void cross_product(
	const int a[],
	const int b[],
	int c[]);

#endif
