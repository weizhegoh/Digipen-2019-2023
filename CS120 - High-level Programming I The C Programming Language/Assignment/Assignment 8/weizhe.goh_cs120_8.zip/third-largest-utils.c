/****************************************************************************
filename [third-largest-utils.c] 
author [Goh Wei Zhe] 
DP email [weizhe.goh@digipen.edu]
course CS120
section A 
date [1st November 2019]
Brief Description: This file contains the 5 functions
****************************************************************************/

/****************************************************************************
Function: ReadInTotalNumIntegers()
Description: Read total number of integers
Inputs: int variables 

int num - store the number of integers

Outputs: Prints the user input if number is more than or equal to 3. If not,
print message and exit program.
****************************************************************************/

/****************************************************************************
Function: ReadInFirst3Numbers()
Description: Scan the first 3 numbers
Inputs: pointers variables 

int *first - store value of num1
int *second - store value of num2 
int *third - store value of num3

Outputs: Prints out 3 intergers scanned from the user input.
****************************************************************************/

/****************************************************************************
Function: Swap()
Description: swap the values between 2 *lhs and *rhs variables
Inputs: int and variables variables 

int temp - store temporary values
int *lhs - store value of num1
int *rhs - store value of num2

Outputs: Prints out the swapped value of lhs and rhs.
****************************************************************************/

/****************************************************************************
Function: Sort3Numbers
Description: Sort 3 numbers according from largest to smallest number
Inputs: int and pointer variables 

int *first - store value of num1
int *second - store value of num2 
int *third - store value of num3

Outputs: Prints out the 1st number as the largest number, 2nd number as the
second largest number and 3rd number as the third largest number 
****************************************************************************/

/****************************************************************************
Function: Maintain3Largest
Description: Generate invoice program
Inputs: int and pointer variables 

int temp - store temporary values
int *first - store value of num1
int *second - store value of num2 
int *third - store value of num3

Outputs: Prints the 3 largest value in deceding order after inputting a 
4th value
****************************************************************************/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>


  int ReadInTotalNumIntegers(void)
  {
    int num;
    printf("Please enter the number of integers:");
    
    if(scanf("%d",&num)==1 && num<3)
    {
      printf("There is no third largest number.\n");
      exit(0);
    }
    return num;
  }
  
  void ReadInFirst3Numbers(int *first, int*second, int*third)
  {
    scanf("%d %d %d", first, second, third);
  }
  
  void Swap(int *lhs,int *rhs)
  {
    int temp;
    temp=*lhs;
    *lhs=*rhs;
    *rhs=temp;
  }
  
   void Sort3Numbers(int *first, int*second, int*third)
  {
    if(*first<*second)
    {
      Swap(first,second);
    }
    
    if(*first<*third)
    {
      Swap(first,third);
    }
    
    if(*second<*third)
    {
      Swap(second,third);
    }
  }
  
  void Maintain3Largest(int number, int*first, int*second, int*third)
  {
    if(number>*first)
    {
      *third=*second;
      *second=*first;
      *first=number;
    }
    
    if(number>*second && number<*first)
    {
      *third=*second;
      *second=number;
    }
    
    if(number>*third && number<*second)
    {
      *third=number;
    }
  }
  
  
  
  