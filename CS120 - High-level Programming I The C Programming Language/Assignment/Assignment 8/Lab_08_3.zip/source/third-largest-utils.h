#ifndef THIRD_LARGEST_UTILS_H
#define THIRD_LARGEST_UTILS_H

int ReadInTotalNumIntegers(void);

void ReadInFirst3Numbers(
    int *first,
    int *second,
    int *third);

void Swap(
    int *lhs,
    int *rhs);

void Sort3Numbers(
    int *first,
    int *second,
    int *third);

void Maintain3Largest(
    int number,
    int *first,
    int *second,
    int *third);

#endif
