#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "third-largest-utils.h"

int main(void)
{
    int num1, num2, num3;
    ReadInFirst3Numbers(&num1, &num2, &num3);
    Sort3Numbers(&num1, &num2, &num3);
    printf("%d %d %d\n", num1, num2, num3);
    return 0;
}
