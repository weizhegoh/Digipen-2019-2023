#include <stdio.h>
#include "third-largest-utils.h"

int main(void)
{
    int num;
    num = ReadInTotalNumIntegers();
    printf("num is %d\n", num);
    return 0;
}
