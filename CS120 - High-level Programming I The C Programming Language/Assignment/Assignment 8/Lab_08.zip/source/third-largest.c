#include <stdio.h>
#include "third-largest-utils.h"

int main(void)
{
    #define INT_MIN (int)0x80000000
    int num;
    int largest = INT_MIN,
        second_largest = INT_MIN,
        third_largest = INT_MIN;

    num = ReadInTotalNumIntegers();
    ReadInFirst3Numbers(&largest, &second_largest, &third_largest);
    Sort3Numbers(&largest, &second_largest, &third_largest);
    num -= 3;
    while (num--)
    {
        int number;
        scanf("%d", &number);
        Maintain3Largest(number, &largest, &second_largest, &third_largest);
    }
    printf("The third largest number is %d\n", third_largest);
    return 0;
}
