/****************************************************************************
filename [macro.c] 
author [Goh Wei Zhe] 
DP email [weizhe.goh@digipen.edu]
course CS120
section A 
date [12th October 2019]
Brief Description: This file contains the main function
****************************************************************************/

/****************************************************************************
Function: main
Description: Demostrate macro parameters
Inputs: int variables
int x;
Outputs: print value of x from calculation with macro N defined as 100 
****************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#ifndef N
#define N 100
#endif


int main (void)
{
  int x = (N*49) + (N%79);
  
  printf("%d",x);
  return 0;
}