/****************************************************************************
filename [nth-largest.c] 
author [Goh Wei Zhe] 
DP email [weizhe.goh@digipen.edu]
course CS120
section A 
date [12th October 2019]
Brief Description: This file contains the main function
****************************************************************************/

/****************************************************************************
Function: main
Description: Calculate the nth-largest number from numerous user input
Inputs: int variables
int num - number of integers from user input.
int inputIndex - counter to scan all the user input.
int arrayIndex - counter to compare user input if is larger than numbers
stored in array.
int shiftIndex - counter to shift all values by one position in the array. 
int array[N] - store all nth highest integer from user into an array. 
int input - stores the value of user input.
Outputs: prints out value of Nth largest number where N = 3 as default.
****************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <limits.h>
#ifndef N
#define N 3
#endif
#define LOWEST 0x80000000

int main(void)
{
  int numM,i,inputIndex,arrayIndex,shiftIndex,array[N],input;
  printf("Please enter the number of integers: ");

  for(i=0;i<N;i++)
  {
    array[i]=(int)LOWEST;
  }

  if(scanf("%d",&numM)==1)
  {
    if(numM<N)
    {
      printf("There is no Nth largest number and N=%d\n", N);
    }
    else
    {
      for(inputIndex=0;inputIndex<numM;++inputIndex)
      {
        scanf("%d",&input);
        
        for(arrayIndex=0;arrayIndex<N;++arrayIndex)
        {
          if(input>array[arrayIndex])
          {
            for(shiftIndex=N-1;shiftIndex>arrayIndex;--shiftIndex)
            {
              array[shiftIndex]=array[shiftIndex-1];
            }
            array[shiftIndex]= input;
            break;
          }
        }
      }
      printf("The Nth largest number is %d where N=%d\n",array[N-1],N);
    }
  }
  return 0;
}