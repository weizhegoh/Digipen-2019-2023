/****************************************************************************
filename [third-largest.c] 
author [Goh Wei Zhe] 
DP email [weizhe.goh@digipen.edu]
course CS120
section A 
date [12th October 2019]
Brief Description: This file contains the main function
****************************************************************************/

/****************************************************************************
Function: main
Description: Calculate the third largest number from numerous user input
Inputs: int variables
int num - number of integers from user input  
int temp - store values temporarily as a backup  
int largest - stores largest number out of all current inputs
int second -stores 2nd largest number out of all current inputs
int third -stores 3rd largest number out of all current inputs
Outputs: prints out value of the variable third
****************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main (void)
{
  int num,temp;
  int largest=0;
  int second=0;
  int third=0;
  
  printf("Please enter the number of integers: ");
  if(scanf("%d", &num)==1)
  {
    if(num<=2)
    {
      printf("There is no third largest number.\n");
    }
    else
    {
      while (--num >=0)
      {
        scanf("%d",&temp);
        if(temp>largest || !largest)
        {
          third=second;
          second=largest;
          largest=temp;
        }
        else
          if((temp>second && temp<largest) ||!second)
          {
            third=second;
            second=temp;
          } 
          else 
            if((temp>third && temp<second) ||!third)
            {
              third=temp;
            }
      }
      printf("The third largest number is %d\n",third);
    }
  }
  return 0;
}
