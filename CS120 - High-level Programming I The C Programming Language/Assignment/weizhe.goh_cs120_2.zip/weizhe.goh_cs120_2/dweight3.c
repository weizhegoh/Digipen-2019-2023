#include <stdio.h>

int main(void)
{
	int height, length, width, volume; 
	double weight, kilogram;
	printf("Enter height of box: ");
	scanf("%d", &height);
	printf("Enter length of box: ");
	scanf("%d", &length);
	printf("Enter width of box: ");
	scanf("%d", &width);
	volume = height * length * width;
	weight = (volume + 165) / 166;
	kilogram = weight*0.453592;
	printf("Volume (cubic inches): %d\n", volume);
	printf("Dimensional weight (kg): %.2f\n", kilogram);
	return 0;
}	
