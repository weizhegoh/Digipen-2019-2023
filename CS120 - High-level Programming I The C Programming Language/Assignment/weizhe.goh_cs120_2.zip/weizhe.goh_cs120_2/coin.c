#include <stdio.h>

int main (void)
{
  double value =0;
	int dollar=0; 
	int fiftycent=0;
	int twentycent =0; 
	int tencent=0;
	int fivecent=0;
	int onecent=0;
	
	printf("Please enter total value: ");
	scanf("%lf",&value);

	while(value >= 1)
	{
		value = value - 1;
		dollar++;
	}
	while(value >=0.50)
	{
		value = value - 0.50;
		fiftycent++;
	}	
	while (value >=0.20)
	{
		value = value - 0.20;
		twentycent++;
	}
	while (value >= 0.10)
	{
		value = value - 0.10;
		tencent++;
	}
	while (value >= 0.05)
	{
		value = value - 0.05;
		fivecent++;
	}
	while (value >= 0.01)
	{
		value = value - 0.01;
		onecent++;
	}	
		
		printf("You need %d one dollar coins\n", dollar);  
		printf("You need %d fifty cent coins\n", fiftycent);
		printf("You need %d twenty cent coins\n", twentycent);
		printf("You need %d ten cent coins\n", tencent);
		printf("You need %d five cent coins \n", fivecent);
		printf("You need %d one cent coins \n", onecent); 
		
		return 0;
}