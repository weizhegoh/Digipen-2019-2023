#ifndef _TILE_STATE_H_
#define _TILE_STATE_H_

/****************************************************************************
Function: Enumeration 
Description: list the types of tile state
Inputs:

NO_ADJACENT_BOMBS - tile has no adjacent bomb
ONE_ADJACENT_BOMB - tile has one adjacent bombs
TWO_ADJACENT_BOMBS - tile has two adjacent bombs
THREE_ADJACENT_BOMBS - tile has three adjacent bombs
FOUR_ADJACENT_BOMBS - tile has four adjacent bombs
FIVE_ADJACENT_BOMBS - tile has five adjacent bombs
SIX_ADJACENT_BOMBS - tile has six adjacent bombs
SEVEN_ADJACENT_BOMBS - tile has seven adjacent bombs
EIGHT_ADJACENT_BOMBS - tile has eight adjacent bombs
BOMB - tile is a bomb

Outputs: set tile to bomb and it amount of adjacent bombs
****************************************************************************/

typedef enum
{
NO_ADJACENT_BOMBS,
ONE_ADJACENT_BOMB,
TWO_ADJACENT_BOMBS,
THREE_ADJACENT_BOMBS,
FOUR_ADJACENT_BOMBS,
FIVE_ADJACENT_BOMBS,
SIX_ADJACENT_BOMBS,
SEVEN_ADJACENT_BOMBS,
EIGHT_ADJACENT_BOMBS,
BOMB
} TileState;


#endif
