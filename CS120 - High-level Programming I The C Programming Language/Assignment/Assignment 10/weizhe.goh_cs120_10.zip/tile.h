#include "tile_state.h"
#include "tile_visibility.h"
#ifndef _TILE_H_
#define _TILE_H_

/****************************************************************************
Function: typedef struct 
Description: structure to store tile state and tile visbility
Inputs:

Tilestate state - set tile state 
TileVisibility visible - set tile visbility

Outputs: set variables for tiles 
****************************************************************************/

typedef struct
{
  TileState state;
  TileVisibility visible;
} tile;  

#endif
