/****************************************************************************
filename [sweeper.c] 
author [Goh Wei Zhe] 
DP email [weizhe.goh@digipen.edu]
course CS120
section A 
date [21th November 2019]
Brief Description: This file contains the 7 functions
****************************************************************************/

/****************************************************************************
Function: Inputs()
Description: Prompt user input for random seed, width, height, probability
Inputs: unsigned int 

unsigned int seed - user input random seed number
unsigned int width - user input width of grid 
unsigned int height - user input height of grid
unsigned int probability - user input probability of bomb

Outputs: scan user input and exit program if user input 0
****************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "tile_state.h"
#include "tile_visibility.h"
#include "tile.h"
  
  unsigned int x,y,column,row,Seed,Width,Height,counter=0,numBomb=0;
  float tile_probability, Probability;
  
  FILE* file;
  tile** map;

void Inputs()
{
  printf("Enter a random seed: ");
  scanf("%u",&Seed);
  fprintf(file, "%u\n", Seed);

  if(Seed==0)
  {
    fclose(file);
    exit(0);
  }
  
  srand(Seed);
  printf("Enter the width of a map: ");
  scanf("%u",&Width);
  fprintf(file, "%u\n", Width);
  
  if(Width==0)
  {
    fclose(file);
    exit(0);
  }
  
  printf("Enter the height of a map: ");
  scanf("%u",&Height);
  fprintf(file, "%u\n", Height);
  
  if(Height==0)
  {
    fclose(file);
    exit(0);
  }
  
  printf("Enter the probability of a bomb: \n");
  scanf("%f",&Probability);
  fprintf(file, "%f\n", Probability);
  
  if(Probability==0)
  {
    fclose(file);
    exit(0);
  }
}

/****************************************************************************
Function: tile** CreateMap()
Description: Allocate memory and create map  
Inputs: unsigned int, float

unsigned int height - height of grid
unsigned int width - width of grid
float probability - probability of bomb

Outputs: Allocate bomb tiles and count the number of adjacent bombs 
****************************************************************************/

tile** CreateMap(unsigned int height, unsigned int width,float probability)
{ 
  map = calloc(height,sizeof(tile*));
  for(row=0;row<height;++row)
  {
    map[row]=calloc(width,sizeof(tile));
  } 
  for(row=0; row<width;++row)
  {
    for(column=0; column<height;++column)
    {
      map[row][column].visible = NOT_VISIBLE;
      tile_probability = (float)(float)(rand())/(float)(RAND_MAX);
      if(tile_probability<=(probability/100))
      {
        map[row][column].state = BOMB;
        numBomb++;
      }
      else
        map[row][column].state=NO_ADJACENT_BOMBS;
    }
  }
  for(row=0; row<width;++row)
  {
    for(column=0; column<height;++column)
    {
      if(map[row][column].state != BOMB)
        counter = 0;
      if(map[row][column].state == BOMB)
        continue;
      if((row-1)<height&&(column-1)<width&&map[row-1][column-1].state==BOMB)
        counter++;
      if((row-1)<height && map[row-1][column].state==BOMB)
        counter++;
      if((row-1)<height&&(column+1)<width&&map[row-1][column+1].state==BOMB)
        counter++;
      if((column-1)<width && map[row][column-1].state==BOMB)
        counter++;
      if((column+1)<width && map[row][column+1].state==BOMB)
        counter++;
      if((row+1)<height&&(column-1)<width&&map[row+1][column-1].state==BOMB)
        counter++;
      if((row+1)<height && map[row+1][column].state==BOMB)
        counter++;
      if((row+1)<height&&(column+1)<width&&map[row+1][column+1].state==BOMB)
        counter++;
      map[row][column].state = counter;
    } 
  }
  return map;
}
/****************************************************************************
Function: printMap()
Description: print out tiles according to their state
Inputs: unsigned int, tile**

unsigned int height - height of tile
unsigned int width - width of tile
tile** map - pointer array 

Outputs: prints map and print tiles according to their state
****************************************************************************/
void printMap(unsigned int height, unsigned int width, tile**Map)
{
  for(row=0;row<width;++row)
  {
    for(column=0;column<height;++column)
    {
      if(Map[row][column].visible==NOT_VISIBLE)
      {
        printf("?|");
      }
      else
      {
        if(Map[row][column].state== NO_ADJACENT_BOMBS)
        {
          printf(" |");
        }
        else if(Map[row][column].state == BOMB)
        {
          printf("*|");
        }
        else
        {
          printf("%d|", map[row][column].state);
        }
      }
    }
    
    printf("\n");
    
    for(counter=0;counter<width;++counter)
    {
      printf("--");
    }
    printf("\n");
  }
}
/****************************************************************************
Function: inputXY
Description: prompt user input and set tile to visible
Inputs: unsigned int 

unsigned int x - x coordinate
unsigned int y - y coordinate

Outputs: set input tile coordinate to visible
****************************************************************************/
void inputXY()
{
  printf("Enter x: ");
  scanf("%u", &x);
  fprintf(file, "%u\n", x);
  
  printf("Enter y: \n");
  scanf("%u", &y);
  fprintf(file, "%u\n", y);
  
  map[y][x].visible=VISIBLE;
}
/****************************************************************************
Function: allVisible()
Description: Makes all tile state to visible
Inputs: unsigned int, tile**

unsigned int height - height of grid
unsigned int width - width of grid
tile**map - pointer array

Outputs: tile state change to visible
****************************************************************************/
void allVisible(unsigned int height, unsigned int width, tile**Map)
{
  for(row=0;row<height;++row)
  {
    for(column=0;column<width;++column)
    {
      Map[row][column].visible=VISIBLE; 
    }
  }
}
/****************************************************************************
Function: destroy_map()
Description: destroy memory located to map
Inputs: tile**, unsigned int

tile**map - pointer array
unsigned int height - height of grid

Outputs: destory memory located to map and free map 
****************************************************************************/
void destroy_map(tile**Map, unsigned int height)
{
  unsigned int i;
  for (i = 0; i < height; ++i)
  free(Map[i]);
  free(Map);
}

/****************************************************************************
Function: Main()
Description: program record user input creating text file 
Inputs: unsigned int 

unsigned int fileInt - textfile counter 
unsigned int grid - total number of grid 
unsigned int numNotBomb - counters number of not bombs

Outputs: create "playback".txt file if does not exist, else, create
create "playback1.txt","playback2.txt"
****************************************************************************/
int main(void)
{
  unsigned int grid,numNotBomb, fileInt=1;
  char charArr[20]="playback.txt";
  file  = fopen("playback.txt", "r");
  
  while(file!=NULL)
  {
    fclose(file);
    sprintf(charArr,"playback%d.txt",fileInt++);
    file = fopen(charArr,"r");
  }
  
  file=fopen(charArr,"w");
  Inputs();
  map = CreateMap(Height, Width, Probability);
  printMap(Height, Width, map);
  grid=Height*Width;
  numNotBomb=grid-numBomb;

  while(1)
  {
    inputXY();
    if(map[y][x].state==BOMB)
    {
      allVisible(Height,Width,map);
      printMap(Height, Width, map);
      printf("You lost!");
      destroy_map(map, Height);
      break;
    }
    if(map[y][x].state!=BOMB)
    {
      numNotBomb--;
      if(numNotBomb==0)
      {
        allVisible(Height,Width,map);
        printMap(Height, Width, map);
        printf("You won!");
        destroy_map(map, Height);
        break;
      }
    }
    printMap(Height, Width, map);
  } 
  fclose(file);
  return 0; 
}