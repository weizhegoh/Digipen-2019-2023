#ifndef _TILE_VISIBILITY_H_
#define _TILE_VISIBILITY_H_

/****************************************************************************
Function: typedef enumeration
Description: tile visbility check
Inputs:

NOT_VISIBLE - set tile visbility to not visible
VISIBLE - set tile visbility to visible

Outputs: set tile visbility to either visible or not visible
****************************************************************************/

typedef enum
{

NOT_VISIBLE,
VISIBLE

} TileVisibility;


#endif
