/******************************************************************************
filename MemoryManagerV2.c
author Goh Wei Zhe
email weizhe.goh@digipen.edu
date created 21 Mar 2020
Brief Description: Create Memory pool, scans unused element, allocate and 
deallocate  an element from pool and free memory pool.
******************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "MemoryManagerV2.h"

#define NUM_BITS 8

void printBinary(struct MemoryPool* memory)
{
  unsigned int binary = 0, bitSize = 0, block = 0, bit = 0;
  
  bitSize = memory->count/NUM_BITS;
  
  for(block = 0; block < bitSize; ++block)
  {
    printf("Block[%d]: ", block);

    for (bit = 0; bit < NUM_BITS; ++bit)
    {      
      if(memory->isActive[block] & (1<<bit))
      {
        binary = 1;
        printf("%d ", binary);
      }
      else
      {
        binary = 0;
        printf("%d ", binary);

      }
    }
    printf("\n");
  }
  printf("\n");
}

void printBinaryList(struct MemoryPool* pool)
{
  struct ArrayAllocNode* current = NULL; 
  
  if(pool == NULL || pool->arrAllocList == NULL)
  {
    printf("Pool is Empty\n");
    return;
  }
  
  current = pool->arrAllocList;
  
  while(current)
  {
    printf("%p-> ", current->arrayPtr);
    current = current->next; 
  }
  
  printf("NULL\n");
}

void* MemoryMgrAllocate(struct MemoryPool* pool)
{
  unsigned int bitSize = 0, blockIndex = 0, bitIndex = 0;

  if(pool == NULL)
  {
    return NULL; 
  }
  
  bitSize = pool->count/NUM_BITS;

  for(blockIndex = 0; blockIndex< bitSize; ++blockIndex)
  {
    if(pool->isActive[blockIndex] != 0)
    {
      break;
    }
  }
  
  if(blockIndex == bitSize)
  {
    return NULL;
  }
  
  for(bitIndex = 0; bitIndex < NUM_BITS ;++bitIndex)
  {
    if(pool->isActive[blockIndex] & (1<<bitIndex))
    {
      break;
    }
  }
  
  pool->isActive[blockIndex] &= (char)~(1<<bitIndex);
  
  printBinary(pool); 
  
  return pool->allocatedMemory + ((blockIndex * NUM_BITS + bitIndex)* pool->unitSize);
}

void MemoryMgrDeallocate(struct MemoryPool* pool, void* target)
{
  unsigned int blockIndex = 0, bitIndex = 0, numElement = 0;
  
  if(pool == NULL || target == NULL)
  {
    return; 
  }
  
  numElement = (unsigned int)((char*)(target)-(pool->allocatedMemory))/pool->unitSize;
  
  bitIndex = numElement%NUM_BITS;
  blockIndex = numElement/NUM_BITS;
  
  pool->isActive[blockIndex] |= (char)(1<<bitIndex);

  printBinary(pool); 
}

unsigned int MemoryMgrInactiveCount(struct MemoryPool* target)
{
  unsigned int blockIndex = 0, bitIndex = 0, inactiveCount = 0, bitSize = 0;

  if(target == NULL)
  { 
    return MM_FAILED;
  }

  bitSize = target->count/NUM_BITS;

  for(blockIndex = 0; blockIndex < bitSize;++blockIndex)
  {
    for (bitIndex = 0; bitIndex < NUM_BITS; ++bitIndex)
    {
      if((target->isActive[blockIndex] & (1<<bitIndex)))
      {
        inactiveCount++;
      }
    }
  }
  
  return inactiveCount;
}

int MemoryMgrCreatePool(struct MemoryPool* result, unsigned int unitSize, unsigned int count)
{
  unsigned int blockIndex = 0, bitSize = 0;
  unsigned char MAX_CHAR = 255;
  
  if(result == NULL || unitSize == 0 || count == 0)
  {
    return MM_FAILED;
  }
  
  if(count%NUM_BITS!=0)
  {
    result->count = count + (NUM_BITS-count%NUM_BITS);
  }
  
  result->unitSize = unitSize;
  result->seekerIndex = 0;
  result->arrAllocList = NULL;
  
  result->allocatedMemory = (char*)malloc(unitSize*result->count);
  
  if (result->allocatedMemory == NULL)
  {
    result->count = 0;
    result->unitSize = 0;
	  return MM_FAILED;
  }
  
  result->isActive = (char*)malloc(sizeof(char)*(result->count/NUM_BITS)); 
  
  if(result->isActive == NULL)
  {
    result->count = 0;
    result->unitSize = 0;
    free(result->allocatedMemory);
    result->allocatedMemory = NULL;
    return MM_FAILED;
  }

  bitSize = (result->count)/NUM_BITS;

  for(blockIndex = 0; blockIndex < bitSize; ++blockIndex)
  {
    result->isActive[blockIndex] = (char)MAX_CHAR;
  }

  printBinary(result); 
  
  return MM_OK;
}

void MemoryMgrFreePool(struct MemoryPool* target)
{
  if(target == NULL)
  {
    return;
  }
  if(target->isActive!=NULL)
  {
    free(target->isActive);
    target->isActive = NULL;
  }
  
  if(target->allocatedMemory!=NULL)
  { 
    free(target->allocatedMemory);
    target->allocatedMemory = NULL;
  }
  
  target->count = 0;
  target->unitSize = 0;
  target->seekerIndex = 0;
}

void* MemoryMgrArrayAllocate(struct MemoryPool* pool, unsigned int count)
{
  unsigned int blockIndex = 0, bitIndex = 0, bitSize = 0, counter = 0;
  struct ArrayAllocNode* newNode = NULL, *current = NULL;
  
  if(pool == NULL || count == 0)
  {
    return NULL;
  }
  
  bitSize = pool->count/NUM_BITS;

  for(blockIndex = 0; blockIndex < bitSize; ++blockIndex)
  {
    for(bitIndex = 0; bitIndex < NUM_BITS ;++bitIndex)
    {
      if(pool->isActive[blockIndex] & (1<<bitIndex))
      {
        ++counter;
      }
      else
      {
        counter = 0;
        continue;
      }
      
      if(counter == count)
      {
        break;
      }
    }
    if(counter == count)
    {
      break;
    }
  }
  
  if(counter != count)
  {
    return NULL;
  }
 
  printf("block %d, bit %d\n", blockIndex, bitIndex);
  bitIndex++;
   
  while(counter)
  {
    counter--; 
    bitIndex--;
    
    if(bitIndex > NUM_BITS)
    {
      blockIndex--;
      bitIndex = NUM_BITS-1;
    }
    pool->isActive[blockIndex] &= (char)~(1<<(bitIndex));
  }
 
  newNode = (struct ArrayAllocNode*)malloc(sizeof(struct ArrayAllocNode));
  
  if(newNode == NULL)
  {
    return NULL;
  }
  
  newNode->arrayPtr = (pool->allocatedMemory) + ((blockIndex * NUM_BITS + bitIndex)* pool->unitSize);
  newNode->length = count;
  newNode->next = NULL;
  
  if(pool->arrAllocList== NULL)
  {
    pool->arrAllocList = newNode;
    
    printBinary(pool); 
    printBinaryList(pool);
    return newNode->arrayPtr;
  }
  
  current = pool->arrAllocList;
  
  while(current->next)
  {
    current = current->next;
  }
  
  current->next = newNode;
  
  printBinary(pool); 
  printBinaryList(pool);
  
  return newNode->arrayPtr;
}

void MemoryMgrArrayDeallocate(struct MemoryPool* pool, void* target)
{
  struct ArrayAllocNode* current = NULL, *delete = NULL;
  unsigned int numElement = 0, blockIndex = 0, bitIndex = 0, length = 0;
  
  if(pool == NULL || target == NULL)
  {
    return; 
  }
  
  numElement = (unsigned int)((char*)(target)-(pool->allocatedMemory))/pool->unitSize;
  
  bitIndex = numElement%NUM_BITS;
  blockIndex = numElement/NUM_BITS; 
  
  printf("block %d, bit %d\n", blockIndex, bitIndex);

  if(pool->arrAllocList->arrayPtr == target)
  {     
    for(length = 0; length < pool->arrAllocList->length; ++length)
    {
      if((bitIndex) >= NUM_BITS)
      {
        blockIndex++;
        bitIndex = 0;
      }
      pool->isActive[blockIndex] |= (char)(1<<(bitIndex++));
    }
    delete = pool->arrAllocList;
    pool->arrAllocList = pool->arrAllocList->next;
    free(delete);
    
    printBinary(pool); 
    printBinaryList(pool);
    
    return;
  }
  
  current = pool->arrAllocList;
  
  while(current->next->arrayPtr)
  {
    if(current->next->arrayPtr == target)
    {       
      for(length = 0; length < current->next->length; ++length)
      { 
      if((bitIndex) >= NUM_BITS)
      {
        blockIndex++;
        bitIndex =  0;
      }
        pool->isActive[blockIndex] |= (char)(1<<(bitIndex++));
      }
      
      delete = current->next;
      current->next = current->next->next;
      free(delete);
      break;
    }
    current = current->next;
  }
  
  printBinary(pool); 
  printBinaryList(pool);
}