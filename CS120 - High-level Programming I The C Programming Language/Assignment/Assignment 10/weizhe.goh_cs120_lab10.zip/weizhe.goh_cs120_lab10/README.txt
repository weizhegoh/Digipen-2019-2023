• /* Start Header ------------------------------------------------------
Copyright (C) 2019 DigiPen Institute of Technology.
File Name: MemoryManagerV2.c
Purpose: Create Memory pool, scans unused element, allocate and 
deallocate  an element from pool and free memory pool.
Language: C programming
Platform: GCC c89
Project: weizhe.goh_cs120_lab10
Author: Goh Wei Zhe 
Student Login: weizhe.goh / 440000119
StudentID: 1900806
Creation date: 31th March 2020
End Header --------------------------------------------------------*/ 

Compile in GCC:
1. gcc -Wall -Werror -Wextra -Wconversion -ansi -pedantic -o MemoryManagerV2.exe MemoryManagerDriverV2.c MemoryManagerV2.c
2. Enter: MemoryManagerV2

Compile in Visual Studio: 
1. Change directory to where the folder is and enter.
2. Enter: cl /W4 /WX /nologo /Za /FeMemoryManagerV2.exe /TC MemoryManagerDriverV2.c MemoryManagerV2.c
3. Enter: MemoryManagerV2
 
