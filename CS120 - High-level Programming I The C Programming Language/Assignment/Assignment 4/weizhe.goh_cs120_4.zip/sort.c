#include <stdio.h>

int main (void)
{

	int first, second, temp;

	printf("Input the first number:  ");
	scanf("%d",&first);

	printf("Input the second number: ");
	scanf("%d",&second);

	if(second>first)
	{
		temp = first;
		first = second;
		second = temp;
	}
		printf("\n%d\n",first);
		printf("%d\n",second);

	
	return 0;
}
