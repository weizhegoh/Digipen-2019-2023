	#include <stdio.h>

int get_Greatest(int a, int b, int c);

int main(void)
{
	int first, second, third;
	
	printf("Input the first number:  ");
	scanf("%d", &first);
	
	printf("Input the second number: ");
	scanf("%d",&second);
	
	printf("Input the third number:  ");
	scanf("%d", &third);
	
	
	printf("\nGreatest: %d\n", get_Greatest(first,second,third));
	
	return 0;
}

int get_Greatest(int a, int b, int c)
{
	
	if (a<b)
	{
		if(c<b)
		{
			return b; 
		}
		else
		{
			return c;
		}
	}
	
	else
	{
		if (c<a)
		{
			return a;
		}
		else
		{	
			return c;
		}
	}
		
		return 0;
		
}
		