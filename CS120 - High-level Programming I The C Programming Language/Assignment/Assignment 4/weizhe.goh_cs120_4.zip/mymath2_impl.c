#include "mymath2.h"
#include <stdio.h> 

float square_root(float n)
{
	const float EPSILON = 1e-6f;
	
	float a=1.0f;
	float b=n; 
	float c;
	float delta;
	
	do
	{
		c=(a+b)/2;	
		delta = c*c-n;
		
		if (delta <0)
			delta = -delta;
		
		if(delta < EPSILON)
			return c;
		
		if((c*c) < n)
			a=c;
		else
			b=c;
		
	}while(1);
	
	
return n;
}




