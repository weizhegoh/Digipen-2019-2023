#include <stdio.h> 
#include "mymath.h"


int multiply (int a, int b);

	int main (void)
	{
		int first, second;
			
		printf("Input the first number:  ");
		scanf("%d", &first);
			
		printf("Input the second number: ");
		scanf("%d", &second);
			
		printf("\nProduct: %d\n", multiply(first,second));

	return 0;	
	}


			
			
			