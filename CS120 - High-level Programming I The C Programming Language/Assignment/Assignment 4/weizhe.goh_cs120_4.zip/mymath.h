#ifndef _MYMATH_H_
#define _MYMATH_H_

#include "mymath.h"


	int multiply (int a, int b)
	{
		int result;
			
		if(a==0 ||b==0)
		{
			return 0;
			result = 0;
		}
		else
		
		while(b!=0)
		{
			result+=a;
			b-=1;
		}
		return result;
	}
	
	#endif
