#ifndef _MYMATH2_H_
#define _MYMATH2_H_


float square_root(float n);

#endif
