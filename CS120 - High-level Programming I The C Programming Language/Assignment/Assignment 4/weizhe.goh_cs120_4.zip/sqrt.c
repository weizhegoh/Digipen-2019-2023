#include "mymath2.h"
#include <stdio.h> 

int main()
{
	float n;
	
	printf("Input a number greater or equal to 1: ");

	if(scanf("%f",&n)!=1 || n<1.0f)
	{
		printf("\nWrong input\n");
	}
	else
	{
				
			printf("\n%f\n", square_root(n)); 

	}

return 0;

}

	
	
	