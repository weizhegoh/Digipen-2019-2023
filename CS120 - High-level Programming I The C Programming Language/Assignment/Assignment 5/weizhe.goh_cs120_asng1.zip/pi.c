/****************************************************************************
filename [pi.c] 
author [Goh Wei Zhe] 
DP email [weizhe.goh@digipen.edu]
course CS120
section A assignment [1] 
date [8th October 2019]
Brief Description: This file contains the circle_pi and leibniz_pi function 
for the PI assignment to calculate pi using a quarter circle and leibniz's 
series.
****************************************************************************/

/****************************************************************************
Function: circle_pi
Description: Calculate pi using a quarter circle
Inputs: double & int variables
double radius - radius of circle
double x - derived by midpoint of rectange width
double width - derived by dividing radius by number of rectanges
double height - derived by square root of radius^2 - x^2
int i - counter for loops
Outputs: double areaQcircle - derived by addition of area of rectangle
****************************************************************************/

/****************************************************************************
Function: leibniz_pi
Description: Calculate pi using a Leibniz's series
Inputs: double & int variables
double areaQCircle - area of quarter Circle
double denominator - increament of denominator  
int i = counter for loops
Outputs: returns area of full circle
****************************************************************************/
#include <stdio.h>
#include <math.h>
#define QUARTERS_IN_CIRCLE  4

/* Calculates PI using a quarter circle */
double circle_pi(int rectangles)
{

  const double radius = 2;
  double x;
  double width = radius/rectangles;
  double height;
  double areaQCircle=0;
  int i;

  for (i=0;i<rectangles;i++)
  {
   x=(width/2) + (i*width);
   height = sqrt((radius*radius)-(x*x));
   areaQCircle += width*height;
  }
    return areaQCircle;
}

/*Calculates PI using a Leibniz's series*/
  double leibniz_pi(int iterations)
  {
   double areaQCircle=1;
   double denominator =3;
   int i;
   
   for(i=1;i<iterations;i++)
   {
     if(i%2)
     {
       areaQCircle-=1/denominator;
     }
     else
     {
       areaQCircle+=1/denominator;
     }
     denominator+=2;
   }
   
   return areaQCircle*QUARTERS_IN_CIRCLE;
  }