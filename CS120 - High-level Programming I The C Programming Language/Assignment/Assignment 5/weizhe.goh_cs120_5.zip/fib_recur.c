/**************************************************************************
filename [fib_recur.c]
author [Goh Wei Zhe] 
DP email [weizhe.goh@digipen.edu]
course CS120
section A 
exercise [lab 5]
date [4th October 2019]
**************************************************************************/

/****************************************************************************
Function: fib() 
Description: Must not use local or global variables. Use different values of
an actual parameters to call itself called recursion method. Must use function
parameters only. Returns the fib number. 
number.
Inputs: NIL
Outputs: Returns the current number (int) of Fibonacci at n-th position
*****************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

unsigned int fib(unsigned int n)
{
if(n==0)
  {
    return 0;
  }
  if(n==1)
  {
    return 1;
  }
  else
  {
  return fib(n-1)+fib(n-2);
  }
}
