/**************************************************************************
filename [fib_stat_loop.c]
author [Goh Wei Zhe] 
DP email [weizhe.goh@digipen.edu]
course CS120
section A 
exercise [lab 5]
date [4th October 2019]
**************************************************************************/

/****************************************************************************
Function: fib() 
Description: Given unsigned integer. Must not use any local non-static or
global variable or call any other functions. Perform calculations using do
while iteration statement. Must use local static variables.
Inputs: int oldest, recent and current in local static variable.
oldest - oldest number to be replaced by recent number.
recent - recent number to be replace by current number.
Outputs: The current number (int) of Fibonacci at n-th position
*****************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

unsigned int fib(unsigned int n)
{ 

  static unsigned int oldest=0;
  static unsigned int recent=1;
  static unsigned int current=0;
  
  if(n==0)
  {
    return 0;
  }
  if(n==1)
  {
    return 1;
  }
  do
  {
    current = oldest + recent;
    oldest = recent;
    recent = current;
    n--;
  }while(n>1);

  return current; 
}
