/**************************************************************************
filename [main.c]
author [Goh Wei Zhe] 
DP email [weizhe.goh@digipen.edu]
course CS120
section A 
exercise [lab 5]
date [4th October 2019]
Brief Description: This file contains the main function for the Fibonacci 
exercise. It is used as a "driver" to test the fib() function.]
**************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

unsigned int fib(unsigned int n);

int main()
{
  unsigned int n;
  printf("Input a number: ");
  if(scanf("%u",&n)!=1)
  {
    printf("Enter a valid number!\n");
    }
    else
    {
      switch(n%10)
      {
        case 1: printf("%ust Fibonacci number is: %u" ,n, fib(n));
        break;
        case 2: printf("%und Fibonacci number is: %u" ,n, fib(n));;
        break;
        case 3: printf("%urd Fibonacci number is: %u" ,n, fib(n));
        break;
        default: printf("%uth Fibonacci number is: %u" ,n, fib(n));
        }
    }
    return 0;
}


