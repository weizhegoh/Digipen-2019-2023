/*******************************************************************************
 * DigiPen Institute of Technology
 * CS 120: Assignment 1
 ******************************************************************************/

#include <stdio.h> /* scanf, printf */

/******************************************************************************/
/* Prototypes of functions defined elsewhere...                               */
/******************************************************************************/

/* Calculates PI using a quarter circle */
double circle_pi(int rectangles);

/* Calculates PI using a Leibniz's series */
double leibniz_pi(int iterations);

/******************************************************************************/
/* The main logic of the program.                                             */
/******************************************************************************/

int main(void)
{
    int iterations; /* loop counter */

    /* Print out table header */
    printf(
		"Approximations for pi\n"
		"Iterations      Circle Method   Leibniz Method\n"
		"----------------------------------------------\n"
	);

    /* Print out values for each set of numbers */
    for (iterations = 1; iterations <= 1000000; iterations *= 10)
    {
	    double pi_circle;
	    double pi_leibniz;

        /* Calculate PI with both methods */
        pi_circle = circle_pi(iterations);
        pi_leibniz = leibniz_pi(iterations);

        /* Print the results of the calculations */
        printf("%10i%20.12f%16.12f\n", iterations, pi_circle, pi_leibniz);
    }

    return 0;
}
