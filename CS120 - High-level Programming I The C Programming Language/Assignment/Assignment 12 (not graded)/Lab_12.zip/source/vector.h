#ifndef VEC_H
#define VEC_H

#if Tchoice == 's'
typedef short T;
#elif Tchoice == 'd'
typedef double T;
#elif Tchoice == 'f'
typedef float T;
#elif Tchoice == 'c'
typedef char T;
#elif Tchoice == 'i'
typedef int T;
#else 
#error "An identifier Tchoice has not been specified with a required value."
#endif

typedef struct Vector Vector;

Vector* construct_vector();
void destroy_vector(Vector* const this);
size_t size(const Vector* const this);
size_t capacity(const Vector* const this);
T* begin(const Vector* const this);
T* end(const Vector* const this);
T get_value(const Vector* const this, size_t index);
T* get_ptr(const Vector* const this, size_t index);
int empty(const Vector* const this);
T* insert(Vector* const this, T* position, T value);
void push_back(Vector* const this, T value);
void pop_back(Vector* const this);
void copy_vector(Vector* const this, const Vector* const rhs);

#endif
