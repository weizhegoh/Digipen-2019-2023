#ifndef REAL_VEC_H
#define REAL_VEC_H

#include "vector.h"

struct Vector
{
	T* buf;
	T* next;
	T* last;
};

#endif
