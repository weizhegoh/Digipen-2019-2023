#include <stdio.h>
#include <stdlib.h>
#include "vector.h"

void print(const Vector* const array)
{
	size_t i;
	for (i = 0; i < size(array); ++i)
	{
#if Tchoice=='s' || Tchoice=='i' || Tchoice=='c'
		printf("%d ", get_value(array, i));
#elif Tchoice=='d'
		printf("%7.5f ", (float)get_value(array, i));
#elif Tchoice=='f'
		printf("%5.3f ", get_value(array, i));
#endif
	}
	printf(
		"(size=%lu, capacity=%lu)\n",
		(unsigned long)size(array),
		(unsigned long)capacity(array)
	);
}

void testPushPop(void)
{
	T i;
	Vector* vec = construct_vector();

	printf("\n********** TestPushPop **********\n");
	printf("Empty array:\n");
	print(vec);

	printf("push_back 5 elements:\n");
	for (i = 0; i < 5; ++i)
	{
		push_back(vec, i);
		print(vec);
	}

	printf("pop_back until empty:\n");
	while (!empty(vec))
	{
		pop_back(vec);
		print(vec);
	}

	destroy_vector(vec);
}

void testInsert1(void)
{
	T i;
	Vector* vec = construct_vector();

	printf("\n********** TestInsert **********\n");
	printf("Empty array:\n");
	print(vec);

	printf("push_back 5 elements:\n");
	for (i = 0; i < 5; i++)
	{
		push_back(vec, (T)((float)i * 1.412492f));
		print(vec);
	}

	printf("insert(3, 99):\n");
	insert(vec, begin(vec) + 3, 99);
	print(vec);

	printf("insert(0, 98):\n");
	insert(vec, begin(vec), 98);
	print(vec);

	printf("insert(6, 97):\n");
	insert(vec, begin(vec) + 6, 97);
	print(vec);

	destroy_vector(vec);
}

void testGetValuePtr(void)
{
	size_t i;
	Vector* vec = construct_vector();

	printf("\n********** TestGetValuePtr **********\n");
	printf("push_back 10 even elements:\n");
	for (i = 0; i < 10; ++i)
	{
		push_back(vec, (T)(2 * i));
	}
	print(vec);

	printf("multiple each value by 3:\n");
	for (i = 0; i < 10; i++)
	{
		*get_ptr(vec, i) = (T)(get_value(vec, i) * 3);
	}
	print(vec);

	destroy_vector(vec);
}

void testInsert2(void)
{
	int ia[] = {2, 4, 6, 6, 8, 10, 6, 12, -6, 14, 16, 6, 6};
	size_t size = sizeof(ia) / sizeof(*ia);
	size_t i;
	Vector* vec = construct_vector();

	printf("\n********** TestInsert2 **********\n");
	printf("Construct from int array:\n");

	for (i = 0; i < size; ++i)
	{
		push_back(vec, (T)(ia[i]));
	}
	print(vec);

	for (i = 0; i < size; ++i)
	{
		T* b = begin(vec);
		*insert(vec, b + 2 * i, (T)(ia[i])) /= 2;
	}
	print(vec);

	destroy_vector(vec);
}

void testAssign(void)
{
	size_t i;
	Vector* a = construct_vector();
	Vector* b = construct_vector();

	printf("\n********** TestAssign **********\n");
	printf("push_back 10 elements:\n");
	for (i = 0; i < 10; ++i)
	{
		push_back(a, (T)((float)i * 2.0f));
		push_back(b, (T)((float)i * 1.0f));
	}
	print(a);
	print(b);

	printf("Copy Assign: b = a, print a,b\n");
	copy_vector(b, a);
	print(a);
	print(b);

	printf("Copy Assign: a = a, print a\n");
	copy_vector(a, a);
	print(a);

	destroy_vector(a);
	destroy_vector(b);
}

int main(int argc, char** argv)
{
	size_t test_num = 0;
	size_t i;
	typedef void (*Test)(void);
	Test tests[] = {
		testPushPop,            /* 1 */
		testInsert1,            /* 2 */
		testInsert2,            /* 3 */
		testGetValuePtr,        /* 4 */
		testAssign              /* 5 */
	};
	size_t num = sizeof(tests) / sizeof(*tests);
	if (argc > 1)
	{
		int n = atoi(argv[1]);
		test_num = (n >= 0) ? (size_t)n : num + 1;
	}
	if (test_num == 0)
	{
		for (i = 0; i < num; ++i)
		{
			tests[i % num]();
		}
	}
	else if (test_num <= num)
	{
		tests[test_num - 1]();
	}
	return 0;
}
