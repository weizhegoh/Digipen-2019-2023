/****************************************************************************
filename [shopping.c] 
author [Goh Wei Zhe] 
DP email [weizhe.goh@digipen.edu]
course CS120
section A 
date [26th October 2019]
Brief Description: This file contains the main function
****************************************************************************/

/****************************************************************************
Function: main
Description: Generate invoice program
Inputs: int and char variables 

int dollarArr[300] - store item price in dollar into array
int centArr[300] - store item price in cent into array
int dollar - item price in dollar
int dollarAmt - total quantity price amount in dollar
int dollarPaid - amount paid in dollar
int dollarPaidInCent - amount paid in dollar convert into cents
int cent - item price in cent
int centAmt - total quantity price amount in cent
int centPaid - amount paid in cent
int totalDollar - total price in dollar
int totalCent - total price in cent
int totalPriceInCent - total price convert to cents
int changeInCent - total change received in cent
int changeDollar - convert change returned into dollar 
int changeCent - remaining change returned in cent
int i - counter
int itemNo - item number
int qty - number of item quantity 
char store - check character 

Outputs: Print a shopping list that contains number of items, unit price,
quantity, unit price amount, total price of items, total amount paid,
and change return.
****************************************************************************/


#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(void)
{
  int dollarArr[300];
  int centArr[300];
  
  int dollar=0;
  int dollarAmt=0;
  int dollarPaid=0;
  int dollarPaidInCent=0;
  int cent=0;
  int centAmt=0;
  int centPaid=0;
  int totalDollar=0;
  int totalCent=0;
  int totalPriceInCent=0;
  int changeInCent=0;
  int changeDollar=0;
  int changeCent=0;
  int i=0;
  int itemNo=0;
  int qty=0;
  char store = 0;
  
  printf("Description    Unit Price    Qty    Amount\n");

  for(;i<=300;i++)
  {
    if(scanf("%d.%d",&dollar,&cent)==2)
    {
    dollarArr[i]=dollar;
    centArr[i]=cent;
    }
    else break;
  }
  
  itemNo = dollar;
  scanf("%d",&qty);
  
  dollarAmt=qty*dollarArr[itemNo];
  centAmt=qty*centArr[itemNo];
  
  dollarAmt+=centAmt/100;
  centAmt=centAmt%100;
  
  totalDollar+=dollarAmt;
  totalCent+=centAmt;
    
  printf("Item %3d%14d.%2d    %-3d %6d.%2d\n",
  itemNo, dollarArr[itemNo], centArr[itemNo], qty,dollarAmt,centAmt);
  
  while(scanf("%d%c%d",&itemNo,&store,&qty)==3)
  {
    if(store == '.')
    {
      dollarPaid = itemNo;
      centPaid = qty;
      break;
    }
    else
      if(itemNo>=0 && itemNo <i)
      {
        dollarAmt=qty*dollarArr[itemNo];
        centAmt=qty*centArr[itemNo];
    
        dollarAmt+=centAmt/100;
        centAmt=centAmt%100;
    
        totalDollar+=dollarAmt;
        totalCent+=centAmt;
    
        printf("Item %3d%14d.%2d    %-3d %6d.%2d\n",
        itemNo, dollarArr[itemNo], centArr[itemNo], qty,dollarAmt,centAmt);
      }
      else
      {
        printf("Item %-d not sold.\n",itemNo);
      }
  }
  
    totalDollar +=totalCent/100;
    totalCent =totalCent%100;
    
    dollarPaidInCent =(dollarPaid*100) + centPaid;
    totalPriceInCent =(totalDollar*100) + totalCent;
    
    if(dollarPaidInCent>=totalPriceInCent)
    {
      changeInCent = dollarPaidInCent - totalPriceInCent;
      changeDollar = changeInCent/100;
      changeCent = changeInCent%100;
    }
    else
    {
      changeInCent = dollarPaidInCent - totalPriceInCent;
      changeDollar = changeInCent/100;
      changeCent = changeInCent%100;
      
      if(changeCent<=0)
      {
        changeCent = -changeCent;
      }
    }
   
    printf("%28c Total: %d.%2d\n",' ', totalDollar,totalCent);
    printf("%29c Paid: %d.%2d\n",' ', dollarPaid,centPaid);
    printf("%27c Change:%4d.%2d\n",' ', changeDollar,changeCent);

      return 0;
}