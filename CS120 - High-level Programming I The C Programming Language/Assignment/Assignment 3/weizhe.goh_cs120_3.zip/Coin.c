#include <stdio.h> 

int main (void)
{

	int dollar,cents;
	int i; 
	int onedollar=0;
	int fiftycent=0;
	int twentycent=0;
	int tencent=0;
	int fivecent=0;
	int onecent=0;
	
	
	printf("Please input total value:");
	i=scanf("%d.%d",&dollar,&cents);	

	if(i!=2)
	{
		printf("You did not type in the correct format in terms of dollars and cents\n");	
	}
	
	if(cents<0 || cents> 99)
	{
		printf("The cents part specified must be between 0 to 99\n");
	}
	
	if(i==2 && !(cents<0 || cents> 99))
	{
	while(dollar>=1)
	{
		dollar-=1;
		onedollar++;
	}
		
	while(cents>=50)
	{
		cents-=50;
		fiftycent++;
	}
	
	while(cents>=20)
	{
		cents-=20;
		twentycent++;
	}
	
	while(cents>=10)
	{
		cents-=10;
		tencent++;
	}
	
	while(cents>=5)
	{
		cents-=5;
		fivecent++;
	}
		
	while(cents>=1)
	{
		cents-=1;
		onecent++;
	
	}
	printf("You need %d one dollar coins\n", onedollar);
	printf("You need %d fifty cents coins\n", fiftycent);
	printf("You need %d twenty cent coins\n", twentycent);
	printf("You need %d ten cent coins\n", tencent);
	printf("You need %d five cent coins\n", fivecent);
	printf("You need %d one cent coins\n", onecent); 
	}
	
	return 0;
}