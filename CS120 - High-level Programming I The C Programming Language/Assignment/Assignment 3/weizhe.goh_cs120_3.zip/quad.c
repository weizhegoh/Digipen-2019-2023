#include <stdio.h>

int main (void)
{
	float a,b,c,d;
		
	printf("Please enter a:");
	scanf("%f",&a);
	
	printf("Please enter b:");
	scanf("%f",&b);
	
	printf("Please enter c:");
	scanf("%f",&c);
	
	d=b*b-(4*a*c);
	
	if(d<0)
	{
		printf("%0.2fx^2+%0.2fx+%0.2f has imaginary roots.", a,b,c);
	}
	else if(d==0)
	{
		printf("%0.2fx^2+%0.2fx+%0.2f has two equal roots.", a,b,c);
	}
	else if(d>0)
	{
		printf("%0.2fx^2+%0.2fx+%0.2f has two distinct real roots.", a,b,c);
	}
	return 0;
	
}
	