/****************************************************************************
filename [fraction.c] 
author [Goh Wei Zhe] 
DP email [weizhe.goh@digipen.edu]
course CS120
section A 
date [24th November 2019]
Brief Description: This file contains the 15 functions
****************************************************************************/

/****************************************************************************
Function: greastestCommonD()
Description: Compute greatest common denominator between 2 numbers
Inputs: Fraction*, int 

int i - counter
int GCD - greatest common denominator
posN - store positive and negative this->numerator
posD - store positive and negative this->denominator

Outputs: return int of greatest common denominator of the 2 numbers 
****************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include "fraction.h"

  int i;
  int GCD;

int greatestCommonD(FRACTION* this)
{ 
  int posN = this->numerator;
  int posD = this->denominator;
  
  if((this->numerator)<0)
  {
    posN*=-1;
  }
  
  if((this->denominator)<0)
  {
    posD*=-1;
  }
   
  for(i=1;i<=posN && i<=posD;++i)
  {
    if(posN%i==0 && posD%i==0)
    GCD = i; 
  }
  return GCD;
}

/****************************************************************************
Function: create_fraction()
Description: Given a numerator and denominator, creates a new fraction object
on a heap and return its pointer
Inputs: int

int numerator - fraction numerator
int denominator - fraction denominator

Outputs: create fraction and return its pointer
****************************************************************************/

FRACTION* create_fraction(int numerator, int denominator)
{
  FRACTION* f = malloc(sizeof(FRACTION));
  f->numerator = numerator;
  f->denominator = denominator;
  
  return f;
}

/****************************************************************************
Function: copy_fraction()
Description: Given an address of an exist heap, creates a new fraction object
on a heap and return its pointer.
Inputs: const FRACTION*

const FRACTION* other - other points to a struct FRACTION that is read only

Outputs: create new fraction object and return its pointer. 
****************************************************************************/

FRACTION* copy_fraction(const FRACTION* other)
{
  FRACTION* f = malloc(sizeof(FRACTION));
  f->numerator = other->numerator;
  f->denominator = other->denominator;
  
  return f;
}

/****************************************************************************
Function: add_fraction()
Description: add fractions from parameter this and other
Inputs: FRACTION* , const FRACTION* 

FRACTION* this - this points to a struct FRACTION 
const FRACTION* other - other points to a struct FRACTION that is read only.

Outputs: stores result into this 
****************************************************************************/

void add_fraction(FRACTION* this, const FRACTION* other)
{  
  if(this->denominator == other->denominator)
  {
    this->numerator += other->numerator;
  }
  else
  { 
    this->numerator *= other->denominator;
    this->numerator += this->denominator * other->numerator;
    this->denominator *= other->denominator;
  }  
  
  if(!(this->denominator))
  {
    get_denominator(this);
  }
  else if(!(this->numerator))
  {
    this->denominator = 1;
  }
  else
  {
    GCD = greatestCommonD(this);
  
    if(GCD)
    {
      this->numerator/=GCD;
      this->denominator/=GCD;
    }
  }
}

/****************************************************************************
Function: subtract_fraction()
Description: subtract fractions from parameter this and other
Inputs: FRACTION*, const FRACTION*

FRACTION* this - this points to a struct FRACTION 
const FRACTION* other - other points to a struct FRACTION that is read only.

Outputs: stores result into this 
****************************************************************************/

void subtract_fraction(FRACTION* this, const FRACTION* other)
{
  if(this->denominator == other ->denominator)
  {
    this->numerator -= other->numerator;
  }
  else
  {
    this->numerator *= other->denominator;
    this->numerator -= this->denominator *other->numerator;
    this->denominator *= other->denominator;
  }
  
  if(!(this->denominator))
  {
    get_denominator(this);
  }
  else if(!(this->numerator))
  {
    this->denominator = 1;
  }
  else
  {
    GCD = greatestCommonD(this);
  
    if(GCD)
    {
      this->numerator/=GCD;
      this->denominator/=GCD;
    }
  }
}

/****************************************************************************
Function: multiply_fraction()
Description: multiply fractions from parameter this and other
Inputs: FRACTION* , const FRACTION*

FRACTION* this - this points to a struct FRACTION 
const FRACTION* other - other points to a struct FRACTION that is read only.

Outputs: stores result into this 
****************************************************************************/

void multiply_fraction(FRACTION* this, const FRACTION* other)
{  
  this->numerator *= other->numerator;
  this->denominator *= other->denominator;
  
  if(!(this->denominator))
  {
    get_denominator(this);
  }
  else if(!(this->numerator))
  {
    this->denominator = 1;
  }
  else
  {
    GCD = greatestCommonD(this);
  
    if(GCD)
    {
      this->numerator/=GCD;
      this->denominator/=GCD;
    }
  }
}

/****************************************************************************
Function: divide_fraction()
Description: divide fractions from parameter this and other
Inputs: FRACTION* , const FRACTION*

FRACTION* this - this points to a struct FRACTION 
const FRACTION* other - other points to a struct FRACTION that is read only.

Outputs: stores result into this 
****************************************************************************/

void divide_fraction(FRACTION* this, const FRACTION* other)
{  
  this->numerator *= other->denominator;
  this->denominator *= other->numerator;
  
  if(!(this->denominator))
  {
    get_denominator(this);
  }
  else if(!(this->numerator))
  {
    this->denominator = 1;
  }
  else
  {
    GCD = greatestCommonD(this);
  
    if(GCD)
    {
      this->numerator/=GCD;
      this->denominator/=GCD;
    }
  }
}

/****************************************************************************
Function: destroy_fraction()
Description: deallocates memory of an existing fraction created by 
create_fraction or copy_fraction.
Inputs: FRACTION*

FRACTION* this - this points to struct FRACTION

Outputs: scan user input and exit program if user input 0
****************************************************************************/

void destroy_fraction(FRACTION* this)
{
  free(this);
}

/****************************************************************************
Function: get_numerator()
Description: Returns a numerator part of the function 
Inputs: const Fraction*

const FRACTION* this - this points to a struct FRACTION that is read only

Outputs: return numerator of function 
****************************************************************************/

int get_numerator(const FRACTION* this)
{
  return (this->numerator);
}

/****************************************************************************
Function: get_denominator()
Description: Returns a denominator part of the function 
Inputs: const Fraction*

const FRACTION* this - this points to a struct FRACTION that is read only

Outputs: return denominator of function 
****************************************************************************/

int get_denominator(const FRACTION* this)
{
  return (this -> denominator);
}

/****************************************************************************
Function: create_mixed_fraction()
Description: Given an proper_fraction object create a new mixed fraction
on a heap and returns its pointer 
Inputs: const Fraction*

const FRACTION* fraction - fraction points to a struct FRACTION that is 
read only

Outputs: create mixed fraction and return its pointer
****************************************************************************/

MIXED_FRACTION* create_mixed_fraction(const FRACTION* fraction)
{
  MIXED_FRACTION* mf = malloc(sizeof(MIXED_FRACTION));
  mf->proper_fraction = 
  create_fraction(fraction->numerator, fraction->denominator); 
  
  if(fraction->denominator)
  {
    mf->whole_number = fraction->numerator / fraction->denominator;
    mf->proper_fraction->numerator = 
    fraction->numerator % fraction->denominator;
    
    if((mf->proper_fraction->denominator)<0)
    {
      mf->proper_fraction->denominator*=-1;
      mf->proper_fraction->numerator*=-1;
    }
  }
  else
  {
    mf->whole_number = 0;
  }
  
  if((mf->whole_number)<0)
  {
    if((mf->proper_fraction->numerator)<0)
    {
      mf->proper_fraction->numerator*=-1;
    }
    
    if((mf->proper_fraction->denominator)<0)
    {
      mf->proper_fraction->denominator*=-1;
    }
  }
  return mf;
}

/****************************************************************************
Function: destroy_mixed_fraction()
Description: Deallocate memory of an existing mixed fraction object created
by create_mixed_fraction
Inputs: const Fraction*

const FRACTION* this - this points to a struct FRACTION that is read only

Outputs: create mixed fraction and return its pointer
****************************************************************************/

void destroy_mixed_fraction(MIXED_FRACTION* this)
{
  free(this->proper_fraction);
  free(this);
}

/****************************************************************************
Function: get_mixed_whole_number()
Description: Returns an integer part of the fraction
Inputs: const MIXED_FRACTION*

const MIXED_FRACTION* this - this points to struct MIXED_FRACTION* that is read
only

Outputs: returns an integer part of the fraction
****************************************************************************/

int get_mixed_whole_number(const MIXED_FRACTION* this)
{
  return (this->whole_number);
}

/****************************************************************************
Function: get_mixed_numerator()
Description: Returns an integer part of the fraction
Inputs: const MIXED_FRACTION* 

const MIXED_FRACTION* this - this points to struct MIXED_FRACTION* that is 
read only

Outputs: returns an numerator part of the fraction
****************************************************************************/

int get_mixed_numerator(const MIXED_FRACTION* this)
{
  return (this->proper_fraction->numerator);
}

/****************************************************************************
Function: get_mixed_numerator()
Description: Returns an integer part of the fraction
Inputs: const MIXED_FRACTION* 

const MIXED_FRACTION* this - this points to struct MIXED_FRACTION* that is
read only

Outputs: returns an denominator part of the fraction
****************************************************************************/

int get_mixed_denominator(const MIXED_FRACTION* this)
{
  return (this->proper_fraction->denominator);
}



