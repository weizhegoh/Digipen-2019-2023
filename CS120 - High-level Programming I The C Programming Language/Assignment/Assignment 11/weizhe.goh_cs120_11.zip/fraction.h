#ifndef _FRACTION_H_
#define _FRACTION_H_

struct FRACTION_t;
typedef struct FRACTION_t FRACTION;

struct MIXED_FRACTION_t;
typedef struct MIXED_FRACTION_t MIXED_FRACTION;

struct FRACTION_t
{
  int numerator;
  int denominator;
};

struct MIXED_FRACTION_t
{
  int whole_number;
  FRACTION* proper_fraction;
};

int greatestCommonD(FRACTION* this);

FRACTION* create_fraction(int numerator, int denominator);

FRACTION* copy_fraction(const FRACTION* other);

void add_fraction(FRACTION* this, const FRACTION* other);

void subtract_fraction(FRACTION* this, const FRACTION* other);

void multiply_fraction(FRACTION* this, const FRACTION* other);

void divide_fraction(FRACTION* this, const FRACTION* other);

void destroy_fraction(FRACTION* this);

int get_numerator(const FRACTION* this);

int get_denominator(const FRACTION* this);

MIXED_FRACTION* create_mixed_fraction(const FRACTION* fraction);

void destroy_mixed_fraction(MIXED_FRACTION* this);

int get_mixed_whole_number(const MIXED_FRACTION* this);

int get_mixed_numerator(const MIXED_FRACTION* this);

int get_mixed_denominator(const MIXED_FRACTION* this);

#endif
