#define _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>   /* atoi      */
#include <stdio.h>    /* printf    */
#include "fraction.h" /* fractions */

typedef enum
{
	foAdd,
	foSubtract,
	foMultiply,
	foDivide
} FRACTION_OPERATION;

typedef enum
{
	FALSE = 0,
	TRUE = 1
} BOOL;

void test_fraction(
	FRACTION_OPERATION operation,
	BOOL is_mixed,
	int numerator1,
	int denominator1,
	int numerator2,
	int denominator2)
{
	typedef void (*ACTION)(FRACTION * this, const FRACTION * other);
	static const ACTION actions[] =
	{
		add_fraction,
		subtract_fraction,
		multiply_fraction,
		divide_fraction
	};
	static const char operators[] =
	{
		'+',
		'-',
		'*',
		'/'
	};

	FRACTION* a = create_fraction(numerator1, denominator1);
	FRACTION* b = create_fraction(numerator2, denominator2);
	FRACTION* c = copy_fraction(a);

	actions[operation](c, b);

	printf(
		"%i/%i %c %i/%i = ",
		get_numerator(a), get_denominator(a),
		operators[operation],
		get_numerator(b), get_denominator(b)
	);

	destroy_fraction(a);
	destroy_fraction(b);

	if (!get_denominator(c))
	{
		printf("(Undefined value)");
	}
	else
	{
		printf(
			"%i/%i",
			get_numerator(c), get_denominator(c)
		);
	}
	if (is_mixed)
	{
		MIXED_FRACTION* m = create_mixed_fraction(c);
		printf(" ==> ");

		if (!get_mixed_denominator(m))
		{
			printf("(Undefined value)");
		}
		else if (!get_mixed_numerator(m))
		{
			printf("%i", get_mixed_whole_number(m));
		}
		else
		{
			if (get_mixed_whole_number(m))
			{
				printf("%i ", get_mixed_whole_number(m));
			}
			printf(
				"%i/%i",
				get_mixed_numerator(m),
				get_mixed_denominator(m)
			);
		}
		destroy_mixed_fraction(m);
	}
	destroy_fraction(c);
	printf("\n");
}

void test_add(void)
{
	printf("===== Testing add =====\n");
	test_fraction(foAdd, FALSE, 2, 3, 1, 6);
	test_fraction(foAdd, FALSE, 1, 5, 4, 9);
	test_fraction(foAdd, FALSE, 3, 7, 12, 21);
	test_fraction(foAdd, FALSE, 5, 8, 3, 16);
	test_fraction(foAdd, FALSE, 7, 8, 3, 12);
	test_fraction(foAdd, FALSE, 0, 8, 3, 16);
	test_fraction(foAdd, FALSE, 1, 1, 3, 16);
	test_fraction(foAdd, FALSE, 5, 8, -3, 16);
	test_fraction(foAdd, FALSE, 1, 5, -4, 9);
	test_fraction(foAdd, FALSE, -1, 5, -4, 9);
	test_fraction(foAdd, FALSE, 1, 2, 1, 2);
	test_fraction(foAdd, FALSE, 5, 5, -5, 5);
	test_fraction(foAdd, FALSE, 0, 4, 5, 7);
	test_fraction(foAdd, FALSE, 0, 0, 0, 0);
}

void test_subtract(void)
{
	printf("===== Testing subtract =====\n");
	test_fraction(foSubtract, FALSE, 2, 3, 1, 6);
	test_fraction(foSubtract, FALSE, 1, 5, 4, 9);
	test_fraction(foSubtract, FALSE, 3, 7, 12, 21);
	test_fraction(foSubtract, FALSE, 5, 8, 3, 16);
	test_fraction(foSubtract, FALSE, 7, 8, 3, 12);
	test_fraction(foSubtract, FALSE, 0, 8, 3, 16);
	test_fraction(foSubtract, FALSE, 1, 1, 3, 16);
	test_fraction(foSubtract, FALSE, 5, 8, -3, 16);
	test_fraction(foSubtract, FALSE, 1, 5, -4, 9);
	test_fraction(foSubtract, FALSE, -1, 5, -4, 9);
	test_fraction(foSubtract, FALSE, 5, 5, 5, 5);
	test_fraction(foSubtract, FALSE, 0, 4, 5, 7);
	test_fraction(foSubtract, FALSE, 0, 0, 0, 0);
}

void test_multiply(void)
{
	printf("===== Testing multiply =====\n");
	test_fraction(foMultiply, FALSE, 2, 3, 1, 6);
	test_fraction(foMultiply, FALSE, 1, 5, 4, 9);
	test_fraction(foMultiply, FALSE, 3, 7, 12, 21);
	test_fraction(foMultiply, FALSE, 5, 8, 3, 16);
	test_fraction(foMultiply, FALSE, 7, 8, 3, 12);
	test_fraction(foMultiply, FALSE, 0, 8, 3, 16);
	test_fraction(foMultiply, FALSE, 1, 1, 3, 16);
	test_fraction(foMultiply, FALSE, 5, 8, -3, 16);
	test_fraction(foMultiply, FALSE, 1, 5, -4, 9);
	test_fraction(foMultiply, FALSE, -1, 5, -4, 9);
	test_fraction(foMultiply, FALSE, 5, 5, 5, 5);
	test_fraction(foMultiply, FALSE, 0, 4, 5, 7);
	test_fraction(foMultiply, FALSE, 0, 0, 0, 0);
}

void test_divide(void)
{
	printf("===== Testing divide =====\n");
	test_fraction(foDivide, FALSE, 2, 3, 1, 6);
	test_fraction(foDivide, FALSE, 1, 5, 4, 9);
	test_fraction(foDivide, FALSE, 3, 7, 12, 21);
	test_fraction(foDivide, FALSE, 5, 8, 3, 16);
	test_fraction(foDivide, FALSE, 7, 8, 3, 12);
	test_fraction(foDivide, FALSE, 0, 8, 3, 16);
	test_fraction(foDivide, FALSE, 1, 1, 3, 16);
	test_fraction(foDivide, FALSE, 5, 8, -3, 16);
	test_fraction(foDivide, FALSE, 1, 5, -4, 9);
	test_fraction(foDivide, FALSE, -1, 5, -4, 9);
	test_fraction(foDivide, FALSE, 5, 5, 5, 5);
	test_fraction(foDivide, FALSE, 0, 4, 5, 7);
	test_fraction(foDivide, FALSE, 0, 0, 0, 0);
}

void test_adding_mixed(void)
{
	printf("===== Testing add and mixed =====\n");
	test_fraction(foAdd, TRUE, 2, 3, 1, 6);
	test_fraction(foAdd, TRUE, 1, 5, 4, 9);
	test_fraction(foAdd, TRUE, 3, 7, 12, 21);
	test_fraction(foAdd, TRUE, 5, 8, 3, 16);
	test_fraction(foAdd, TRUE, 7, 8, 3, 12);
	test_fraction(foAdd, TRUE, 0, 8, 3, 16);
	test_fraction(foAdd, TRUE, 1, 1, 3, 16);
	test_fraction(foAdd, TRUE, 5, 8, -3, 16);
	test_fraction(foAdd, TRUE, 1, 5, -4, 9);
	test_fraction(foAdd, TRUE, -1, 5, -4, 9);
	test_fraction(foAdd, TRUE, 1, 2, 1, 2);
	test_fraction(foAdd, TRUE, 5, 5, -5, 5);
	test_fraction(foAdd, TRUE, 0, 4, 5, 7);
	test_fraction(foAdd, TRUE, 0, 0, 0, 0);
}

void test_subtract_mixed(void)
{
	printf("===== Testing subtract and mixed =====\n");
	test_fraction(foSubtract, TRUE, 2, 3, 1, 6);
	test_fraction(foSubtract, TRUE, 1, 5, 4, 9);
	test_fraction(foSubtract, TRUE, 3, 7, 12, 21);
	test_fraction(foSubtract, TRUE, 5, 8, 3, 16);
	test_fraction(foSubtract, TRUE, 7, 8, 3, 12);
	test_fraction(foSubtract, TRUE, 0, 8, 3, 16);
	test_fraction(foSubtract, TRUE, 1, 1, 3, 16);
	test_fraction(foSubtract, TRUE, 5, 8, -3, 16);
	test_fraction(foSubtract, TRUE, 1, 5, -4, 9);
	test_fraction(foSubtract, TRUE, -1, 5, -4, 9);
	test_fraction(foSubtract, TRUE, 5, 5, 5, 5);
	test_fraction(foSubtract, TRUE, 0, 4, 5, 7);
	test_fraction(foSubtract, TRUE, 0, 0, 0, 0);
}

void test_multiply_mixed(void)
{
	printf("===== Testing multiply and mixed =====\n");
	test_fraction(foMultiply, TRUE, 2, 3, 1, 6);
	test_fraction(foMultiply, TRUE, 1, 5, 4, 9);
	test_fraction(foMultiply, TRUE, 3, 7, 12, 21);
	test_fraction(foMultiply, TRUE, 5, 8, 3, 16);
	test_fraction(foMultiply, TRUE, 7, 8, 3, 12);
	test_fraction(foMultiply, TRUE, 0, 8, 3, 16);
	test_fraction(foMultiply, TRUE, 1, 1, 3, 16);
	test_fraction(foMultiply, TRUE, 5, 8, -3, 16);
	test_fraction(foMultiply, TRUE, 1, 5, -4, 9);
	test_fraction(foMultiply, TRUE, -1, 5, -4, 9);
	test_fraction(foMultiply, TRUE, 5, 5, 5, 5);
	test_fraction(foMultiply, TRUE, 0, 4, 5, 7);
	test_fraction(foMultiply, TRUE, 0, 0, 0, 0);
}

void test_divide_mixed(void)
{
	printf("===== Testing divide and mixed =====\n");
	test_fraction(foDivide, TRUE, 2, 3, 1, 6);
	test_fraction(foDivide, TRUE, 1, 5, 4, 9);
	test_fraction(foDivide, TRUE, 3, 7, 12, 21);
	test_fraction(foDivide, TRUE, 5, 8, 3, 16);
	test_fraction(foDivide, TRUE, 7, 8, 3, 12);
	test_fraction(foDivide, TRUE, 0, 8, 3, 16);
	test_fraction(foDivide, TRUE, 1, 1, 3, 16);
	test_fraction(foDivide, TRUE, 5, 8, -3, 16);
	test_fraction(foDivide, TRUE, 1, 5, -4, 9);
	test_fraction(foDivide, TRUE, -1, 5, -4, 9);
	test_fraction(foDivide, TRUE, 5, 5, 5, 5);
	test_fraction(foDivide, TRUE, 0, 4, 5, 7);
	test_fraction(foDivide, TRUE, 0, 0, 0, 0);
}

void test_all(void)
{
	test_add();
	test_subtract();
	test_multiply();
	test_divide();
	test_adding_mixed();
	test_subtract_mixed();
	test_multiply_mixed();
	test_divide_mixed();
}

int main(int argc, char** argv)
{
	typedef void (*TEST)(void);
	static const TEST tests[] =
	{
		test_all,
		test_add,
		test_subtract,
		test_multiply,
		test_divide,
		test_adding_mixed,
		test_subtract_mixed,
		test_multiply_mixed,
		test_divide_mixed,
	};

	int test_index = 0;
	if (argc > 1)
	{
		/* atoi: ASCII to int */
		test_index = atoi(argv[1]);
	}
	tests[test_index % 9]();
	return 0;
}
