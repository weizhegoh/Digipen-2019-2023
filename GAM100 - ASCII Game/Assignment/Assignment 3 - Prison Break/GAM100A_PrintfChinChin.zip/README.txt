Game Name: Prison Break

Team Name: Printf(ChinChin)

Class-Section Year: GAM100OF19-A

Team Members: 
Irfan Hidayat B Rosland (irfanhidayatb.r@digipen.edu)
Goh Wei Zhe (weizhe.goh@digipen.edu)
Ryan Lim Zhi Xian (zhixianryan.lim@digipen.edu)
Lim Chin Ann (l.chinann@digipen.edu)
