#ifndef ENEMY_H
#define ENEMY_H

struct Enemy
{
	double x, y;
	double velocity;
	int i;
	int upperX, lowerX;
	int upperY, lowerY;
	int moveDirection;
	int turnCW;
};

enum Direction
{
	UP = 0,
	DOWN,
	LEFT,
	RIGHT,
	CHASE
};

void enemyControls(struct Enemy* enemies, int numEnemies);

void enemyRender(struct Enemy* enemies, int numEnemies);

void gameOver(struct Enemy *enemies, int numEnemies);
#endif
