#ifndef PLAYER_H
#define PLAYER_H

void UpdatePlayer(float dt);
void DrawPlayer();

int Dist_2_Wall(const double CharaX, const double CharaY, int keystate);

int offsetX; int offsetY;

#endif