#ifndef MOVEMENT_H
#define MOVEMENT_H

void movement();
//void LevelOneCollision();
void wallCollision();

int offsetX; int offsetY;

#endif