/**********************************************************************************
* \file			level3.c
* \brief		level 3 Page
* \author		Wei Zhe, Ryan, Irfan
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#include "Level3.h"
#include <Windows.h>
#include <stdio.h>
#include "Console/Console.h"
#include "StateMachine/StateMachine.h"
#include "Variables.h"
#include "Player.h"
#include "enemy.h"
#include "Clock.h"
#include "GameLogic.h"

#define NUMENEMIES 8
#define NUMKEYS 1

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;

struct Enemy enemies[NUMENEMIES];	
struct Key key[NUMKEYS];	

void initKey3(struct Key* key, int numKeys)	//Done by: Irfan
{
	key[0].x = 5;
	key[0].y = 5;
}

void initEnemy3(struct Enemy* enemies, int numEnemies)	//Done by: Wei Zhe
{
	//Enemy 1 (Vertical AI)
	enemies[0].velocity = 0.010;
	enemies[0].x = 6;
	enemies[0].y = 30;
	enemies[0].upperX = 6;
	enemies[0].lowerX = 6;
	enemies[0].upperY = 48;
	enemies[0].lowerY = 4;
	enemies[0].moveDirection = UP;
	enemies[0].turnCW = 0;

	//Enemy 2 (Vertical AI)
	enemies[1].velocity = 0.005;
	enemies[1].x = 13;
	enemies[1].y = 33;
	enemies[1].upperX = 13;
	enemies[1].lowerX = 13;
	enemies[1].upperY = 48;
	enemies[1].lowerY = 4;
	enemies[1].moveDirection = DOWN;
	enemies[1].turnCW = 0;

	//Enemy 3 (Vertical AI)
	enemies[2].velocity = 0.010;
	enemies[2].x = 103;
	enemies[2].y = 30;
	enemies[2].upperX = 103;
	enemies[2].lowerX = 103;
	enemies[2].upperY = 65;
	enemies[2].lowerY = 11;
	enemies[2].moveDirection = UP;
	enemies[2].turnCW = 0;

	//Enemy 4 (Vertical AI)
	enemies[3].velocity = 0.005;
	enemies[3].x = 111;
	enemies[3].y = 33;
	enemies[3].upperX = 111;
	enemies[3].lowerX = 111;
	enemies[3].upperY = 65;
	enemies[3].lowerY = 11;
	enemies[3].moveDirection = DOWN;
	enemies[3].turnCW = 0;

	//Enemy 5 (Horizontal AI)
	enemies[4].velocity = 0.020;
	enemies[4].x = 100;
	enemies[4].y = 58;
	enemies[4].upperX = 116;
	enemies[4].lowerX = 3;
	enemies[4].upperY = 58;
	enemies[4].lowerY = 58;
	enemies[4].moveDirection = LEFT;
	enemies[4].turnCW = 0;

	//Enemy 6 (Horizontal AI)
	enemies[5].velocity = 0.010;
	enemies[5].x = 100;
	enemies[5].y = 55;
	enemies[5].upperX = 116;
	enemies[5].lowerX = 3;
	enemies[5].upperY = 55;
	enemies[5].lowerY = 55;
	enemies[5].moveDirection = RIGHT;
	enemies[5].turnCW = 0;

	//Enemy 7 (Clockwise AI)
	enemies[6].velocity = 0.010;
	enemies[6].x = 44.99f;
	enemies[6].y = 26.99f;
	enemies[6].upperX = 58;
	enemies[6].lowerX = 44;
	enemies[6].upperY = 40;
	enemies[6].lowerY = 26;
	enemies[6].moveDirection = RIGHT;
	enemies[6].turnCW = 1;

	//Enemy 8 (Anti-Clockwise AI)
	enemies[7].velocity = 0.005;
	enemies[7].x = 61.99f;
	enemies[7].y = 26.99f;
	enemies[7].upperX = 75;
	enemies[7].lowerX = 61;
	enemies[7].upperY = 39;
	enemies[7].lowerY = 26;
	enemies[7].moveDirection = LEFT;
	enemies[7].turnCW = -1;
}

void level3Transit() //Done by: Ryan Lim
{
	if (CharaX <= 116 && CharaX >= 100)
	{
		if (CharaY <= 8 && CharaY >= 2)
		{
			StateMachine_ChangeState(State_Level4);
		}
	}
}

//*********************************************************************************
//									INPUT
//*********************************************************************************
void Level3_ProcessInput()
{
	if (GetAsyncKeyState(VK_ESCAPE) & 1)
		StateMachine_ChangeState(State_GameOver);
}

//*********************************************************************************
//									UPDATE
//*********************************************************************************
void Level3_Update()
{
	UpdatePlayer(Clock_GetDeltaTime());
	enemyControls(enemies, NUMENEMIES);
	if (GetKey)
	{
		level3Transit();
	}
	gameOver(enemies, NUMENEMIES);
	keyCollision(key, NUMKEYS);
}

//*********************************************************************************
//									RENDER
//*********************************************************************************
void Level3_Render()
{
	int y = 75;
	Console_SetRenderBuffer_String(110, y += 2, "  _      ________      ________ _        ____  ");	//Done by: Wei Zhe
	Console_SetRenderBuffer_String(110, y += 2, " | |    |  ____\\ \\    / /  ____| |      |___ \\ ");
	Console_SetRenderBuffer_String(110, y += 2, " | |    | |__   \\ \\  / /| |__  | |        __) |");
	Console_SetRenderBuffer_String(110, y += 2, " | |    |  __|   \\ \\/ / |  __| | |       |__ < ");
	Console_SetRenderBuffer_String(110, y += 2, " | |____| |____   \\  /  | |____| |____   ___) |");
	Console_SetRenderBuffer_String(110, y += 2, " |______|______|   \\/   |______|______| |____/ ");

	printfile();
	printExit(2, 100, 16, 6);
	keyRender(key, NUMKEYS);
	enemyRender(enemies, NUMENEMIES);
	if (GetKey)	//Done by: Irfan
	{
		printKey();
	}
	DrawPlayer();
}

//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void Level3_EnterState()
{
	CharaX = 62;
	CharaY = 15;

	readFromFile("level3.txt");
	initKey3(key, NUMKEYS);
	initEnemy3(enemies, NUMENEMIES);
	gameOver(enemies, NUMENEMIES);
	if (GetAsyncKeyState(VK_ESCAPE))
	{
	}
}

void Level3_ExitState()
{
	GetKey = 0;
}
