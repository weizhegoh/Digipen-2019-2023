/**********************************************************************************
* \file			Win.c
* \brief		Win Page
* \author		Chin Ann
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <Windows.h>
#include "Console/Console.h"
#include "StateMachine/StateMachine.h"
#include "Win.h"

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;

//*********************************************************************************
//									INPUT
//*********************************************************************************
void Win_ProcessInput()
{
	if (GetAsyncKeyState(VK_ESCAPE) & 1)
	{
		StateMachine_ChangeState(State_MainMenu);
	}
}

//*********************************************************************************
//									UPDATE
//*********************************************************************************
void Win_Update()
{
}

//*********************************************************************************
//									RENDER
//*********************************************************************************
void Win_Render()	//Done by: Chin Ann
{
	int y = 0;
	int x = 0;
	
	y = 50;
	x = 50;
	Console_SetRenderBuffer_String(x, y++, "Press > Escape < to exit to the Main Menu");
	Print_YOU_WIN("GAME_OVER_YOU_WIN.txt");
}

//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void Win_EnterState()	//Done by: Chin Ann
{
}

void Win_ExitState()	//Done by: Chin Ann
{
}
void Print_YOU_WIN(char* textfile)
{ 
	FILE* file2;
	if (!fopen_s(&file2,  textfile, "r") && file2 != 0)
	{
		char string_buffer2[100];

		int y = 25;

		while (fgets(string_buffer2, sizeof(string_buffer2), file2) != NULL)
		{
			int x = 30;
			for (int i = 0;i < strlen(string_buffer2);++i)
			{
				if (string_buffer2[i] != '\n')
				{
					Console_SetRenderBuffer_Char(x, y, string_buffer2[i]);
					++x;
				}
			}
			++y;
		}
	}
	fclose(file2);
}

