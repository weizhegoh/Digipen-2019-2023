/**********************************************************************************
* \file			level5.c
* \brief		level 5 Page
* \author		Wei Zhe, Ryan, Irfan
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#include "Level5.h"
#include <Windows.h>
#include "Console/Console.h"
#include "StateMachine/StateMachine.h"
#include "Variables.h"
#include "Player.h"
#include "enemy.h"
#include <stdio.h>
#include "Clock.h"
#include "GameLogic.h"

#define NUMENEMIES 10
#define NUMKEYS 1

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;

struct Enemy enemies[NUMENEMIES];
struct Key key[NUMKEYS];

void initKey5(struct Key* key, int numKeys)	//Done by: Irfan
{
	key[0].x = 59;
	key[0].y = 34;
}

void initEnemy5(struct Enemy* enemies, int numEnemies) //Done by: Wei Zhe
{
	//Enemy 1 (Vertical AI)
	enemies[0].velocity = 0.010;
	enemies[0].x = 7;
	enemies[0].y = 28;
	enemies[0].upperX = 7;
	enemies[0].lowerX = 7;
	enemies[0].upperY = 60;
	enemies[0].lowerY = 4;
	enemies[0].moveDirection = UP;
	enemies[0].turnCW = 0;

	//Enemy 2 (Vertical AI)
	enemies[1].velocity = 0.005;
	enemies[1].x = 108;
	enemies[1].y = 31;
	enemies[1].upperX = 108;
	enemies[1].lowerX = 108;
	enemies[1].upperY = 64;
	enemies[1].lowerY = 4;
	enemies[1].moveDirection = DOWN;
	enemies[1].turnCW = 0;

	//Enemy 3 (Vertical AI)
	enemies[2].velocity = 0.010;
	enemies[2].x = 41;
	enemies[2].y = 28;
	enemies[2].upperX = 41;
	enemies[2].lowerX = 41;
	enemies[2].upperY = 52;
	enemies[2].lowerY = 23;
	enemies[2].moveDirection = UP;
	enemies[2].turnCW = 0;

	//Enemy 4 (Vertical AI)
	enemies[3].velocity = 0.005;
	enemies[3].x = 73;
	enemies[3].y = 31;
	enemies[3].upperX = 73;
	enemies[3].lowerX = 73;
	enemies[3].upperY = 42;
	enemies[3].lowerY = 24;
	enemies[3].moveDirection = DOWN;
	enemies[3].turnCW = 0;

	//Enemy 5 (Horizontal AI)
	enemies[4].velocity = 0.008;
	enemies[4].x = 83;
	enemies[4].y = 61;
	enemies[4].upperX = 111;
	enemies[4].lowerX = 3;
	enemies[4].upperY = 61;
	enemies[4].lowerY = 61;
	enemies[4].moveDirection = LEFT;
	enemies[4].turnCW = 0;

	//Enemy 6 (Horizontal AI)
	enemies[5].velocity = 0.020;
	enemies[5].x = 98;
	enemies[5].y = 6;
	enemies[5].upperX = 107;
	enemies[5].lowerX = 3;
	enemies[5].upperY = 6;
	enemies[5].lowerY = 6;
	enemies[5].moveDirection = RIGHT;
	enemies[5].turnCW = 0;

	//Enemy 7 (Horizontal AI)
	enemies[6].velocity = 0.008;
	enemies[6].x = 83;
	enemies[6].y = 13;
	enemies[6].upperX = 114;
	enemies[6].lowerX = 3;
	enemies[6].upperY = 13;
	enemies[6].lowerY = 13;
	enemies[6].moveDirection = LEFT;
	enemies[6].turnCW = 0;

	//Enemy 8 (Clockwise AI)
	enemies[7].velocity = 0.005;
	enemies[7].x = 23.99f;
	enemies[7].y = 21.99f;
	enemies[7].upperX = 33;
	enemies[7].lowerX = 23;
	enemies[7].upperY = 51;
	enemies[7].lowerY = 21;
	enemies[7].moveDirection = LEFT;
	enemies[7].turnCW = 1;

	//Enemy 9 (Anti-Clockwise AI)
	enemies[8].velocity = 0.015;
	enemies[8].x = 93.99f;
	enemies[8].y = 14.99f;
	enemies[8].upperX = 103;
	enemies[8].lowerX = 93;
	enemies[8].upperY = 48;
	enemies[8].lowerY = 14;
	enemies[8].moveDirection = LEFT;
	enemies[8].turnCW = -1;

	//Enemy 10 (Horizontal AI)
	enemies[9].velocity = 0.005;
	enemies[9].x = 83;
	enemies[9].y = 50;
	enemies[9].upperX = 88;
	enemies[9].lowerX = 38;
	enemies[9].upperY = 50;
	enemies[9].lowerY = 50;
	enemies[9].moveDirection = LEFT;
	enemies[9].turnCW = 0;
}

void level5Transit()	//Done by: Ryan Lim
{
	if (CharaX <= 116 && CharaX >= 110)
	{
		if (CharaY <= 8 && CharaY >= 2)
		{
			StateMachine_ChangeState(state_Win);
		}
	}
}

//*********************************************************************************
//									INPUT
//*********************************************************************************
void Level5_ProcessInput()
{
	if (GetAsyncKeyState(VK_ESCAPE) & 1)
		StateMachine_ChangeState(State_GameOver);
}

//*********************************************************************************
//									UPDATE
//*********************************************************************************
void Level5_Update()
{
	UpdatePlayer(Clock_GetDeltaTime());
	enemyControls(enemies, NUMENEMIES);
	gameOver(enemies, NUMENEMIES);
	if (GetKey)	//Done by: Irfan
	{
		level5Transit();
	}
	keyCollision(key, NUMKEYS);

}

//*********************************************************************************
//									RENDER
//*********************************************************************************
void Level5_Render()
{
	int y = 75;
	Console_SetRenderBuffer_String(110, y += 2, "  _      ________      ________ _        _____ ");	//Done by: Wei Zhe
	Console_SetRenderBuffer_String(110, y += 2, " | |    |  ____\\ \\    / /  ____| |      | ____|");
	Console_SetRenderBuffer_String(110, y += 2, " | |    | |__   \\ \\  / /| |__  | |      | |__  ");
	Console_SetRenderBuffer_String(110, y += 2, " | |    |  __|   \\ \\/ / |  __| | |      |___ \\ ");
	Console_SetRenderBuffer_String(110, y += 2, " | |____| |____   \\  /  | |____| |____   ___) |");
	Console_SetRenderBuffer_String(110, y += 2, " |______|______|   \\/   |______|______| |____/ ");

	printfile();
	printExit(2, 110, 6, 6);
	keyRender(key, NUMKEYS);
	enemyRender(enemies, NUMENEMIES);
	if (GetKey)
	{
		printKey();
	}
	DrawPlayer();
}       

//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void Level5_EnterState()
{
	CharaX = 5;
	CharaY = 12;

	readFromFile("level5.txt");
	initKey5(key, NUMKEYS);
	initEnemy5(enemies, NUMENEMIES);
	DrawPlayer();
	gameOver(enemies, NUMENEMIES);
	if (GetAsyncKeyState(VK_ESCAPE))
	{
	}
}

void Level5_ExitState()
{
	GetKey = 0;
}
