/**********************************************************************************
* \file			PrisonBreak.c
* \brief		State Machine
* \author		Irfan
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#include <stdio.h>
#include "Console/Console.h"
#include "Variables.h"
#include "StateMachine/StateMachine.h"
#include "Clock.h"
#include "StateMachine/Global.h"

int main()
{
	StartUp();
	StateMachine_ChangeState(State_DiGiPen_Logo);

	//while (!bExitGameRequested)
	while(Global_IsGameRunning())
	{
		Clock_GameLoopStart();
		StateMachine_StartFrame();
		StateMachine_ProcessInput();
		StateMachine_Update();
		StateMachine_Render();
	}

	Console_CleanUp();
}
