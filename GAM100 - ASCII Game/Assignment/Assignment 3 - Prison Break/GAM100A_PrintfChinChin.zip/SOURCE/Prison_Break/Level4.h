#pragma once
#ifndef LEVEL4_H
#define LEVEL4_H

void Level4_EnterState();
void Level4_ExitState();

void Level4_ProcessInput();
void Level4_Update();
void Level4_Render();

#endif  GAME_H

