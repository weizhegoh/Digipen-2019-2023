#include <Windows.h>
#include "Clock.h"
#include "Movement.h"
#include "Variables.h"

int CharaX = 15; int CharaY = 35; int limit = 0;
int keystate = VK_RIGHT; int chargecheck = 0;
char str[256]; char* indicate[10];
double charge = 0.0; double velocity = 0.75;
offsetX = 0;
offsetY = 0;

void movement()
{
	wallY = 179; wallX = 196;
	WallposX = 125; WallposY = 130;
	fillerpos = 124; filler = 178;
	double time = Clock_GetDeltaTime() / 75;
	double disttraveled = 0;


	//Saving direction
	if (GetAsyncKeyState(VK_LEFT))
	{
		keystate = VK_LEFT;
		*indicate = "LEFT";
	}
	else if (GetAsyncKeyState(VK_RIGHT))
	{
		keystate = VK_RIGHT;
		*indicate = "RIGHT";
	}
	else if (GetAsyncKeyState(VK_UP))
	{
		keystate = VK_UP;
		*indicate = "UP";
	}
	else if (GetAsyncKeyState(VK_DOWN))
	{
		keystate = VK_DOWN;
		*indicate = "DOWN";
	}
	//Charge
	if (GetAsyncKeyState(VK_SPACE) & 1)
	{
		if ((charge <= 9 && charge >= 0) && limit == 0)
		{
			charge += time;
		}
		else if (charge >= 9 && limit == 0)
		{
			limit = 1;
			charge -= time;
			if (charge < 0)
			{
				charge = 0;
			}
		}
		else if (charge >= 0 && limit == 1)
		{
			charge -= time;
			if (charge < 0)
			{
				charge = 0;
				limit = 0;
			}
		}
		else if (charge <= 0 && limit == 1)
		{
			limit = 0;
			charge += time;
		}
	}

	if ((int)charge > 0 && GetAsyncKeyState(VK_SPACE) == 0)
	{
		if (keystate == VK_RIGHT)
		{
			CharaX = CharaX + (charge*time);
			//offsetX += (charge*time*velocity);
		}
		else if (keystate == VK_LEFT)
		{
			CharaX = CharaX - (charge*time);
			//offsetX -= (charge*time*velocity);
		}
		else if (keystate == VK_UP)
		{
			CharaY = CharaY - (charge*time);
			//offsetY -= (charge*time*velocity);
		}
		else if (keystate == VK_DOWN)
		{
			CharaY = CharaY + (charge * time);
			//offsetY += (charge*time*velocity);
		}
		chargecheck++;
		if (chargecheck == (int)charge)
		{
			chargecheck = 0; charge = 0;
		}
	}

	int camPos_update(CharaX, CharaY);
	
	/**************************************************************
	Render
	**************************************************************/
	//Display Character

	/*
	Console_SetRenderBuffer_Char(CharaX, CharaY, 219 , 0x000A);
	Console_SetRenderBuffer_Char(CharaX-1, CharaY-1,' ', 0x000A);
	Console_SetRenderBuffer_Char(CharaX, CharaY-1, 153, 0x000A);
	Console_SetRenderBuffer_Char(CharaX+1, CharaY-1, ' ', 0x000A);
	Console_SetRenderBuffer_Char(CharaX-1, CharaY, 174, 0x000A);
	Console_SetRenderBuffer_Char(CharaX+1, CharaY, 175, 0x000A);
	Console_SetRenderBuffer_Char(CharaX-1, CharaY+1, ' ', 0x000A);
	Console_SetRenderBuffer_Char(CharaX, CharaY+1, 227, 0x000A);
	Console_SetRenderBuffer_Char(CharaX+1, CharaY+1, ' ', 0x000A);
	*/

	Console_SetRenderBuffer_Char((CharaX - offsetX), (CharaY - offsetY), 219, 0x000A);
	Console_SetRenderBuffer_Char((CharaX - offsetX) - 1, (CharaY - offsetY) - 1, ' ', 0x000A);
	Console_SetRenderBuffer_Char((CharaX - offsetX), (CharaY - offsetY) - 1, 153, 0x000A);
	Console_SetRenderBuffer_Char((CharaX - offsetX), + 1, (CharaY - offsetY) - 1, ' ', 0x000A);
	Console_SetRenderBuffer_Char((CharaX - offsetX), - 1, (CharaY - offsetY), 174, 0x000A);
	Console_SetRenderBuffer_Char((CharaX - offsetX), + 1, (CharaY - offsetY), 175, 0x000A);
	Console_SetRenderBuffer_Char((CharaX - offsetX), - 1, (CharaY - offsetY) + 1, ' ', 0x000A);
	Console_SetRenderBuffer_Char((CharaX - offsetX), (CharaY - offsetY) + 1, 227, 0x000A);
	Console_SetRenderBuffer_Char((CharaX - offsetX), + 1, (CharaY - offsetY) + 1, ' ', 0x000A);

	//Display Direction
	sprintf_s(str, 256, "DIRECTION : %s", *indicate); Console_SetRenderBuffer_String(125, 10, str, 0x000A);


	//Display Battery wall
	for (int i = 0; i <= 10; i++)
	{
		Console_SetRenderBuffer_Char(WallposX, 1, wallX); Console_SetRenderBuffer_Char(WallposX, 3, wallX);
		++WallposX;
	}

	//Fill up the bar
	if (charge <= 11 && charge >= 0)
	{
		for (int i = 0; i <= charge; i++)
		{
			Console_SetRenderBuffer_Char(fillerpos, 2, filler);
			fillerpos++;
		}
	}
	else
	{
		for (int i = 8; i >= charge; i--)
		{
			Console_SetRenderBuffer_Char(fillerpos, 2, filler);
			fillerpos--;
		}
	}
	Console_SetRenderBuffer_Char(124, 2, wallY); Console_SetRenderBuffer_Char(136, 2, wallY);

}

//collission
/*void LevelOneCollision()
{


	if (CharaX >= L1RedS_W && CharaX <= L1RedE_W)
	{
		if (CharaY >= L1RedS_H && CharaY <= L1RedE_H)
		{
			collisioncheck = 1;
		}
	}

	if (CharaX >= L1RedS_W2 && CharaX <= L1RedE_W2)
	{
		if (CharaY >= L1RedS_H && CharaY <= L1RedE_H)
		{
			collisioncheck = 1;
		}
	}

	if (CharaX >= L1RedS_W2 && CharaX <= L1RedE_W2)
	{
		if (CharaY >= L1RedS_H && CharaY <= L1RedE_H)
		{
			collisioncheck = 1;
		}
	}
}
*/

void wallCollision()
{
	if (CharaX >= L1borderS_W && CharaX <= L1borderE_W)
	{
		if (CharaY <= L1borderS_H)
		{
			CharaY += 1;
		}

		if (CharaY >= L1borderE_H)
		{
			CharaY -= 1;
		}
	}
}