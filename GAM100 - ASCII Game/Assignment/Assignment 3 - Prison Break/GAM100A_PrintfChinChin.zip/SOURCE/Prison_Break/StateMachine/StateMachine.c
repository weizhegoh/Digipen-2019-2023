/**********************************************************************************
* \file			StateMachine.c
* \brief		Game Transition State
* \author		Chin Ann
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/
#include "StateMachine.h"
#include "States/MainMenu.h"
#include "States/GameOver.h"
#include "Libraries/Console.h"
#include "../Level1.h"
#include "../Level2.h"
#include "../Level3.h"
#include "../Level4.h"
#include "../Level5.h"
#include "../Instruction.h"
#include "../DiGiPen_Logo.h"
#include "../Win.h"
#include "../Credits.h"
#include "../Level_Selection.h"


static GameState sCurrentState = State_Default;
static GameState sRequestedState = State_Default;

// Please note that once you know Function and Pointers, we will update this code
// For now, we are using switch and direction function calls

void StateMachine_StartFrame()
{
	if (sCurrentState != sRequestedState)
	{
		// Exit CurrentState
		switch (sCurrentState)
		{
		case State_MainMenu:	MainMenu_ExitState();	   break;
		case State_GameOver:	GameOver_ExitState();	   break;
		case State_Level1:		Level1_ExitState();		   break;
		case State_Level2:		Level2_ExitState();		   break;
		case State_Level3:		Level3_ExitState();		   break;
		case State_Level4:		Level4_ExitState();		   break;
		case State_Level5:		Level5_ExitState();		   break;
		case State_Instruction: Instruction_ExitState();   break;
		case State_Level_Select: Level_Select_ExitState(); break;
		case State_DiGiPen_Logo: DiGiPen_Logo_ExitState(); break;
		case State_Credits:      Credits_ExitState();      break;
		case state_Win:          Win_ExitState();          break;
		default:										   break;
		}

		// Change State
		sCurrentState = sRequestedState;

		// Enter next state CurrentState
		switch (sCurrentState)
		{
		case State_MainMenu:	MainMenu_EnterState();		break;
		case State_GameOver:	GameOver_EnterState();		break;
		case State_Level1:		Level1_EnterState();		break;
		case State_Level2:		Level2_EnterState();		break;
		case State_Level3:		Level3_EnterState();		break;
		case State_Level4:		Level4_EnterState();		break;
		case State_Level5:		Level5_EnterState();		break;
		case State_Instruction: Instruction_EnterState();	break;
		case State_Level_Select: Level_Select_EnterState(); break;
		case State_DiGiPen_Logo: DiGiPen_Logo_EnterState(); break;
		case State_Credits:      Credits_EnterState();      break;
		case state_Win:          Win_EnterState();          break;
		default:											break;
		}
	}
}

void StateMachine_ChangeState(GameState newState)
{
	sRequestedState = newState;
}

void StateMachine_ProcessInput()
{
	switch (sCurrentState)
	{
		case State_MainMenu:	MainMenu_ProcessInput();		break;
		case State_GameOver:	GameOver_ProcessInput();		break;
		case State_Level1:		Level1_ProcessInput();			break;
		case State_Level2:		Level2_ProcessInput();			break;
		case State_Level3:		Level3_ProcessInput();			break;
		case State_Level4:		Level4_ProcessInput();			break;
		case State_Level5:		Level5_ProcessInput();			break;
		case State_Instruction: Instruction_ProcessInput();		break;
		case State_Level_Select: Level_Select_ProcessInput();	break;
		case State_DiGiPen_Logo: DiGiPen_Logo_ProcessInput();	break;
		case State_Credits:      Credits_ProcessInput();		break;
		case state_Win:          Win_ProcessInput();			break;
		default:												break;
	}
}

void StateMachine_Update()
{
	switch (sCurrentState)
	{
		case State_MainMenu:	MainMenu_Update();			break;
		case State_GameOver:	GameOver_Update();			break;
		case State_Level1:		Level1_Update();			break;
		case State_Level2:		Level2_Update();			break;
		case State_Level3:		Level3_Update();			break;
		case State_Level4:		Level4_Update();			break;
		case State_Level5:		Level5_Update();			break;
		case State_Instruction: Instruction_Update();		break;
		case State_Level_Select: Level_Select_Update();		break;
		case State_DiGiPen_Logo: DiGiPen_Logo_Update();		break;
		case State_Credits:      Credits_Update();			break;
		case state_Win:          Win_Update();				break;
		default:											break;
	}
}

void StateMachine_Render()
{
	// Clear the Rendering Buffer
	Console_ClearRenderBuffer();

	// Render the scenes in the Buffer
	switch (sCurrentState)
	{
		case State_MainMenu:	MainMenu_Render();			break;
		case State_GameOver:	GameOver_Render();			break;
		case State_Level1:		Level1_Render();			break;
		case State_Level2:		Level2_Render();			break;
		case State_Level3:		Level3_Render();			break;
		case State_Level4:		Level4_Render();			break;
		case State_Level5:		Level5_Render();			break;
		case State_Instruction: Instruction_Render();       break;
		case State_Level_Select: Level_Select_Render();		break;
		case State_DiGiPen_Logo: DiGiPen_Logo_Render();     break;
		case State_Credits:      Credits_Render();          break;
		case state_Win:          Win_Render();              break;
		default:											break;
	}
	// Copy the Render Buffer to the Screen
	Console_SwapRenderBuffer();
}


