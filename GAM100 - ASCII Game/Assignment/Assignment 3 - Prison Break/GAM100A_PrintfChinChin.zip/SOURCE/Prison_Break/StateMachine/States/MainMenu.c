/**********************************************************************************
* \file			MainMenu.c
* \brief		Main Menu Page
* \author		Chin Ann, Wei Zhe
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "MainMenu.h"
#include <Windows.h>
#include "../../Console/Console.h"
#include "../StateMachine.h"
#include "../Global.h"
#include "../../Instruction.h"
#include "../../Variables.h"
#include "../../Level_Selection.h"

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;
int pointer_arrow_X = 63;
int pointer_arrow_Y = 50;
int previous = 0;
int current = 0;

//*********************************************************************************
//									INPUT
//*********************************************************************************
void MainMenu_ProcessInput()	//Done by: Chin Ann
{
	previous = current;
	if (GetAsyncKeyState(VK_DOWN) & 1)
	{
		// curr = down
		select_menu();
	}
	else if (GetAsyncKeyState(VK_UP) & 1)
	{
		// curr = up
		select_menu();
	}
	else
	{
		//curr = 0
		current = 0;
	}

	//Start
	if ((pointer_arrow_Y == 50) && (GetAsyncKeyState(VK_RETURN) & 1))
		StateMachine_ChangeState(State_Level1);
	//Instructions manu
	else if ((pointer_arrow_Y == 52) && (GetAsyncKeyState(VK_RETURN) & 1))
		StateMachine_ChangeState(State_Instruction);
	//Level
	else if ((pointer_arrow_Y == 54) && (GetAsyncKeyState(VK_RETURN) & 1))
		StateMachine_ChangeState(State_Level_Select);
	//Credits
	else if ((pointer_arrow_Y == 56) && (GetAsyncKeyState(VK_RETURN) & 1))
		StateMachine_ChangeState(State_Credits);
	//Exit
	else if ((pointer_arrow_Y == 58) && (GetAsyncKeyState(VK_RETURN) & 1))
		Global_Exit();
}

void select_menu()	//Done by: Chin Ann
{
	if (GetAsyncKeyState(VK_UP))
	{
		pointer_arrow_Y -= 2;
	}
	else if (GetAsyncKeyState(VK_DOWN))
	{
		pointer_arrow_Y += 2;
	}

	if (pointer_arrow_Y < 50)
	{
		pointer_arrow_Y = 50;
	}
	if (pointer_arrow_Y > 58)
	{
		pointer_arrow_Y = 58;
	}
}

//*********************************************************************************
//									UPDATE
//*********************************************************************************

void MainMenu_Update()
{
}	

//*********************************************************************************
//									RENDER
//*********************************************************************************
void MainMenu_Render()	//Done by: Chin Ann
{

	int y = 48;
	int x = 65;
	unsigned char Main_Menu_Colour_Selected[10] = {0x0000B};

	Print_Prison_Break_Main_Menu("PRISON_BREAK_MAIN_MENU.txt");
	Console_SetRenderBuffer_String_Colour(x, y++, "Main Menu",0x0000E);
	Console_SetRenderBuffer_String(x-3, y++, "----------------");
	Console_SetRenderBuffer_String(x, y++, "Start");
	if(pointer_arrow_Y == (y-1))
	{
		Console_SetRenderBuffer_String_Colour(x, y-1, "Start",*Main_Menu_Colour_Selected);
	}
	Console_SetRenderBuffer_String(x, y++, " ");
	Console_SetRenderBuffer_String(x, y++, "Instructions");
	if (pointer_arrow_Y == (y - 1))
	{
		Console_SetRenderBuffer_String_Colour(x, y - 1, "Instructions", *Main_Menu_Colour_Selected);
	}
	Console_SetRenderBuffer_String(x, y++, " ");
	Console_SetRenderBuffer_String(x, y++, "Select Levels");
	if (pointer_arrow_Y == (y - 1))
	{
		Console_SetRenderBuffer_String_Colour(x, y - 1, "Select Levels", *Main_Menu_Colour_Selected);
	}
	Console_SetRenderBuffer_String(x, y++, " ");
	Console_SetRenderBuffer_String(x, y++, "Credits");
	if (pointer_arrow_Y == (y - 1))
	{
		Console_SetRenderBuffer_String_Colour(x, y - 1, "Credits", *Main_Menu_Colour_Selected);
	}
	Console_SetRenderBuffer_String(x, y++, " ");
	Console_SetRenderBuffer_String(x, y++, "Exit");
	if (pointer_arrow_Y == (y - 1))
	{
		Console_SetRenderBuffer_String_Colour(x, y - 1, "Exit", *Main_Menu_Colour_Selected);
	}
	Console_SetRenderBuffer_Colour_Char(pointer_arrow_X, pointer_arrow_Y, 175,0x0000B);

	y = 62;
	x = 58;
	Console_SetRenderBuffer_String(x, y++, "Press >Enter< to Select");
}



//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void MainMenu_EnterState()
{
	if (GetAsyncKeyState(VK_RETURN))
	{
	}
}

void MainMenu_ExitState()
{

}
void Print_Main_Manu_Border()	//Done by: Chin Ann
{
	FILE* file;
	if (!fopen_s(&file, "main_manu_selection_border.txt", "r") && file != 0)
	{
		//char string_buffer[80];
		char string_buffer[100];

		int y = 49;

		while (fgets(string_buffer, sizeof(string_buffer), file) != NULL)
		{
			int x = 61;
			for (int i = 0;i < strlen(string_buffer);++i)
			{
				if (string_buffer[i] != '\n')
				{
					Console_SetRenderBuffer_Char(x, y, string_buffer[i]);
					++x;
				}
			}
			++y;
		}
	}
	fclose(file);
}

void Print_Prison_Break_Main_Menu(char* textfile) // Wei Zhe
{
	FILE* file2;
	if (!fopen_s(&file2, textfile, "r") && file2 != 0)
	{
		char string_buffer2[100];

		int y = 26;

		while (fgets(string_buffer2, sizeof(string_buffer2), file2) != NULL)
		{
			int x = 40;
			for (int i = 0; i < strlen(string_buffer2); ++i)
			{
				if (string_buffer2[i] != '\n')
				{
					Console_SetRenderBuffer_Colour_Char(x, y, string_buffer2[i],0x0000D);
					++x;
				}
			}
			++y;
		}
	}
	fclose(file2);
}
