#ifndef MAINMENU_H
#define MAINMENU_H

void select_menu();

void MainMenu_EnterState();
void MainMenu_ExitState();

void MainMenu_ProcessInput();
void MainMenu_Update();
void MainMenu_Render();
void Print_Main_Manu_Border();
void Print_Prison_Break_Main_Menu(char* textfile);


#endif // MAINMENU_H

