/**********************************************************************************
* \file			GameOver.c
* \brief		GameOver page 
* \author		Wei Zhe, Chin Ann, Ryan
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "GameOver.h"
#include <Windows.h>
#include "../../Console/Console.h"
#include "../StateMachine.h"
#include "../../Variables.h"

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;

//*********************************************************************************
//									INPUT
//*********************************************************************************
void GameOver_ProcessInput()
{
	if (GetAsyncKeyState(VK_ESCAPE) & 1)
	{	
		StateMachine_ChangeState(State_MainMenu);
	}		
}

//*********************************************************************************
//									UPDATE
//*********************************************************************************
void GameOver_Update()
{
	CharaX = 15; CharaY = 35;
}

//*********************************************************************************
//									RENDER
//*********************************************************************************
void GameOver_Render()
{
	int y = 28;
	int x = 40;
	
	Print_Game_Over_Bars("Prison_Bars.txt");
	Print_Game_Over_Colour("Game_Over_Back_To_Your_Cell.txt");
	Console_SetRenderBuffer_String(x, y++, " ");

	y = 49;
	x = 52; 
	Console_SetRenderBuffer_String(x, y++, "                                       ");
	Console_SetRenderBuffer_String(x, y++, "                                       ");
	Console_SetRenderBuffer_String_Colour(x, y++,        "Press >Escape< to exit to the Main Menu",0x0000E);
	Console_SetRenderBuffer_String(x, y++, "                                       ");
}

//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void GameOver_EnterState()
{
}

void GameOver_ExitState()
{
}

void Print_Game_Over_Colour(char* textfile)	//Done by: Wei Zhe and  updated by: Chin Ann
{
	FILE* file;
	if (!fopen_s(&file, textfile, "r") && file != 0)
	{
		char string_buffer[400];

		int y = 28;

		while (fgets(string_buffer, sizeof(string_buffer), file) != NULL)
		{
			int x = 1;
			for (int i = 0; i < strlen(string_buffer); ++i)
			{
				if (string_buffer[i] != '\n')
				{
					Console_SetRenderBuffer_Colour_Char(x, y, string_buffer[i], 0x000C);
					++x;
				}
			}
			++y;
		}
		fclose(file);
	}
}

void Print_Game_Over_Bars(char* textfile)	//Done by: Chin Ann
{
	FILE* file;
	if (!fopen_s(&file, textfile, "r") && file != 0)
	{
		char string_buffer[400];

		int y = 0;

		while (fgets(string_buffer, sizeof(string_buffer), file) != NULL)
		{
			int x = 0;
			for (int i = 0; i < strlen(string_buffer); ++i)
			{
				if (string_buffer[i] != '\n')
				{
					Console_SetRenderBuffer_Colour_Char(x, y, string_buffer[i], 0x000F);
					++x;
				}
			}
			++y;
		}
		fclose(file);
	}
}

