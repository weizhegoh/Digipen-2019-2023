#ifndef STATEMACHINE_H
#define STATEMACHINE_H

typedef enum GameState
{
	State_Default,
	State_MainMenu,
	State_GameOver,
	State_Level1,
	State_Level2,
	State_Level3,
	State_Level4,
	State_Level5,
	State_Instruction,
	State_Level_Select,
	State_DiGiPen_Logo,
	State_Credits,
	state_Win,
} GameState;

void StateMachine_StartFrame();
void StateMachine_ChangeState(GameState newState);
void StateMachine_ProcessInput();
void StateMachine_Update();
void StateMachine_Render();

#endif // MAINMENU_H

