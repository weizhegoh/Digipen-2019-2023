/**********************************************************************************
* \file			level1.c
* \brief		level 1 Page
* \author		Wei Zhe, Ryan, Irfan
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#include "Level1.h"
#include <Windows.h>
#include "Console/Console.h"
#include "StateMachine/StateMachine.h"
#include "Variables.h"
#include "Player.h"
#include "enemy.h"
#include "Clock.h"
#include "GameLogic.h"

#define NUMENEMIES 4
#define NUMKEYS 1

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;

struct Enemy enemies[NUMENEMIES];
struct Key key[NUMKEYS];

void initKey(struct Key* key, int numKeys) //Done by: Irfan
{
	key[0].x = 100;
	key[0].y = 10;
}

void initEnemy(struct Enemy* enemies, int numEnemies)	//Done by: Wei Zhe
{
	//Enemy 1 (Vertical AI)
	enemies[0].velocity = 0.010;
	enemies[0].x = 45;
	enemies[0].y = 30;
	enemies[0].upperX = 45;
	enemies[0].lowerX = 45;
	enemies[0].upperY = 41;
	enemies[0].lowerY = 24;
	enemies[0].moveDirection = UP;
	enemies[0].turnCW = 0;

	//Enemy 2 (Vertical AI)
	enemies[1].velocity = 0.005;
	enemies[1].x = 75;
	enemies[1].y = 33;
	enemies[1].upperX = 75;
	enemies[1].lowerX = 75;
	enemies[1].upperY = 41;
	enemies[1].lowerY = 24;
	enemies[1].moveDirection = DOWN;
	enemies[1].turnCW = 0;

	//Enemy 3 (Horizontal AI)
	enemies[2].velocity = 0.020;
	enemies[2].x = 100;
	enemies[2].y = 15;
	enemies[2].upperX = 114;
	enemies[2].lowerX = 83;
	enemies[2].upperY = 15;
	enemies[2].lowerY = 15;
	enemies[2].moveDirection = RIGHT;
	enemies[2].turnCW = 0;

	//Enemy 4 (Horizontal AI)
	enemies[3].velocity = 0.008;
	enemies[3].x = 85;
	enemies[3].y = 55;
	enemies[3].upperX = 114;
	enemies[3].lowerX = 83;
	enemies[3].upperY = 55;
	enemies[3].lowerY = 55;
	enemies[3].moveDirection = LEFT;
	enemies[3].turnCW = 0;
}

void levelTransit() // Done by:Ryan Lim
{
	if (CharaX <= 116 && CharaX >= 110)
	{
		if (CharaY <= 66 && CharaY >= 60)
		{
			StateMachine_ChangeState(State_Level2);
		}
	}
}

//*********************************************************************************
//									INPUT
//*********************************************************************************
void Level1_ProcessInput()
{
	if (GetAsyncKeyState(VK_ESCAPE) & 1)
		StateMachine_ChangeState(State_GameOver);
}

//*********************************************************************************
//									UPDATE
//*********************************************************************************
void Level1_Update()
{
	UpdatePlayer(Clock_GetDeltaTime());
	enemyControls(enemies, NUMENEMIES);
	gameOver(enemies, NUMENEMIES);
	if (GetKey)
	{
		levelTransit();
	}
	keyCollision(key, NUMKEYS);
}

//*********************************************************************************
//									RENDER
//*********************************************************************************
void Level1_Render()
{
	int y = 75;

	Console_SetRenderBuffer_String(120, y += 2, "  _     _______     _______ _       _ ");	//Done by: Wei Zhe
	Console_SetRenderBuffer_String(120, y += 2, " | |   | ____\\ \\   / / ____| |     / |");
	Console_SetRenderBuffer_String(120, y += 2, " | |   |  _|  \\ \\ / /|  _| | |     | |");
	Console_SetRenderBuffer_String(120, y += 2, " | |___| |___  \\ V / | |___| |___  | |");
	Console_SetRenderBuffer_String(120, y += 2, " |_____|_____|  \\_/  |_____|_____| |_|");
	Console_SetRenderBuffer_String(120, y += 2, "                                      ");

	printfile();
	printExit(60, 110, 6, 6);
	keyRender(key, NUMKEYS);
	enemyRender(enemies, NUMENEMIES);
	if (GetKey)	//Done by: Irfan
	{
		printKey();
	}
	DrawPlayer();
}

//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void Level1_EnterState()
{
	readFromFile("level1.txt");
	initEnemy(enemies, NUMENEMIES);
	initKey(key, NUMKEYS);
	if (GetAsyncKeyState(VK_ESCAPE))
	{
	}
}

void Level1_ExitState()
{
	GetKey = 0;
}
