/**********************************************************************************
* \file			enemy.c
* \brief		enemies control page
* \author		Wei Zhe
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#include <Windows.h>
#include "Console/Console.h"
#include "Variables.h"
#include "StateMachine/StateMachine.h"
#include "Clock.h"
#include "enemy.h"
#include "GameLogic.h"

void enemyControls(struct Enemy *enemies, int numEnemies) //Done by: Wei Zhe
{
	int i;
	double up;
	double down;
	double left;
	double right;

	for (i = 0;i < numEnemies; ++i)
	{
		left = enemies[i].x - enemies[i].velocity*Clock_GetDeltaTime();
		right = enemies[i].x + enemies[i].velocity*Clock_GetDeltaTime();
		up = enemies[i].y - enemies[i].velocity*Clock_GetDeltaTime();
		down = enemies[i].y + enemies[i].velocity*Clock_GetDeltaTime();

	
		if (enemies[i].moveDirection == UP)
		{
			enemies[i].y = up;
		}
		else if (enemies[i].moveDirection == DOWN)
		{
			enemies[i].y = down;
		}
		else if (enemies[i].moveDirection == LEFT)
		{
			enemies[i].x = left;
		}
		else if (enemies[i].moveDirection == RIGHT)
		{
			enemies[i].x = right;
		}

		if (enemies[i].x > enemies[i].upperX)
		{
			if (enemies[i].turnCW == 1)
			{
				enemies[i].x = enemies[i].upperX;
				enemies[i].moveDirection = DOWN;
			}
			else if (enemies[i].turnCW == -1)
			{
				enemies[i].x = enemies[i].upperX;
				enemies[i].moveDirection = UP;
			}
			else
			{
				enemies[i].moveDirection = LEFT;
			}
		}
		else if (enemies[i].x < enemies[i].lowerX)
		{
			if (enemies[i].turnCW == 1)
			{
				enemies[i].x = enemies[i].lowerX;
				enemies[i].moveDirection = UP;
			}
			else if (enemies[i].turnCW == -1)
			{
				enemies[i].x = enemies[i].lowerX;
				enemies[i].moveDirection = DOWN;
			}
			else
			{
				enemies[i].moveDirection = RIGHT;
			}
		}
			if (enemies[i].y > enemies[i].upperY)
		{
			if (enemies[i].turnCW == 1)
			{
				enemies[i].y = enemies[i].upperY;
				enemies[i].moveDirection = LEFT;
			}
			else if (enemies[i].turnCW == -1)
			{
				enemies[i].y = enemies[i].upperY;
				enemies[i].moveDirection = RIGHT;
			}
			else
			{
				enemies[i].moveDirection = UP;
			}
		}
		else if (enemies[i].y < enemies[i].lowerY)
		{
			if (enemies[i].turnCW == 1)
			{
				enemies[i].y = enemies[i].lowerY;
				enemies[i].moveDirection = RIGHT;
			}
			else if (enemies[i].turnCW == -1)
			{
				enemies[i].y = enemies[i].lowerY;
				enemies[i].moveDirection = LEFT;
			}
			else
			{
				enemies[i].moveDirection = DOWN;
			}
		}
	}
}

void gameOver(struct Enemy *enemies, int numEnemies)	//Done by: Wei Zhe
{	
	for (int i = 0;i < numEnemies;++i)
	{
		if (CharaX >= (int)(enemies[i].x - 1) && CharaX <= (int)(enemies[i].x + 1))
		{
			if (CharaY >= (int)(enemies[i].y - 2) && CharaY <= (int)(enemies[i].y + 2))
			{
				GetKey = 0;
				StateMachine_ChangeState(State_GameOver);
			}
		}
	}
}

void enemyRender(struct Enemy *enemies, int numEnemies)	//Done by: Wei Zhe
{
	int i;

	for (i = 0; i <numEnemies;i++)
	{
		Console_SetRenderBuffer_Char((int)(enemies[i].x), (int)(enemies[i].y), 240);
		Console_SetRenderBuffer_Char((int)(enemies[i].x), (int)(enemies[i].y-1), 232);
		Console_SetRenderBuffer_Char((int)(enemies[i].x-1), (int)(enemies[i].y), 218);
		Console_SetRenderBuffer_Char((int)(enemies[i].x + 1), (int)(enemies[i].y), 191);
		Console_SetRenderBuffer_Char((int)(enemies[i].x - 1), (int)(enemies[i].y + 1), 217);
		Console_SetRenderBuffer_Char((int)(enemies[i].x+1), (int)(enemies[i].y+1), 192);
	}
}