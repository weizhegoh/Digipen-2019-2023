#ifndef CREDITS_H
#define CREDITS_H

void Credits_ProcessInput();
void Credits_Update();
void Credits_Render();
void Credits_EnterState();
void Credits_ExitState();

void Print_Prision_Break_Text();


void Print_Credicts_Title();

void Print_Time2();

void Print_Credits(char* textfile);

#endif