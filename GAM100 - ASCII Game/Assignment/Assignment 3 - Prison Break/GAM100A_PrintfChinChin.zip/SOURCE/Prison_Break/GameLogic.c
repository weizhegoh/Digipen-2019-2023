/**********************************************************************************
* \file			GameLogic.c
* \brief		Key Page
* \author		Irfan, Wei Zhe
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#include <Windows.h>
#include "Console/Console.h"
#include "Variables.h"
#include "StateMachine/StateMachine.h"
#include "Clock.h"
#include "enemy.h"
#include "GameLogic.h"

void keyRender(struct Key *key, int numKeys) //Done by: Irfan
{
	if (!GetKey)
	{
		int i;
		for (i = 0; i < numKeys; i++)
		{
			Console_SetRenderBuffer_KeyChar(key[i].x, key[i].y, ' ');
			Console_SetRenderBuffer_KeyChar(key[i].x + 1, key[i].y, ' ');
			Console_SetRenderBuffer_KeyChar(key[i].x, key[i].y + 1, ' ');
			Console_SetRenderBuffer_KeyChar(key[i].x + 1, key[i].y + 1, ' ');
		}
	}
}

void keyCollision(struct Key *key, int numKeys) //Done by: Wei Zhe
{
	
	for (int i = 0; i < numKeys; ++i)
	{
		if ((int)(CharaX+1) >= key[i].x && (int)(CharaX-1) <= key[i].x + 1)
		{
			if ((int)(CharaY+1) >= key[i].y && (int)(CharaY-1) <= key[i].y + 1)
			{
				GetKey = 1;
			}
		}
	}
}

void printKey()	//Done by: Irfan
{
	if (GetKey)
	{
		int vert = 80;
		int hor = 30;
		Console_SetRenderBuffer_String(hor, vert, " 8 8 8 8                     ,ooo.  ");
		Console_SetRenderBuffer_String(hor, vert += 1, " 8a8 8a8                    oP   ?b ");
		Console_SetRenderBuffer_String(hor, vert += 1, "d888a888zzzzzzzzzzzzzzzzzzzz8     8b");
		Console_SetRenderBuffer_String(hor, vert += 1, " `''^'''                    ?o___oP'");

		Console_SetRenderBuffer_String(hor += 50, vert, "OBTAINED");
		Console_SetRenderBuffer_String(hor, vert += 1, "KEY!");
	}
}