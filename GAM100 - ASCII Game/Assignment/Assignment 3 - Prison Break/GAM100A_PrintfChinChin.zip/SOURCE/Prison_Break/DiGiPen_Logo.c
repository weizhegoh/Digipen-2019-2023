/**********************************************************************************
* \file			DiGiPen_Logo.c
* \brief		prints out digipen logo for 2 seconds
* \author		Lim Chin Ann
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <Windows.h>
#include "DiGiPen_Logo.h"
#include "Console/Console.h"
#include "StateMachine/StateMachine.h"
#include "Clock.h"


//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;
static float timer = 0.0f;
unsigned long time;

//*********************************************************************************
//									INPUT
//*********************************************************************************
void DiGiPen_Logo_ProcessInput()
{
	if (GetAsyncKeyState(VK_ESCAPE) & 1 || timer > 1500.0f)
		StateMachine_ChangeState(State_MainMenu);
}
//*********************************************************************************
//									UPDATE
//*********************************************************************************
void DiGiPen_Logo_Update()	//Done by: Chin Ann
{
	timer += Clock_GetDeltaTime();	
}
//*********************************************************************************
//									RENDER
//*********************************************************************************
void DiGiPen_Logo_Render()	//Done by: Chin Ann
{
	time += (unsigned long)Clock_GetDeltaTime();

	Read_Digipen_txt_file();
	Print_file_IO();
}
//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void DiGiPen_Logo_EnterState()
{
}

void DiGiPen_Logo_ExitState()
{
}

//*********************************************************************************
//									Self add
//*********************************************************************************

void Read_Digipen_txt_file()	//Done by: Chin Ann
{
	typedef FILE* fpointer;
	long int i;
	long int size;
	char *logo;

	fpointer fp;
	fp = fopen("DigiPenLogo_Unofficial.txt", "r");
	fseek(fp, 0L, SEEK_END);
	size = ftell(fp);
	logo = (char*)malloc((size_t)size);
	fseek(fp, 0L, SEEK_SET);
	for (i = 0; i < size;++i)
	{
		*(logo + i) = (char)fgetc(fp); /*same as above*/ /*it is a one d array*/

		int x = 20;
		int y = 20;
		Console_SetRenderBuffer_Colour_Char(x, y++, logo[i], 0x000A);
	}
	free(logo); /*if dont have this will have memory leak which will lag the com*/
	fclose(fp);
}
void Print_Time()	//Done by: Chin Ann
{
	Clock_GetElapsedTimeUs();
	Console_SetRenderBuffer_String(28, 3, "Time:");

	char buffer_time[33];
	sprintf_s(buffer_time, 33, "%lu", time / 1000);
	Console_SetRenderBuffer_String(34, 3, buffer_time);
	Console_SetRenderBuffer_String(36, 3, "s    ");
}

void Print_file_IO()	//Done by: Chin Ann
{
	FILE* file;
	if (!fopen_s(&file, "DigiPenLogo_Unofficial.txt", "r") && file != 0)
	{
		char string_buffer[100];
		
		int y = 25;
		
		while (fgets(string_buffer, sizeof(string_buffer), file) != NULL)
		{
			int x = 25;
			for (int i = 0;i < strlen(string_buffer);++i)
			{
				if (string_buffer[i] != '\n')
				{
					Console_SetRenderBuffer_Colour_Char(x,y, string_buffer[i],0x00B0C);
					++x;
				}
			}
			++y;
		}
	}
	fclose(file);
}