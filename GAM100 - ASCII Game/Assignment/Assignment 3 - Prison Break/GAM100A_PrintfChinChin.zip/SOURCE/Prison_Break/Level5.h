#pragma once
#ifndef LEVEL5_H
#define LEVEL5_H

void Level5_EnterState();
void Level5_ExitState();

void Level5_ProcessInput();
void Level5_Update();
void Level5_Render();

#endif // GAME_H
