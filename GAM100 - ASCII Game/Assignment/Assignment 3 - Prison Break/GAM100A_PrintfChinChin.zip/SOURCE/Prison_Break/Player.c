/**********************************************************************************
* \file			Player.c
* \brief		Player controls
* \author		Ryan, Wei Zhe
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#include <Windows.h>
#include "Clock.h"
#include "Player.h"
#include "Variables.h"

double CharaX = 15; double CharaY = 35; int limit = 0;
int keystate = VK_RIGHT; int chargecheck = 0;
char str[256]; char* indicate[10];
double charge = 0.0; double velocity = 2.5;
int dist2wall = 0; double projdist = 0;

void UpdatePlayer(float dt)
{
	WallposX = (int)CharaX; WallposY = 130;
	fillerpos = (int)CharaX; filler = 178;
	double time = dt / 15.0;

	//Saving direction
	if (GetAsyncKeyState(VK_LEFT))
	{
		keystate = VK_LEFT;

	}
	else if (GetAsyncKeyState(VK_RIGHT))
	{
		keystate = VK_RIGHT;
	}
	else if (GetAsyncKeyState(VK_UP))
	{
		keystate = VK_UP;
	}
	else if (GetAsyncKeyState(VK_DOWN))
	{
		keystate = VK_DOWN;
	}
	//Charge
	if (GetAsyncKeyState(VK_SPACE) & 1)
	{
		if ((charge <= 5 && charge >= 0) && limit == 0)
		{
			charge += time;
		}
		else if (charge >= 5 && limit == 0)
		{
			limit = 1;
			charge -= time;
			if (charge < 0)
			{
				charge = 0;
			}
		}
		else if (charge >= 0 && limit == 1)
		{
			charge -= time;
			if (charge < 0)
			{
				charge = 0;
				limit = 0;
			}
		}
		else if (charge <= 0 && limit == 1)
		{
			limit = 0;
			charge += time;
		}
	}

	if ((int)charge > 0 && GetAsyncKeyState(VK_SPACE) == 0)
	{
		dist2wall = Dist_2_Wall(CharaX, CharaY, keystate);

		if (keystate == VK_RIGHT)
		{
			projdist = charge;

			if ((CharaX + charge * time * velocity) >= 120)
			{
				CharaX = (CharaX + dist2wall) - 2;
			}
			else if (projdist > dist2wall)
			{
				CharaX = (CharaX + dist2wall) - 2;
			}
			else if (projdist <= dist2wall)
			{
				CharaX += (charge * time * velocity);
			}
		}
		else if (keystate == VK_LEFT)
		{
			projdist = charge;

			if ((CharaX - (charge * time * velocity)) <= 0)
			{
				CharaX = (CharaX - dist2wall) + 3;
			}
			else if (projdist > dist2wall)
			{
				CharaX = (CharaX - dist2wall) + 2;
			}
			else if (projdist <= dist2wall)
			{
				CharaX -= (charge * time * velocity);
			}
		}

		else if (keystate == VK_UP)
		{
			projdist = charge;

			if ((CharaY - (charge * time * velocity)) <= 0)
			{
				CharaY = (CharaY + dist2wall) + 3;
			}
			else if (projdist > dist2wall)
			{
				CharaY = (CharaY - dist2wall) + 2;
			}
			else if (projdist <= dist2wall)
			{
				CharaY -= (charge * time * velocity);
			}
		}

		else if (keystate == VK_DOWN)
		{
			projdist = charge;

			if ((CharaY + (charge * time * velocity)) >= 70)
			{
				CharaY = (CharaY + dist2wall) - 3;
			}
			else if (projdist > dist2wall)
			{
				CharaY = (CharaY + dist2wall) - 2;
			}
			else if (projdist <= dist2wall)
			{
				CharaY += (charge * time * velocity);
			}
		}
	
		projdist = 0; dist2wall = 0;
		chargecheck++;
		if (chargecheck >= (int)charge)
		{
			chargecheck = 0; charge = 0;
		}
	}
}

void DrawPlayer()	
{
	/**************************************************************
	Render
	**************************************************************/
	//Display Character done by: Wei Zhe
	Console_SetRenderBuffer_Char((int)(CharaX),   (int)(CharaY), 219);
	Console_SetRenderBuffer_Char((int)(CharaX)-1, (int)(CharaY)-1, ' ');
	Console_SetRenderBuffer_Char((int)(CharaX),   (int)(CharaY)-1, 153);
	Console_SetRenderBuffer_Char((int)(CharaX)+1, (int)(CharaY)-1, ' ');
	Console_SetRenderBuffer_Char((int)(CharaX)-1, (int)(CharaY), 174);
	Console_SetRenderBuffer_Char((int)(CharaX)+1, (int)(CharaY), 175);
	Console_SetRenderBuffer_Char((int)(CharaX)-1, (int)(CharaY)+1, ' ');
	Console_SetRenderBuffer_Char((int)(CharaX),   (int)(CharaY)+1, 227);
	Console_SetRenderBuffer_Char((int)(CharaX)+1, (int)(CharaY)+1, ' ');

	//Display Direction  Done by: Ryan Lim
	if (keystate == VK_LEFT)
	{
		Console_SetRenderBuffer_Char((int)CharaX - 2, (int)CharaY, '<');
	}
	else if (keystate == VK_RIGHT)
	{
		Console_SetRenderBuffer_Char((int)CharaX + 2, (int)CharaY, '>');
	}
	else if (keystate == VK_UP)
	{
		Console_SetRenderBuffer_Char((int)CharaX, (int)CharaY - 2, '^');
	}
	else if (keystate == VK_DOWN)
	{
		Console_SetRenderBuffer_Char((int)CharaX, (int)CharaY + 2, 'v');
	}

	if (GetAsyncKeyState(VK_SPACE) != 0)
	{
		//Display Battery wall		Done by: Ryan Lim
		//for (int i = 0; i <= 4; i++)
		//{
		//	Console_SetRenderBuffer_Char(WallposX - 2, (int)CharaY - 3, wallX); Console_SetRenderBuffer_Char(WallposX - 2, (int)CharaY - 5, wallX);
		//	++WallposX;
		//}

		//Display charge bar		Done by: Ryan Lim
		if (charge <= 5 && charge >= 0)
		{
			if (charge > 0)
			{
				for (int i = 0; i <= (int)charge; i++)
				{
					Console_SetRenderBuffer_Char(fillerpos - 2, (int)CharaY - 4, filler);
					fillerpos++;
				}
			}
		}
		else
		{
			if (charge > 0)
			{
				for (int i = 5; i >= charge; i--)
				{
					Console_SetRenderBuffer_Char(fillerpos - 2, (int)CharaY - 4, filler);
					fillerpos--;
				}
			}
		}
		//Console_SetRenderBuffer_Char((int)CharaX - 3, (int)CharaY - 4, wallY); Console_SetRenderBuffer_Char((int)CharaX + 3, (int)CharaY - 4, wallY);
	}
}

int Dist_2_Wall(const double CharaX, const double CharaY, int keystate) //Done by: Ryan Lim
{
	int dist2wall = 0;
	int projectionX = (int)CharaX;
	int projectionY = (int)CharaY;

	while (projectionX < 160 && projectionY < 90 &&
		lineArr[projectionY][projectionX] != '1' && lineArr[projectionY][projectionX] != '2')
	{
		if (keystate == VK_RIGHT)
		{
			projectionX += 1;
			dist2wall++;
		}
		else if (keystate == VK_LEFT)
		{
			projectionX -= 1;
			dist2wall++;
		}
		else if (keystate == VK_UP)
		{
			projectionY -= 1;
			dist2wall++;
		}
		else if (keystate == VK_DOWN)
		{
			projectionY += 1;
			dist2wall++;
		}
	}
	return dist2wall;
}
