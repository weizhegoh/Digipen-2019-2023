/**********************************************************************************
* \file			level4.c
* \brief		level 4 Page
* \author		Wei Zhe, Ryan, Irfan
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#include "Level4.h"
#include <Windows.h>
#include "Console/Console.h"
#include "StateMachine/StateMachine.h"
#include "Variables.h"
#include "Player.h"
#include "enemy.h"
#include <stdio.h>
#include "Clock.h"
#include "GameLogic.h"

#define NUMENEMIES 8
#define NUMKEYS 1

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;

struct Enemy enemies[NUMENEMIES];	
struct Key key[NUMKEYS];	

void initKey4(struct Key* key, int numKeys)	//Done by: Irfan
{
	key[0].x = 3;
	key[0].y = 3;
}

void initEnemy4(struct Enemy* enemies, int numEnemies)	//Done by: Wei Zhe
{
	//Enemy 1 (Vertical AI)
	enemies[0].velocity = 0.005;
	enemies[0].x = 30;
	enemies[0].y = 58;
	enemies[0].upperX = 30;
	enemies[0].lowerX = 30;
	enemies[0].upperY = 64;
	enemies[0].lowerY = 57;
	enemies[0].moveDirection = UP;
	enemies[0].turnCW = 0;

	//Enemy 2 (Vertical AI)
	enemies[1].velocity = 0.007;
	enemies[1].x = 17;
	enemies[1].y = 31;
	enemies[1].upperX = 17;
	enemies[1].lowerX = 17;
	enemies[1].upperY = 42;
	enemies[1].lowerY = 3;
	enemies[1].moveDirection = DOWN;
	enemies[1].turnCW = 0;

	//Enemy 3 (Horizontal AI)
	enemies[2].velocity = 0.005;
	enemies[2].x = 108;
	enemies[2].y = 13;
	enemies[2].upperX = 115;
	enemies[2].lowerX = 94;
	enemies[2].upperY = 13;
	enemies[2].lowerY = 13;
	enemies[2].moveDirection = LEFT;
	enemies[2].turnCW = 0;

	//Enemy 4 (Horizontal AI)
	enemies[3].velocity = 0.005;
	enemies[3].x = 108;
	enemies[3].y = 31;
	enemies[3].upperX = 114;
	enemies[3].lowerX = 94;
	enemies[3].upperY = 31;
	enemies[3].lowerY = 31;
	enemies[3].moveDirection = RIGHT;
	enemies[3].turnCW = 0;

	//Enemy 5 (Horizontal AI)
	enemies[4].velocity = 0.005;
	enemies[4].x = 68;
	enemies[4].y = 51;
	enemies[4].upperX = 80;
	enemies[4].lowerX = 47;
	enemies[4].upperY = 51;
	enemies[4].lowerY = 51;
	enemies[4].moveDirection = RIGHT;
	enemies[4].turnCW = 0;

	//Enemy 6 (Horizontal AI)
	enemies[5].velocity = 0.005;
	enemies[5].x = 103;
	enemies[5].y = 47;
	enemies[5].upperX = 114;
	enemies[5].lowerX = 94;
	enemies[5].upperY = 47;
	enemies[5].lowerY = 2;
	enemies[5].moveDirection = RIGHT;
	enemies[5].turnCW = 0;

	//Enemy 7 (Clockwise AI)
	enemies[6].velocity = 0.010;
	enemies[6].x = 41.99f;
	enemies[6].y = 13.99f;
	enemies[6].upperX = 68;
	enemies[6].lowerX = 40;
	enemies[6].upperY = 38;
	enemies[6].lowerY = 13;
	enemies[6].moveDirection = RIGHT;
	enemies[6].turnCW = 1;

	//Enemy 8 (Vertical AI)
	enemies[7].velocity = 0.005;
	enemies[7].x = 77;
	enemies[7].y = 58;
	enemies[7].upperX = 77;
	enemies[7].lowerX = 77;
	enemies[7].upperY = 65;
	enemies[7].lowerY = 3;
	enemies[7].moveDirection = DOWN;
	enemies[7].turnCW = 0;
}

void level4Transit() //Done by: Ryan Lim
{

	if (CharaX <= 116 && CharaX >= 92)
	{
		if (CharaY <= 66 && CharaY >= 58)
		{
			StateMachine_ChangeState(State_Level5);
		}
	}
}

//*********************************************************************************
//									INPUT
//*********************************************************************************
void Level4_ProcessInput()
{
	if (GetAsyncKeyState(VK_ESCAPE) & 1)
		StateMachine_ChangeState(State_GameOver);
}

//*********************************************************************************
//									UPDATE
//*********************************************************************************
void Level4_Update()
{
	UpdatePlayer(Clock_GetDeltaTime());
	enemyControls(enemies, NUMENEMIES);
	gameOver(enemies, NUMENEMIES);
	if (GetKey)
	{
		level4Transit();
	}
	keyCollision(key, NUMKEYS);
}

//*********************************************************************************
//									RENDER
//*********************************************************************************
void Level4_Render()
{
	int y = 75;
	Console_SetRenderBuffer_String(110, y += 2, "  _      ________      ________ _        _  _   ");	//Done by: Wei Zhe
	Console_SetRenderBuffer_String(110, y += 2, " | |    |  ____\\ \\    / /  ____| |      | || |  ");
	Console_SetRenderBuffer_String(110, y += 2, " | |    | |__   \\ \\  / /| |__  | |      | || |_ ");
	Console_SetRenderBuffer_String(110, y += 2, " | |    |  __|   \\ \\/ / |  __| | |      |__   _|");
	Console_SetRenderBuffer_String(110, y += 2, " | |____| |____   \\  /  | |____| |____     | |  ");
	Console_SetRenderBuffer_String(110, y += 2, " |______|______|   \\/   |______|______|    |_|  ");

	printfile();
	printExit(58, 92, 24, 8);
	keyRender(key, NUMKEYS);
	enemyRender(enemies, NUMENEMIES);
	if (GetKey)	//Done by: Irfan
	{
		printKey();
	}
	DrawPlayer();
}

//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void Level4_EnterState()
{
	CharaX = 5;
	CharaY = 63;

	readFromFile("level4.txt");
	initKey4(key, NUMKEYS);
	initEnemy4(enemies, NUMENEMIES);
	gameOver(enemies, NUMENEMIES);
	if (GetAsyncKeyState(VK_ESCAPE))
	{
	}
}

void Level4_ExitState()
{
	GetKey = 0;
}
