/**********************************************************************************
* \file			level2.c
* \brief		level 2 Page
* \author		Wei Zhe, Ryan, Irfan
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#include "Level2.h"
#include <Windows.h>
#include "Console/Console.h"
#include "StateMachine/StateMachine.h"
#include "Variables.h"
#include "Player.h"
#include "enemy.h"
#include "Clock.h"
#include "GameLogic.h"

#define NUMENEMIES 4
#define NUMKEYS 1

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;

struct Enemy enemies[NUMENEMIES];	
struct Key key[NUMKEYS];	

void initKey2(struct Key* key, int numKeys)	//Done by: Irfan
{
	key[0].x = 38;
	key[0].y = 65;
}

void initEnemy2(struct Enemy* enemies, int numEnemies)	//Done by: Wei Zhe
{
	//Enemy 1 (Clockwise AI)
	enemies[0].velocity = 0.012;
	enemies[0].x = 40.99f;
	enemies[0].y = 18.99f;
	enemies[0].upperX = 79;
	enemies[0].lowerX = 40;
	enemies[0].upperY = 26;
	enemies[0].lowerY = 18;
	enemies[0].moveDirection = RIGHT;
	enemies[0].turnCW = 1;

	//Enemy 2 (Clockwise AI)
	enemies[1].velocity = 0.015;
	enemies[1].x = 94.99f;
	enemies[1].y = 47.99f;
	enemies[1].upperX = 115;
	enemies[1].lowerX = 86;
	enemies[1].upperY = 60;
	enemies[1].lowerY = 47;
	enemies[1].moveDirection = RIGHT;
	enemies[1].turnCW = 1;

	//Enemy 3 (Anti-Clockwise AI)
	enemies[2].velocity = 0.005;
	enemies[2].x = 84.99f;
	enemies[2].y = 6.99f;
	enemies[2].upperX = 114;
	enemies[2].lowerX = 84;
	enemies[2].upperY = 34;
	enemies[2].lowerY = 6;
	enemies[2].moveDirection = LEFT;
	enemies[2].turnCW = -1;

	//Enemy 4 (Anti-Clockwise AI)
	enemies[3].velocity = 0.010;
	enemies[3].x = 14.99f;
	enemies[3].y = 48.99f;
	enemies[3].upperX = 34;
	enemies[3].lowerX = 5;
	enemies[3].upperY = 63;
	enemies[3].lowerY = 48;
	enemies[3].moveDirection = RIGHT;
	enemies[3].turnCW = -1;
}

void level2Transit()//(Done by: Ryan Lim)
{
	if (CharaX <= 116 && CharaX >= 110)
	{
		if (CharaY <= 66 && CharaY >= 60)
		{
			StateMachine_ChangeState(State_Level3);
		}
	}
}

//*********************************************************************************
//									INPUT
//*********************************************************************************
void Level2_ProcessInput()
{
	if (GetAsyncKeyState(VK_ESCAPE) & 1)
		StateMachine_ChangeState(State_GameOver);
}

//*********************************************************************************
//									UPDATE
//*********************************************************************************
void Level2_Update()
{
	UpdatePlayer(Clock_GetDeltaTime());
	enemyControls(enemies, NUMENEMIES);
	gameOver(enemies, NUMENEMIES);
	if (GetKey)
	{
		level2Transit();
	}
	keyCollision(key, NUMKEYS);
}

//*********************************************************************************
//									RENDER
//*********************************************************************************
void Level2_Render()
{
	int y = 75;
	Console_SetRenderBuffer_String(110, y += 2, "  _      ________      ________ _        ___  ");	//Done by: Wei Zhe
	Console_SetRenderBuffer_String(110, y += 2, " | |    |  ____\\ \\    / /  ____| |      |__ \\ ");
	Console_SetRenderBuffer_String(110, y += 2, " | |    | |__   \\ \\  / /| |__  | |         ) |");
	Console_SetRenderBuffer_String(110, y += 2, " | |    |  __|   \\ \\/ / |  __| | |        / / ");
	Console_SetRenderBuffer_String(110, y += 2, " | |____| |____   \\  /  | |____| |____   / /_ ");
	Console_SetRenderBuffer_String(110, y += 2, " |______|______|   \\/   |______|______| |____|");

	printfile();
	printExit(60, 110, 6, 6);
	keyRender(key, NUMKEYS);
	enemyRender(enemies, NUMENEMIES);
	if (GetKey)	//Done by: Irfan
	{
		printKey();
	}
	DrawPlayer();
}

//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void Level2_EnterState()
{
	CharaX = 5;
	CharaY = 7;

	readFromFile("level2.txt");
	initKey2(key, NUMKEYS);
	initEnemy2(enemies, NUMENEMIES);
	gameOver(enemies, NUMENEMIES);
	if (GetAsyncKeyState(VK_ESCAPE))
	{
	}
}

void Level2_ExitState()
{
	GetKey = 0;
}
