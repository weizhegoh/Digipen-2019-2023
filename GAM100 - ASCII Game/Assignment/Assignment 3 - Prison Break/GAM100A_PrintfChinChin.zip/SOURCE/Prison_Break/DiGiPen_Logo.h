#ifndef DIGIPEN_LOGO_H
#define DIGIPEN_LOGO_H

void DiGiPen_Logo_ProcessInput();
void DiGiPen_Logo_Update();
void DiGiPen_Logo_Render();
void DiGiPen_Logo_EnterState();
void DiGiPen_Logo_ExitState();

void Read_Digipen_txt_file();
void Print_Time();



void Print_file_IO();




#endif
