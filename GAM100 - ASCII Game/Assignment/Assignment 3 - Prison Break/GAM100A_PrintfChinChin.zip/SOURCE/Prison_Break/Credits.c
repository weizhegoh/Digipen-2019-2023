/**********************************************************************************
* \file			Credits.c
* \brief		Credit Page
* \author		Lim Chin Ann
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <Windows.h>
#include "DiGiPen_Logo.h"
#include "Console/Console.h"
#include "StateMachine/StateMachine.h"
#include "Clock.h"
#include "Credits.h"


//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;
static float timer = 0.0f;
unsigned long time;
int the_case = 0;



//*********************************************************************************
//									INPUT
//*********************************************************************************
void Credits_ProcessInput()	//Done by: Chin Ann
{
	if (timer >= 0000.0f && timer < 3000.0f)
		the_case = 0;
	else if (timer >= 3000.0f && timer < 6000.0f)
		the_case = 1;
	else if (timer >= 6000.0f && timer <9000.0f )
	{
		the_case = 2;			
	}
	else if (timer >= 9000.0f && timer < 12000.0f)
	{
		the_case = 3;
	}
	else if (timer >= 12000.0f && timer < 15000.0f)
	{
		the_case = 4;
	}
	else if (timer >= 15000.0f && timer < 18000.0f)
	{
		the_case = 5;
	}
	else if (timer >= 18000.0f)
	{
		timer = 0.0f;
		time = 0;
	}
		
	if (GetAsyncKeyState(VK_ESCAPE) & 1 )
		StateMachine_ChangeState(State_MainMenu);
}
//*********************************************************************************
//									UPDATE
//*********************************************************************************
void Credits_Update()
{
	timer += Clock_GetDeltaTime();

}
//*********************************************************************************
//									RENDER
//*********************************************************************************
//void Intructions_Render()
void Credits_Render()	//Done by: Chin Ann
{
	time += (unsigned long)Clock_GetDeltaTime();
	switch (the_case)
	{
	
	case 0: Print_Credits("Credits.txt"); 
		Console_SetRenderBuffer_String_Colour(60, 45, "COPYRIGHT (c) 2019 BY DIGIPEN CORP,USA.", 0x0000f);
		Console_SetRenderBuffer_String_Colour(70, 47, "ALL RIGHTS RESERVED.", 0x0000f); break;
	case 1: Print_Credits("Credits2.txt"); break;
	case 2: Print_Credits("Credits3.txt"); break;
	case 3: Print_Credits("Credits4.txt"); break;
	case 4: Print_Credits("Credits5.txt"); break;
	case 5: Print_Credits("Credits6.txt"); break;

	default: break;
	}
	
	Print_Credicts_Title();
	Console_SetRenderBuffer_String(60, 60, "Press >  Esc  < to go back to Main Manu");


}
//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void Credits_EnterState()
{
}

void Credits_ExitState()
{
}

//*********************************************************************************
//									Self add
//*********************************************************************************
void Print_Prision_Break_Text()	//Done by: Chin Ann
{
	FILE* file;
	if (!fopen_s(&file, "Prison_break_one_line.txt", "r") && file != 0)
	{
		
		char string_buffer[200];
		int y = 10;

		while (fgets(string_buffer, sizeof(string_buffer), file) != NULL)
		{
			int x = 25;
			for (int i = 0;i < strlen(string_buffer);++i)
			{
				if (string_buffer[i] != '\n')
				{
					Console_SetRenderBuffer_Char(x, y, string_buffer[i]);
					++x;
				}
			}
			++y;
		}
	}
	fclose(file);
}

void Print_Credicts_Title()	//Done by: Chin Ann
{
	FILE* file;
	if (!fopen_s(&file, "credicts.txt", "r") && file != 0)
	{

		char string_buffer[200];
		int y = 10;

		while (fgets(string_buffer, sizeof(string_buffer), file) != NULL)
		{
			int x = 47;
			for (int i = 0;i < strlen(string_buffer);++i)
			{
				if (string_buffer[i] != '\n')
				{
					Console_SetRenderBuffer_Colour_Char(x, y, string_buffer[i],0x0000E);
					++x;
				}
			}
			++y;
		}
	}
	fclose(file);
}

void Print_Time2()	//Done by: Chin Ann
{
	Clock_GetElapsedTimeUs();
	Console_SetRenderBuffer_String(28, 50, "Time:");

	char buffer_time[33];
	sprintf_s(buffer_time, 33, "%lu", time / 1000);
	Console_SetRenderBuffer_String(34, 50, buffer_time);
	Console_SetRenderBuffer_String(36, 50, "s    ");

}

//char* textfile
void Print_Credits(char* textfile)	//Done by: Chin Ann
{
	FILE* file;
	if (!fopen_s(&file,  textfile, "r") && file != 0)
	{

		char string_buffer[50];
		int y = 30;

		while (fgets(string_buffer, sizeof(string_buffer), file) != NULL)
		{
			int x = 50;
			for (int i = 0; i < strlen(string_buffer); ++i)
			{
				if (string_buffer[i] != '\n')
				{
					Console_SetRenderBuffer_Char(x, y, string_buffer[i]);
					++x;
				}
			}
			++y;
		}
	}
	fclose(file);
}