﻿/**********************************************************************************
* \file			Instruction.c
* \brief		Instruction Page
* \author		Chin Ann
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <Windows.h>
#include "Instruction.h"
#include "Console/Console.h"
#include "StateMachine/StateMachine.h"
#include "Console/Console.h"
#include "Clock.h"

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;
static float timer = 0.0f;
unsigned long time;
int Instructions_3D_Y = 15;

//*********************************************************************************
//									INPUT
//*********************************************************************************
void Instruction_ProcessInput()
{	
	if (GetAsyncKeyState(VK_ESCAPE) & 1)
		StateMachine_ChangeState(State_MainMenu);
}
//*********************************************************************************
//									UPDATE
//*********************************************************************************
void Instruction_Update()
{
	timer += Clock_GetDeltaTime();
	time += (unsigned long)Clock_GetDeltaTime();
}
//*********************************************************************************
//									RENDER
//*********************************************************************************
//void Intructions_Render()
void Instruction_Render()	//Done by: Chin Ann
{
	Print_Instructions_3D();
	
	if (timer >= 0000.0f && timer < 0500.0f)
		Print_Instructions_3D_Colour("Instructions_3D_I.txt");

	else if (timer >= 0500.0f && timer < 1000.0f)
		Print_Instructions_3D_Colour("Instructions_3D_IN.txt");

	else if (timer >= 1000.0f && timer < 1500.0f)
		Print_Instructions_3D_Colour("Instructions_3D_INS.txt");
	else if (timer >= 1500.0f && timer < 2000.0f)
		Print_Instructions_3D_Colour("Instructions_3D_INST.txt");
	else if (timer >= 2000.0f && timer < 2500.0f)
		Print_Instructions_3D_Colour("Instructions_3D_INSTR.txt");

	else if (timer >= 2500.0f && timer < 3000.0f)
		Print_Instructions_3D_Colour("Instructions_3D_INSTRU.txt");
	
	else if (timer >= 3000.0f && timer < 3500.0f)	                          
		Print_Instructions_3D_Colour("Instructions_3D_INSTRUC.txt");
	else if (timer >= 3500.0f && timer < 4000.0f)
		Print_Instructions_3D_Colour("Instructions_3D_INSTRUCT.txt");
	else if (timer >= 4000.0f && timer < 4500.0f)
		Print_Instructions_3D_Colour("Instructions_3D_INSTRUCTI.txt");
	else if (timer >= 4500.0f && timer < 5000.0f)
		Print_Instructions_3D_Colour("Instructions_3D_INSTRUCTIO.txt");
	else if (timer >= 5000.0f && timer < 5500.0f)
		Print_Instructions_3D_Colour("Instructions_3D_INSTRUCTION.txt");
	else if (timer >= 5500.0f && timer < 6000.0f)
		Print_Instructions_3D_Colour("Instructions_3D_INSTRUCTIONS.txt");

	else if (timer = 6000.0f)
	{
		timer = 0.0f;
		time = 0;
	}
	
	Print_Instructions();
	Print_Direction_Instructions();
}
//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void Instruction_EnterState()
{
}

void Instruction_ExitState()
{
}

//*********************************************************************************
//									Self add
//*********************************************************************************

void Print_Direction_Instructions()	//Done by: Chin Ann
{
	int Print_Instructions_X = 54;
	int Print_Instructions_Y = 59;

	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, '[');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'U');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'p');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, ' ');
	Console_SetRenderBuffer_Colour_Char(Print_Instructions_X++, Print_Instructions_Y, 24,0x0000A);
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, ']');
	//Down
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, ' ');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, '[');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'D');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'O');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'W');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'N');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, ' ');
	Console_SetRenderBuffer_Colour_Char(Print_Instructions_X++, Print_Instructions_Y, 25,0x0000B);
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, ']');
	//right
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, ' ');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, '[');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'R');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'I');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'G');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'H');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'T');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, ' ');
	Console_SetRenderBuffer_Colour_Char(Print_Instructions_X++, Print_Instructions_Y, 26,0x0000C);
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, ']');
	//left
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, ' ');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, '[');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'L');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'E');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'F');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, 'T');
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, ' ');
	Console_SetRenderBuffer_Colour_Char(Print_Instructions_X++, Print_Instructions_Y, 27,0x0000D);
	Console_SetRenderBuffer_Char(Print_Instructions_X++, Print_Instructions_Y, ']');
}

void Print_Instructions()	//Done by: Chin Ann
{
	FILE* file;
	if (!fopen_s(&file, "Instructions.txt", "r") && file != 0)
	{
		char string_buffer[200];

		int y = 35;

		while (fgets(string_buffer, sizeof(string_buffer), file) != NULL)
		{
			int x = 45;
			for (int i = 0;i < strlen(string_buffer);++i)
			{
				if (string_buffer[i] != '\n')
				{
					Console_SetRenderBuffer_Char(x, y, string_buffer[i]);
					++x;
				}
			}
			++y;
		}
	}
	fclose(file);
}

void Print_Instructions_3D()	//Done by: Chin Ann
{
	FILE* file;
	if (!fopen_s(&file, "Instructions_3D.txt", "r") && file != 0)
	{
		char string_buffer[200];

		int y = Instructions_3D_Y;

		while (fgets(string_buffer, sizeof(string_buffer), file) != NULL)
		{
			int x = 20;
			for (int i = 0;i < strlen(string_buffer);++i)
			{
				if (string_buffer[i] != '\n')
				{
					Console_SetRenderBuffer_Char(x, y, string_buffer[i]);
					++x;
				}
			}
			++y;
		}
	}
	fclose(file);
}

void Print_Instruction_Time()	//Done by: Chin Ann
{
	Clock_GetElapsedTimeUs();
	Console_SetRenderBuffer_String(28, 3, "Time:");

	char buffer_time[33];
	sprintf_s(buffer_time, 33, "%lu", time / 1000);
	Console_SetRenderBuffer_String(34, 3, buffer_time);
	Console_SetRenderBuffer_String(36, 3, "s    ");
}

void Print_Instructions_3D_Colour(char* textfile)	//Done by: Chin Ann
{
	FILE* file;
	if (!fopen_s(&file, textfile, "r") && file != 0)
	{
		char string_buffer[200];

		int y = Instructions_3D_Y;

		while (fgets(string_buffer, sizeof(string_buffer), file) != NULL)
		{
			int x = 20;
			for (int i = 0;i < strlen(string_buffer);++i)
			{
				if (string_buffer[i] != '\n')
				{
					Console_SetRenderBuffer_Colour_Char(x, y, string_buffer[i],0x0000B);
					++x;
				}
			}
			++y;
		}
		fclose(file);
	}
}