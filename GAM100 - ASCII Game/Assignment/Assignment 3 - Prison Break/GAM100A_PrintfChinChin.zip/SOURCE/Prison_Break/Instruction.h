#ifndef INSTRUCTION_H
#define INSTRUCTION_H

void Instruction_EnterState();
void Instruction_ExitState();


void Instruction_Update();

void Instruction_Render();
void Instruction_ProcessInput();
void Print_Direction_Instructions();
void Print_Instructions();

void Print_Instructions_3D();
void Print_Instruction_Time();
void Print_Instructions_3D_Colour(char* textfile);



#endif
