/**********************************************************************************
* \file			GameOver.c
* \brief		Select Level Page
* \author		Wei Zhe, Chin Ann, Ryan
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <Windows.h>
#include "Level_Selection.h"
#include "StateMachine/Global.h"
#include "Console/Console.h"
#include "StateMachine/StateMachine.h"

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;
int Level_Pointer_Arrow_X = 63;
int Level_Pointer_Arrow_Y = 48;
int Prision_Break_X = 23;
int Prision_Break_Y = 25;
int Display_Selections_X = 65;
int Display_Selections_Y = 48;
int Display_Selections_Y_Min = 48;
int Display_Selections_Y_Max = 60;
int level_Previous = 0;
int Level_Current = 0;

typedef enum
{
	Level1 = 1,
	levll2 = 2,
	level3 = 3,
	level4 = 4,
	level5 = 5

}Selection;

//*********************************************************************************
//									INPUT
//*********************************************************************************
void Level_Select_ProcessInput()	//Done by: Chin Ann
{
	level_Previous = Level_Current;
	if (GetAsyncKeyState(VK_DOWN) & 1)
	{
		Select_Level();
	}
	else if (GetAsyncKeyState(VK_UP) & 1)
	{
		Select_Level();

	}
	else
	{
		Level_Current = 0;
	}
	//Level 1
	if ((Level_Pointer_Arrow_Y == Display_Selections_Y_Min) && (GetAsyncKeyState(VK_RETURN) & 1))
		StateMachine_ChangeState(State_Level1);
	//level 2
	else if ((Level_Pointer_Arrow_Y == (Display_Selections_Y_Min+2)) && (GetAsyncKeyState(VK_RETURN) & 1))
		StateMachine_ChangeState(State_Level2);

	//Level 3
	else if ((Level_Pointer_Arrow_Y == (Display_Selections_Y_Min + 4)) && (GetAsyncKeyState(VK_RETURN) & 1))
		StateMachine_ChangeState(State_Level3);

	//Level 4
	else if ((Level_Pointer_Arrow_Y == (Display_Selections_Y_Min + 6)) && (GetAsyncKeyState(VK_RETURN) & 1))
		StateMachine_ChangeState(State_Level4);

	//level 5
	else if ((Level_Pointer_Arrow_Y == (Display_Selections_Y_Min + 8)) && (GetAsyncKeyState(VK_RETURN) & 1))
		StateMachine_ChangeState(State_Level5);

	//Back
	else if ((Level_Pointer_Arrow_Y == (Display_Selections_Y_Min + 10)) && (GetAsyncKeyState(VK_RETURN) & 1))
		StateMachine_ChangeState(State_MainMenu);
	//Exit GAME
	else if ((Level_Pointer_Arrow_Y == (Display_Selections_Y_Min + 12)) && (GetAsyncKeyState(VK_RETURN) & 1))
		Global_Exit();

	if (GetAsyncKeyState(VK_ESCAPE) & 1)
		StateMachine_ChangeState(State_MainMenu);
}
//*********************************************************************************
//									UPDATE
//*********************************************************************************
void Level_Select_Update()
{

}
//*********************************************************************************
//									RENDER
//*********************************************************************************
void Level_Select_Render()	//Done by: Chin Ann
{
	Display_Selections();
	Print_Prison_Break_Line("Prison_Break_Line.txt");	
}
//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void Level_Select_EnterState()
{
}

void Level_Select_ExitState()
{
}

//*********************************************************************************
//									Self add
//*********************************************************************************
void Select_Level()	//Done by: Chin Ann
{
	if (GetAsyncKeyState(VK_UP))
	{
		Level_Pointer_Arrow_Y -= 2;
	}
	else if (GetAsyncKeyState(VK_DOWN))
	{
		Level_Pointer_Arrow_Y += 2;
	}


	if (Level_Pointer_Arrow_Y < Display_Selections_Y_Min)//50
	{
		Level_Pointer_Arrow_Y = Display_Selections_Y_Min;//50
	}
	if (Level_Pointer_Arrow_Y > Display_Selections_Y_Max)//56
	{
		Level_Pointer_Arrow_Y = Display_Selections_Y_Max;//56
	}
}

void Display_Selections()	//Done by: Chin Ann
{
	int x = Display_Selections_X;
	int y = Display_Selections_Y;
	unsigned char colour_selected[10] = { 0x0000E };
	
	Console_SetRenderBuffer_String(x, y++, "LEVEL [1]");
	if (Level_Pointer_Arrow_Y == (y-1))
	{
		Console_SetRenderBuffer_String_Colour(x, y - 1, "LEVEL [1]", *colour_selected);
	}
	
	Console_SetRenderBuffer_String(x, y++, " ");
	Console_SetRenderBuffer_String(x, y++, "LEVEL [2]");
	if (Level_Pointer_Arrow_Y == (y - 1))
	{
		Console_SetRenderBuffer_String_Colour(x, y - 1, "LEVEL [2]", *colour_selected);
	}
	Console_SetRenderBuffer_String(x, y++, " ");
	Console_SetRenderBuffer_String(x, y++, "LEVEL [3]");
	if (Level_Pointer_Arrow_Y == (y - 1))
	{
		Console_SetRenderBuffer_String_Colour(x, y - 1, "LEVEL [3]", *colour_selected);
	}
	Console_SetRenderBuffer_String(x, y++, " ");
	Console_SetRenderBuffer_String(x, y++, "LEVEL [4]");
	if (Level_Pointer_Arrow_Y == (y - 1))
	{
		Console_SetRenderBuffer_String_Colour(x, y - 1, "LEVEL [4]", *colour_selected);
	}
	Console_SetRenderBuffer_String(x, y++, " ");
	Console_SetRenderBuffer_String(x, y++, "LEVEL [5]");
	if (Level_Pointer_Arrow_Y == (y - 1))
	{
		Console_SetRenderBuffer_String_Colour(x, y - 1, "LEVEL [5]", *colour_selected);
	}
	Console_SetRenderBuffer_String(x, y++, " ");
	Console_SetRenderBuffer_String(x, y++, "BACK");
	if (Level_Pointer_Arrow_Y == (y - 1))
	{
		Console_SetRenderBuffer_String_Colour(x, y - 1, "BACK", *colour_selected);
	}
	Console_SetRenderBuffer_String(x, y++, " ");
	Console_SetRenderBuffer_String(x, y++, "Exit GAME");
	if (Level_Pointer_Arrow_Y == (y - 1))
	{
		Console_SetRenderBuffer_String_Colour(x, y - 1, "Exit GAME", *colour_selected);
	}
	Console_SetRenderBuffer_Colour_Char(Level_Pointer_Arrow_X, Level_Pointer_Arrow_Y, 175,0x0000E);
	y+=6;
	Console_SetRenderBuffer_String(x-15, y++, "Press >  Esc  < to go back to Main Manu");
}

void Print_Prison_Break_Line(char* textfile)	//Done by: Chin Ann
{
	FILE* file2;
	if (!fopen_s(&file2, textfile, "r") && file2 != 0)
	{
		char string_buffer2[200];

		int y = Prision_Break_Y;

		while (fgets(string_buffer2, sizeof(string_buffer2), file2) != NULL)
		{
			int x = Prision_Break_X;
			for (int i = 0; i < strlen(string_buffer2); ++i)
			{
				if (string_buffer2[i] != '\n')
				{
					Console_SetRenderBuffer_Colour_Char(x, y, string_buffer2[i], 0x0000A);
					++x;
				}
			}
			++y;
		}

	}
	fclose(file2);

}
