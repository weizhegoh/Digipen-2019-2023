#ifndef LEVEL1_H
#define LEVEL1_H

void Level1_EnterState();
void Level1_ExitState();

void Level1_ProcessInput();
void Level1_Update();
void Level1_Render();

#endif