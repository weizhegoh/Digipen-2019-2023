#include "Variables.h"
#include "Console/Console.h"
#include "StateMachine/StateMachine.h"
#include <stdio.h>
#define BORDER 'X'

char lineArr[70][120];

void StartUp()	//Done by: Irfan
{
	//Initialise Variables
	bExitGameRequested = 0;
	GetKey = 0;

	//engine initialise
	Console_Init();
	int winSizeX = 160;
	int winSizeY = 90;

	//Window
	Console_SetTitle("Prison Break");
	Console_SetSquareFont();
	Console_SetWindowedMode(winSizeX, winSizeY, false);
	Console_SetCursorVisibility(false);
}

char map[70][120];
int futureX, futureY;

//Prints the exit on the level
void printExit(int OriginX,int OriginY, int length, int breath)	//Done by: Ryan
{
	for (int i = 0; i <= breath; i++)
	{
		for (int j = 0; j <= length; j++)
		{
			Console_SetRenderBuffer_ExitZoneChar(OriginY, OriginX, 219, 0x0000A);
			OriginY++;
		}
		OriginY -= length+1;
		OriginX++;
	}
}

//Read the map text file
void readFromFile(char* filename) //Done by: Wei Zhe
{
	FILE* file;
	errno_t err;
	int x=0, y=0;
	char temp;
	
	err = fopen_s(&file,filename, "r");
	if (err)
	{
		return;
	}

	while (1)
	{
		temp = fgetc(file);
	
		if(temp == EOF)
		{
			break;
		}

		if (temp == '\n')
		{
			y++;
			x = 0;
			continue;
		}
		lineArr[y][x++] = temp;
	}
	fclose(file);
}

void printfile()	//Done by: Wei Zhe8
{
	for (int y = 0;y < 70;++y)
	{
		for (int x = 0; x<120;++x)
		{
			if (lineArr[y][x] == '1')
				Console_SetRenderBuffer_Colour_Char(x, y, 'X', 0x000B);
			else if (lineArr[y][x] == '2')
				Console_SetRenderBuffer_Char(x, y, ' ');
			else
				Console_SetRenderBuffer_Char(x, y, ' ');
		}
	}
}