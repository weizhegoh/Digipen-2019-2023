#ifndef GAMELOGIC_H
#define GAMELOGIC_H

int GetKey; 
struct Key
{
	int x;
	int y;
};


void keyRender(struct Key *key, int numKeys);
void keyCollision(struct Key *key, int numKeys);
void printKey();


#endif
