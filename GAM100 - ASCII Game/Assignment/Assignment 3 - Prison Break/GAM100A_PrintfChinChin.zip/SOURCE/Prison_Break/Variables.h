#ifndef VARIABLES_H
#define VARIABLES_H
#include "Console/Console.h"
#include <Windows.h>

int bExitGameRequested;

static double enemyX;
static double enemyY;

int borderS_H, borderE_H, borderS_W, borderE_W; //bordercoordinates
int L1borderS_H, L1borderE_H, L1borderS_W, L1borderE_W;
int L1RedS_H, L1RedE_H, L1RedS_W, L1RedE_W;
int L1RedS_W2, L1RedE_W2, L1RedS_W3, L1RedE_W3;
double CharaX; double CharaY; double charge; int limit;
double chargetime; int keystate; int chargecheck;
char str[256];
char wallY; char wallX;
int WallposX; int WallposY;
int fillerpos; char filler;
char* indicate[10];
char lineArr[70][120];
int GetKey;

void StartUp();
void readFromFile(char* filename);
void printfile();
void printExit(int OriginX, int OriginY, int length, int breath);

#endif