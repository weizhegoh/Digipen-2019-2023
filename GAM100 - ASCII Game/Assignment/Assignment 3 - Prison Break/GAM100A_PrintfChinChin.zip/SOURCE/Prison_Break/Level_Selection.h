#ifndef LEVEL_SELECTION_H
#define LEVEL_SELECTION_H

void Level_Select_EnterState();
void Level_Select_ExitState();

void Select_Level();
void Level_Select_Update();

void Level_Select_Render();
void Level_Select_ProcessInput();



void Display_Selections();
void Print_Prison_Break_Line(char* textfile);



#endif
