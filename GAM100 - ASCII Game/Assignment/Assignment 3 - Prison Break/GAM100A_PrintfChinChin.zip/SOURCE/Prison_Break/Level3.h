#pragma once
#ifndef LEVEL3_H
#define LEVEL3_H

void Level3_EnterState();
void Level3_ExitState();

void Level3_ProcessInput();
void Level3_Update();
void Level3_Render();

#endif // GAME_H
