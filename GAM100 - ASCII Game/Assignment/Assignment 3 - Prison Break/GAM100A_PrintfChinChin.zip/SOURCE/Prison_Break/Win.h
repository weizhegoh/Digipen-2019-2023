#ifndef WIN_H
#define WIN_H

void Win_EnterState();
void Win_ExitState();

void Win_ProcessInput();
void Win_Update();
void Win_Render();
void Print_YOU_WIN(char* textfile);
//void Print_YOU_WIN();


#endif // GAME_H
