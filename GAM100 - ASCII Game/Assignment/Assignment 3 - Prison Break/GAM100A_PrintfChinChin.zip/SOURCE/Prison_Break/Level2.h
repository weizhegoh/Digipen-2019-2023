#ifndef LEVEL2_H
#define LEVEL2_H

void Level2_EnterState();
void Level2_ExitState();

void Level2_ProcessInput();
void Level2_Update();
void Level2_Render();

#endif // GAME_H
