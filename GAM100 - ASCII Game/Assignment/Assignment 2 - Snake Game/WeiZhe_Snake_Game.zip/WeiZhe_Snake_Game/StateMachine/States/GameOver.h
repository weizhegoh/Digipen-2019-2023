#ifndef GAMEOVER_H
#define GAMEOVER_H

void GameOver_EnterState();
void GameOver_ExitState();

void GameOver_ProcessInput();
void GameOver_Update();
void GameOver_Render();

#endif // GAME_H