#include "MainMenu.h"
#include <Windows.h>
#include "../Libraries/Console.h"
#include "../StateMachine.h"
#include "../Global.h"

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;


//*********************************************************************************
//									INPUT
//*********************************************************************************
void MainMenu_ProcessInput()
{
	if (GetAsyncKeyState(VK_RETURN) & 1)
		StateMachine_ChangeState(State_Game);

	if (GetAsyncKeyState(VK_ESCAPE) & 1)
		Global_Exit();
}
//*********************************************************************************
//									UPDATE
//*********************************************************************************

void MainMenu_Update()
{
}

//*********************************************************************************
//									RENDER
//*********************************************************************************
void MainMenu_Render()
{
	Console_SetRenderBuffer_String(3, 25, " __________  ____   ______  ________  ____     ___  __________   ");
	Console_SetRenderBuffer_String(3, 26, "|          ||    | |      ||        ||    |   |   ||          |  ");
	Console_SetRenderBuffer_String(3, 27, "|      ____||     ||      ||   _    ||    |  |   | |     _____|  ");
	Console_SetRenderBuffer_String(3, 28, "|     |____ |      |      ||  |_|   ||    |_|   |  |    |_____   ");
	Console_SetRenderBuffer_String(3, 29, "|____      ||             ||        ||         |   |     _____|  ");
	Console_SetRenderBuffer_String(3, 30, " ____|     ||    |        ||        ||    ___   |  |    |_____   ");
	Console_SetRenderBuffer_String(3, 31, "|          ||    ||       ||   __   ||   |   |   | |          |  ");
	Console_SetRenderBuffer_String(3, 32, "|_________ ||____| |_____ ||__|  |__||___|    |___||__________|  ");
	Console_SetRenderBuffer_String(3, 33, "       ____________  _________  ______   ______  _________       ");
	Console_SetRenderBuffer_String(3, 34, "      |            ||         ||      | |      ||         |      ");
	Console_SetRenderBuffer_String(3, 36, "      |    ________||    _    ||       |       ||    _____|      ");
	Console_SetRenderBuffer_String(3, 37, "      |   |   _____ |   |_|   ||   |       |   ||   |_____       ");
	Console_SetRenderBuffer_String(3, 38, "      |   |  |_    ||         ||   ||     ||   ||    _____|      ");
	Console_SetRenderBuffer_String(3, 39, "      |   |____|   ||   __    ||   | |___| |   ||   |_____       ");
	Console_SetRenderBuffer_String(3, 40, "      |            ||  |  |   ||   |       |   ||         |      ");
	Console_SetRenderBuffer_String(3, 40, "      |____________||__|  |___||___|       |___||_________|      ");

	Console_SetRenderBuffer_String(20, 50, "Press >Enter< to Play");
	Console_SetRenderBuffer_String(20, 51, "Press >Escape< to Quit the program");

}

//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void MainMenu_EnterState()
{
}

void MainMenu_ExitState()
{
}
