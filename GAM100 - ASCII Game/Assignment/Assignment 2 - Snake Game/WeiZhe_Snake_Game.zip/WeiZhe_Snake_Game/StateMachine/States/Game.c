#include "Game.h"
#include <Windows.h>
#include "../Libraries/Console.h"
#include "../StateMachine.h"

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;
static int bExitGameRequested = 0;
static double iSnakeX[256];
static double iSnakeY[256];
static char tscore[3];
static int score = 0;
static int length = 1;
static int foodX = 40;
static int foodY = 40;
static char lastKeyPressed = 'R';
static double Velocity = 0.0001;

void borders()
{
	//Top border
	int height = 0;
	int width;
	for (width = 0; width < 70; width++)
	{
		Console_SetRenderBuffer_Char(width, height, '#');
	}

	//Bottom border
	height = 69;
	for (width = 0; width < 70; width++)
	{
		Console_SetRenderBuffer_Char(width, height, '#');
	}

	//Left border
	width = 0;
	for (height = 0; height < 70;height++)
	{
		Console_SetRenderBuffer_Char(width, height, '#');
	}
	width = 69;

	//Right
	for (height = 0; height < 70;height++)
	{
		Console_SetRenderBuffer_Char(width, height, '#');
	}
}

void snakeMove()
{
	if (lastKeyPressed == 'L')
	{
		iSnakeX[0] = (int)iSnakeX[0] + Velocity * Clock_GetDeltaTime();
		iSnakeX[0] = (int)iSnakeX[0] - 1;
	}
	else if (lastKeyPressed == 'R')
	{
		iSnakeX[0] = (int)iSnakeX[0] + Velocity * Clock_GetDeltaTime();
		iSnakeX[0] = (int)iSnakeX[0] + 1;
	}
	if (lastKeyPressed == 'U')
	{
		iSnakeY[0] = (int)iSnakeY[0] + Velocity * Clock_GetDeltaTime();
		iSnakeY[0] = (int)iSnakeY[0] - 1;
	}
	if (lastKeyPressed == 'D')
	{
		iSnakeY[0] = (int)iSnakeY[0] + Velocity * Clock_GetDeltaTime();
		iSnakeY[0] = (int)iSnakeY[0] + 1;
	}
}

void gameOver()
{
	if ((int)iSnakeX[0] <= 0 || (int)iSnakeX[0] >= 69)
	{
		bExitGameRequested = 1;
	}
	if ((int)iSnakeY[0] <= 0 || (int)iSnakeY[0] >= 69)
	{
		bExitGameRequested = 1;
	}
}

void food()
{
	if ((int)iSnakeX[0] == foodX && (int)iSnakeY[0] == foodY)
	{
		foodX = Random_Range(1, 68);
		foodY = Random_Range(1, 68);
		++length;
		++score;
	}
}

void snakeLength()
{
	for (int i = length - 1; i > 0; --i)
	{
		iSnakeX[i] = (int)iSnakeX[i - 1];
		iSnakeY[i] = (int)iSnakeY[i - 1];
	}
}

void snakeDie()
{
	for (int i = 1; i < length; i++)
	{
		if (iSnakeX[0] == (int)iSnakeX[i] && iSnakeY[0] == (int)iSnakeY[i])
		{
			bExitGameRequested = 1;
		}
	}
}

void snakeScore()
{
	for (int i = 0; i <= score; i++)
	{
		if (score < 256)
		{
			tscore[2] = score % 10;
		}

		if (score >= 10)
		{
			tscore[1] = score / 10;
		}
		if (score >= 100)
		{
			tscore[0] = score / 100;
		}
	}
}

void drawBody()
{
	for (int i = 0; i < length; ++i)
	{
		Console_SetRenderBuffer_Char(iSnakeX[i], iSnakeY[i], 'X');
	}
}

//*********************************************************************************
//									INPUT
//*********************************************************************************
void Game_ProcessInput()
{
	if (GetAsyncKeyState(VK_LEFT) && lastKeyPressed != 'R')
	{
		lastKeyPressed = 'L';
	}
	else if (GetAsyncKeyState(VK_RIGHT) && lastKeyPressed != 'L')
	{
		lastKeyPressed = 'R';
	}
	else if (GetAsyncKeyState(VK_UP) && lastKeyPressed != 'D')
	{
		lastKeyPressed = 'U';
	}
	else if (GetAsyncKeyState(VK_DOWN) && lastKeyPressed != 'U')
	{
		lastKeyPressed = 'D';
	}

	if (GetAsyncKeyState(VK_ESCAPE) & 1)
		StateMachine_ChangeState(State_GameOver);
}

//*********************************************************************************
//									UPDATE
//*********************************************************************************
void Game_Update()
{
	Clock_GameLoopStart();
	
	food();
	snakeLength();
	snakeMove();
	snakeScore();
	snakeDie();
	gameOver();

	if (bExitGameRequested)
	{
		StateMachine_ChangeState(State_GameOver);
	}
}

//*********************************************************************************
//									RENDER
//*********************************************************************************
void Game_Render()
{
	int y = 0;
	borders();
	drawBody();
	Console_SetRenderBuffer_Char(foodX, foodY, ' ');
	Console_SetRenderBuffer_Char(foodX, foodY, '*');
	Console_SetRenderBuffer_String(30, 72, "Score: ");
	Console_SetRenderBuffer_Char(36, 72, tscore[0] + '0');
	Console_SetRenderBuffer_Char(37, 72, tscore[1] + '0');
	Console_SetRenderBuffer_Char(38, 72, tscore[2] + '0');
	if (score > 256)
	{
		Console_SetRenderBuffer_String(30, 75, "You Win!");
	}
}

//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void Game_EnterState()
{
	for (int i = 0; i < 256; ++i)
	{
		iSnakeX[i] = -1;
		iSnakeY[i] = -1;
	}

	iSnakeX[0] = 30;
	iSnakeY[0] = 30;

	foodX = 40;
	foodY = 40;
	score = 0;
	length = 1;
	bExitGameRequested = 0;
	lastKeyPressed = 'R';
}

void Game_ExitState()
{
}
