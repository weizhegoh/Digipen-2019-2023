#include "GameOver.h"
#include <Windows.h>
#include "../Libraries/Console.h"
#include "../StateMachine.h"

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;


//*********************************************************************************
//									INPUT
//*********************************************************************************
void GameOver_ProcessInput()
{
	if (GetAsyncKeyState(VK_ESCAPE) & 1)
		StateMachine_ChangeState(State_MainMenu);
}

//*********************************************************************************
//									UPDATE
//*********************************************************************************
void GameOver_Update()
{
}


//*********************************************************************************
//									RENDER
//*********************************************************************************
void GameOver_Render()
{
	Console_SetRenderBuffer_String(3, 33, "       ____________  _________  ______   ______  _________       ");
	Console_SetRenderBuffer_String(3, 34, "      |            ||         ||      | |      ||         |      ");
	Console_SetRenderBuffer_String(3, 36, "      |    ________||    _    ||       |       ||    _____|      ");
	Console_SetRenderBuffer_String(3, 37, "      |   |   _____ |   |_|   ||   |       |   ||   |_____       ");
	Console_SetRenderBuffer_String(3, 38, "      |   |  |_    ||         ||   ||     ||   ||    _____|      ");
	Console_SetRenderBuffer_String(3, 39, "      |   |____|   ||   __    ||   | |___| |   ||   |_____       ");
	Console_SetRenderBuffer_String(3, 40, "      |            ||  |  |   ||   |       |   ||         |      ");
	Console_SetRenderBuffer_String(3, 41, "      |____________||__|  |___||___|       |___||_________|      ");
	Console_SetRenderBuffer_String(3, 42, "       ___________  ___         ___  __________  _________     ");
	Console_SetRenderBuffer_String(3, 43, "      |           ||   |       |   ||          ||         |     ");
	Console_SetRenderBuffer_String(3, 44, "      |    ___    | |   |     |   | |    ______||   __    |     ");
	Console_SetRenderBuffer_String(3, 45, "      |   |   |   |  |   |   |   |  |   |______ |  |__|   |     ");
	Console_SetRenderBuffer_String(3, 46, "      |   |   |   |   |   | |   |   |    ______||         |     ");
	Console_SetRenderBuffer_String(3, 47, "      |   |___|   |    |   |   |    |   |______ |  |    __|     ");
	Console_SetRenderBuffer_String(3, 48, "      |           |     |     |     |          ||  ||  |__     ");
	Console_SetRenderBuffer_String(3, 49, "      |___________|      |___|      |__________||__| |____|     ");

	Console_SetRenderBuffer_String(17, 55, "Press >Escape< to exit to the Main Menu");
}

//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void GameOver_EnterState()
{
}

void GameOver_ExitState()
{
}
