/**********************************************************************************
* \file			Main.c
* \brief		Basic State Machine Example for GAM 100 class
* \author		Yannick Gerber
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#include "Global.h"
#include "StateMachine.h"
#include "Libraries/Console.h"

#include "Random/Random.h"
#include "stdio.h"
#include <Windows.h>			//To use the Input system
#include "Clock/Clock.h"
#include <math.h>

int main()
{
	// Game Initialization
	Console_Init();
	Console_SetTitle("GAM100: State Machine");
	Console_SetCursorVisibility(0);

	StateMachine_ChangeState(State_MainMenu);

	Random_Init();
	Console_SetSquareFont();
	Console_SetWindowedMode(70, 80, false);
	Console_SetCursorVisibility(false);

	// Game Loop
	while (Global_IsGameRunning())
	{
		StateMachine_StartFrame();
		StateMachine_ProcessInput();
		StateMachine_Update();
		StateMachine_Render();

		Sleep(50);
	}

	// Game Shutdown
	Console_CleanUp();
}
