/**********************************************************************************
* \file			Main.c
* \brief		Basic State Machine Example for GAM 100 class
* \author		Yannick Gerber
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#include "Global.h"
#include "StateMachine.h"
#include "Libraries/Console.h"

int main()
{
	// Game Initialization
	Console_Init();
	Console_SetTitle("GAM100: State Machine");
	Console_SetWindowedMode(80, 15, false);
	Console_SetCursorVisibility(0);

	StateMachine_ChangeState(State_MainMenu);

	// Game Loop
	while (Global_IsGameRunning())
	{
		StateMachine_StartFrame();
		StateMachine_ProcessInput();
		StateMachine_Update();
		StateMachine_Render();
	}

	// Game Shutdown
	Console_CleanUp();
}
