#ifndef MAINMENU_H
#define MAINMENU_H

void MainMenu_EnterState();
void MainMenu_ExitState();

void MainMenu_ProcessInput();
void MainMenu_Update();
void MainMenu_Render();

#endif // MAINMENU_H

