#include "GameOver.h"
#include <Windows.h>
#include "stdio.h"
#include <Windows.h>              //To use the Input system
#include "libaries/Console.h"
#include "StateMachine.h"

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;


//*********************************************************************************
//									INPUT
//*********************************************************************************
void GameOver_ProcessInput()
{
	if (GetAsyncKeyState(VK_ESCAPE) &1)
		StateMachine_ChangeState(State_MainMenu);
}

//*********************************************************************************
//									UPDATE
//*********************************************************************************
void GameOver_Update()
{
}


//*********************************************************************************
//									RENDER
//*********************************************************************************
void GameOver_Render()
{
	int y = 10;
	Console_SetRenderBuffer_String(1, y++, "   ___________  _________  ______   ______  ________    ");
	Console_SetRenderBuffer_String(1, y++, "  |           ||         ||      | |      ||        |   ");
	Console_SetRenderBuffer_String(1, y++, "  |    _______||    _    ||       |       ||   _____|   ");
	Console_SetRenderBuffer_String(1, y++, "  |   |  _____ |   |_|   ||   |       |   ||  |_____    ");
	Console_SetRenderBuffer_String(1, y++, "  |   | |_    ||         ||   ||     ||   ||   _____|   ");
	Console_SetRenderBuffer_String(1, y++, "  |   |___|   ||   __    ||   | |___| |   ||  |_____    ");
	Console_SetRenderBuffer_String(1, y++, "  |           ||  |  |   ||   |       |   ||        |   ");
	Console_SetRenderBuffer_String(1, y++, "  |___________||__|  |___||___|       |___||________|   ");
	Console_SetRenderBuffer_String(1, y++, "   ___________  ___         ___  ________  _________  ");
	Console_SetRenderBuffer_String(1, y++, "  |           ||   |       |   ||        ||         | ");
	Console_SetRenderBuffer_String(1, y++, "  |    ___    | |   |     |   | |   _____||   __    | ");
	Console_SetRenderBuffer_String(1, y++, "  |   |   |   |  |   |   |   |  |  |_____ |  |__|   | ");
	Console_SetRenderBuffer_String(1, y++, "  |   |   |   |   |   | |   |   |   _____||         | ");
	Console_SetRenderBuffer_String(1, y++, "  |   |___|   |    |   |   |    |  |_____ |  |    __| ");
	Console_SetRenderBuffer_String(1, y++, "  |           |     |     |     |        ||  ||  |__  ");
	Console_SetRenderBuffer_String(1, y++, "  |___________|      |___|      |________||__| |____| ");
	y = y + 10;
	Console_SetRenderBuffer_String(10, y++, "Press >Escape< to exit to the Main Menu");
}



//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void GameOver_EnterState()
{
}

void GameOver_ExitState()
{
}
