#include "MainMenu.h"
#include <Windows.h>
#include "stdio.h"
#include "libaries/Console.h"
#include "libaries/Clock.h"
#include "libaries/Random.h"
#include "StateMachine.h"
#include "Global.h"

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;


//*********************************************************************************
//									INPUT
//*********************************************************************************
void MainMenu_ProcessInput()
{
	if (GetAsyncKeyState(VK_RETURN) & 1)
		StateMachine_ChangeState(State_Game);

	if (GetAsyncKeyState(VK_ESCAPE) & 1)
		Global_Exit();
}

//*********************************************************************************
//									UPDATE
//*********************************************************************************

void MainMenu_Update()
{
}


//*********************************************************************************
//									RENDER
//*********************************************************************************
void MainMenu_Render()
{


	
				
		
	int y = 10;
	Console_SetRenderBuffer_String(1, y++, " ________  ___   ___  ________  ___     ___  ________   ");
	Console_SetRenderBuffer_String(1, y++, "|        ||   | |   ||        ||   |   |   ||        |  ");
	Console_SetRenderBuffer_String(1, y++, "|     ___||    ||   ||   _    ||   |  |   | |    ____|  ");
	Console_SetRenderBuffer_String(1, y++, "|    |___ |     |   ||  |_|   ||   |_|   |  |   |____   ");
	Console_SetRenderBuffer_String(1, y++, "|___     ||         ||        ||        |   |    ____|  ");
	Console_SetRenderBuffer_String(1, y++, " ___|    ||   |     ||        ||   ___   |  |   |____   ");
	Console_SetRenderBuffer_String(1, y++, "|        ||   ||    ||   __   ||  |   |   | |        |  ");
	Console_SetRenderBuffer_String(1, y++, "|________||___| |___||__|  |__||__|    |___||________|  ");
	Console_SetRenderBuffer_String(1, y++, "   ___________  _________  ______   ______  ________    ");
	Console_SetRenderBuffer_String(1, y++, "  |           ||         ||      | |      ||        |   ");
	Console_SetRenderBuffer_String(1, y++, "  |    _______||    _    ||       |       ||   _____|   ");
	Console_SetRenderBuffer_String(1, y++, "  |   |  _____ |   |_|   ||   |       |   ||  |_____    ");
	Console_SetRenderBuffer_String(1, y++, "  |   | |_    ||         ||   ||     ||   ||   _____|   ");
	Console_SetRenderBuffer_String(1, y++, "  |   |___|   ||   __    ||   | |___| |   ||  |_____    ");
	Console_SetRenderBuffer_String(1, y++, "  |           ||  |  |   ||   |       |   ||        |   ");
	Console_SetRenderBuffer_String(1, y++, "  |___________||__|  |___||___|       |___||________|   ");
	y = y + 5;
	Console_SetRenderBuffer_String(15, y++, "Press >Enter< to Play");
	Console_SetRenderBuffer_String(10, y++, "Press >Escape< to Quit the program");
}



//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void MainMenu_EnterState()
{

}

void MainMenu_ExitState()
{
}
