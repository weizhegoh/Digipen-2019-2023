#include "Game.h"
#include "stdio.h"
#include <Windows.h>              //To use the Input system
#include "libaries/Console.h"
#include "libaries/Clock.h"
#include "libaries/Random.h"
#include "StateMachine.h"

//*********************************************************************************
//								LOCAL VARIABLES
//*********************************************************************************
static int	SelectedMenu = 0;

const int width = 40, height = 40;
static int mapX = 0, mapY = 0;
int i;

static int direction = 2; /*1=left, 2=right 3=up, 4=down*/
static int iTailX[100], iTailY[100];
static int nTail = 1 ;
static double	iSnakeEX = 40.0f / 2, iSnakeEY = 40.0f / 2;	 // Euler method calculation for movement
static double	Velocity = 0.01;	// Units per milliseconds
int prevX, prevY;
int prev2X, prev2Y;

static int iFoodX[10] = { 0 };
static int iFoodY[10] = { 0 };
static int foodcounter = 0;
static int foodTemp=0;

static int score;
static int scorecounter;// score time counter
static int scoredisplay[7] = { 0 };  // storage for char digi

static int life;
static int godmode=0;
static double ETime =0.0f;
static double TimeVelocity = 0.001;
//*********************************************************************************
//									Functions
//*********************************************************************************

void time(void)
{
	ETime = ETime + TimeVelocity * Clock_GetDeltaTime();
}
void map(void)
{
	for (mapX = 2; mapX <= width+1; mapX++)
	{
		Console_SetRenderBuffer_String(mapX, 2, "!");
	}
	Console_Printf(mapX, mapY, "!");
	for (mapY = 3; mapY < height + 1; mapY++)
	{
		mapX = 2;
		Console_SetRenderBuffer_String(mapX, mapY, "!");
		for (mapX = 3; mapX <= width; mapX++)
		{
			Console_SetRenderBuffer_String(mapX, mapY, " ");
		}
		Console_SetRenderBuffer_String(mapX, mapY, "!");
	}
	for (mapX = 2; mapX <= width + 1; mapX++)
	{
		Console_SetRenderBuffer_String(mapX, mapY, "!");
	}
	
	int y = 3;
	
	
	Console_SetRenderBuffer_String(42,2,    " _______________");
	Console_SetRenderBuffer_String(42, y++, "|---------------|  ");
	Console_SetRenderBuffer_String(42, y++, "|    Made By:   |  ");
	Console_SetRenderBuffer_String(42, y++, "|---------------|  ");
	Console_SetRenderBuffer_String(42, y++, "|   Liang Ping  |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|    Wei Zhe    |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|---------------|  ");
	Console_SetRenderBuffer_String(42, y++, "|    Control    |  ");
	Console_SetRenderBuffer_String(42, y++, "|---------------|  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|Arrow Key: Move|  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|  ESC :  EXIT  |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|---------------|  ");
	Console_SetRenderBuffer_String(42, y++, "|     Cheat     |  ");
	Console_SetRenderBuffer_String(42, y++, "|---------------|  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "| F1 : + Score  |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "| F2 : GodModOn |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "| F3 : GodModOff|  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, y++, "|               |  ");
	Console_SetRenderBuffer_String(42, mapY++, " _______________");
	


}
void scoreboard(void) {
	int tempscore,temptime;
	int n = 1;
	Console_SetRenderBuffer_String(3, 1, "Score: ");

	//Store char digi 0-9 into array
	for (i = 0; i <7; i++) {
		tempscore = score;
		tempscore = tempscore / n;
		if (tempscore == 0)
		{
			scoredisplay[i] = 0;
		}
		else {
			scoredisplay[i] = tempscore % 10;
		}
		n = n * 10;
	}  

	//Display digi 0-9
	for (i = 0; i <7; i++) {

		Console_SetRenderBuffer_Char(16 - i, 1, scoredisplay[i] + '0');
	}

	if ((int)ETime  == scorecounter) {
		if (scorecounter < 10) { score = score + 1;}
		if (scorecounter > 10 && scorecounter <= 20) 
		{
			score = score + 5; //increase score
			Velocity = 0.015;// increase speed when time is over 10sec
		}
		if (scorecounter >20)
		{ 
			score = score + 10; //increase score
			Velocity = 0.02; // increase speed when time is over 20sec
		}
		scorecounter++;
	}

	Console_SetRenderBuffer_String(33, 1, "Life: ");
	Console_SetRenderBuffer_Char(39, 1, life + '0');

}
void drawsnake(void) {

	prevX = iTailX[0];
	prevY = iTailY[0];
	iTailX[0] = (int)iSnakeEX;
	iTailY[0] = (int)iSnakeEY;
	Console_SetRenderBuffer_String((int)iSnakeEX, (int)iSnakeEY, "O");
	if (prevX != (int)iSnakeEX || prevY != (int)iSnakeEY) {
		for (i = 1; i < nTail; ++i)
		{
			prev2X = iTailX[i];
			prev2Y = iTailY[i];
			iTailX[i] = prevX;
			iTailY[i] = prevY;
			prevX = prev2X;
			prevY = prev2Y;
		}
	}
	for (i = 1; i < nTail; ++i) {
		Console_SetRenderBuffer_String(iTailX[i], iTailY[i], "o");
	}





}
void food(void)
{
	if ((int)ETime == foodTemp) //check for time
	{
		if (foodcounter < 10)
		{
			iFoodX[foodcounter] = Random_Range(4, 39);
			iFoodY[foodcounter] = Random_Range(4, 39);
			foodcounter++;
			
		}
		foodTemp++;//time counter
	}
	if (foodcounter > 0){
		for (i = 0; i < foodcounter; i++) {
			Console_SetRenderBuffer_String(iFoodX[i], iFoodY[i], "F");//print food
		}
	}
	for (i = 0; i < foodcounter; i++) {
		if (iTailX[0] == iFoodX[i] && iTailY[0] == iFoodY[i])
		{
			score++;
			nTail++;
			for (int j = i; j < foodcounter; j++) {
				iFoodX[j] = iFoodX[j + 1];
				iFoodY[j] = iFoodY[j + 1];
			}
			foodcounter--;
		}
	}
}
void WLcondition(void) {
	// death on snake touch it tail
	for (i = 1; i < nTail; ++i) {
		if (nTail >= 4) {
			if (iTailX[0] == iTailX[i] && iTailY[0] == iTailY[i]) {
				iSnakeEX = width / 2;
				iSnakeEY = height / 2;
				if (godmode != 1) {
					if (life < 1) {
						StateMachine_ChangeState(State_GameOver);
					}
					else
					{
						life--;
					}
				}
			}
		}
	}
	// death on snake touch border
	if ((int)iSnakeEX < 3 || (int)iSnakeEY <3 || (int)iSnakeEX>width || (int)iSnakeEY > height) {
		iSnakeEX = width / 2;
		iSnakeEY = height / 2;
		if (godmode != 1) {
			if (life < 1) {
				StateMachine_ChangeState(State_GameOver);
			}
			else
			{
				life--;
			}
		}
	}

}
void movement() {

	if (direction == 1) {
		iSnakeEX = iSnakeEX - Velocity * Clock_GetDeltaTime(); //left
	}
	else if (direction == 2) {
		iSnakeEX = iSnakeEX + Velocity * Clock_GetDeltaTime(); //right
	}
	else if (direction == 3) {
		iSnakeEY = iSnakeEY - Velocity * Clock_GetDeltaTime(); //up
	}
	else if (direction == 4) {
		iSnakeEY = iSnakeEY + Velocity * Clock_GetDeltaTime(); //down
	}

}

//*********************************************************************************
//									INPUT
//*********************************************************************************
void Game_ProcessInput()
{
	if (GetAsyncKeyState(VK_ESCAPE) & 1) {
	StateMachine_ChangeState(State_GameOver);
	}
	if (GetAsyncKeyState(VK_LEFT)) {
		if (direction == 2) {
			direction = direction;
		}
		else {
			direction = 1;
		}
	}
	if (GetAsyncKeyState(VK_RIGHT)) {
		if (direction == 1) {
			direction = direction;
		}
		else {
			direction = 2;
		}
	}
	if (GetAsyncKeyState(VK_UP)) {
		if (direction == 4) {
			direction = direction;
		}
		else {
			direction = 3;
		}
	}
	if (GetAsyncKeyState(VK_DOWN)) {
		if (direction == 3) {
			direction = direction;
		}
		else {
			direction = 4;
		}
	}
	if (GetAsyncKeyState(VK_F1)) {
		score++;
	}
	if (GetAsyncKeyState(VK_F2)) {
		if (godmode == 0) { godmode = 1; }
	}
	if (GetAsyncKeyState(VK_F3)) {
		if (godmode == 1) { godmode = 0; }
	}

}



//*********************************************************************************
//									UPDATE
//*********************************************************************************
void Game_Update()
{

	
	WLcondition();
	movement();
	time();

}


//*********************************************************************************
//									RENDER
//*********************************************************************************
void Game_Render()
{  
	map();
	scoreboard();
	drawsnake();
	food();
	
}


//*********************************************************************************
//								STATE MANAGEMENT
//*********************************************************************************
void Game_EnterState()
{
	score = 0;
	nTail = 0;
	life = 3;
	ETime = 0.0f;
	foodTemp=0;
	scorecounter=0;
	foodcounter = 0;
	for (i = 0; i < 100; i++) {
		iTailX[i] = 0;
		iTailY[i] = 0;
	}
	for (i = 0; i < 10; i++) {
		iFoodX[i] = 0;
		iFoodY[i] = 0;
	}
	for (i = 0; i < 7; i++) {
		scoredisplay[i] = 0;
	}
	
}

void Game_ExitState()
{

}
