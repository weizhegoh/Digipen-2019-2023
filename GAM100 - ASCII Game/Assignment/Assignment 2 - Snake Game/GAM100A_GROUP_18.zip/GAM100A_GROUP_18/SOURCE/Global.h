#ifndef GLOBAL_H
#define GLOBAL_H
#include <stdbool.h>

void Global_Exit();
bool Global_IsGameRunning();

#endif // GLOBAL_H
