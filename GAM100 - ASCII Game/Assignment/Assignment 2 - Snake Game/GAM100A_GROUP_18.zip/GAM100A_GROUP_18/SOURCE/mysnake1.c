// SnakeGame.cpp : This file contains the 'main' function. Program execution begins and ends there.

//

#include "stdio.h"
#include <Windows.h>              //To use the Input system
#include "libaries/Console.h"
#include "libaries/Clock.h"
#include "libaries/Random.h"
#include "StateMachine.h"


int main()

{
	//Engine Initialization
	Random_Init();
	Console_Init();
	//Window mode
	Console_SetSquareFont();
	Console_SetWindowedMode(60, 50, false);
	Console_SetCursorVisibility(false);

	StateMachine_ChangeState(State_MainMenu);

	while (Global_IsGameRunning())
	{
		Clock_GameLoopStart();
		Console_ClearRenderBuffer();
		StateMachine_StartFrame();
		StateMachine_ProcessInput();
		StateMachine_Update();
		StateMachine_Render();
		Console_SwapRenderBuffer();


		//Sleep(100);

	}



	//Engine Cleanup
	Console_CleanUp();

}
//Print a text
//Console_Printf(5, 5, "Hello Students");
