#include "Libraries/Console.h"
#include "Libraries/Clock.h"
#include <Windows.h>
#include <stdio.h>

static int		bGameIsRunning	= 1;
static int		NormalX			= 0;		// X for the normal method, incrementing every frame
static double	EulerX			= 0.0f;		// Euler method calculation for movement
static double	Velocity		= 0.001;	// Units per milliseconds

int main()
{
	// Game Initialization
	Console_Init();
	Console_SetTitle("GAM100: DeltaTime Test");
	Console_SetWindowedMode(80, 15, false);
	Console_SetCursorVisibility(0);

	char str[256];

	// Saved Values after 5seconds
	double	timeStamp = 0;
	double	savedEulerX = 0;
	int		savedNormalX = 0;
	int		savedFrameCount = 0;		// counts How many frame in 5seconds
	
	int y = 0;						// Text Row
	int frameCount = 0;				// Frame Counter
	
	// Game Loop
	while (bGameIsRunning)
	{
		++frameCount;

		// Frame Time calculation, DeltaTime      
		Clock_GameLoopStart();

		////////////////////////////////////////////////// PROCESS INPUT ////////////////////////////////////////////////// 
		if (GetAsyncKeyState(VK_ESCAPE))
			bGameIsRunning = 0;

		////////////////////////////////////////////////// UPDATE ////////////////////////////////////////////////// 
		EulerX = EulerX + Velocity * Clock_GetDeltaTime();
		NormalX = NormalX + 1;

		////////////////////////////////////////////////// RENDERING ////////////////////////////////////////////////// 
		// Reset the text row position
		y = 0;

		// Display DeltaTime
		Console_Printf(0, y++, "FRAME INFO");
		sprintf_s(str, 256, "dT:%f ms", Clock_GetDeltaTime());
		Console_Printf(0, y++, str);

		// Display the Change of NormalX and EulerX every frame
		sprintf_s(str, 256, "NormalX:%d", NormalX);
		Console_Printf(0, y++, str);

		sprintf_s(str, 256, "EulerX:%f", EulerX);
		Console_Printf(0, y++, str);
		
		if (timeStamp == 0)
		{
			// at the 5seconds, we record some values, this is done once only thanks to the timeStamp test
			if (Clock_GetElapsedTimeMs() >= 5000)
			{
				timeStamp = Clock_GetElapsedTimeMs();
				savedEulerX = EulerX;
				savedNormalX = NormalX;
				savedFrameCount = frameCount;
			}
		} 
		else
		{
			Console_Printf(0, y++, "============================");
			Console_Printf(0, y++, "AT THE 5 SECOND MARK:");

			sprintf_s(str, 256, "The loop has been executed %d times", savedFrameCount);
			Console_Printf(0, y++, str);


			sprintf_s(str, 256, "After %f ms, Euler method X =%f", timeStamp, savedEulerX);
			Console_Printf(0, y++, str);

			sprintf_s(str, 256, "After %f ms, Normal X =%d", timeStamp, savedNormalX);
			Console_Printf(0, y++, str);

		}

		// Change this value to make the gameloop last longer
		// 1000 = executed once per second
		Sleep(1000);
	}

	// Game Shutdown
	Console_CleanUp();
}
