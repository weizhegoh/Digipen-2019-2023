/**********************************************************************************
* \file			ColorTest.c
* \brief		Demo for the Console palette functionality
* \author		Yannick Gerber
* \version		1.0
* \date			2019
*
* \note			Course: GAM100
* \copyright	Copyright (c) 2019 DigiPen Institute of Technology. Reproduction
				or disclosure of this file or its contents without the prior
				written consent of DigiPen Institute of Technology is prohibited.
**********************************************************************************/

#include <Windows.h>
#include <stdio.h>

#include "../Libraries/Console.h"
#include "../Libraries/Clock.h"
#include "../Libraries/Random.h"

static int gRequestedExitGame = 0;
typedef unsigned char BYTE;

#define WINDOW_WIDTH 120
#define WINDOW_HEIGHT 50

static BYTE FireBuffer1[WINDOW_WIDTH][WINDOW_HEIGHT];
static BYTE FireBuffer2[WINDOW_WIDTH][WINDOW_HEIGHT];
static BYTE CoolingMap[WINDOW_WIDTH][WINDOW_HEIGHT];

static int CoolingFactor = 40;
static int PaletteSwitch = 0;

void GameInit()
{
	for (int j = 0; j < WINDOW_HEIGHT; ++j)
		for (int i = 0; i < WINDOW_WIDTH; ++i)
		{
			FireBuffer1[i][j] = 0;
			FireBuffer2[i][j] = 0;
			CoolingMap[i][j] = Random_Range(3, CoolingFactor);
		}
}


// Set the 16 colors of the palette to shades of red
void SetPaletteRed()
{
	ConsoleColorPalette palette;
	// Set the palette to a red Fire Shade, using R G B macros from windows
	int r = 255; int g = 200; int b = 0;
	for (int i = 0; i < 16; ++i)
	{
		(r > 0) ? (r -= 15) : (r = 0);
		(g > 0) ? (g -= 25) : (g = 0);
		(b > 0) ? (b -= 10) : (b = 0);
		palette.color[15 - i] = RGB(r, g, b);
	}
	palette.color[0] = RGB(0, 0, 0);

	// Apply palette to the console
	Console_SetColorPalette(&palette);
}

// Set the 16 colors of the palette to shades of green
void SetPaletteGreen()
{
	ConsoleColorPalette palette;
	// Set the palette to Green Shade
	int r = 200; int g = 255; int b = 0;
	for (int i = 0; i < 16; ++i)
	{
		(r > 0) ? (r -= 25) : (r = 0);
		(g > 0) ? (g -= 15) : (g = 0);
		(b > 0) ? (b -= 10) : (b = 0);
		palette.color[15 - i] = RGB(r, g, b);
	}
	palette.color[0] = RGB(0, 0, 0);

	// Apply palette to the console
	Console_SetColorPalette(&palette);
}

void RandomizeCoolingMap()
{
	for (int j = 0; j < WINDOW_HEIGHT-1; ++j)
		for (int i = 0; i < WINDOW_WIDTH; ++i)
			CoolingMap[i][j] = CoolingMap[i][j+1];

	for (int i = 0; i < WINDOW_WIDTH; ++i)
		CoolingMap[i][WINDOW_HEIGHT-1] = Random_Range(3, CoolingFactor);

}

void HeatSource()
{
	for (int i = 1; i < WINDOW_WIDTH - 1; ++i)
	{
		FireBuffer1[i][(WINDOW_HEIGHT - 4)] = Random_Range(220, 255);
		FireBuffer1[i][(WINDOW_HEIGHT - 3)] = Random_Range(220, 255);
		FireBuffer1[i][(WINDOW_HEIGHT - 2)] = Random_Range(220, 255);
		FireBuffer1[i][(WINDOW_HEIGHT - 1)] = Random_Range(220, 255);
	}
}

void SpawnRandomFireSpot()
{
	for (int k = 0; k < 3; ++k)
	{
		const int x = Random_Range(1, WINDOW_WIDTH - 12);
		const int y = Random_Range(1, WINDOW_HEIGHT - 12);
		const int size = Random_Range(4, 10);

		for (int j = 1; j < size; ++j)
			for (int i = 1; i < size; ++i)
			{
				FireBuffer1[x + i][y + j] = Random_Range(220, 255);
			}
	}
}

void FireEffect()
{
	for (int y = 1; y < WINDOW_HEIGHT - 2; ++y)
	{
		for (int x = 1; x < WINDOW_WIDTH - 2; ++x)
		{
			BYTE f = (FireBuffer1[x + 1][y] +
				FireBuffer1[x - 1][y] +
				FireBuffer1[x][y + 1] +
				FireBuffer1[x][y - 1]) / 4;

			BYTE cooling = CoolingMap[x][y];

			if (f>cooling)
				f -= cooling;
			else
				f = 0;

			FireBuffer2[x][y - 1] = f;
		}
	}
}

// You can now modify the render buffer before rendering it by calling Console_RenderBuffer_PostProcess
// Everything rendered before with Console_SetRenderBuffer_XXXXX is in the buffer already, and you can modify their value
// Useful to make post process effects, like shadow map, or a fog ... or here, to add a fire background
void ApplyFireBackground(CHAR_INFO* buffer, int bufferSize)
{
	for (int y = 0; y < WINDOW_HEIGHT; ++y)
		for (int x = 0; x < WINDOW_WIDTH; ++x)
		{
			FireBuffer1[x][y] = FireBuffer2[x][y];
			buffer[x + y * WINDOW_WIDTH].Attributes = buffer[x + y * WINDOW_WIDTH].Attributes | (FireBuffer2[x][y] / 16) << 4;
		}
}


void GameInput()
{
	if (GetAsyncKeyState(VK_ESCAPE))
		gRequestedExitGame = 1;

	if (GetAsyncKeyState(VK_DOWN) & 0x8000)
	{
		CoolingFactor += 5;

		if (CoolingFactor > 60)
			CoolingFactor = 60;
	}

	if (GetAsyncKeyState(VK_UP) & 0x8000)
	{
		CoolingFactor -= 5;

		if (CoolingFactor < 10)
			CoolingFactor = 10;

	}

	if (GetAsyncKeyState(VK_RETURN) & 0x8000)
	{
		SpawnRandomFireSpot();
	}

	if (GetAsyncKeyState(VK_SPACE) & 0x8000)
	{
		PaletteSwitch = !PaletteSwitch;

		if (PaletteSwitch)
			SetPaletteGreen();
		else
			SetPaletteRed();

	}
}

void GameUpdate()
{
	HeatSource();
	FireEffect();
	RandomizeCoolingMap();
}


// Do not do this in your games, this is incredibly slow. 
// You should Use another buffer that you just copy
void RenderDigipenLogo()
{
	int dY = (WINDOW_HEIGHT - 36) / 2;
	int dX = (WINDOW_WIDTH - 54) / 2;
	Console_SetRenderBuffer_Printf(dX, dY++, "immmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmf");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                                                   e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                                                   e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                       #@@@  #@@@@@@@@@@@          e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                      ##@@@ ##@@@@@@@@@@@@@        e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                      ##@@@ ##@@@@@@@@@@@@@@@      e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                      ##@@@ ##@@@`````````@@@@     e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                      ##@@@ ##@@@         ##@@@    e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                      ##@@@ ##@@@       ##@@@@     e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                      ##@@@ ##@@@@@@@@@@@@@@@      e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                      ##@@@ ##@@@@@@@@@@@@@        e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                      ##@@@ ##@@@@@@@@@@@          e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e         #@@@@@@@@@@@ ##@@@ ````````````           e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e      ##@@@@@@@@@@@@@ ##@@@                        e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e     ##@@@@@@@@@@@@@@ ##@@@                        e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e    ##@@@@@``````@@@@ ##@@@                        e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e   ##@@@       ##@@@@ ##@@@                        e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e   ##@@@@@     ##@@@@ ##@@@                        e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e    ##@@@@@@@@@@@@@@@ ##@@@                        e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e     ###@@@@@@@@@@@@@ ##@@@                        e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e      ###`@@@@@@@@@@@ ##@@@                        e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e        ````````````  ##@@@                        e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                      ````                         e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e @@@@@@@                  @@@@@@@                  e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e @@@@@@@@  @@@        @@@ @@   @@@  @@@@@          e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e @@@   @@@      @@@@@     @@   @@@ @@    @ @@@@@@  e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e @@@   @@@ @@@ @@  @@ @@@ @@@@@@@  @@@@@@@ @@@ @@@ e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e @@@@@@@@@ @@@ @@  @@ @@@ @@       @@      @@@ @@@ e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e @@@@@@@@  @@@  @@@@@ @@@ @@        @@@@@  @@@ @@@ e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                 @@@@                              e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e               @@@@                                e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                                                   e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                                                   e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e         INSTITUTE OF TECHNOLOGY SINGAPORE         e");
	Console_SetRenderBuffer_Printf(dX, dY++, "e                                                   e");
	Console_SetRenderBuffer_Printf(dX, dY++, "hmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmg");
}

void RenderHelp()
{
	int dY = 2;
	Console_SetRenderBuffer_Printf(2, dY++, "<UP>/<DOWN> Fire intensity [%d]", 60-CoolingFactor);	 // You can now use variadics in the console printf
	Console_SetRenderBuffer_Printf(2, dY++, "<SPACE> Change color");
	Console_SetRenderBuffer_Printf(2, dY++, "<ENTER> Random fire spot");

	for (int y = 2; y < dY; ++y)
		for (int x = 2; x < 35; ++x)
			Console_SetRenderBuffer_CellColor(x, y, 14 | 2 << 4);
}

void GameRender()
{
	Console_ClearRenderBuffer();
	RenderHelp();												// Normal Rendering, as you would do in the SNAKE Game
	RenderDigipenLogo();
	Console_RenderBuffer_PostProcess(ApplyFireBackground);		// Post Effect Fire: you can manipulate the render buffer before swapping it
																// We can still render more, and post process more before swapping the render buffer to the video buffer
	Console_SwapRenderBuffer();
}


int main()
{
	Console_Init();
	Console_SetTitle("GAM100: Palette Test");
	// Setting the the smallest available Font to the console Window
	Console_SetTerminalFont(4,6);
	Console_SetWindowedMode(WINDOW_WIDTH, WINDOW_HEIGHT, false);
	Console_SetCursorVisibility(0);
	Console_Clear();

	Random_Init();
	GameInit();

	SetPaletteRed();

	while (!gRequestedExitGame)
	{
		Clock_GameLoopStart();

		GameInput();
		GameUpdate();
		GameRender();

		Sleep(60);
	}

	Console_CleanUp();
}
