/*
 * temp.h
 *
 *  Created on: 22 gen 2016
 *      Author: cnoviello
 */

#ifndef __TEMP_H__
#define __TEMP_H__

float getMCUTemperature();

#endif /* __TEMP_H__ */
