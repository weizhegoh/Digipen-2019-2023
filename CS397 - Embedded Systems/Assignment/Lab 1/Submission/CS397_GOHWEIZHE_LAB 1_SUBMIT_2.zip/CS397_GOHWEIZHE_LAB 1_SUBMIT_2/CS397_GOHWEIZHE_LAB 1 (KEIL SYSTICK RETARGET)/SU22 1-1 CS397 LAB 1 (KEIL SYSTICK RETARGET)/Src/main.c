/*****************************************************************************
 @Project		: 
 @File 			: main.c
 @Details  	:
 @Author		: fongfh
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  fongfh     16 Jul 18  		Initial Release
	 1.1	fongfh			9 Sep 20			Add buzzer (HAL.c)
   
******************************************************************************/

#include "Common.h"
#include "Hal.h"
#include "BSP.h"
#include "LED.h"
#include "NVIC.h"

/*****************************************************************************
 Define
******************************************************************************/


/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/



/*****************************************************************************
 Local Variables
******************************************************************************/
static volatile BOOL	g_bSystemTick = FALSE;
static volatile BOOL  g_rLED = FALSE;
static volatile BOOL  g_gLED = FALSE;
static volatile BOOL	g_bLED = FALSE;	
static volatile BOOL  g_wLED = FALSE;
static volatile BOOL  g_yLED = FALSE;

static int            g_count = 0;
volatile unsigned long colour;
int sequence = 0;


/*****************************************************************************
 Local Functions
******************************************************************************/
__STATIC_INLINE uint32_t Configure_SysTick(uint32_t ticks)
{
	
	uint32_t reload_value = ticks - 1UL;
	
	//if reload value higher than 24 bit value, return 1
	if((reload_value) > SysTick_LOAD_RELOAD_Msk) 
		return 1UL;
	
	SysTick->LOAD = reload_value;
	
	//set priority for SysTick interrupt
	NVIC_SetPriority (SysTick_IRQn, (1UL << __NVIC_PRIO_BITS) - 1UL);	
	
	//Load SysTick counter value
	SysTick->VAL   = 0UL;
	
	//Enable SysTick Timer, Interrupt and CPU clock. 
	SysTick->CTRL  = SysTick_CTRL_CLKSOURCE_Msk |
                   SysTick_CTRL_TICKINT_Msk   |
                   SysTick_CTRL_ENABLE_Msk;  
	return 0UL;
}

/*****************************************************************************
 Implementation
******************************************************************************/

int main()
{
	BSPInit(); /* in BSP.c   */
	
	BOOL bToggle = TRUE;

	SystemCoreClockUpdate();
	
	/** NOTE for Lab 1:                                                             **/
	/** This program currently uses the CMSIS function to configure                 **/ 
	/**   It is for testing your setup.                                             **/
  /** For LAB1, COMMENT OUT THIS LINE OF CODE &                                   **/
  /**   replace it with your own function: Configure_SysTick(ticks)               **/
	/**   to provide system ticks for every 10 ms.                                  **/
  /**   Use the lecture example as a guide.                                       **/	
	//SysTick_Config( SystemCoreClock/1000 );   /* Initialize SysTick ticks every 1 ms */
	
	/* print to Virtual COM port temrinal */
	//printf ("\nHello World! \n\r"); // display to virtual COM port
	//printf ("Welcome to CS397!:\n\r");
	
	volatile uint32_t ticks = SystemCoreClock/100;
	Configure_SysTick(ticks);
	
	for(;;)
  {
    if (FALSE != g_bSystemTick) /* check every system tick */
		{
			g_bSystemTick = FALSE;
		}
		
		if( FALSE != g_bLED )	/* Check if LED flag is set   */
		{
			/* Clear SysTick flag so we only processes it once       */
			g_bLED = FALSE;	
			/* Set LED to BLUE if toggle is TRUE(=1),                 */
			/* otherwise if toggle is FALSE(=0), the LED will be off */
			//LED_BLUE_SET (bToggle);
			LED_RGB_SET( colour * bToggle ); 
			//bToggle = !bToggle;	/* Inverse toggle, so if 0 it becomes 1, 1 becomes 0 */
		}		
	}	
}

/*****************************************************************************
 Callback functions
******************************************************************************/
void SysTick_Handler( void )  
{
	g_bSystemTick = TRUE;	
	g_count++;

	if(g_count == 1 && sequence == 0)
	{
		colour = RGB_RED;
		sequence = 1;
	}
	else if(g_count%170 == 0 && sequence == 1)
	{
		colour = RGB_GREEN;
		sequence = 2;
	}
	else if (g_count%270 == 0 && sequence == 2) /* set flag every 10ms */
  {
		colour = RGB_BLUE;
		sequence = 3;
  }
	else if(g_count%400 == 0 && sequence == 3)
	{
		colour = RGB_WHITE;
	}
	else if(g_count%650 == 0)
	{
		g_count = 0;
		colour = RGB_RED;
		sequence = 0;
	}
	
	g_bLED = TRUE;
}

/*****************************************************************************
 Local functions
******************************************************************************/

