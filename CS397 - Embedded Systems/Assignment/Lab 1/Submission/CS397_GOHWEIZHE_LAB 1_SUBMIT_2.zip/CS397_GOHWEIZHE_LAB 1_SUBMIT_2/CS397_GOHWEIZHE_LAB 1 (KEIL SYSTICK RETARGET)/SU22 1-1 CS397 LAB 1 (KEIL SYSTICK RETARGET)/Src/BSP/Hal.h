/*****************************************************************************
 @Project	: 
 @File 		: 
 @Details  	: Ports and peripherals configuration                    
 @Author	: 
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  Name     XXXX-XX-XX  		Initial Release
   
******************************************************************************/

#ifndef __HAL_DOT_H__
#define __HAL_DOT_H__


/*****************************************************************************
 Define
******************************************************************************/
#define PA_UART0_RX				0U		// PA0
#define PA_UART0_TX				1U		// PA1
#define PA_LCD_SSI0_SCK		2U
#define PA_LCD_SSI0_CS		3U
#define PA_BUZZER					4U
#define PA_LCD_SSI0_MOSI 	5U
#define PA_LCD_DC					6U
#define PA_LCD_RESET			7U

#define PB_LED_IR					0U
#define PB_LCD_BL					1U
#define PB_T3CCP0					2U
#define PB_T3CCP1					3U
#define PB_ADC_AIN10			4U

//#define PC_STEPPER0				4U
//#define PC_STEPPER1				5U
//#define PC_STEPPER2				6U
//#define PC_STEPPER3				7U

#define PD_OUTPUT					1U
//#define PD_KEYPAD_ROW0		0U
//#define PD_KEYPAD_ROW1		1U
//#define PD_KEYPAD_ROW2		2U
//#define PD_KEYPAD_ROW3		3U

//#define PE_IR_INPUT				0U
//#define PE_KEYPAD_COL0		1U
//#define PE_KEYPAD_COL1		2U
//#define PE_KEYPAD_COL2		3U
//#define PE_ADC_AIN8				5U
//#define PE_ADC_AIN9				4U

#define PF_SW2						0U
#define PF_LED_RED				1U
#define PF_LED_BLUE				2U
#define PF_LED_GREEN			3U
#define PF_SW1						4U


/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Macro
******************************************************************************/
#define BIT( x )					(1U<<(x))

/* LEDs */
#define LED_RED_ON()				( GPIOF->DATA |= BIT(PF_LED_RED) )
#define LED_RED_OFF()				(GPIOF->DATA &= ~BIT(PF_LED_RED))
#define LED_RED_SET( x )		((x)? LED_RED_ON() : LED_RED_OFF())

#define LED_BLUE_ON()				(GPIOF->DATA |= BIT(PF_LED_BLUE))
#define LED_BLUE_OFF()			(GPIOF->DATA &= ~BIT(PF_LED_BLUE))
#define LED_BLUE_SET( x )		((x)? LED_BLUE_ON() : LED_BLUE_OFF())

#define LED_GREEN_ON()			(GPIOF->DATA |= BIT(PF_LED_GREEN))
#define LED_GREEN_OFF()			(GPIOF->DATA &= ~BIT(PF_LED_GREEN))
#define LED_GREEN_SET( x )	((x)? LED_GREEN_ON() : LED_GREEN_OFF())


/******************************************************************************
 Global functions
******************************************************************************/


/******************************************************************************
 @Description 	: 

 @param			: 
 
 @revision		: 1.0.0
 
******************************************************************************/
void Port_Init( void );
void write_ASCII_UART0 (char);


#endif /* __HAL_DOT_H__ */









