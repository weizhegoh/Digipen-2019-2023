/*****************************************************************************
 @Project	: 
 @File 		: Hal.c
 @Details  	: All Ports and peripherals configuration                    
 @Author	: 
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  Name     XXXX-XX-XX  		Initial Release
   
******************************************************************************/
#include <Common.h>
#include "Hal.h"


/*****************************************************************************
 Define
******************************************************************************/


/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/


/*****************************************************************************
 Implementation
******************************************************************************/

void Port_Init( void )
{
	/* enable GPIO port and clock to Port F (pg 340)		*/
	SYSCTL->RCGCGPIO |= SYSCTL_RCGCGPIO_R0|  		/* enable Port A clock		*/
											SYSCTL_RCGCGPIO_R5; 		/* enable Port F clock */
	
	/* enable clock to UART0   */
	SYSCTL->RCGCUART |= SYSCTL_RCGCUART_R0;
	
	/* Wait for GPIO port to be ready */
	while( 0 == (SYSCTL->PRGPIO & SYSCTL_PRGPIO_R0) );	/* port A */
	while( 0 == (SYSCTL->PRGPIO & SYSCTL_PRGPIO_R5)){};	/* port F */
	
	/* Wait for UART to be ready */
	while( 0 == (SYSCTL->PRUART & SYSCTL_PRUART_R0) ); 
		
	/* Unlock GPIO PF[0] */
	GPIOF->LOCK = GPIO_LOCK_KEY;	/* Unlock Port F (pg 684)		*/
	GPIOF->CR |= BIT(PF_SW2) | BIT(PF_SW1);		/* Set Commit Control register for PF[0] */
		
	/* Initialize RGB LED  */
	GPIOF->DIR |= BIT(PF_LED_RED) | BIT(PF_LED_BLUE) | BIT(PF_LED_GREEN);
	GPIOF->DEN |= BIT(PF_LED_RED) | BIT(PF_LED_BLUE) | BIT(PF_LED_GREEN);
	GPIOF->AFSEL &=	~( BIT(PF_LED_RED) | BIT(PF_LED_BLUE) | BIT(PF_LED_GREEN) );
	
	/* Buzzer */
	GPIOA->DIR |= BIT( PA_BUZZER);
	GPIOA->DEN |= BIT (PA_BUZZER);
	
	/*SW1 & SW2*/
	GPIOF->DIR &= ~( BIT(PF_SW1) | BIT(PF_SW2));
	GPIOF->PUR |= BIT(PF_SW1) | BIT(PF_SW2);
	GPIOF->DEN |= BIT(PF_LED_RED) | BIT(PF_LED_BLUE) | BIT(PF_LED_GREEN) | BIT(PF_SW1) | BIT(PF_SW2);
		
	/* initialize GPIO PA0 (UART0_RX) & PA1 (UART0_TX)   */
	GPIOA->AFSEL |= BIT(PA_UART0_RX) | BIT(PA_UART0_TX);
	GPIOA->DEN |= BIT(PA_UART0_RX) | BIT(PA_UART0_TX);
	GPIOA->AMSEL &= ~( BIT(PA_UART0_RX) | BIT(PA_UART0_TX) );
	GPIOA->PCTL &= ~( GPIO_PCTL_PA0_M | GPIO_PCTL_PA1_M ); /* clear Port C config bits  */
	GPIOA->PCTL |= GPIO_PCTL_PA0_U0RX | GPIO_PCTL_PA1_U0TX;
	
		
	/** initialize UART0   **/	
	UART0->CTL &= ~UART_CTL_UARTEN; 					/* disable UART during initialization  	*/
	UART0->CC &= ~UART_CC_CS_M; 							//  clock source mask
	UART0->CC |= UART_CC_CS_SYSCLK; 					// set to system clock
	
	UART0->CTL &= ~UART_CTL_HSE;											/* use 16X CLKDIV  							*/
	UART0->IBRD = 5;	 					/* int (80,000,000 / (16 * 921,600)) = 5.425347    */
	UART0->FBRD = 27;  					/* int (5.425347 * 64 + 0.5 = int (27.72) = 27   */
	
	UART0->LCRH &= ~UART_LCRH_WLEN_M; 	
	UART0->LCRH |= UART_LCRH_WLEN_7 | UART_LCRH_PEN; 	/* 7 data bits, parity enable  	*/
	UART0->LCRH |= UART_LCRH_EPS ;   									/* even parity  								*/ 	
	UART0->LCRH &= ~UART_LCRH_STP2;  									/* 1 stop bit 									*/ 
	
	UART0->LCRH |= UART_LCRH_FEN; 										/* enable FIFO*/
	
	UART0->CTL |= UART_CTL_TXE; 											/* transmit enable 							*/
	UART0->CTL |= UART_CTL_UARTEN; 										/* enable UART0   		*/
	
/**enable interrupts for SW1 and SW2*/
/**intr mask reg mask interrups first, enable after configured **/
GPIOF->IM &= ~( BIT(PF_SW1) | BIT(PF_SW2) ); /* mask intrs*/
GPIOF->IBE &= ~( BIT(PF_SW1) | BIT(PF_SW2) ); /* disable both edges*/
GPIOF->IS &= ~( BIT(PF_SW1) | BIT(PF_SW2) ); /* edge sensitive*/
GPIOF->IEV &= ~( BIT(PF_SW1) | BIT(PF_SW2) ); /* detect falling edges */
GPIOF->IM |= BIT(PF_SW1) | BIT(PF_SW2); /* enable intrs in mask*/
}		


/** Write an ASCII character to UART0				**/
/** character = ASCII to write 							**/
void write_ASCII_UART0 (char character )
{
	while( 0 != (UART0->FR & UART_FR_TXFF) ){}; 	/* wait if TX FIFO full					*/
	UART0->DR = character; 												/* write character to UART data reg */
}















