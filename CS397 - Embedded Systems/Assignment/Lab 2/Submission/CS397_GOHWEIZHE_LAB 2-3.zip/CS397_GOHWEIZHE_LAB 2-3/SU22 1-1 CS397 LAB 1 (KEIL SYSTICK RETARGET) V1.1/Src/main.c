/*****************************************************************************
 @Project		: 
 @File 			: main.c
 @Details  	:
 @Author		: fongfh
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  fongfh     16 Jul 18  		Initial Release
	 1.1	fongfh			9 Sep 20			Add buzzer
   
******************************************************************************/

#include "Common.h"
#include "Hal.h"
#include "BSP.h"
#include "LED.h"
#include "IRQ.h"

/*****************************************************************************
 Define
******************************************************************************/
#define BOUNCE_PERIOD 15
#define SW1 (~GPIOF->DATA >> 4 & 0x0001 ? 1 : 0)
#define SW2 (~GPIOF->DATA & 0x0001 ? 1 : 0)

/*****************************************************************************
 Type definition
******************************************************************************/
void GPIOF_Handler (void);


/*****************************************************************************
 Global Variables
******************************************************************************/



/*****************************************************************************
 Local Variables
******************************************************************************/
static volatile BOOL	g_bSystemTick = FALSE;
static volatile BOOL	g_bLED = FALSE;
static int            g_count = 0;
static int 						g_debounce = 0;

volatile unsigned long colour;
volatile unsigned long rbg_colour[5] = {RGB_RED, RGB_YELLOW, RGB_GREEN, RGB_CYAN, RGB_BLUE};
volatile int beep[5] = {15,2,2,2,15};
static int i = 2;

static BOOL SW_TOGGLE = FALSE;
BOOL bToggle = TRUE;
//BOOL sound 	 = FALSE;

/*****************************************************************************
 Local Functions
******************************************************************************/
void GPIOF_Button_IRQHandler ( uint32_t Status)
{
		/*check if it is SW1 (PF4) interrupt */
	if( 0 != (Status & BIT(PF_SW1)))
	{
		GPIOF->ICR = BIT(PF_SW1); /* clear intr bit */
	
		/*add C statements to process SW1 intr*/
		if(g_debounce <=0)
		{
			g_debounce = BOUNCE_PERIOD;
			SW_TOGGLE = TRUE;
		}
		
	}
	
	/*check if it is SW2 (PF0) intr */
	if( 0 != (Status & BIT(PF_SW2 )))
	{
		GPIOF->ICR = BIT(PF_SW2); /* clear intr bit */
		/*add C statements to process SW2 intr*/

			if(g_debounce <= 0)
			{
				g_debounce = BOUNCE_PERIOD;
				SW_TOGGLE = TRUE;
			}
	}
}

/*****************************************************************************
 Implementation
******************************************************************************/

int main()
{
	BSPInit(); /* in BSP.c   */

	SystemCoreClockUpdate();
	SysTick_Config( SystemCoreClock/1000 );   /* Initialize SysTick ticks every 1 ms */
	
	/* print to Virtual COM port temrinal */
	//printf ("\nHello World! \n\r"); // display to virtual COM port
	//printf ("Welcome to CS397!\n\r");
	
	IRQ_Init(); /* in IRQ.c*/
	
	LED_RGB_SET(RGB_GREEN);

	for(;;)
  {
    if (FALSE != g_bSystemTick) /* check every system tick */
		{
			g_bSystemTick = FALSE;
		}
			
		//if( FALSE != g_bLED )	/* Check if LED flag is set   */
		//{
			/* Clear SysTick flag so we only processes it once       */
			//g_bLED = FALSE;	
			/* Set LED to BLUE if toggle is TRUE(=1),                 */
			/* otherwise if toggle is FALSE(=0), the LED will be off */
			//LED_RGB_SET(colour * bToggle );
			//BUZZER_SET(sound);			
			//bToggle = !bToggle;	/* Inverse toggle, so if 0 it becomes 1, 1 becomes 0 */
		//}		
	}
}

/*****************************************************************************
 Callback functions
******************************************************************************/
void SysTick_Handler( void )  
{
	g_bSystemTick = TRUE;
	
	g_debounce ? g_debounce-- : g_debounce;
	g_count++;
	
	if(g_debounce == 0 && SW_TOGGLE)
	{
		SW_TOGGLE = FALSE;
		
		if(SW1)
		{
			if(i >= 0 && i <= 3)
			{
				++i;
				BUZZER_ON();
				LED_RGB_SET(rbg_colour[i]);
				g_count = 0;
			}
		}
		
		if(SW2)
		{
			if(i >= 1 && i <= 4)
			{
				--i;
				BUZZER_ON();
				LED_RGB_SET(rbg_colour[i]);
				g_count = 0;
			}
		}
	}
	
	if((g_count >0) && (g_count % beep[i] == 0))
		BUZZER_OFF();
	
	//g_bLED = TRUE;
}

/* ISR: interrupt handler for PORT F interrupt */
void GPIOF_Handler (void)
{
	uint32_t status = GPIOF->RIS ; /* read & store interrupt status */
	GPIOF_Button_IRQHandler (status); /* ISR function in main.c */
}
/*****************************************************************************
 Local functions
******************************************************************************/

