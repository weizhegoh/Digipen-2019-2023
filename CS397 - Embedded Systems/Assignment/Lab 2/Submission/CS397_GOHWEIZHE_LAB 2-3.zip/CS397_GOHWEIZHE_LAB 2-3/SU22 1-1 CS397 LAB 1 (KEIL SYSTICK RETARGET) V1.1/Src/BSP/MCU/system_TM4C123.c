/**************************************************************************//**
 * @file     system_TM4C.c
 * @brief    CMSIS Device System Source File for
 *           Texas Instruments TIVA TM4C123 Device Series
 * @version  V1.01
 * @date     19. March 2015
 *
 * @note
 *                                                             modified by Keil
 ******************************************************************************/

#include <stdint.h>
#include "TM4C123GH6PM7.h"



/*----------------------------------------------------------------------------
  Define clocks
 *----------------------------------------------------------------------------*/
#define XTALM       (16000000UL)            /* Main         oscillator freq */
#define XTALI       (16000000UL)            /* Internal     oscillator freq */
#define XTAL30K     (   30000UL)            /* Internal 30K oscillator freq */
#define XTAL32K     (   32768UL)            /* external 32K oscillator freq */

#define PLL_CLK    (400000000UL)
#define ADC_CLK     (PLL_CLK/25)
#define CAN_CLK     (PLL_CLK/50)


/*----------------------------------------------------------------------------
  Clock Variable definitions
 *----------------------------------------------------------------------------*/
uint32_t SystemCoreClock = XTALI; /* by default internal RC 16MHz */


static uint32_t const XTAL_NO_PLL[] = 
{ 
	0,0,0,0,0,0,
	4000000,
	4096000,
	4915200,
	5000000,
	5120000,
	6000000,
	6144000,
	7372800,
	8000000,
	8192000,
	10000000,
	12000000,
	12288000,
	13560000,
	14318180,
	16000000,
	16384000,
	18000000,
	20000000,
	24000000,
	25000000
};



/*----------------------------------------------------------------------------
  Clock functions
 *----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------
  Get the OSC clock
 *----------------------------------------------------------------------------*/
void SystemCoreClockUpdate( void )            /* Get Core Clock Frequency      */
{
	uint32_t rcc, rcc2;

	/* Determine clock frequency according to clock register values */
	rcc  = SYSCTL->RCC;
	rcc2 = SYSCTL->RCC2;

	/* If RCC2 enabled, it will override RCC for same bit field */
	if( 0 != (rcc2 & SYSCTL_RCC2_USERCC2) )
	{   
		/* RCC2 is used */

		if( 0 == (rcc2&SYSCTL_RCC2_BYPASS2) )
		{
			/* With PLL */
			SystemCoreClock = PLL_CLK;
			
			if( 0 == (rcc2&SYSCTL_RCC2_DIV400) )
			{
				/* PLL output is devided by 2. Refer page. 222 of datasheet */
				SystemCoreClock = SystemCoreClock>>1;
				
				/* divisor */
				if( 0 != (rcc&SYSCTL_RCC_USESYSDIV) ) 
				{ 
					SystemCoreClock = SystemCoreClock / (((rcc2>>SYSCTL_RCC2_SYSDIV2_S) & (0x3F)) + 1);
				}
			}
			else
			{
				/* divisor */
				if( 0 != (rcc&SYSCTL_RCC_USESYSDIV) ) 
				{ 
					SystemCoreClock = SystemCoreClock / (((rcc2>>SYSCTL_RCC2_SYSDIV2_DIV400_S) & (0x7F)) + 1);
				}
			}
		}
		else
		{
			/* Without PLL */
			SystemCoreClock = XTAL_NO_PLL[(rcc>>6)&0x1fU];
					/* */
			if( 0 != (rcc&SYSCTL_RCC_USESYSDIV) ) 
			{ 
				SystemCoreClock = SystemCoreClock / (((rcc2>>SYSCTL_RCC2_SYSDIV2_S) & (0x3F)) + 1);
			}
		}
		
	} 
	else 
	{
		if( 0 != (rcc&SYSCTL_RCC_BYPASS) )
		{                            /* check BYPASS */ /* Simulation does not work at this point */
			SystemCoreClock = XTAL_NO_PLL[(rcc>>6)&0x1fU];
		} 
		else
		{
			SystemCoreClock = PLL_CLK;
			SystemCoreClock = SystemCoreClock>>1; /* Devided by 2 */
		}

		if( 0 != (rcc&SYSCTL_RCC_USESYSDIV) ) 
		{
			SystemCoreClock = SystemCoreClock / (((rcc>>SYSCTL_RCC_SYSDIV_S) & (0x0F)) + 1);
		}
	}
}

/**
 * Initialize the system
 *
 * @param  none
 * @return none
 *
 * @brief  Setup the microcontroller system.
 *         Initialize the System.
 */
void SystemInit (void)
{
	__IO uint32_t rcc;
	__IO uint32_t rcc2;
	
	#if(__FPU_USED == 1)
    SCB->CPACR |= ((3UL<<10*2)           /* set CP10 Full Access */
                   | (3UL<<11*2) );      /* set CP11 Full Access */
	#endif
	
	SYSCTL->RCC |= SYSCTL_RCC_BYPASS;   /* 1. bypass the PLL for now        */
	/* 1. enable main osc during PLL setup */
	SYSCTL->RCC &= ~(SYSCTL_RCC_MOSCDIS | SYSCTL_RCC_USESYSDIV); 

 	/* Wait main clock (MOSC) to be ready */
	while( 0 == (SYSCTL->RIS & SYSCTL_RIS_MOSCPUPRIS) ){};	
	SYSCTL->MISC = SYSCTL_RIS_MOSCPUPRIS; /* clear MOSC power-up intr status */
		
	SYSCTL->RCC &= ~(SYSCTL_RCC_XTAL_M | SYSCTL_RCC_SYSDIV_M);
	SYSCTL->RCC |= SYSCTL_RCC_XTAL_16MHZ  /* 2. select 16MHz xtal            */
							| SYSCTL_RCC_USESYSDIV;   /*    & enable system clk divider  */
		
	/*** Enable RCC2   ***/
	SYSCTL->RCC2 |= SYSCTL_RCC2_USERCC2; // this bit must be set to use RCC2	
	SYSCTL->RCC2 |= SYSCTL_RCC2_DIV400; // 3. set DIV400 to 1 (use 400MHz PLL clock)  */
	SYSCTL->RCC2 &= ~(0x7f<<SYSCTL_RCC2_SYSDIV2_DIV400_S);  /* clear divisor bits */
	SYSCTL->RCC2 &= ~SYSCTL_RCC2_OSCSRC2_M;
	SYSCTL->RCC2 |= SYSCTL_RCC2_OSCSRC2_MO // 4. select main oscillator
							 | (4U<<SYSCTL_RCC2_SYSDIV2_DIV400_S); /* 5. set Divisor  */

	
	SYSCTL->RCC2 &= ~SYSCTL_RCC2_PWRDN2; /* 6. activate PLL  */
	while( 0 == (SYSCTL->PLLSTAT & SYSCTL_PLLSTAT_LOCK) ){}; /* 7. wait for PLL to lock  */
					
	/* Enable PLL. PLL is locked correctly */
	SYSCTL->RCC2 &= ~SYSCTL_RCC2_BYPASS2;	/* 8. enable PLL */
}


























