#ifndef __IRQ_DOT_H__
#define __IRQ_DOT_H__

#include <Common.h>

void IRQ_Init (void);


#endif