#include "IRQ.h"

/*initialize NVIC */
void IRQ_Init (void)
{
	NVIC_SetPriority(GPIOF_IRQn, 5);
	NVIC_EnableIRQ(GPIOF_IRQn);
}

