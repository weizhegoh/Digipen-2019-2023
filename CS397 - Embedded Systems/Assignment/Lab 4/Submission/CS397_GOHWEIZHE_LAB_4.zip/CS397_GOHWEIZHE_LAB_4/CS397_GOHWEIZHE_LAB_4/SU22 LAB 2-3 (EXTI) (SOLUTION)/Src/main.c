/*****************************************************************************
 @Project		: 
 @File 			: main.c
 @Details  	:
 @Author		: fongfh
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  Name     16 Jul 18  		Initial Release
   
******************************************************************************/

#include "Common.h"
#include "Hal.h"
#include "BSP.h"
#include "LED.h"
#include "IRQ.h"

/*****************************************************************************
 Define
******************************************************************************/
#define BUZZ_20MS 		20U
#define BUZZ_100MS		100U
#define DEBOUNCE 			10U

// update ADC every 20 ms
#define ADC_UPDATE_MS 20U 													

#define PB6(x) ( *((volatile uint32_t *) (0x40005000UL + 0x44)) = x << 6)
#define PF2_STATUS (~GPIOF->DATA>>2 & 0x0001? 1 : 0 )

#define intensity 2u
#define COUNT 50000

#define LOW 	0
#define HIGH 	1

#define MAX_RANGE 4095.f
#define MAX_INTENSITY 90
#define MIN_INTENSITY  10
/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/
static volatile BOOL			g_bSystemTick = FALSE;

static volatile int 			nRGB = RGB_OFF;
static volatile uint8_t 	nColor = 0U;
static volatile BOOL			g_bSW1 = FALSE;
static volatile BOOL			g_bSW2 = FALSE;
static volatile uint16_t	g_nSW1 = 0U;
static volatile uint16_t	g_nSW2 = 0U;
static volatile uint16_t	g_nBuzzer = 0U;

static volatile int 	 	  g_nAdcUpdate = ADC_UPDATE_MS;
static volatile BOOL		  g_bAdcUpdate = FALSE;
static volatile uint16_t  AIN8_Result;

static volatile BOOL 			PB6_ToggleOn = FALSE;
static volatile BOOL			IntensityOn = FALSE;
static volatile BOOL 			PWN_Intensity = LOW;
static volatile int 			PWN_Curr_Intensity = 10;

static volatile BOOL 			changeIntensity = FALSE;
static volatile int 			counter = 0;

/*****************************************************************************
 Local Functions
******************************************************************************/
void main_AdcInit( void );

extern void TIMER0A_IRQHandler( uint32_t Status );

/*****************************************************************************
 Implementation
******************************************************************************/

int main()
{
	BSPInit(); /* in BSP.c   */
	
	SystemCoreClockUpdate();
	SysTick_Config( SystemCoreClock/1000 );   /* Initialize SysTick Timer to trigger every 1 ms */
	
	const uint8_t aTempToColor[7] = {RGB_BLUE,RGB_MAGENTA,RGB_CYAN,RGB_GREEN,RGB_WHITE,RGB_YELLOW,RGB_RED};
	
	main_AdcInit();
	IRQ_Init();
		
	for(;;)
  {
		if(PF2_STATUS )
		{
			IntensityOn = TRUE;
			LED_RGB_SET(RGB_BLUE);
		}
		else
			LED_RGB_SET(RGB_OFF); 
		
		if(!PF2_STATUS && IntensityOn)
		{
			IntensityOn = FALSE;
			changeIntensity = TRUE;
		}
		
		if (!(PF2_STATUS) && changeIntensity &&(counter > COUNT))
		{
			counter = 0;
			changeIntensity = FALSE;
			
			if((PWN_Curr_Intensity >= MAX_INTENSITY) && (!PWN_Intensity)) 
				PWN_Intensity = HIGH;
			
			if((PWN_Curr_Intensity <= MIN_INTENSITY) &&  (PWN_Intensity)) 
				PWN_Intensity = LOW;
			
			if(PWN_Intensity == HIGH)
				PWN_Curr_Intensity -= intensity;
			else 
				PWN_Curr_Intensity += intensity;
			
			uint32_t value = maxValue;
			value = (maxValue - (value * PWN_Curr_Intensity / 100)) - 1;
			uint8_t pre_scalar = 0x0;
			
			if(value > 0xFFFF)
				pre_scalar = value - 0xFFFF;
			else
				pre_scalar = 0x0;
			
			TIMER1->TAMATCHR = value;
			TIMER1->TAPMR = pre_scalar;
		}
		
		counter++;
		
		if(FALSE != g_bSystemTick)								/* Check if flag is set by the SysTick Handler  */
    {
      g_bSystemTick = FALSE;										/* Clear SysTick flag so we only processes it once */			
		}		
		
		if(g_bAdcUpdate != FALSE && ADC0_BUSY() == 0)
		{
			g_bAdcUpdate = FALSE;
			AIN8_Result = ADC0_GET_FIFO();						/* Read measurements */
			ADC0_SS0_Start(); 												/* Start next measurement */
			
			float minFrequency = 0xC80; 							  
			float maxFrequency = 0x1F4;    						
			
			// AIN8 result from 0 - 4095
			float time = (float)AIN8_Result / MAX_RANGE; 
			
			// ( a + t * (b - a) ) - 1
			TIMER0->TAILR = (int)(minFrequency +  (time * (maxFrequency - minFrequency))) - 1; 
			
		}
		
		if(g_bSW1 == TRUE || g_bSW2 == TRUE)
		{
			if(g_bSW1 == TRUE)
			{
				g_bSW1 = FALSE;
			
				TIMER0->CTL |= TIMER_CTL_TAEN;
				PB6_ON();
			}
			
			if(g_bSW2 == TRUE)
			{
				g_bSW2 = FALSE;
			
				TIMER0->CTL &= ~TIMER_CTL_TAEN;
				PB6_OFF();
			}	
		}						
	}
	
}

/*****************************************************************************
 Callback functions
******************************************************************************/
void SysTick_Handler( void )  
{
	static int nCount = 0;
	
	if( 0 != g_nAdcUpdate )
	{
		g_nAdcUpdate--;
		if( 0 == g_nAdcUpdate )
		{
			g_bAdcUpdate = TRUE;
			g_nAdcUpdate = ADC_UPDATE_MS;
		}
	}
	
	/* Provide system tick */
   if (nCount++ == 1000) 												/* Count too 1000, only then set the flag */
   {
      g_bSystemTick = TRUE;
      nCount=0;
   }
	 
	if(g_nBuzzer != 0)
	{
		g_nBuzzer--;
    if (g_nBuzzer == 0)
    {
			BUZZER_OFF();
    }
	}
	
	if(g_nSW1 != 0)
	{
		g_nSW1--;
    if (g_nSW1 == 0)
    {
			g_bSW1 = SW1();
    }
	}
	
	if(g_nSW2 != 0)
	{
		g_nSW2--;
    if (g_nSW2 == 0)
    {
			g_bSW2 = SW2();
    }
	}
}

/*****************************************************************************
 Local functions
******************************************************************************/
/* Set SS0 for AIN8 */
void main_AdcInit( )
{
	ADC0->ACTSS &= ~ADC_ACTSS_ASEN0; 							/* Disable ADC */
	ADC0->EMUX |= ADC_EMUX_EM0_PROCESSOR; 				/* Set Processer as trigger */
	ADC0->SSMUX0 |= (0x08 << ADC_SSMUX0_MUX0_S); 	/* Connect AIN8 to SS0 */
	ADC0->SSCTL0 |= ADC_SSCTL0_END0; 							/* 1st sample is End of Seq */
	ADC0->SAC |= ADC_SAC_AVG_32X; 								/* Set hardware averaging to 32 times */
	ADC0->ACTSS |= ADC_ACTSS_ASEN0;								/* Enable ADC */
	ADC0_SS0_Start();															/* Start first measurement */
}

/*****************************************************************************
 Interrupt functions
******************************************************************************/
void GPIOF_Button_IRQHandler( uint32_t Status )
{

	if( 0 != (Status&BIT(PF_SW1)) )
	{
		GPIOF->ICR = BIT(PF_SW1);

		if(g_nSW1 == 0)
		{
			g_nSW1 = DEBOUNCE;
		}
	}
	
	if( 0 != (Status&BIT(PF_SW2)) )
	{
		GPIOF->ICR = BIT(PF_SW2);
			
		if(g_nSW2 == 0)
		{
			g_nSW2 = DEBOUNCE;
		}
	}
}

extern void TIMER0A_IRQHandler( uint32_t Status )
{
	/* if TRUE, timeout intr has occurred */
	if( 0 != (Status & TIMER_RIS_TATORIS) )
	{
		TIMER0->ICR |= TIMER_ICR_TATOCINT; 					/* clear intr */
		
		/** interrupt processing codes **/
		PB6_ToggleOn = !PB6_ToggleOn;
		
		if(PB6_ToggleOn)
			PB6_ON();
		else 
			PB6_OFF();
	}
}
