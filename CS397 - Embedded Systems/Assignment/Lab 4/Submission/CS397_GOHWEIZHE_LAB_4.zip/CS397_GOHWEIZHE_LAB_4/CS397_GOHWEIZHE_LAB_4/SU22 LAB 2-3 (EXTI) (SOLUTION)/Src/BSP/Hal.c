/*****************************************************************************
 @Project	: 
 @File 		: Hal.c
 @Details  	: All Ports and peripherals configuration                    
 @Author	: 
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  Name     XXXX-XX-XX  		Initial Release
   
******************************************************************************/
#include <Common.h>
#include "Hal.h"

/*****************************************************************************
 Define
******************************************************************************/


/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/


/*****************************************************************************
 Implementation
******************************************************************************/

void Port_Init( void )
{
	/* enable GPIO port and clock to Port A & F (pg 340)		*/
	SYSCTL->RCGCGPIO |= SYSCTL_RCGCGPIO_R0; 								/* Enable clock to Port A */
	SYSCTL->RCGCGPIO |= SYSCTL_RCGCGPIO_R5; 								/* Enable clock to Port F */
	
	SYSCTL->RCGCGPIO |= SYSCTL_RCGCGPIO_R1; 								// Enable Clock to GPIO B
	SYSCTL->RCGCGPIO |= SYSCTL_RCGCGPIO_R4; 								// Enable Port E clock
	
	SYSCTL->RCGCADC |= SYSCTL_RCGCADC_R0; 									// Enable Clock for ADC0
	
	/* Wait for GPIO ports to be ready */
	while( 0 == (SYSCTL->PRGPIO & SYSCTL_PRGPIO_R0)){};	
	while( 0 == (SYSCTL->PRGPIO & SYSCTL_PRGPIO_R5)){};	
	
	while( 0 == (SYSCTL->PRGPIO & SYSCTL_PRGPIO_R4)){}; 		// Port E 
	while( 0 == (SYSCTL->PRADC & SYSCTL_PRADC_R0) ) {}; 		// Wait for clock to be ready 
	while( 0 == (SYSCTL->PRGPIO & SYSCTL_RCGCGPIO_R1)){};	
		
	/* Enable Buzzer pin as output */
	GPIOA->DIR |= BIT(PA_BUZZER);
	GPIOA->DEN |= BIT(PA_BUZZER);	
		
	/* Unlock GPIO PF[0] */
	GPIOF->LOCK = GPIO_LOCK_KEY;														/* Unlock Port F (pg 684)		*/
	GPIOF->CR |= BIT(PF_SW2) | BIT(PF_SW1) ;								// Set Commit Control register for PF[0] 
			
	/* Initialize button SW1 and SW2 with Interrupts  */
	GPIOF->DIR |= BIT(PF_LED_RED)  | BIT(PF_LED_GREEN); 		
	GPIOF->DIR &= ~( BIT(PF_SW1) | BIT(PF_SW2) );
	
	GPIOF->PUR |= BIT(PF_SW1) | BIT(PF_SW2);
	GPIOF->DEN |= BIT(PF_LED_RED)  | BIT(PF_LED_GREEN) | BIT(PF_SW1) | BIT(PF_SW2); 
	
	GPIOF->IM &= ~( BIT(PF_SW1) | BIT(PF_SW2) ); 						// Masking interrupts
	GPIOF->IBE &= ~( BIT(PF_SW1) | BIT(PF_SW2) ); 					/* Disable both edges */
	GPIOF->IS &= ~( BIT(PF_SW1) | BIT(PF_SW2) );  					/* Edge Detection */
	GPIOF->IEV &= ~( BIT(PF_SW1) | BIT(PF_SW2) ); 					/* Falling edges */
	GPIOF->IM |= BIT(PF_SW1) | BIT(PF_SW2); 								// Enable interrupts in mask */
	
	/* Initialize RGB LED  */
	GPIOF->DIR |= BIT(PF_LED_RED) | BIT(PF_LED_GREEN); 			
	GPIOF->DEN |= BIT(PF_LED_RED)  | BIT(PF_LED_GREEN);		  
	GPIOF->AFSEL &=	~( BIT(PF_LED_RED) | BIT(PF_LED_GREEN) ); 
	
	/* Enable analog function for AIN8 */
	GPIOE->DEN &= ~BIT(PE_ADC_AIN8);
	GPIOE->AMSEL |= BIT(PE_ADC_AIN8);
	SYSCTL->RCGCTIMER |= SYSCTL_RCGCTIMER_R0; 							// Timer 0 

	GPIOB->DIR |= BIT(PB_T0CCP0);
	GPIOB->DEN |= BIT(PB_T0CCP0);
  GPIOB->AFSEL |= ~BIT(PB_T0CCP0); 												// Enable Alternate Function
  GPIOB->PCTL &= ~GPIO_PCTL_PB6_M; 												// Reset PB6 mask
  GPIOB->PCTL |= GPIO_PCTL_PB6_T0CCP0; 										// Enable PB6 Timer 0
	
	/** enable timer clock **/
	SYSCTL->RCGCTIMER |= SYSCTL_RCGCTIMER_R0; 							// Enable timer 0 clock
	while(0 == (SYSCTL->PRTIMER & SYSCTL_PRTIMER_R0)){};	  // Timer 0
		
	/** setup Timer 0A in 16-bits operation **/
	TIMER0->CTL &= ~TIMER_CTL_TAEN; 												/* 1. disable timer 0 during setup */
	TIMER0->CFG |= TIMER_CFG_16_BIT; 												/* 2. set to 16-bit mode */
	TIMER0->TAMR |= TIMER_TAMR_TAMR_PERIOD ;								/* 3. periodic mode */
	TIMER0->TAMR &= ~TIMER_TAMR_TACDIR;											/* 4. count down */
	TIMER0->TAMR |= TIMER_TAMR_TAILD;											  /* new TAILR/pre_scalar values loaded */
	
	/* after time-out */
	TIMER0->TAILR = 0x0C80; 																/* 5. reload value; max = 0xFFFF */ //3200 (C80) - 500 (1F4) 
	TIMER0->TAPR = 0x00; 																		/* 6. prescaler (8 bits) */
	TIMER0->IMR |= TIMER_IMR_TATOIM; 												/* 7. enable timeout intr */
	TIMER0->ICR |= TIMER_ICR_TATOCINT; 											/* 8. clear timeout flag */
	TIMER0->CTL |= TIMER_CTL_TAEN; 													/* 9. enable timer 0 */
		
	SYSCTL->RCGCTIMER |= SYSCTL_RCGCTIMER_R1; 							// Timer 1
	while( 0 == (SYSCTL->PRTIMER & SYSCTL_PRTIMER_R1)){};
	
	/* setup Timer 1 GPIO pin at PF2 */
	GPIOF->AFSEL |= BIT (PF_2); 														// enable alternate function
	GPIOF->PCTL |= GPIO_PCTL_PF2_T1CCP0; 										// enable timer 1 in PF2
	GPIOF->DIR |= BIT (PF_2); 															// set as output
	GPIOF->DEN |= BIT (PF_2); 															// enable PF2
		
	TIMER1->CTL &= ~TIMER_CTL_TAEN; 												// disable timer 0 during setup
	TIMER1->CFG |= TIMER_CFG_16_BIT; 												// set to 16-bit mode
	
	/* TAAMS-enable PWM; TAMR-Periodic mode */
	TIMER1->TAMR |= TIMER_TAMR_TAAMS | TIMER_TAMR_TAMR_PERIOD;
	TIMER1->TAMR &= ~TIMER_TAMR_TACMR; 											// TACMR-Edge-Count mode
		
	TIMER1->TAPR = 0x0; 																		/* prescaler (8 bits) */
	TIMER1->TAILR = maxValue -1; 											// TAILR-pulse period
	TIMER1->TAMATCHR = 0xE665;
	TIMER1->TAPMR = 0x0;
	TIMER1->CTL |= TIMER_CTL_TAEN; 													// enable timer 1
		
}		


















