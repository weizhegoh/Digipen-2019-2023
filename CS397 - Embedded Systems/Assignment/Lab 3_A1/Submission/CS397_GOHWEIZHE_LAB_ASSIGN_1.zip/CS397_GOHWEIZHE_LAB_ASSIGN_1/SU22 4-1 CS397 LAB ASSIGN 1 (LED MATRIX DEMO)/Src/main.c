/*****************************************************************************
 @Project		: ECE300 - Lab 5 - Keypad
 @File 			: main.c
 @Details  	:
 @Author		: ldenissen
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0       			13 Aug 19  		Initial Release
   
******************************************************************************/

#include "Common.h"
#include "Hal.h"
#include "BSP.h"
#include "LED.h"
#include "IRQ.h"
#include "spim.h"
#include "LCD_ST7735R.h"
#include "gui.h"
#include "MATRIX.h"
#include "string.h"

/*****************************************************************************
 Define
******************************************************************************/
#define LCD_BUF_SIZE			4096
#define LCD_UPDATE_MS			10U
#define BUZZER_MS					100U
#define MATRIX_UPDATE_MS	100U
#define MAX7219_CHIPS  2U

#define BOUNCE_PERIOD 15

#define SW1_SWITCH (~GPIOF->DATA>>4 & 0x0001 ? 1 : 0 )
#define SW2_SWITCH (~GPIOF->DATA & 0x0001 ? 1 : 0 )

/*****************************************************************************
 Type definition
******************************************************************************/

/*****************************************************************************
 Global Variables
******************************************************************************/
void GUI_AppDraw( BOOL bFrameStart );

/*****************************************************************************
 Local const Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/
static volatile BOOL	g_bSystemTick = FALSE;
static volatile BOOL	g_bSecTick = FALSE;
static int            g_nCount = 0;
static volatile BOOL	g_bToggle = FALSE;
static unsigned int		g_nTimeSec = 0;

static volatile int 	g_bSpiDone = FALSE;
static SPIM_HANDLE		g_SpimHandle;
static GUI_DATA				g_aBuf[LCD_BUF_SIZE];
static GUI_MEMDEV			g_MemDev;
static volatile BOOL 	g_bLCDUpdate = FALSE;
static volatile int 	g_nLCD = LCD_UPDATE_MS;
static volatile BOOL	g_bBacklightOn = TRUE;

static volatile BOOL 	g_bLcdFree  = TRUE;

static SPIM_HANDLE		g_SpimHandleMatrix;
static volatile BOOL 	g_bMatrixUpdate = FALSE;
static volatile int 	g_nMatrix = MATRIX_UPDATE_MS;


static int g_debounce = 0;
static int current_switch = 0;
static int current_mode = 1;
static char s[255] = "";
static char s1[255] = "";
static volatile int index = 0;
static int string_index = 0;
static volatile char g_UART_CharRx;

/*****************************************************************************
 Local Functions
******************************************************************************/
static void main_LcdInit( void );
static void main_MatrixUpdate(void);
void displayString(char c);
/*****************************************************************************
 Implementation
******************************************************************************/
int main()
{
	Port_Init();
	UART_Init();
	SystemCoreClockUpdate ();
	SysTick_Config( SystemCoreClock/1000 );  
	
	/* SSI initialization */
	NVIC_SetPriority( SSI0_IRQn, 0 );
	
	SpimInit(
		&g_SpimHandle,
		0U,
		25000000U,
		SPI_CLK_INACT_LOW,
		SPI_CLK_RISING_EDGE,
		SPI_DATA_SIZE_8 );
	
	SpimInit(
		&g_SpimHandleMatrix,
		1U,
		10000000U,
		SPI_CLK_INACT_LOW,
		SPI_CLK_RISING_EDGE,
		SPI_DATA_SIZE_8 );

	main_LcdInit();
	
	Matrix_Init(&g_SpimHandleMatrix,MAX7219_CHIPS);
	
	IRQ_Init();
	current_mode = 1;
	
	string_index = 0;
	
  printf ("\nCS397 Lab Assignment 1 \n\r");
	strcpy(s, "CS397 Lab Assignment 1");
	printf ("Current mode: Demo\n\r");

	for(;;)
  {
		if( FALSE != g_bSystemTick)
		{
			g_bSystemTick = FALSE;
			
			if(((UART0->FR & UART_FR_RXFE) == 0))
			{
				g_UART_CharRx = read_ASCII_UART0();
				displayString(g_UART_CharRx);
			}
		}
		/* LCD update */
		if( FALSE != g_bLCDUpdate )
		{
			if( 0 != g_bLcdFree )
			{
				g_bLCDUpdate = FALSE;
				g_bLcdFree = FALSE;
			  
				/* Draw every block. Consumes less time  */
				GUI_Draw_Exe(); 
			}
		}
		
		if(g_bMatrixUpdate == TRUE)
		{
			g_bMatrixUpdate = FALSE;
			main_MatrixUpdate();
		}
	}
}	

/*****************************************************************************
 Callback functions
******************************************************************************/
void displayString(char c)
{
	if(c == '\r')
	{
		s1[string_index] = '\0';
		strcpy(s, s1);
		
		//printf("\nInput New Message: \n\r");
		
		for(int i = 0; i < string_index; i++)
			write_ASCII_UART0(s[i]);
		
		printf("\n\r");
		
		printf("Input New Message : \n\r");
		string_index = 0;
		index = 0;
	}
	else
		s1[string_index++] = c;
}

void SysTick_Handler( void )  
{
	g_bSystemTick = TRUE;
	
	g_debounce ? g_debounce-- : g_debounce;
	
	/* Provide system tick */
  g_nCount++;
  if (g_nCount == 1000)
  {
    g_bSecTick = TRUE;
		g_nCount=0;
		
		/* Keep track of time based on 1 sec interval */ 
		g_nTimeSec++;
		if(g_nTimeSec > 24*60*60)
		{
			g_nTimeSec = 0;
		}
		LED_RGB_SET( RGB_BLUE*(g_nTimeSec & 1U) );		/* Toggle LED every 1 sec based on time LSB */
  }

	if( 0 != g_nMatrix )
	{
		g_nMatrix--;
		if( 0 == g_nMatrix )
		{
			g_nMatrix = MATRIX_UPDATE_MS;
			(current_mode == 1) ? g_nMatrix *= 10 : g_nMatrix;
			g_bMatrixUpdate = TRUE;
		}
	}
	
	if( 0 != g_nLCD )
	{
		g_nLCD--;
		if( 0 == g_nLCD )
		{
			g_nLCD = LCD_UPDATE_MS;
			g_bLCDUpdate = TRUE;
		}
	}
	
	//If debounce timer = 0 and Switch is pressed 
	if((current_switch != 0) && (g_debounce == 0))
	{	
		if(SW1_SWITCH)
		{
			if(current_mode == 2)
				current_mode = 1;
			else 
				current_mode = 2;
			
			printf("Current mode: ");
			
			if(current_mode == 1)
			{
				printf("Demo mode\n\r");
			}
			else if(current_mode == 2)
			{
				printf("Display Mode\n\r");
				printf("Input Message : \n\r");
			}
			
			current_switch = 0;
		}
		
		current_switch = 0;
		
		if(SW2_SWITCH)
		{
			current_switch = 0;
		}
	}
}

void GUI_AppDraw( BOOL bFrameStart )
{
	/* This function invokes from GUI library */
	char buf[128];
		
	GUI_Clear( ClrBlue ); /* Set background to blue.Refer to gui.h */
	GUI_SetFont( &FONT_Arialbold16 );
	GUI_SetFontBackColor( ClrBlue );
	GUI_PrintString( "CS397 SU22", ClrYellow , 14, 8 );
	GUI_SetFont( &FONT_Arialbold12 );
	GUI_PrintString( "Assign #1", ClrWhite , 14, 28 );

	GUI_SetColor(ClrYellow);
	GUI_DrawFilledRect(0,55,127,115);
	GUI_SetFont( &FONT_Arialbold16 );	
	GUI_PrintString( "31 May 22", ClrBlack, 16, 62 );
	GUI_SetFont( &FONT_Arialbold24 );
	//sprintf( buf, "%c", g_cKey);
	//GUI_PrintString( buf, ClrBlack, 55, 88 );
	
	GUI_SetColor( ClrLightCyan );
	GUI_DrawFilledRect( 0, 140, 127, 159);
	GUI_SetFont( &FONT_Arialbold16 );
	GUI_SetFontBackColor( ClrLightCyan );
	sprintf( buf, "Time: %02u:%02u:%02u", (g_nTimeSec/3600)%24, (g_nTimeSec/60)%60, g_nTimeSec%60 );
	
	GUI_PrintString( buf, ClrBlack, 12, 142 );
}

static void main_cbLcdTransferDone( void )
{
	g_bLcdFree = TRUE;
}

static void main_cbGuiFrameEnd( void )
{
	g_bLcdFree = TRUE;
}

/*****************************************************************************
 Local functions
******************************************************************************/

static void main_MatrixUpdate( void )
{
	if(current_mode == 1)
	{
		static char c = 0x00; // char E
		
		Matrix_SendChar (c+1, 0);
		Matrix_SendChar (c,1);

		if(c == 0xff)
			c = 0x00;
		else 
			c++;
	}
	
	if(current_mode == 2)
	{
		size_t length = strlen(s);
		Matrix_SendString((uint8_t*)s, length, 0, index);
		
		if(index < length * 8 - 1 + 15)
			index++;
		else
			index = 0;
	}
}

static void main_LcdInit( void )
{
	int screenx;
	int screeny;
	
	/* g_SpimHandle shall be itializaed before use */
	
	/* Choosing a landscape orientation */
	LcdInit( &g_SpimHandle, LCD_POTRAIT_180 );
	
	/* Get physical LCD size in pixels */
	LCD_GetSize( &screenx, &screeny );
	
	/* Initialize GUI */
	GUI_Init(
		&g_MemDev,
		screenx,
		screeny,
		g_aBuf,
		sizeof(g_aBuf) );
	
	/* Switch to transfer word for faster performance */
	SpimSetDataSize( &g_SpimHandle, SPI_DATA_SIZE_16 );
	GUI_16BitPerPixel( TRUE );
	
	/* Clear LCD screen to Blue */
	GUI_Clear( ClrBlue );

  /* set font color background */
  GUI_SetFontBackColor( ClrBlue );
    
  /* Set font */
	GUI_SetFont( &g_sFontCalibri10 );
	
	LCD_AddCallback( main_cbLcdTransferDone );
	
	GUI_AddCbFrameEnd( main_cbGuiFrameEnd );
	
	/* Backlight ON */
	LCD_BL_ON();
}

/*****************************************************************************
 Interrupt functions
******************************************************************************/
void GPIOF_Button_IRQHandler( uint32_t Status )
{

	if( 0 != (Status&BIT(PF_SW1)) )
	{
		GPIOF->ICR = BIT(PF_SW1);
		g_debounce = BOUNCE_PERIOD;
		current_switch = 1;
	}
	
	if( 0 != (Status&BIT(PF_SW2)) )
	{
		GPIOF->ICR = BIT(PF_SW2);
		
	}
}
