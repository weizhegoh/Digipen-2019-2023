/*****************************************************************************
 @Project		: 
 @File 			: matrix.c
 @Details  	:                  
 @Author		: FongFH
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  FongFH    3 May 22 		Initial Release
   
******************************************************************************/
#include <Common.h>
#include "Hal.h"
#include "spim.h"
#include "MATRIX.h"
#include "MATRIX_FONT.h"


/*****************************************************************************
 Define
******************************************************************************/


/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/

/*****************************************************************************
 Local Variables
******************************************************************************/
static PSPIM_HANDLE	g_pSpimHandle;
static int g_nChipCount;
static volatile BOOL g_bSPIMatrixDone = FALSE;

/*****************************************************************************
 Local Helpers
******************************************************************************/
 void cbMatrixSpiDone( void )
{
	g_bSPIMatrixDone = TRUE;
}

 void Matrix_SendToAll(uint8_t address, uint8_t value) {  
	
	uint8_t i, data[2];
	data[0] = address;
	data[1] = value;

	MATRIX_CS_LOW();
	
	for(i=0; i < g_nChipCount; i++)
	{
		SpimTransfer(g_pSpimHandle, data, 0, 2U); 
		while( 0 == g_bSPIMatrixDone );
		g_bSPIMatrixDone = 0;
	}
	
  MATRIX_CS_HIGH(); // Finish transfer.
}

static void Matrix_SendByte(uint8_t address, uint8_t value) {  
	
	uint8_t data[2];
	data[0] = address;
	data[1] = value;

	SpimTransfer(g_pSpimHandle, data, 0, 2U); 
	while( 0 == g_bSPIMatrixDone );
	g_bSPIMatrixDone = 0;
}

void Matrix_Send_No_Op() 
{  
	uint8_t data[2];
	data[0] = 0x00;
	data[1] = 0x00;

	SpimTransfer(g_pSpimHandle, data, 0, 2U); 
	while( 0 == g_bSPIMatrixDone );
	g_bSPIMatrixDone = 0;
}

/*****************************************************************************
 Export functions
******************************************************************************/;


/*****************************************************************************
 Implementation
******************************************************************************/
void Matrix_Init(	PSPIM_HANDLE pSpimHAndle, uint8_t nChipCount )
{
	uint8_t chip;

	ASSERT( 0 != pSpimHAndle );

	/* Keep SPI handle for later use */
	g_pSpimHandle = pSpimHAndle;
	
	g_nChipCount = nChipCount;
	
	/* Add a callback from SPI to notify SPI done */
	SpimAddCallbackTransferDone( g_pSpimHandle, cbMatrixSpiDone );
	
	MATRIX_CS_HIGH();

  // repeatedly configure the chips in case they start up in a mode which
  // draws a lot of current
  for (chip = 0; chip < g_nChipCount; chip++)
    {
    Matrix_SendToAll(MAX7219_REG_SCANLIMIT, 7);     // show 8 digits
    Matrix_SendToAll(MAX7219_REG_DECODEMODE, 0);    // use bit patterns
    Matrix_SendToAll(MAX7219_REG_DISPLAYTEST, 0);   // no display test
    Matrix_SendToAll(MAX7219_REG_INTENSITY, 0x3);    // character intensity: range: 0 to 15
    Matrix_Clear();                          				// clear display
    Matrix_SendToAll (MAX7219_REG_SHUTDOWN, 1);     // not in shutdown mode (ie. start it up)
    }
}

void Matrix_Clear()
{
	int i;
	
	for(i=1; i<9; i++)
	{
		Matrix_SendToAll(i,0);
	}
}

uint8_t Reverse(uint8_t b)
{
	 b = (b & 0xF0) >> 4 | (b & 0x0F) << 4;
   b = (b & 0xCC) >> 2 | (b & 0x33) << 2;
   b = (b & 0xAA) >> 1 | (b & 0x55) << 1;
   return b;
}

void Transpose(uint8_t* pixels)
{
	int m = 1; int n = 1;
	unsigned x, y, t; 
	
	uint8_t B[8];
   // Load the array and pack it into x and y. 

   x = (pixels[0]<<24)   | (pixels[m]<<16)   | (pixels[2*m]<<8) | pixels[3*m]; 
   y = (pixels[4*m]<<24) | (pixels[5*m]<<16) | (pixels[6*m]<<8) | pixels[7*m]; 

   t = (x ^ (x >> 7)) & 0x00AA00AA;  x = x ^ t ^ (t << 7); 
   t = (y ^ (y >> 7)) & 0x00AA00AA;  y = y ^ t ^ (t << 7); 

   t = (x ^ (x >>14)) & 0x0000CCCC;  x = x ^ t ^ (t <<14); 
   t = (y ^ (y >>14)) & 0x0000CCCC;  y = y ^ t ^ (t <<14); 

   t = (x & 0xF0F0F0F0) | ((y >> 4) & 0x0F0F0F0F); 
   y = ((x << 4) & 0xF0F0F0F0) | (y & 0x0F0F0F0F); 
   x = t; 

   B[0]=x>>24;    B[n]=x>>16;    B[2*n]=x>>8;  B[3*n]=x; 
   B[4*n]=y>>24;  B[5*n]=y>>16;  B[6*n]=y>>8;  B[7*n]=y; 
	
	
	for (uint8_t i = 0; i < 8; i++)
	{
		pixels [i] = B[i];
	}
}

void Matrix_SendChar (uint8_t data, int no_op)
{
  // get this character from PROGMEM
  uint8_t pixels [8];
	uint8_t column;
	
  for (uint8_t i = 0; i < 8; i++)
	{
		pixels [i] = Reverse(MAX7219_font[data][i]);
	}
	
	Transpose(pixels);
	
	for (column = 0; column < 8; column++)
  {
    // start sending
    MATRIX_CS_LOW();
		
		Matrix_SendByte (column + 1, pixels[column]);
		
		for(int i = 0; i < no_op; i++)
			Matrix_Send_No_Op();
		
		MATRIX_CS_HIGH();
	}
}  // end of sendChar

void Matrix_SendString (uint8_t* data,const size_t length, int no_op,int index)
{
	uint8_t s[length][8];
	
	uint8_t pixels[8];
	uint8_t column;
	
	for(size_t j = 0; j < length; j++)
	{
		for(uint8_t i = 0; i < 8; i++)
		{
			pixels[i] = MAX7219_font[data[j]][i];
		}
		
		for(uint8_t i = 0; i < 8; i++)
		{
			s[j][i] = pixels[i];
		}
	}
	
	size_t x = (index - 15) % 8;
	size_t y = (index - 15) / 8;
	
	(index < 16 ) ? x = 0, y =0 : y ;  
		
	uint8_t print_string[16];
	memset(&print_string,0, 16);
	
	int copy_size = 0x0;
	int copy_offset = 0x0;
	
	if(index < 16)
	{
		copy_offset = index;
		copy_size = index + 1;
	}
	else
	{
		copy_offset = 15;
		copy_size = 16;
	}
	
	if(index > length* 8)
		copy_size = 16 - (index + 1 - length * 8);
	
	for(int k = 0; k < copy_size; k++)
		print_string[15 - copy_offset + k] = s[y][x+k];

	for(size_t j = 0; j < 2; j++)
	{
		for(uint8_t i = 0; i < 8; i++)
		{
			pixels[i] = Reverse(print_string[i+j * 8]);
		}
		Transpose(pixels);
		
		for(uint8_t i = 0; i < 8; i++)
		{
			print_string[i + j * 8] = pixels[i];
		}
	}
		
	for(column = 0; column < 8; column++)
	{
		MATRIX_CS_LOW();
		Matrix_SendByte(column + 1, print_string[8 + column]);
		MATRIX_CS_HIGH();
	}
	
	for(column = 0; column < 8; column++)
	{
		MATRIX_CS_LOW();
		Matrix_SendByte(column + 1, print_string[column]);
		Matrix_Send_No_Op();
		MATRIX_CS_HIGH();
	}
}

/*****************************************************************************
 Callback functions
******************************************************************************/


/*****************************************************************************
 Local functions
******************************************************************************/





















