/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dac.h"
#include "dma.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#define DAC2_START_VALUE 2048
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
static float count = 0.0f;
static int 	 DAC1_Value = 0;
static int 	 DAC2_Value = 0;

static float temperature = 0.0f;
static uint32_t adc1[1], arr1[1];
static uint32_t adc2[3], arr2[3];

static float vsense = 3.3 /4096.0;

static float adc1_value, adc2_value, adc3_value, adc4_value;
static float dac1, dac2;
static int b1_pressed = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART3_UART_Init();
  MX_DAC_Init();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_ADC3_Init();
  /* USER CODE BEGIN 2 */
  DAC1_Value = 0;
  DAC2_Value = DAC2_START_VALUE;

   HAL_DAC_Start(&hdac, DAC_CHANNEL_1);
   HAL_DAC_Start(&hdac, DAC_CHANNEL_2);
   HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1, DAC_ALIGN_12B_R, DAC1_Value);
   HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R, DAC2_Value);

   HAL_ADC_Start_DMA(&hadc1, arr1, 1);
   HAL_ADC_Start_IT(&hadc1);
   HAL_ADC_Start_DMA(&hadc3, arr2, 3);
   HAL_ADC_Start_IT(&hadc3);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if(b1_pressed)
	  {
		b1_pressed = 0;
		count = 0.0f;
		DAC1_Value = 0;
		DAC2_Value = DAC2_START_VALUE;
	  }

	  adc1_value = (adc2[0] * 3.3f) / 4095.f; // A3 (PF3)
	  adc2_value = (adc2[1] * 3.3f) / 4095.f; // A4 (PF5)
	  adc3_value = (adc2[2] * 3.3f) / 4095.f; // A5 (PF10)
	  adc4_value = (adc1[0] * 3.3f) / 4095.f;  // Temp V

	  dac1 = (DAC1_Value * 3.3f) / 4095.f;
	  dac2 = (DAC2_Value * 3.3f) / 4095.f;

	  printf("CS397 %.1f DAC(V): %.2f %.2f ADC(V): %.2f %.2f %.2f %.2f Temp(degC): %.2f\r\n",
			  count, dac1, dac2, adc2_value, adc3_value, adc1_value, adc4_value, temperature);

	  if( (int)(count * 10) == 0 || (int)(count * 10) == 100 || (int)(count * 10) == 200)
		  HAL_GPIO_WritePin(GPIOB, LD2_Pin, GPIO_PIN_SET);
	 else
		  HAL_GPIO_WritePin(GPIOB, LD2_Pin, GPIO_PIN_RESET);

	  if(dac1 >= 3.0f || dac2 >= 3.0f )
		  HAL_GPIO_WritePin(GPIOB, LD3_Pin, GPIO_PIN_SET);
	  else
		  HAL_GPIO_WritePin(GPIOB, LD3_Pin, GPIO_PIN_RESET);

	  HAL_GPIO_TogglePin(GPIOB, LD1_Pin);

	  count += 0.1f;

	  if(count > 20.9)
		  count = 0.0f;

	  DAC1_Value += 100;
	  DAC2_Value += 100;

	  if(DAC1_Value > 4095)
		  DAC1_Value = 0;

	  if(DAC2_Value > 4095)
		  DAC2_Value = 0;

	  HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1, DAC_ALIGN_12B_R, DAC1_Value);
	  HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R, DAC2_Value);

	  HAL_Delay(500);
	  HAL_ADC_Start_IT(&hadc1);
	  HAL_ADC_Start_IT(&hadc3);
	  HAL_Delay(500);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 128;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
    if( hadc->Instance == ADC1 )
    {
    adc1[0] = arr1[0];

    temperature = (((adc1[1] * vsense ) - 0.76 ) / 0.0025) + 25.0;
    }

    if( hadc->Instance == ADC3 )
   {
    	for(int i = 0; i < 3; i++)
    	{
    		adc2[i] = arr2[i];
    	}
   }
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_Pin == GPIO_PIN_13)
	{
		b1_pressed = 1;
		count = 0.0f;
		DAC1_Value = 0;
		DAC2_Value = DAC2_START_VALUE;
	}
}

int __io_putchar(int ch)
{
	uint8_t c[1];
	c[0] = ch & 0x00FF;
	HAL_UART_Transmit(&huart3, &*c, 1, 10);
	return ch;
}

int _write(int file, char *ptr, int len)
{
	int DataIdx;
	for(DataIdx= 0; DataIdx< len; DataIdx++)
	{
		__io_putchar(*ptr++);
	}
	return len;
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
