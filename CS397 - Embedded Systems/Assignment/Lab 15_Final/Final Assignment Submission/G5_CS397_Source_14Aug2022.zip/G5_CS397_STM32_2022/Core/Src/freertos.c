/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "httpserver-netconn.h"
#include "adc.h"
#include "dac.h"
#include "can.h"
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
osThreadId mainLoopHandle;
/* USER CODE END Variables */
osThreadId defaultTaskHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
void StartMainLoop(void const * argument);
/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void const * argument);

extern void MX_LWIP_Init(void);
void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* GetIdleTaskMemory prototype (linked to static allocation support) */
void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;
  /* place for user code */
}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 1024);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  osThreadDef(mainLoop, StartMainLoop, osPriorityNormal, 0, 1024);
  mainLoopHandle = osThreadCreate(osThread(mainLoop), NULL);
  /* USER CODE END RTOS_THREADS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* init code for LWIP */
  MX_LWIP_Init();
  /* USER CODE BEGIN StartDefaultTask */
  http_server_netconn_init();
  /* Infinite loop */
  for(;;)
  {
    osDelay(500);
    //HAL_GPIO_TogglePin(GPIOB, LD2_Pin);
  }
  /* USER CODE END StartDefaultTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
void StartMainLoop(void const * argument)
{
  for(;;)
  {
	/* Reset */
	if (b1)
	{
	  b1 = 0;
	  dac1 = 0.0;
	  dac2 = 2050.0;
	}
	/* Converting values to V */
	float dac1v = dac1 * vsense;
	float dac2v = dac2 * vsense;
	float adc1v = adc[0] * vsense;
	float adc2v = adc[1] * vsense;
	float adc3v = adc[2] * vsense;
	float adc4v = adc[3] * vsense;
	float temperature = ((adc4v - 0.76 ) / 0.0025) + 25.0;
	printf("DAC = %.2f %.2f ADC = %.2f %.2f %.2f %.2f Temp = %4.2f deg.C \r\n", dac1v, dac2v, adc1v, adc2v, adc3v, adc4v, temperature);
	if (!man_led)
	{
	  /* green LED */
	  HAL_GPIO_TogglePin(GPIOB, LD1_Pin);
	  /* red LED */
      if (dac1v >= 3.0 || dac2v >= 3.0)
	    HAL_GPIO_WritePin(GPIOB, LD3_Pin, GPIO_PIN_SET);
	  else
	    HAL_GPIO_WritePin(GPIOB, LD3_Pin, GPIO_PIN_RESET);
      if (F0Update == 0)
    	HAL_GPIO_WritePin(GPIOB, LD2_Pin, GPIO_PIN_RESET);
      else
    	F0Update--;
	}
	dac1 += 100;
	dac2 += 100;
	if ( dac1 > 4095 )
	  dac1 = 0;
	if ( dac2 > 4095 )
	  dac2 = 0;

	HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1, DAC_ALIGN_12B_R, dac1);
	HAL_DAC_SetValue(&hdac, DAC_CHANNEL_2, DAC_ALIGN_12B_R, dac2);
	HAL_Delay(500);
	HAL_ADC_Start_IT(&hadc1);
	HAL_ADC_Start_IT(&hadc3);
	HAL_Delay(500);
  }
}
/* USER CODE END Application */

