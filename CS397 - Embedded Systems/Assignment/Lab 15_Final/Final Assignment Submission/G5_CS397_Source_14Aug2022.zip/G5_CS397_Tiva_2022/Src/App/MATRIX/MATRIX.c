/*****************************************************************************
 @Project		: 
 @File 			: matrix.c
 @Details  	:                  
 @Author		: FongFH
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  FongFH    3 May 22 		Initial Release
   
******************************************************************************/
#include <Common.h>
#include "Hal.h"
#include "spim.h"
#include "MATRIX.h"
#include "MATRIX_FONT.h"


/*****************************************************************************
 Define
******************************************************************************/


/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/

/*****************************************************************************
 Local Variables
******************************************************************************/
static PSPIM_HANDLE	g_pSpimHandle;
static int g_nChipCount;
static volatile BOOL g_bSPIMatrixDone = FALSE;

/*****************************************************************************
 Local Helpers
******************************************************************************/
static void cbMatrixSpiDone( void )
{
	g_bSPIMatrixDone = TRUE;
}

void Matrix_SendToAll(uint8_t address, uint8_t value) {  
	
	uint8_t i, data[2];
	data[0] = address;
	data[1] = value;

	MATRIX_CS_LOW();
	
	for(i=0; i < g_nChipCount; i++)
	{
		SpimTransfer(g_pSpimHandle, data, 0, 2U); 
		while( 0 == g_bSPIMatrixDone );
		g_bSPIMatrixDone = 0;
	}
	
  MATRIX_CS_HIGH(); // Finish transfer.
}

void Matrix_SendByte(uint8_t address, uint8_t value) {  
	
	uint8_t data[2];
	data[0] = address;
	data[1] = value;
	
	SpimTransfer(g_pSpimHandle, data, 0, 2U); 
	while( 0 == g_bSPIMatrixDone );
	g_bSPIMatrixDone = 0;
	
}


/*****************************************************************************
 Export functions
******************************************************************************/;


/*****************************************************************************
 Implementation
******************************************************************************/
void Matrix_Init(	PSPIM_HANDLE pSpimHAndle, uint8_t nChipCount )
{
	uint8_t chip;

	ASSERT( 0 != pSpimHAndle );

	/* Keep SPI handle for later use */
	g_pSpimHandle = pSpimHAndle;
	
	g_nChipCount = nChipCount;
	
	/* Add a callback from SPI to notify SPI done */
	SpimAddCallbackTransferDone( g_pSpimHandle, cbMatrixSpiDone );
	
	MATRIX_CS_HIGH();

  // repeatedly configure the chips in case they start up in a mode which
  // draws a lot of current
  for (chip = 0; chip < g_nChipCount; chip++)
    {
    Matrix_SendToAll(MAX7219_REG_SCANLIMIT, 7);     // show 8 digits
    Matrix_SendToAll(MAX7219_REG_DECODEMODE, 0);    // use bit patterns
    Matrix_SendToAll(MAX7219_REG_DISPLAYTEST, 0);   // no display test
    Matrix_SendToAll(MAX7219_REG_INTENSITY, 0x3);    // character intensity: range: 0 to 15
    Matrix_Clear();                          				// clear display
    Matrix_SendToAll (MAX7219_REG_SHUTDOWN, 1);     // not in shutdown mode (ie. start it up)
    }
}

void Matrix_Clear()
{
	int i;
	
	for(i=1; i<9; i++)
	{
		Matrix_SendToAll(i,0);
	}
}

void Matrix_SendChar (uint8_t data, int count)
{
  // get this character from PROGMEM
  uint8_t pixels [8];
	uint8_t temp [8];	
	uint8_t col;
	
  for (uint8_t i = 0; i < 8; i++)
	{
		pixels [i] = MAX7219_font[data][i];
	}
	for(int i = 0; i < 8; i++) {
		pixels[i] = (pixels[i] & 0xF0) >> 4 | (pixels[i] & 0x0F) << 4;
   pixels[i] = (pixels[i] & 0xCC) >> 2 | (pixels[i] & 0x33) << 2;
   pixels[i] = (pixels[i] & 0xAA) >> 1 | (pixels[i] & 0x55) << 1;
	}
	
	for(int i = 0; i < 8; i++) {
			for(int j = 0; j < 8; j++) {
					temp[i] = (temp[i] << 1) | ((pixels[j] >> (7 - i)) & 0x01);
			}
	}
	
	for (col = 0; col < 8; col++)
  {
    // start sending
    MATRIX_CS_LOW();
		
		if(count)
			Matrix_SendByte(MAX7219_REG_NOOP, 0);
		Matrix_SendByte (col + 1, temp[col]);		
		if(!count)
			Matrix_SendByte(MAX7219_REG_NOOP, 0);
		
		MATRIX_CS_HIGH();
	}
}  // end of sendChar

uint8_t* Matrix_Out (char* data, int offset, int size)
{
  // get this character from PROGMEM
  uint8_t pixels [8*size];
	uint8_t temp [8*size];	
	uint8_t temp2 [8];	
	uint8_t temp3 [8];
	static uint8_t ret[16];
	uint8_t col;
	
	for (int j = 0; j < size; j++)
	{	
		char tempc = data[j];
		for (int i = 0; i < 8; i++)
		{
			pixels[j*8+i] = MAX7219_font[tempc][i];
			temp[j*8+i] = pixels[j*8+i];
		}
	}
	for (int i = 0; i < 8; i++)
	{
		if (offset < 8)
		{
			if ((i+offset-8)>=0)
				pixels[i] = temp[i+offset-8];
			else
				pixels[i] = 0;
			
			temp2[i] = 0;			
		}
		else if (offset < 16)
		{
			if ((i+offset-8)<(size*8))
				pixels[i] = temp[i+offset-8];
			else
				pixels[i] = 0;
			if ((i+offset-16)>=0)
				temp2[i] = temp[i+offset-16];
			else
				temp2[i] = 0;
		}
		else 
		{
			if ((i+offset-16)<(size*8))
				temp2[i] = temp[i+offset-16];
			else
				temp2[i] = 0;
			if ((i+offset-8)<(size*8))
				pixels[i] = temp[i+offset-8];
			else
				pixels[i] = 0;
		}
	}
	for(int i = 0; i < 8; i++) {
		pixels[i] = (pixels[i] & 0xF0) >> 4 | (pixels[i] & 0x0F) << 4;
		pixels[i] = (pixels[i] & 0xCC) >> 2 | (pixels[i] & 0x33) << 2;
		pixels[i] = (pixels[i] & 0xAA) >> 1 | (pixels[i] & 0x55) << 1;
		
		temp2[i] = (temp2[i] & 0xF0) >> 4 | (temp2[i] & 0x0F) << 4;
		temp2[i] = (temp2[i] & 0xCC) >> 2 | (temp2[i] & 0x33) << 2;
		temp2[i] = (temp2[i] & 0xAA) >> 1 | (temp2[i] & 0x55) << 1;
	}
	
	for(int i = 0; i < 8; i++) {
			for(int j = 0; j < 8; j++) {
					temp[i] = (temp[i] << 1) | ((pixels[j] >> (7 - i)) & 0x01);
					temp3[i] = (temp3[i] << 1) | ((temp2[j] >> (7 - i)) & 0x01);
			}
	}
	for(int i = 0; i < 8; i++) {
		ret[i] = temp[i];
		ret[i+8] = temp3[i];
	}
	return ret;
//	for (col = 0; col < 8; col++)
//  {
//    // start sending
//    MATRIX_CS_LOW();
//			
//		Matrix_SendByte(MAX7219_REG_NOOP, 0);
//		Matrix_SendByte (col + 1, temp[col]);	
//		
//		MATRIX_CS_HIGH();
//	}
//	for (col = 0; col < 8; col++)
//  {
//    // start sending
//    MATRIX_CS_LOW();
//			
//		Matrix_SendByte (col + 1, temp3[col]);
//		Matrix_SendByte(MAX7219_REG_NOOP, 0);
//		
//		MATRIX_CS_HIGH();
//	}
}  // end of sendChar
void Matrix_Print(uint8_t* data)
{
	for (int col = 0; col < 8; col++)
	{
	  // start sending
	  MATRIX_CS_LOW();
			
		Matrix_SendByte(MAX7219_REG_NOOP, 0);
		Matrix_SendByte (col + 1, data[col]);	
		
		MATRIX_CS_HIGH();
	}
	for (int col = 0; col < 8; col++)
	{
	  // start sending
	  MATRIX_CS_LOW();
			
		Matrix_SendByte (col + 1, data[col + 8]);
		Matrix_SendByte(MAX7219_REG_NOOP, 0);
		
		MATRIX_CS_HIGH();
	} 
}
/*****************************************************************************
 Callback functions
******************************************************************************/


/*****************************************************************************
 Local functions
******************************************************************************/





















