/*****************************************************************************
 @Project		: 
 @File 			: MATRIX.h
 @Details  	: Functions for Matrix display                    
 @Author		: 
 @Hardware	: MAX7219
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  FongFH     	3 May 22  	Initial Release
   
******************************************************************************/

#include "stdint.h"
#include "spim.h"

/*****************************************************************************
 Define
******************************************************************************/
#define MAX7219_REG_NOOP         0x00
#define MAX7219_REG_DECODEMODE   0x09
#define MAX7219_REG_INTENSITY    0x0A
#define MAX7219_REG_SCANLIMIT    0x0B
#define MAX7219_REG_SHUTDOWN     0x0C
#define MAX7219_REG_DISPLAYTEST  0x0F

/*****************************************************************************
 Type definition
******************************************************************************/


/******************************************************************************
 Global functions
******************************************************************************/

static void Matrix_SendByte (uint8_t reg, uint8_t data);
static void Matrix_SendToAll (uint8_t reg, uint8_t data);

void Matrix_Init(	PSPIM_HANDLE pSpimHAndle, uint8_t nChipCount );
void Matrix_Clear( void );
void Matrix_WriteReg (uint8_t reg, uint8_t data);
void Matrix_SendChar (uint8_t data, int count);
uint8_t* Matrix_Out(char* data, int offset, int size);
void Matrix_Print(uint8_t* data);