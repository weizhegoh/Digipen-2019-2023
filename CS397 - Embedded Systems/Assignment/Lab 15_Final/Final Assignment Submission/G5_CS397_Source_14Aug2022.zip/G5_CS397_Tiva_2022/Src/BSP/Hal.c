/*****************************************************************************
 @Project	: 
 @File 		: Hal.c
 @Details  	: All Ports and peripherals configuration                    
 @Author	: 
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  Name     XXXX-XX-XX  		Initial Release
   
******************************************************************************/
#include <Common.h>
#include "Hal.h"


/*****************************************************************************
 Define
******************************************************************************/


/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/


/*****************************************************************************
 Implementation
******************************************************************************/

void Port_Init( void )
{
	/* enable GPIO port and clock to Port F (pg 340)		*/
	SYSCTL->RCGCGPIO |= SYSCTL_RCGCGPIO_R0
					 | SYSCTL_RCGCGPIO_R1
					 | SYSCTL_RCGCGPIO_R2
					 | SYSCTL_RCGCGPIO_R3
					 | SYSCTL_RCGCGPIO_R4
					 | SYSCTL_RCGCGPIO_R5;
	
	/* enable clock to UART0   */
	SYSCTL->RCGCUART |= SYSCTL_RCGCUART_R0;
	
	/* Enable Clock for SSI0 module */
	SYSCTL->RCGCSSI |= SYSCTL_RCGCSSI_R0
					| SYSCTL_RCGCSSI_R1;
	
	/* Wait for GPIO port to be ready */
	while( 0 == (SYSCTL->PRGPIO & SYSCTL_PRGPIO_R0) );
	while( 0 == (SYSCTL->PRGPIO & SYSCTL_PRGPIO_R1) );
	while( 0 == (SYSCTL->PRGPIO & SYSCTL_PRGPIO_R2) );
	while( 0 == (SYSCTL->PRGPIO & SYSCTL_PRGPIO_R3) );
	while( 0 == (SYSCTL->PRGPIO & SYSCTL_PRGPIO_R4) );
	while( 0 == (SYSCTL->PRGPIO & SYSCTL_PRGPIO_R5) );
	
	/* Wait for UART to be ready */
	while( 0 == (SYSCTL->PRUART & SYSCTL_PRUART_R0) ); 
	
	/* Waiting clock ready */
	while( 0 == (SYSCTL->PRSSI & SYSCTL_PRSSI_R0) );
	while( 0 == (SYSCTL->PRSSI & SYSCTL_PRSSI_R1) );
	
	/*Enable Clocks Gate for Timers */
	SYSCTL->RCGCTIMER	|= SYSCTL_RCGCTIMER_R0  
					| SYSCTL_RCGCTIMER_R1 
					| SYSCTL_RCGCTIMER_R2 
					| SYSCTL_RCGCTIMER_R3 
					| SYSCTL_RCGCTIMER_R4 
					| SYSCTL_RCGCTIMER_R5; 
					
	/* Unlock GPIO PF[0] */
	GPIOF->LOCK = GPIO_LOCK_KEY;	/* Unlock Port F (pg 684)		*/
	GPIOF->CR |= BIT(PF_SW2);			/* Set Commit Control register for PF[0] */
		
	/* Initialize RGB LED  */
	GPIOF->DIR |= BIT(PF_LED_RED) | BIT(PF_LED_BLUE) | BIT(PF_LED_GREEN);
	GPIOF->DEN |= BIT(PF_LED_RED) | BIT(PF_LED_BLUE) | BIT(PF_LED_GREEN);
	GPIOF->AFSEL &=	~( BIT(PF_LED_RED) | BIT(PF_LED_BLUE) | BIT(PF_LED_GREEN) );
	
	/* User button SW1 & SW2 */
	GPIOF->LOCK = GPIO_LOCK_KEY;
	
	GPIOF->CR |= (BIT(PF_SW1) | BIT(PF_SW2));
	GPIOF->DIR &= ~(BIT(PF_SW1) | BIT(PF_SW2));
	GPIOF->DEN |= (BIT(PF_SW1) | BIT(PF_SW2));
	GPIOF->AFSEL &= ~(BIT(PF_SW1) | BIT(PF_SW2));
	GPIOF->PCTL &= ~(BIT(PF_SW1) | BIT(PF_SW2));
	GPIOF->PUR |= (BIT(PF_SW1) | BIT(PF_SW2));
	
	GPIOF->IM &= ~(BIT(PF_SW1) | BIT(PF_SW2));
	GPIOF->IBE &= ~(BIT(PF_SW1) | BIT(PF_SW2)); /* Disable both edge */
	GPIOF->IS &= ~(BIT(PF_SW1) | BIT(PF_SW2)); /* edge detection */
	GPIOF->IEV = ~(BIT(PF_SW1) | BIT(PF_SW2)); /* Falling edge */
	GPIOF->IM |= (BIT(PF_SW1) | BIT(PF_SW2));

	/* Buzzer */
	GPIOA->DIR |= BIT( PA_BUZZER);
	GPIOA->DEN |= BIT (PA_BUZZER);
	
	/* initialize GPIO PA0 (UART0_RX) & PA1 (UART0_TX)   */
	// GPIOA->LOCK = GPIO_LOCK_KEY; 
	// GPIOA->CR |= BIT(PA_UART0_RX) | BIT(PA_UART0_TX); 
	
	GPIOA->AFSEL |= BIT(PA_UART0_RX) | BIT(PA_UART0_TX);
	GPIOA->DEN |= BIT(PA_UART0_RX) | BIT(PA_UART0_TX);
	GPIOA->AMSEL &= ~( BIT(PA_UART0_RX) | BIT(PA_UART0_TX) );
	GPIOA->PCTL &= ~( GPIO_PCTL_PA0_M | GPIO_PCTL_PA1_M ); /* clear Port C config bits  */
	GPIOA->PCTL |= GPIO_PCTL_PA0_U0RX | GPIO_PCTL_PA1_U0TX;
	
	/* LED MATRIX */
	GPIOD->DIR |= BIT(PD_SSI1_CS);
	GPIOD->DEN |= BIT(PD_SSI1_CS);
	GPIOD->AFSEL &= ~BIT(PD_SSI1_CS);
	GPIOD->PCTL &= ~( GPIO_PCTL_PD1_M );
	GPIOD->DATA |= BIT(PD_SSI1_CS);

	GPIOD->DEN |= BIT(PD_SSI1_SCK) | BIT(PD_SSI1_MOSI);
	GPIOD->AFSEL |= (BIT(PD_SSI1_SCK) | BIT(PD_SSI1_MOSI) );
	GPIOD->PCTL &= ~(GPIO_PCTL_PD0_M | GPIO_PCTL_PD3_M);
	GPIOD->PCTL |= (GPIO_PCTL_PD0_SSI1CLK | GPIO_PCTL_PD3_SSI1TX);
	
	/** initialize UART0   **/	
	UART0->CTL &= ~UART_CTL_UARTEN; 					/* disable UART during initialization  	*/
	UART0->CC &= ~UART_CC_CS_M; 							//  clock source mask
	UART0->CC |= UART_CC_CS_SYSCLK; 					// set to system clock
	
	UART0->CTL &= ~UART_CTL_HSE;											/* use 16X CLKDIV  							*/
	UART0->IBRD = 5;	 					/* int (80,000,000 / (16 * 921,600)) = 5.425347    */
	UART0->FBRD = 27;  					/* int (5.425347 * 64 + 0.5 = int (27.72) = 27   */
	
	UART0->LCRH &= ~UART_LCRH_WLEN_M; 	
	UART0->LCRH |= UART_LCRH_WLEN_7 | UART_LCRH_PEN; 	/* 7 data bits, parity enable  	*/
	UART0->LCRH |= UART_LCRH_EPS ;   									/* even parity  								*/ 	
	UART0->LCRH &= ~UART_LCRH_STP2;  									/* 1 stop bit 									*/ 
	
	UART0->LCRH |= UART_LCRH_FEN; 										/* enable FIFO*/
	
	UART0->CTL |= UART_CTL_TXE; 											/* transmit enable 							*/
	UART0->CTL |= UART_CTL_UARTEN; 										/* enable UART0   		*/
	
	
	/************************
	 CAN0
	*************************/	
	SYSCTL->RCGCCAN |= SYSCTL_RCGCCAN_R0;
	while( 0 == (SYSCTL->PRCAN & SYSCTL_PRCAN_R0) ){}
	
/*
	GPIOB->LOCK = GPIO_LOCK_KEY;
	GPIOB->CR |=  BIT(PB_CAN0_RX) | BIT(PB_CAN0_TX);
	GPIOB->DEN |= BIT(PB_CAN0_RX) | BIT(PB_CAN0_TX);
	GPIOB->AFSEL |= BIT(PB_CAN0_RX) | BIT(PB_CAN0_TX);
	GPIOB->PCTL |= GPIO_PCTL_PB4_CAN0RX | GPIO_PCTL_PB5_CAN0TX;
*/

	GPIOE->CR    |= BIT(PE_CAN0_RX) | BIT(PE_CAN0_TX);
	GPIOE->DEN   |= BIT(PE_CAN0_RX) | BIT(PE_CAN0_TX);
	GPIOE->AFSEL |= BIT(PE_CAN0_RX) | BIT(PE_CAN0_TX);
	GPIOE->PCTL  |= GPIO_PCTL_PE4_CAN0RX | GPIO_PCTL_PE5_CAN0TX;	
	
}		


/** Write an ASCII character to UART0				**/
/** character = ASCII to write 							**/
void write_ASCII_UART0 (char character )
{
	while( 0 != (UART0->FR & UART_FR_TXFF) ){}; 	/* wait if TX FIFO full					*/
	UART0->DR = character; 												/* write character to UART data reg */
}

char read_ASCII_UART0 (void)
{
	//while(0 != (UART0->FR & UART_FR_RXFE)){};
	return (UART0->DR);
}














