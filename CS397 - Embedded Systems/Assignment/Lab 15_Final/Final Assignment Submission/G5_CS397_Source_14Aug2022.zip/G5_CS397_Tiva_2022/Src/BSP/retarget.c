#include <Common.h>
#include "Hal.h"

/*****************************************************************************
 Define
******************************************************************************/
#if defined(__CC_ARM)
struct __FILE
{
  int handle; 
};
#endif

FILE __stdout; //STDOUT


int fputc(int ch, FILE * stream)
{
	write_ASCII_UART0(ch); //Transmit Character
	return ch; //return the character written to denote a successful write
}
