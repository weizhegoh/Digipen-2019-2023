/*****************************************************************************
 @Project		: 
 @File 			: main.c
 @Details  	:
 @Author		: fongfh
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  fongfh     16 Jul 18  		Initial Release
	 1.1	fongfh			9 Sep 20			Add buzzer (HAL.c)
   
******************************************************************************/

#include "Common.h"
#include "Hal.h"
#include "BSP.h"
#include "LED.h"
#include "NVIC.h"

#include "CAN.h"
#include "IRQ.h"
#include "spim.h"
#include "LCD_ST7735R.h"
#include "gui.h"
#include "MATRIX.h"
#include "string.h"

/*****************************************************************************
 Define
******************************************************************************/
#define BUZZER_LONG				100U
#define BUZZER_SHORT			15U
#define MATRIX_UPDATE_MS	200U
#define MAX7219_CHIPS  		2U

/*****************************************************************************
 Type definition
******************************************************************************/


/*****************************************************************************
 Global Variables
******************************************************************************/


/*****************************************************************************
 Local Variables
******************************************************************************/
static volatile BOOL	g_bSystemTick = FALSE;
static volatile BOOL	g_bLED = FALSE, g_bCAN = TRUE;
static int            g_count = 0, g_buzzCount = 0;
static unsigned int		g_nTimeSec = 0;

static CAN_HANDLE			g_CAN0Handle;
static tCANMsgObject 	g_CAN0RxMsg;
static uint8_t 				g_aCAN0RxMsgData[8];
static volatile BOOL 	g_bOnCAN0Rx = FALSE;

static tCANMsgObject 	g_CAN0TxMsg;
static uint8_t 				g_aCAN0TxMsgData[8];

static volatile int 	g_bSpiDone = FALSE;
static SPIM_HANDLE		g_SpimHandle;
static SPIM_HANDLE		g_SpimHandleMatrix;

static volatile BOOL 	g_bMatrixUpdate = FALSE;
static volatile int 	g_nMatrix = MATRIX_UPDATE_MS;
static int						g_offset = 0;
static char						g_UART_CharRx;
static char						g_string[255] = "sample/0";
static int						g_string_size = 7;
static char						g_buffer[255] = "";
static int						g_buffer_size = 0;
/*****************************************************************************
 Local Functions
******************************************************************************/
static void main_CAN0Init( void );
static void main_MatrixUpdate(void);
static void main_StringUpdate(char);

/*****************************************************************************
 Callback Functions
******************************************************************************/
static void main_cbOnCAN0Rx( int nObj );

/*****************************************************************************
 Implementation
******************************************************************************/
 
int main()
{
	BSPInit(); /* in BSP.c   */
	
	BOOL bToggle = TRUE;
	
	SystemCoreClockUpdate();
	
	/** NOTE for Lab 1:                                                             **/
	/** This program currently uses the CMSIS function to configure                 **/ 
	/**   It is for testing your setup.                                             **/
  /** For LAB1, COMMENT OUT THIS LINE OF CODE &                                   **/
  /**   replace it with your own function: Configure_SysTick(ticks)               **/
	/**   to provide system ticks for every 10 ms.                                  **/
  /**   Use the lecture example as a guide.                                       **/	
	SysTick_Config( SystemCoreClock/1000 );   /* Initialize SysTick ticks every 1 ms */
	
	/* print to Virtual COM port temrinal */
	printf ("\nG5 CS397 Project\n\r"); // display to virtual COM port
	printf ("Input new message (max size 16):\n\r");
	/* SSI initialization */
	NVIC_SetPriority( SSI0_IRQn, 0 );
	
	SpimInit(
		&g_SpimHandle,
		0U,
		25000000U,
		SPI_CLK_INACT_LOW,
		SPI_CLK_RISING_EDGE,
		SPI_DATA_SIZE_8 );
	
	SpimInit(
		&g_SpimHandleMatrix,
		1U,
		10000000U,
		SPI_CLK_INACT_LOW,
		SPI_CLK_RISING_EDGE,
		SPI_DATA_SIZE_8 );

	Matrix_Init(&g_SpimHandleMatrix,MAX7219_CHIPS);
	
	IRQ_Init();
	
	main_CAN0Init();
	
	for(;;)
  { 
    if (FALSE != g_bSystemTick) /* check every system tick */
		{
			g_bSystemTick = FALSE;
			if((UART0->FR & UART_FR_RXFE) == 0)
			{
				g_UART_CharRx = read_ASCII_UART0();
				write_ASCII_UART0 (g_UART_CharRx);
				main_StringUpdate(g_UART_CharRx);
			}
		}
		
		if( FALSE != g_bLED )	/* Check if LED flag is set   */
		{
			/* Clear SysTick flag so we only processes it once       */
			g_bLED = FALSE;	
			/* Set LED to BLUE if toggle is TRUE(=1),                 */
			/* otherwise if toggle is FALSE(=0), the LED will be off */
			//LED_BLUE_SET (bToggle);
			LED_RGB_SET( RGB_BLUE * bToggle ); 
			bToggle = !bToggle;	/* Inverse toggle, so if 0 it becomes 1, 1 becomes 0 */
		}
		
		if(g_bMatrixUpdate == TRUE)
		{
			g_bMatrixUpdate = FALSE;
			main_MatrixUpdate();
		}
		
		
		if( FALSE != g_bOnCAN0Rx )
	  {
      g_bOnCAN0Rx = FALSE;

			// Read data 
			CANMessageGet(&g_CAN0Handle, 1, &g_CAN0RxMsg, 0);
		  
			if ( g_CAN0RxMsg.ui32MsgLen > 0)
			{
				if ( g_CAN0RxMsg.ui32MsgID == 848)
				{
					BUZZER_ON();
					g_buzzCount = 0;
				}
				else if ( g_CAN0RxMsg.ui32MsgID == 849)
				{
					BUZZER_OFF();
					g_buzzCount = 0;
				}
				else if ( g_CAN0RxMsg.ui32MsgID == 850)
				{
					BUZZER_ON();
					g_buzzCount = BUZZER_SHORT;
				}
				else if ( g_CAN0RxMsg.ui32MsgID == 851)
				{
					BUZZER_ON();
					g_buzzCount = BUZZER_LONG;
				}
				else
				{
					for (int i = 0; i < g_CAN0RxMsg.ui32MsgLen; ++i)
					{
						g_string[i] = g_aCAN0RxMsgData[i];
					}
					g_string[g_CAN0RxMsg.ui32MsgLen] = '\0';
					g_string_size = g_CAN0RxMsg.ui32MsgLen + 1;
					g_buffer_size = 0;
					g_offset = 0;
					printf ("Message changed to: %s\n\r", g_string);
					printf ("Input new message (max size 16):\n\r");
					g_bCAN = TRUE;
				}
				g_CAN0RxMsg.ui32MsgLen = 0;
			}			
		}
	
		if( FALSE != g_bCAN )
		{
			g_bCAN = FALSE;				
			g_aCAN0TxMsgData[0] = g_string[0];
			g_aCAN0TxMsgData[1] = g_string[1];
			g_aCAN0TxMsgData[2] = g_string[2];
			g_aCAN0TxMsgData[3] = g_string[3];
			g_aCAN0TxMsgData[4] = g_string[4];
			g_aCAN0TxMsgData[5] = g_string[5];
			g_aCAN0TxMsgData[6] = g_string[6];
			g_aCAN0TxMsgData[7] = g_string[7];
			
		  g_CAN0TxMsg.ui32MsgID = 0x389;
			g_CAN0TxMsg.ui32Flags   = MSG_OBJ_TX_INT_ENABLE;
			g_CAN0TxMsg.ui32MsgLen = 8;
			g_CAN0TxMsg.pui8MsgData = g_aCAN0TxMsgData;
			
			// CAN0 Tx Msg 1
			CANMessageSet(&g_CAN0Handle, 2, &g_CAN0TxMsg, MSG_OBJ_TYPE_TX);
			
			g_aCAN0TxMsgData[0] = g_string[8];
			g_aCAN0TxMsgData[1] = g_string[9];
			g_aCAN0TxMsgData[2] = g_string[10];
			g_aCAN0TxMsgData[3] = g_string[11];
			g_aCAN0TxMsgData[4] = g_string[12];
			g_aCAN0TxMsgData[5] = g_string[13];
			g_aCAN0TxMsgData[6] = g_string[14];
			g_aCAN0TxMsgData[7] = g_string[15];
			
			g_CAN0TxMsg.ui32MsgID = 0x390;
			g_CAN0TxMsg.ui32Flags   = MSG_OBJ_TX_INT_ENABLE;
			g_CAN0TxMsg.ui32MsgLen = 8;
			g_CAN0TxMsg.pui8MsgData = g_aCAN0TxMsgData;
			
			// CAN0 Tx Msg 2
			CANMessageSet(&g_CAN0Handle, 3, &g_CAN0TxMsg, MSG_OBJ_TYPE_TX);				
		}		
	}	
}

/*****************************************************************************
 Callback functions
******************************************************************************/
void SysTick_Handler( void )  
{
	g_bSystemTick = TRUE;
	
	g_count++;
	
	if (g_count%1000 == 0) /* set flag every 1000ms */
  {
		g_bLED = TRUE;
  }
	
	if( 0 != g_nMatrix )
	{
		g_nMatrix--;
		if( 0 == g_nMatrix )
		{
			g_nMatrix = MATRIX_UPDATE_MS;
			
			g_bMatrixUpdate = TRUE;
		}
	}
	
	if (g_buzzCount > 0)
	{
		if (--g_buzzCount == 0)
			BUZZER_OFF();
	}
}

static void main_cbOnCAN0Rx( int nObj )
{
	g_bOnCAN0Rx = TRUE;
}
/*****************************************************************************
 Local functions
******************************************************************************/
static void main_CAN0Init( void )
{
	CANInit( &g_CAN0Handle, 0 ); /* Initializes CAN0 */

	CANBitRateSet( &g_CAN0Handle, SystemCoreClock, 125000 ); /* Set CAN0 to 1Mbps */

	CANIntEnable( &g_CAN0Handle, CAN_INT_MASTER | CAN_INT_ERROR | CAN_INT_STATUS ); /* Enable CAN0 Interrupts */

	CANEnable( &g_CAN0Handle ); /* Enable CAN0 */

	CANIntRegister( &g_CAN0Handle, main_cbOnCAN0Rx ); /* Add callback to get data received notification */
	
	g_CAN0RxMsg.ui32MsgID = 0;
	g_CAN0RxMsg.ui32MsgIDMask = 0;
	g_CAN0RxMsg.ui32Flags = MSG_OBJ_RX_INT_ENABLE | MSG_OBJ_USE_ID_FILTER;
	g_CAN0RxMsg.ui32MsgLen = 8;
	g_CAN0RxMsg.pui8MsgData = g_aCAN0RxMsgData;
	
	/* Now load the message object into the CAN peripheral.  Once loaded the
	 CAN will receive any message on the bus, and an interrupt will occur.
	 Use message object 1 for receiving messages (this is not the same as
	 the CAN ID which can be any value in this example). */
	 CANMessageSet(&g_CAN0Handle, 1, &g_CAN0RxMsg, MSG_OBJ_TYPE_RX);
}

static void main_MatrixUpdate( void )
{
	//static char c = 0xF9; // char E
	int test_size = g_string_size - 1;
	uint8_t* display = Matrix_Out (g_string, g_offset++, test_size);
	Matrix_Print(display);
	//Matrix_Out (g_string, g_offset++, test_size);
	if (g_offset > (test_size+2)*8)
		g_offset = 0;	
}

void main_StringUpdate(char c)
{
	if (c == '\r')
	{
		if (g_buffer_size > 0)
		{
			memset(g_string, '\0', 255);
			//Matrix_Out (g_string, 0, 0);
			for(int i = 0; i < g_buffer_size; i++)
				g_string[i] = g_buffer[i];
			g_string[g_buffer_size++] = '\0';
			g_string_size = g_buffer_size;
			//memset(g_buffer, '\0', 255);
			g_buffer_size = 0;
			g_offset = 0;
			printf ("Message changed to: %s\n\r", g_string);
			printf ("Input new message (max size 16):\n\r");
			g_bCAN = TRUE;
		}
	}
	else
		if (g_buffer_size < 16)
			g_buffer[g_buffer_size++] = c;
}

/*****************************************************************************
 Interrupt functions
******************************************************************************/
void GPIOF_Button_IRQHandler( uint32_t Status )
{

	if( 0 != (Status&BIT(PF_SW1)) )
	{
		GPIOF->ICR = BIT(PF_SW1);
	}
	
	if( 0 != (Status&BIT(PF_SW2)) )
	{
		GPIOF->ICR = BIT(PF_SW2);
	}
}
