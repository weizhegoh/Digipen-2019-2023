// ---------------------------------------------------------------------------
// includes

#include "AEEngine.h"
#include "BasicEngine/BasicEngine.h"
#include "Random.h"
#include "MyGame.h"


// ---------------------------------------------------------------------------
void CreateLevel1()
{
	new Player();
	new Enemy();
}

// ---------------------------------------------------------------------------
void CreateLevel2()
{
	new Player();
	new Enemy();
	new Enemy();
	new Enemy();
	new Enemy();
}

// ---------------------------------------------------------------------------
void ReadKeyAndChangeLevel(int& _level)
{
	if (AEInputCheckCurr(AEVK_0))
	{
		BasicEngine::Core::DeleteAll();
		_level = 0;
	}
	else if (AEInputCheckCurr(AEVK_1) && _level!=1)
	{
		BasicEngine::Core::DeleteAll();
		CreateLevel1();
		_level = 1;
	}
	else if (AEInputCheckCurr(AEVK_2) && _level!=2)
	{
		BasicEngine::Core::DeleteAll();
		CreateLevel2();
		_level = 2;
	}
	else if (AEInputCheckCurr(AEVK_NUM_PLUS))
	{
		new Enemy();
	}

}

// ---------------------------------------------------------------------------
int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPWSTR    lpCmdLine,
	_In_ int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	// AE Init
	AESysInit(hInstance, nCmdShow, SCREEN_W, SCREEN_H, 1, 60, true, NULL);
	AESysSetWindowTitle("GAM150su20 SimpleEngine Demo");
	AESysReset();
	AEGfxSetBackgroundColor(0.f, 0.f, 0.f);

	Random::InitSeed();	
	unsigned int loopCounter = 0;

	int currentLevel = 0;

	BasicEngine::Core core;

	// Precache Textures
	BasicEngine::AssetManager::GetTexture("playerShip1_blue.png");
	
	// Game Loop
	while (core.IsRunning())
	{
		LOG("----- Loop %d ----- \n", loopCounter);
		AESysFrameStart();	// could move it into core

		// Input
		core.Input();
		
		// Update
		core.Update();

		// Render
		core.Render();

		// Debug Display
#if defined(_DEBUG)
		core.DebugDisplay();
#endif

		ReadKeyAndChangeLevel(currentLevel);
		
		AESysFrameEnd();
		++loopCounter;
	}

	BasicEngine::AssetManager::DeleteAll();
	
	// free the system
	AESysExit();
}