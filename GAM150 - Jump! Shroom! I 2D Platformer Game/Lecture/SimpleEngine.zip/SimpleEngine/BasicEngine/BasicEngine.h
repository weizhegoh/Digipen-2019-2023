#pragma once

#include "AEEngine.h"
#include "Types.h"

namespace BasicEngine
{
	// ---------------------------------------------------------------------------
	struct IGameObject
	{
		virtual void Update() = 0;
		virtual void Render() = 0;

		virtual UInt32 GetID() const = 0;
		virtual void DebugDisplay(char _fontID, float& _nextX, float& _nextY, float _glyphHeight) = 0;
		
		virtual ~IGameObject() = default;
	};

	// ---------------------------------------------------------------------------
	class Core
	{
	public:
		Core()
		{
			// Grow Array to 5000
			m_pGameObjects.reserve(m_Capacity);
			
			m_DebugfontID = AEGfxCreateFont("Roboto-Regular.ttf", 12);
			ASSERT(m_DebugfontID >= 0, "Failed to create mesh font !!");
		}

		virtual ~Core()
		{
			DeleteAll();
			AEGfxDestroyFont(m_DebugfontID);
		}

		void Input()
		{
			// Handling Input
			AEInputUpdate();

			// check if forcing the application to quit
			if (AEInputCheckTriggered(AEVK_ESCAPE) || 0 == AESysDoesWindowExist())
				m_Running = false;
		}

		void Update()
		{
			for (IGameObject* go : m_pGameObjects)
				go->Update();
		}

		void Render()
		{
			for (IGameObject* go : m_pGameObjects)
				go->Render();
		}

		void DebugDisplay()
		{
			const UInt32 strBufferSize = 256;
			char strBuffer[strBufferSize];
			float x = -0.95f;
			float y = 0.95f;
			float glyphWidth, glyphHeight = 0;

			sprintf_s(strBuffer, "Basic Engine Info [Objects: %d] [fps: %.2f] [debugcount: %d]",
				static_cast<UInt32>(m_pGameObjects.size()),
				1.f / AEFrameRateControllerGetFrameTime(),
				m_DebugCount);

			AEGfxSetBlendMode(AE_GFX_BM_BLEND);
			AEGfxGetPrintSize(m_DebugfontID, strBuffer, 1.0f, glyphWidth, glyphHeight);
			AEGfxPrint(m_DebugfontID, strBuffer, x, y, 1.0f, 1.f, 1.f, 1.f);

			glyphHeight *= 1.05f;

			if (m_pGameObjects.empty())
			{
				y -= glyphHeight * 2;
				sprintf_s(strBuffer, strBufferSize, "No Objects");
				AEGfxPrint(m_DebugfontID, strBuffer, x, y, 0.8f, 0.6f, 0.f, 0.f);

				return;
			}

			// Display the IDs of the objects
			y -= glyphHeight * 2;
			UInt32 n = 0;
			n += sprintf_s(strBuffer + n, strBufferSize - n, "ID: ");

			for (IGameObject* go : m_pGameObjects)
			{
				if ((strBufferSize - n) > 15)
					n += sprintf_s(strBuffer + n, strBufferSize - n, "[%d] ", go->GetID());
				else
				{
					sprintf_s(strBuffer + n, strBufferSize - n, "...");
					break;
				}
			}

			AEGfxPrint(m_DebugfontID, strBuffer, x, y, 0.8f, 0.6f, 0.6f, 0.6f);

			// Go through all the Objects
			y -= glyphHeight * 2;
			UInt32 i = 0;
			sprintf_s(strBuffer, strBufferSize, "GameObjects Infos:");
			AEGfxPrint(m_DebugfontID, strBuffer, x, y, 1.0f, 1.f, 1.f, 1.f);
			for (IGameObject* go : m_pGameObjects)
			{
				go->DebugDisplay(m_DebugfontID, x, y, glyphHeight);
				++i;
				if (i > 50)
					break;
			}

			++m_DebugCount;
		}

		static void DeleteAll()
		{
			while(!m_pGameObjects.empty())
			{
				IGameObject* go = m_pGameObjects.back();
				m_pGameObjects.pop_back();
				
				delete go;
			}
		}

		static void RegisterObject(IGameObject* _obj)
		{
			m_pGameObjects.push_back(_obj);
		}

		static void UnregisterObject(IGameObject* _obj)
		{
			for(auto it = m_pGameObjects.begin(); it != m_pGameObjects.end();++it )
			{
				if( (*it) ==_obj)
				{
					m_pGameObjects.erase(it);
					return;
				}
			}
		}

		bool IsRunning() const { return m_Running; }
		
	protected:
		const UInt32 m_Capacity = 5000;
		static std::vector<IGameObject*> m_pGameObjects;
		char m_DebugfontID = -1;
		UInt32 m_DebugCount = 0;

		bool m_Running = true;
	};

	std::vector<IGameObject*> Core::m_pGameObjects {};

	// ---------------------------------------------------------------------------
	class GameObject : public IGameObject
	{
	public:

		virtual const char* GetTypeName() { return "GameObject"; };
		
		GameObject()
		:m_UniqueID(++m_UniqueIDCounter)
		{
			Core::RegisterObject(this);
		}

		virtual ~GameObject()
		{
			Core::UnregisterObject(this);
		}

		void Update() override {};
		void Render() override {};

		UInt32 GetID() const override { return m_UniqueID; }
		void	DebugDisplay(char _fontID, float& _nextX, float& _nextY, float _glyphHeight) override {};
		
	protected:
		UInt32 m_UniqueID;

		static UInt32 m_UniqueIDCounter;
	};

	UInt32 GameObject::m_UniqueIDCounter = 0;

	// ---------------------------------------------------------------------------
	class AssetManager
	{
	public:

		static void DeleteAll()
		{
			for (auto it = m_pTextures.begin(); it != m_pTextures.end(); ++it)
				AEGfxTextureUnload(it->second);

			m_pTextures.clear();
		}

		static void UnloadTexture(const char* _filename)
		{
			if (m_pTextures.find(_filename) == m_pTextures.end())
				return;
			
			AEGfxTextureUnload(m_pTextures[_filename]);
			m_pTextures.erase(_filename);
		}

		static AEGfxTexture* GetTexture(const char* _filename)
		{
			if(m_pTextures.find(_filename) == m_pTextures.end())
			{
				AEGfxTexture* pTexture = AEGfxTextureLoad(_filename);
				ASSERT(pTexture, "Failed to load %s", _filename);

				m_pTextures[_filename] = pTexture;
			}

			return m_pTextures[_filename];
		}

	protected:
		static std::unordered_map<const char*, AEGfxTexture*> m_pTextures;
	};

	std::unordered_map<const char*, AEGfxTexture*>	AssetManager::m_pTextures{};
}