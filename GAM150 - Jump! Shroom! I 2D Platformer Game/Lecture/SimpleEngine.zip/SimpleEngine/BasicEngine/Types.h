#pragma once

#define LOG_ENABLED

#if defined(_DEBUG)
#if defined(LOG_ENABLED)
#define LOG(msg, ...) printf(msg, __VA_ARGS__)
#else
#define LOG(msg, ...) 
#endif

#define DEBUGBREAK() __debugbreak()

#define ASSERT(expression, msg, ...)	\
		{									\
			if (!(expression))				\
			{								\
				LOG(msg, __VA_ARGS__);		\
				DEBUGBREAK();				\
			}								\
		}									\

#define BREAK(msg, ...)					\
		{									\
			LOG(msg, __VA_ARGS__);			\
			DEBUGBREAK();					\
		}									\

#else
#define LOG(msg, ...)
#define ASSERT()
#define BREAK(msg, ...)
#endif


#include <vector>
#include <algorithm>
#include <unordered_map>

namespace BasicEngine
{
	using UInt32 = unsigned int;
	using UInt64 = unsigned long long;
}