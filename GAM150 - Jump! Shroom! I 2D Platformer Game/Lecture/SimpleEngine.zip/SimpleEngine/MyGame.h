#pragma once

#include "BasicEngine/BasicEngine.h"
#include "Random.h"


#define SCREEN_W (1280)
#define SCREEN_H (720)

#define SCREEN_W_HALF (SCREEN_W/2)
#define SCREEN_H_HALF (SCREEN_H/2)


// ---------------------------------------------------------------------------
struct TransformComponent
{
	float m_X = 0;
	float m_Y = 0;
};

// ---------------------------------------------------------------------------
struct VisualComponent
{
	AEGfxVertexList*	m_pMesh = nullptr;
	AEGfxTexture*		m_pTexture = nullptr;
};

// ---------------------------------------------------------------------------
class DynamicObject : public BasicEngine::GameObject
{
public:
	const char* GetTypeName() override { return "DynamicObject"; };

	void Update() override
	{
		LOG("[Object %d] %s Is ticking\n", GetID(), GetTypeName());
	}

	void Render() override
	{
		LOG("[Object %d] %s Is Rendering\n", GetID(), GetTypeName());
	}
};

// ---------------------------------------------------------------------------
class Player : public DynamicObject
{
public:
	const char* GetTypeName() override { return "Player"; };

	Player()
	{
		AEGfxMeshStart();
		AEGfxTriAdd(
			-30.0f, -30.0f, 0x00FF00FF, 0.0f, 1.0f,
			30.0f, -30.0f, 0x00FFFF00, 1.0f, 1.0f,
			-30.0f, 30.0f, 0x0000FFFF, 0.0f, 0.0f);
		AEGfxTriAdd(
			30.0f, -30.0f, 0x00FFFFFF, 1.0f, 1.0f,
			30.0f, 30.0f, 0x00FFFFFF, 1.0f, 0.0f,
			-30.0f, 30.0f, 0x00FFFFFF, 0.0f, 0.0f);

		m_Visual.m_pMesh = AEGfxMeshEnd();
		m_Visual.m_pTexture = BasicEngine::AssetManager::GetTexture("playerShip1_blue.png");
	}

	virtual ~Player()
	{
		AEGfxMeshFree(m_Visual.m_pMesh);
	}

	void DebugDisplay(char _fontID, float& _nextX, float& _nextY, float _glyphHeight) override
	{
		const BasicEngine::UInt32 strBufferSize = 256;
		char strBuffer[strBufferSize];

		_nextY -= _glyphHeight;
		sprintf_s(strBuffer, strBufferSize, " - Player: X=%.0f, Y=%.0f", m_Transform.m_X, m_Transform.m_Y);
		AEGfxPrint(_fontID, strBuffer, _nextX, _nextY, 1.0f, 1.f, 0.f, 1.f);
	};

	void Update() override
	{
		// Object 1 Control
		if (AEInputCheckCurr(AEVK_UP))			m_Transform.m_Y += 3.0f;
		else if (AEInputCheckCurr(AEVK_DOWN))	m_Transform.m_Y -= 3.0f;

		if (AEInputCheckCurr(AEVK_LEFT))			m_Transform.m_X -= 3.0f;
		else if (AEInputCheckCurr(AEVK_RIGHT))	m_Transform.m_X += 3.0f;
	}

	void Render() override
	{
		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(m_Transform.m_X, m_Transform.m_Y);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
		AEGfxTextureSet(m_Visual.m_pTexture, 0.0f, 0.0f);
		AEGfxSetTransparency(1.0);
		AEGfxMeshDraw(m_Visual.m_pMesh, AE_GFX_MDM_TRIANGLES);
	}


protected:
	TransformComponent m_Transform;
	VisualComponent		m_Visual;
};

// ---------------------------------------------------------------------------
class Enemy : public DynamicObject
{
public:
	const char* GetTypeName() override { return "Enemy"; };

	Enemy()
	{
		AEGfxMeshStart();
		AEGfxTriAdd(
			-10.0f, -10.0f, 0x00FFFFFF, 0.0f, 1.0f,
			10.0f, -10.0f, 0x00FFFFFF, 1.0f, 1.0f,
			-10.0f, 10.0f, 0x00FFFFFF, 0.0f, 0.0f);
		AEGfxTriAdd(
			10.0f, -10.0f, 0x00FFFFFF, 1.0f, 1.0f,
			10.0f, 10.0f, 0x00FFFFFF, 1.0f, 0.0f,
			-10.0f, 10.0f, 0x00FFFFFF, 0.0f, 0.0f);
		
		m_Visual.m_pMesh = AEGfxMeshEnd();


		const char* textureNames[] = { "meteorBrown_med1.png", "meteorBrown_med2.png", "meteorGrey_med1.png", "meteorGrey_med2.png" };
		const char index = Random::GetRange(0, 3);
		
		m_Visual.m_pTexture = BasicEngine::AssetManager::GetTexture(textureNames[index]);
		
		m_Transform.m_X = static_cast<float>(Random::GetRange(-SCREEN_W_HALF, SCREEN_W_HALF));
		m_Transform.m_Y = static_cast<float>(Random::GetRange(-SCREEN_H_HALF, SCREEN_H_HALF));

		m_SlopeX = Random::GetRange(-4, 4);
		m_SlopeY = Random::GetRange(-4, 4);
	}

	virtual ~Enemy()
	{
		AEGfxMeshFree(m_Visual.m_pMesh);
	}

	void DebugDisplay(char _fontID, float& _nextX, float& _nextY, float _glyphHeight) override
	{
		const BasicEngine::UInt32 strBufferSize = 256;
		char strBuffer[strBufferSize];

		_nextY -= _glyphHeight;
		sprintf_s(strBuffer, strBufferSize, " - Enemy ID=%d, (X=%.0f, Y=%.0f)", GetID(), m_Transform.m_X, m_Transform.m_Y);
		AEGfxPrint(_fontID, strBuffer, _nextX, _nextY, 1.0f, 0.f, 0.6f, 0.8f);
	};

	void Update() override
	{
		m_Transform.m_X += m_SlopeX;
		m_Transform.m_Y += m_SlopeY;

		if (m_Transform.m_X > SCREEN_W_HALF)		// Leave screen on the right
			m_Transform.m_X = -SCREEN_W_HALF;
		else if (m_Transform.m_X < -SCREEN_W_HALF) // Leave screen on the left
			m_Transform.m_X = SCREEN_W_HALF;

		if (m_Transform.m_Y > SCREEN_H_HALF)		// Leave screen on the right
			m_Transform.m_Y = -SCREEN_H_HALF;
		else if (m_Transform.m_Y < -SCREEN_H_HALF) // Leave screen on the left
			m_Transform.m_Y = SCREEN_H_HALF;
	}

	void Render() override
	{
		AEGfxSetBlendMode(AE_GFX_BM_BLEND);
		AEGfxSetRenderMode(AE_GFX_RM_TEXTURE);
		AEGfxSetPosition(m_Transform.m_X, m_Transform.m_Y);
		AEGfxSetTintColor(1.0f, 1.0f, 1.0f, 1.0f);
		AEGfxTextureSet(m_Visual.m_pTexture, 0.0f, 0.0f);
		AEGfxSetTransparency(1.0);
		AEGfxMeshDraw(m_Visual.m_pMesh, AE_GFX_MDM_TRIANGLES);
	}
	
protected:
	TransformComponent	m_Transform;
	VisualComponent		m_Visual;

	int m_SlopeX = 0;
	int m_SlopeY = 0;
};
