#pragma once

#include <cstdlib>
#include <ctime>

class Random
{
public:
	static void InitSeed();
	static int Get();		
	static int GetRange(int min, int max);
};


inline void Random::InitSeed()
{
	std::srand(static_cast<int> (std::time(nullptr)));
}

inline int Random::Get()
{
	return std::rand();
}

inline int Random::GetRange(int min, int max)
{
	return min + std::rand() / (RAND_MAX  / (max - min + 1) + 1);
}
