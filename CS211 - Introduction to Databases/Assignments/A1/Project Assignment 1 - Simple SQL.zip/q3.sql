select name, title, stars 
from movie, rating, reviewer 
where reviewer.rID = rating.rID and rating.mID = movie.mID and movie.director = reviewer.name