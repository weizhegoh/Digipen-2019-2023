select name from reviewer, movie, rating 
where title = 'Gone with the Wind' and reviewer.rID = rating.rID and movie.mID = rating.mID
order by stars asc