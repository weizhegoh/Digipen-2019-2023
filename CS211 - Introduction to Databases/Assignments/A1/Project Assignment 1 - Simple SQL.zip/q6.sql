select name as 'reviewer name', title as 'movie title', stars, ratingDate as 'rating Date' from movie, rating, reviewer 
where reviewer.rID = rating.rID and rating.mID = movie.mID
order by reviewer.name, movie.title, rating.stars asc
