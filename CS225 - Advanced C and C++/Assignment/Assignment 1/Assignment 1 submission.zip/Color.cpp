// Provide the implementation of the Color class
// The interface has been already provided for you.