
# 1. Assignment result
This file represents an assignment result.

## 1.1. Initial paragraph
This is the first paragraph of the result file.

## 1.2. Final paragraph
This is the second paragraph of the result file.
> This is a quote.

This is the third paragraph of the result file.
This is the last paragraph of the result file.
