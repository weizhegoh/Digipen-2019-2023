#include "Text.h"
#include <iostream>

Text::Text(std::ostream& stream) :os{ stream } {}

IFormatter& Text::insertHeader1(std::string s)
{
	os << s << std::endl;
	return *this;
}

IFormatter& Text::paragraph(std::string s)
{
    static int count = 0;
	++count;

	os << s << std::endl;

	if (count <= 2)
	{
		std::cout << std::endl;
	}

	return *this;
}

IFormatter& Text::insertHeader2(std::string s)
{
	os << s << std::endl;
	return *this;
}

IFormatter& Text::blockquote(std::string s)
{
	os << "\"" << s << "\"" << std::endl;
	return *this;
}

IFormatter* construct(std::ostream& stream)
{
	IFormatter* result = new Text(stream);
	return result;
}

Text::~Text(){}