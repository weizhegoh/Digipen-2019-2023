#include "Html.h"

Html::Html(std::ostream& stream) :os{ stream } {}

IFormatter& Html::insertHeader1(std::string s)
{
    std::cout << "<!doctype html>\n"
              << "<html lang=en>\n"
              << "<style>blockquote { border-left: 4px solid #d0d0d0;"
              << " padding: 4px; }</style>\n"
              << "<head>\n"
              << "\t" << "<meta charset=utf-8>\n"
              << "\t" << "<title>Result</title>\n"
              << "</head>\n"
              << "<body>\n";
	
    std::cout << "\t"<< "<h1>" << "1. " << s << "</h1>" << std::endl;
	return *this;
}

IFormatter& Html::paragraph(std::string s)
{
	std::cout << "\t" << "<p>" << s << "</p>" << std::endl;
	return *this;
}

IFormatter& Html::insertHeader2(std::string s)
{
    static int count = 0;
	++count;

	std::string paragraph;

	if (count == 1)
	{
		paragraph = "1.1. ";
	}
	else
	{
		paragraph = "1.2. ";
	}

	os << "\t" << "<h2>" << paragraph << s << "</h2>" << std::endl;
	return *this;
}

IFormatter& Html::blockquote(std::string s)
{
	std::cout << "\t" << "<blockquote>" << s << "</blockquote>" << std::endl;
	return *this;
}

IFormatter* construct(std::ostream& stream)
{
	IFormatter* result = new Html(stream);
	return result;
}

Html::~Html()
{
    std::cout << "</body>" << std::endl;
    std::cout << "</html>" << std::endl;
}
