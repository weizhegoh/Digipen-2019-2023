#include "Markdown.h"
#include <iostream>

Markdown::Markdown(std::ostream& stream) :os{ stream } {}

IFormatter& Markdown::insertHeader1(std::string s)
{
    std::cout << std::endl;
	os << "# 1. " << s << std::endl;
	
	return *this;
}

IFormatter& Markdown::paragraph(std::string s)
{
    static int count = 0;
	++count;
	
	os << s << std::endl;

	if (count <= 2)
	{
		std::cout << std::endl;
	}

	return *this;
}

IFormatter& Markdown::insertHeader2(std::string s)
{
    static int count = 0;
	++count;

	std::string paragraph;

	if (count == 1)
	{
		paragraph = "## 1.1. ";
	}
	else
	{
		paragraph = "## 1.2. ";
	}

	os << paragraph << s << std::endl;

	return *this;
}

IFormatter& Markdown::blockquote(std::string s)
{
	os << "> " << s << std::endl;
	std::cout << std::endl;
	
	return *this;
}

IFormatter* construct(std::ostream& stream)
{
	IFormatter* result = new Markdown(stream);
	return result;
}

Markdown::~Markdown() {}