#pragma once
#include "IFormatter.h"

class Markdown : public IFormatter
{
public:
	//std::ostream& os;
	//Markdown(std::ostream& stream);
	Markdown& insertHeader1(std::string s);
	Markdown& paragraph(std::string s);
	Markdown& insertHeader2(std::string s);
	Markdown& blockquote(std::string s);
};

