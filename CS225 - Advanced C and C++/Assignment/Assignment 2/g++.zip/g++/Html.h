#pragma once
#include "IFormatter.h"
#include <iostream>

class Html : public IFormatter
{
	//std::ostream os;
	Html& insertHeader1(std::string s) = 0;
	Html& paragraph(std::string s) = 0;
	Html& insertHeader2(std::string s) = 0;
	Html& blockquote(std::string s) = 0;
};

