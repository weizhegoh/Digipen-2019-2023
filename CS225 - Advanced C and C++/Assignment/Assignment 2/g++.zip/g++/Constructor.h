#ifndef _CONSTRUCTOR_H_
#define _CONSTRUCTOR_H_

#include "IFormatter.h"

#include <iostream>

IFormatter* construct(std::ostream& stream);

#endif
