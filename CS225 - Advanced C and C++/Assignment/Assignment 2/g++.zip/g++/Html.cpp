#include "Html.h"

Html& Html::insertHeader1(std::string s)
{
	std::cout << s << std::endl;
	return *this;
}

Html& Html::paragraph(std::string s)
{
	std::cout << s << std::endl;
	return *this;
}

Html& Html::insertHeader2(std::string s)
{
	std::cout << s << std::endl;
	return *this;
}

Html& Html::blockquote(std::string s)
{
	std::cout << s << std::endl;
	return *this;
}