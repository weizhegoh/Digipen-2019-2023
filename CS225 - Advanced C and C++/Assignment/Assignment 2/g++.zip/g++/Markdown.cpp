#include "Markdown.h"
#include <iostream>

//Markdown::Markdown(std::ostream& stream) :os{ stream } {}

Markdown& Markdown::insertHeader1(std::string s)
{
	std::cout << s << std::endl;
	return *this;
}

Markdown& Markdown::paragraph(std::string s)
{
	std::cout << s << std::endl;
	return *this;
}

Markdown& Markdown::insertHeader2(std::string s)
{
	std::cout << s << std::endl;
	return *this;
}

Markdown& Markdown::blockquote(std::string s)
{
	std::cout << s << std::endl;
	return *this;
}

//
//IFormatter* construct(std::ostream& stream)
//{
//	IFormatter* result = new Markdown(stream);
//	return result;
//}
