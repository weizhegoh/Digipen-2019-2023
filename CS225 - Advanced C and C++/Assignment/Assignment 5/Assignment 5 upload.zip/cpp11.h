/* Start Header
*****************************************************************/
/*!
\file cpp11.h
\author Goh Wei Zhe, weizhe.goh, 440000119
\par email: weizhe.goh\@digipen.edu
\date November 18, 2020
\brief Contains definition for generating an index sequence using C++11 approach
Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
*/
/* End Header
*******************************************************************/

#ifndef CPP11_H_
#define CPP11_H_

template <size_t Count, size_t... Rest>
struct make_sequence_impl
{
	using type = typename make_sequence_impl<Count-1,Rest...,1UL<<Count >::type;
};

template <size_t... Rest>
struct make_sequence_impl<0, Rest...>
{
	using type = index_sequence<Rest..., 1>;
};

template <size_t T>
using make_sequence = typename make_sequence_impl<T>::type;

#endif // !CPP11_H_H
