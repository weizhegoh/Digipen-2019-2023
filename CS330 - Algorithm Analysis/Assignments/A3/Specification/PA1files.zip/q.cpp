/*!*****************************************************************************
\file    q.cpp
\author  ABC
\par     DP email: ABC@digipen.edu
\par     Course: CS330
\par     Section: A
\par     Programming Assignment #1
\date    28-06-2021

\brief

*******************************************************************************/

#include <iostream>
#include <vector>
#include <numeric> //accumulate

namespace CS330
{
  namespace subsetsum
  {
    
    bool subset_rec(std::vector<int> const& set, int sum, std::vector<int> & subset, unsigned long index) {

      int curr_sum = std::accumulate(subset.begin(), subset.end(), 0);
    
      /*----- Success: find a solution -------*/
      if (curr_sum == sum) {
        for (unsigned long i = 0; i < subset.size(); ++i) { 
          std::cout << subset[i] << " "; }
        std::cout << "  sum " << curr_sum << std::endl;
        return true;
      }

      /*----- Hit the bottom: start backtracking -------*/ 
    
      // Add code here
      // Your code should print out the candidate solution before return false
      // The output should be in format (# represents a number): 
      // # # # #   sum #

      /*----- Backtracking -------*/ 
    
      // ADD code here. 
      // You backtracking should stop as soon as the first solution is found.
    
      // left: add nothing {} to the solution

      // right: add the element set[index] to the solution
	

      return false; // continue backtracking
    }

    std::vector<int> subset_sum(std::vector<int> const& set, int sum) {
      std::vector<int> subset;
      CS330::subsetsum::subset_rec(set, sum, subset, 0);
      return subset;
    }  
   
  }
}