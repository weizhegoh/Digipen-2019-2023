/*!*****************************************************************************
\file    q.cpp
\author  ABC
\par     DP email: ABC@digipen.edu
\par     Course: CS330
\par     Section: A
\par     Programming Assignment #2
\date    07-07-2021

\brief

*******************************************************************************/

// only include the following two head files
#include <iostream>
#include <vector>
// Don't add more

namespace CS330
{
  namespace divide
  {
    // This function is used to print a list
    void print(std::vector<int> & nums)
    {
      for (std::vector<int>::const_iterator i = nums.begin(); i != nums.end(); ++i)
        std::cout << *i << ' ';
      std::cout << std::endl;      
    }
    
    // This function is used to check your task 3 - rearrange numbers
    bool check_neg_bef_pos(std::vector<int> & nums)
    { 
      for (unsigned i=1; i<nums.size(); ++i)
          if(nums[i-1]>0 && nums[i]<0) return false;
      return true;
    }
 
    // Define your own functions here
    
   
    
  }
}
