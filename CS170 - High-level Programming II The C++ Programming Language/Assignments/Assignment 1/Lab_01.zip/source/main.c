#include <stdio.h>
#include "forward_list.h"

int main(void)
{
	int i;
    forward_list* list1 = NULL;
    forward_list* list2 = NULL;
    const int numbers[] =
	{
        11, 12, 13, 14, 15,
		21, 22, 23, 24, 25,
		31, 32, 33, 34, 35
    };
    int size = sizeof(numbers) / sizeof(*numbers);
    
	list1 = create_list();
	list2 = create_list();
		
    for (i = 0; i < size; i++)
	{
		push_back_list(list1, numbers[i]);
		push_front_list(list2, numbers[i]);
		
        printf("List1 (%2u nodes): ", count_list(list1));
        print_list(list1);
		
        printf("List2 (%2u nodes): ", count_list(list2));
        print_list(list2);
		
        printf("\n");
    }

    destroy_list(list2);
	list2 = NULL;
	
	destroy_list(list1);
	list1 = NULL;
	
    return 0;
}
