#include <stdio.h>
#include <stdlib.h>

#include "forward_list.h"

/*******************************************************************************
 * DATA TYPES
 ******************************************************************************/

struct node
{
    int number;        /* data portion */
    struct node* next; /* pointer portion */
};

struct forward_list
{
	struct node* head;
};

typedef struct node node;

/*******************************************************************************
 * HELPER FUNCTIONS
 ******************************************************************************/

node* create_node(int number, node* next)
{
	node* result = (node*)malloc(sizeof(node));
	result->number = number;
	result->next = next;
	return result;
}

void destroy_node(node* const this)
{
	free(this);
}

/*******************************************************************************
 * FUNCTIONS OF A FORWARD LIST
 ******************************************************************************/

forward_list* create_list(void)
{
	return (forward_list*)calloc(1, sizeof(forward_list));
}

void destroy_list(forward_list* const this)
{
	/* TODO */
}

unsigned int count_list(const forward_list* const this)
{
	/* TODO */
}

void push_front_list(forward_list* const this, int value)
{
	if (this)
	{
		this->head = create_node(value, this->head);
	}
}

void push_back_list(forward_list* const this, int value)
{
	/* TODO */
}

void print_list(const forward_list* const this)
{
	/* TODO */
}
