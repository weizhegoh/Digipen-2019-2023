/******************************************************************************/
/*!
\file		Matrix3x3.cpp
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh\@digipen.edu
\date   	July 26, 2020
\brief		Consist of all functions required to implement a 2D matrix library

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
 /******************************************************************************/

#include "Matrix3x3.h"
#include <math.h>

#define PI	3.14159265358f
#define EPSILON		0.0001f


namespace CS230
{
	/**************************************************************************/
	/*!
		Conversion constructor function of union Matrix3x3
	*/
	/**************************************************************************/
	Matrix3x3::Matrix3x3(const float* pArr):
		m00(pArr[0]), m01(pArr[1]), m02(pArr[2]),
		m10(pArr[3]), m11(pArr[4]), m12(pArr[5]),
		m20(pArr[6]), m21(pArr[7]), m22(pArr[8]){}

	/**************************************************************************/
	/*!
		Parameterized constructor function of union Matrix3x3
	*/
	/**************************************************************************/
	Matrix3x3::Matrix3x3(float _00, float _01, float _02,
		float _10, float _11, float _12,
		float _20, float _21, float _22) :

		m00(_00), m01(_01), m02(_02),
		m10(_10), m11(_11), m12(_12),
		m20(_20), m21(_21), m22(_22){}

	/**************************************************************************/
	/*!
		Copy constructor function and returns Matrix
	*/
	/**************************************************************************/
	Matrix3x3 & Matrix3x3::operator=(const Matrix3x3& rhs)
	{
		for (int i = 0; i < 9; ++i)
		{
			this->m[i] = rhs.m[i];
		}

		return *this;
	}

	/**************************************************************************/
	/*!
		Mutiplication operator function multiplies matrix rhs with this matrix
		Returns matrix as a result.
	*/
	/**************************************************************************/
	Matrix3x3& Matrix3x3::operator *= (const Matrix3x3& rhs)
	{
		this->m00 = (this->m00 * rhs.m00) + (this->m01 * rhs.m10) + (this->m02 * rhs.m20);
		this->m01 = (this->m00 * rhs.m01) + (this->m01 * rhs.m11) + (this->m02 * rhs.m21);
		this->m02 = (this->m00 * rhs.m02) + (this->m01 * rhs.m12) + (this->m02 * rhs.m22);

		this->m10 = (this->m10 * rhs.m00) + (this->m11 * rhs.m10) + (this->m12 * rhs.m20);
		this->m11 = (this->m10 * rhs.m01) + (this->m11 * rhs.m11) + (this->m12 * rhs.m21);
		this->m12 = (this->m10 * rhs.m02) + (this->m11 * rhs.m12) + (this->m12 * rhs.m22);

		this->m20 = (this->m20 * rhs.m00) + (this->m21 * rhs.m10) + (this->m22 * rhs.m20);
		this->m21 = (this->m20 * rhs.m01) + (this->m21 * rhs.m11) + (this->m22 * rhs.m21);
		this->m22 = (this->m20 * rhs.m02) + (this->m21 * rhs.m12) + (this->m22 * rhs.m22);

		return *this;
	}

	/**************************************************************************/
	/*!
		Multiplication operator function multiplies matrix lhs with matrix rhs
		and store matrix into mResult. Return mResult as a result.
	*/
	/**************************************************************************/
	Matrix3x3 operator * (const Matrix3x3& lhs, const Matrix3x3& rhs)
	{
		Matrix3x3 mResult;

		mResult.m00 = (lhs.m00 * rhs.m00) + (lhs.m01 * rhs.m10) + (lhs.m02 * rhs.m20);
		mResult.m01 = (lhs.m00 * rhs.m01) + (lhs.m01 * rhs.m11) + (lhs.m02 * rhs.m21);
		mResult.m02 = (lhs.m00 * rhs.m02) + (lhs.m01 * rhs.m12) + (lhs.m02 * rhs.m22);

		mResult.m10 = (lhs.m10 * rhs.m00) + (lhs.m11 * rhs.m10) + (lhs.m12 * rhs.m20);
		mResult.m11 = (lhs.m10 * rhs.m01) + (lhs.m11 * rhs.m11) + (lhs.m12 * rhs.m21);
		mResult.m12 = (lhs.m10 * rhs.m02) + (lhs.m11 * rhs.m12) + (lhs.m12 * rhs.m22);

		mResult.m20 = (lhs.m20 * rhs.m00) + (lhs.m21 * rhs.m10) + (lhs.m22 * rhs.m20);
		mResult.m21 = (lhs.m20 * rhs.m01) + (lhs.m21 * rhs.m11) + (lhs.m22 * rhs.m21);
		mResult.m22 = (lhs.m20 * rhs.m02) + (lhs.m21 * rhs.m12) + (lhs.m22 * rhs.m22);

		return mResult;
	}

	/**************************************************************************/
	/*!
		This operator multiplies the matrix pMtx with the vector rhs
		and returns the result as a vector
	 */
	 /**************************************************************************/
	Vector2D  operator * (const Matrix3x3& pMtx, const Vector2D& rhs)
	{
		Vector2D v2Multiply;

		v2Multiply.x = (pMtx.m00 * rhs.x) + (pMtx.m01 * rhs.y) + (pMtx.m02 * 1.0f);
		v2Multiply.y = (pMtx.m10 * rhs.x) + (pMtx.m11 * rhs.y) + (pMtx.m12 * 1.0f);

		return v2Multiply;
	}

	/**************************************************************************/
	/*!
		This function sets the matrix pResult to the identity matrix
	 */
	 /**************************************************************************/
	void Mtx33Identity(Matrix3x3& pResult)
	{
		for (int i = 0; i < 9; ++i)
		{
			if (i % 4 == 0)
			{
				pResult.m[i] = 1.0f;
			}
			else
			{
				pResult.m[i] = 0.0f;
			}
		}
	}

	/**************************************************************************/
	/*!
		This function creates a translation matrix from x & y
		and saves it in pResult
	 */
	 /**************************************************************************/
	void Mtx33Translate(Matrix3x3& pResult, float x, float y)
	{
		Mtx33Identity(pResult);

		pResult.m02 = x;
		pResult.m12 = y;
	}

	/**************************************************************************/
	/*!
		This function creates a scaling matrix from x & y
		and saves it in pResult
	 */
	 /**************************************************************************/
	void Mtx33Scale(Matrix3x3& pResult, float x, float y)
	{
		Mtx33Identity(pResult);

		pResult.m00 *= x;
		pResult.m11 *= y;
	}

	/**************************************************************************/
	/*!
		This matrix creates a rotation matrix from "angle" whose value
		is in radian. Save the resultant matrix in pResult.
	 */
	 /**************************************************************************/
	void Mtx33RotRad(Matrix3x3& pResult, float angle)
	{
		Mtx33Identity(pResult);

		pResult.m00 = cosf(angle);
		pResult.m01 = -sinf(angle);
		pResult.m10 = sinf(angle);
		pResult.m11 = cosf(angle);
	}

	/**************************************************************************/
	/*!
		This matrix creates a rotation matrix from "angle" whose value
		is in degree. Save the resultant matrix in pResult.
	 */
	 /**************************************************************************/
	void Mtx33RotDeg(Matrix3x3& pResult, float angle)
	{
		float angleInRadian = angle * PI / 180;

		Mtx33Identity(pResult);

		pResult.m00 = cosf(angleInRadian);
		pResult.m01 = -sinf(angleInRadian);
		pResult.m10 = sinf(angleInRadian);
		pResult.m11 = cosf(angleInRadian);
	}

	/**************************************************************************/
	/*!
		This functions calculated the transpose matrix of pMtx
		and saves it in pResult
	 */
	 /**************************************************************************/
	void Mtx33Transpose(Matrix3x3& pResult, const Matrix3x3& pMtx)
	{
		pResult.m00 = pMtx.m00;
		pResult.m01 = pMtx.m10;
		pResult.m02 = pMtx.m20;

		pResult.m10 = pMtx.m01;
		pResult.m11 = pMtx.m11;
		pResult.m12 = pMtx.m21;
		  
		pResult.m20 = pMtx.m02;
		pResult.m21 = pMtx.m12;
		pResult.m22 = pMtx.m22;
	}

	/**************************************************************************/
	/*!
		This function calculates the inverse matrix of pMtx and saves the
		result in pResult. If the matrix inversion fails, pResult
		would be set to NULL.
	*/
	/**************************************************************************/
	void Mtx33Inverse(Matrix3x3* pResult, float* determinant, const Matrix3x3& pMtx)
	{
		*determinant = (pMtx.m[0] * ((pMtx.m[4] * pMtx.m[8]) - (pMtx.m[7] * pMtx.m[5]))) +			//calculate determinant
					(-(pMtx.m[1] * ((pMtx.m[3] * pMtx.m[8]) - (pMtx.m[5] * pMtx.m[6])))) +
					(pMtx.m[2] * ((pMtx.m[3] * pMtx.m[7]) - (pMtx.m[4] * pMtx.m[6])));

		if (*determinant <= EPSILON)													
		{
			pResult = NULL;
			return;
		}

		Matrix3x3 adjugateMatrix;
		Matrix3x3 transposeMatrix;

		adjugateMatrix.m[0] =  ((pMtx.m[4] * pMtx.m[8]) - (pMtx.m[5] * pMtx.m[7]));					//cofactor matrix
		adjugateMatrix.m[1] = -((pMtx.m[3] * pMtx.m[8]) - (pMtx.m[5] * pMtx.m[6]));
		adjugateMatrix.m[2] =  ((pMtx.m[3] * pMtx.m[7]) - (pMtx.m[4] * pMtx.m[6]));

		adjugateMatrix.m[3] = -((pMtx.m[1] * pMtx.m[8]) - (pMtx.m[2] * pMtx.m[7]));
		adjugateMatrix.m[4] =  ((pMtx.m[0] * pMtx.m[8]) - (pMtx.m[2] * pMtx.m[6]));
		adjugateMatrix.m[5] = -((pMtx.m[0] * pMtx.m[7]) - (pMtx.m[1] * pMtx.m[6]));

		adjugateMatrix.m[6] =  ((pMtx.m[1] * pMtx.m[5]) - (pMtx.m[2] * pMtx.m[4]));
		adjugateMatrix.m[7] = -((pMtx.m[0] * pMtx.m[5]) - (pMtx.m[2] * pMtx.m[3]));
		adjugateMatrix.m[8] =  ((pMtx.m[0] * pMtx.m[4]) - (pMtx.m[1] * pMtx.m[3]));

		Mtx33Transpose(transposeMatrix, adjugateMatrix);											//Transpose Matrix

		for (int i = 0; i < 9; ++i)
		{
			pResult->m[i] = adjugateMatrix.m[i] / *determinant;
		}
	}
}