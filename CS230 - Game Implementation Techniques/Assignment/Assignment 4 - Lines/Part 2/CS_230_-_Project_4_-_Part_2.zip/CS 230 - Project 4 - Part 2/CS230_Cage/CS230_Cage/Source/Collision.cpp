/******************************************************************************/
/*!
\file		Collision.cpp
\author 	DigiPen
\par    	email: digipen\@digipen.edu
\date   	January 01, 2017
\brief

Copyright (C) 2017 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/

#include "main.h"

/******************************************************************************/
/*!

 */
/******************************************************************************/
void BuildLineSegment(LineSegment &lineSegment, 
					  const AEVec2 &pos, 
					  float scale, 
					  float dir)
{
	// your code goes here
	UNREFERENCED_PARAMETER(lineSegment);
	UNREFERENCED_PARAMETER(pos);
	UNREFERENCED_PARAMETER(scale);
	UNREFERENCED_PARAMETER(dir);
}

/******************************************************************************/
/*!
	
 */
/******************************************************************************/
int CollisionIntersection_CircleLineSegment(const Circle &circle, 
											const AEVec2 &ptEnd,
											const LineSegment &lineSeg, 
											AEVec2 &interPt, 
											AEVec2 &normalAtCollision,
											float &interTime,
											bool& checkLineEdges)
{
	// your code goes here
	UNREFERENCED_PARAMETER(circle);
	UNREFERENCED_PARAMETER(ptEnd);
	UNREFERENCED_PARAMETER(lineSeg);
	UNREFERENCED_PARAMETER(interPt);
	UNREFERENCED_PARAMETER(normalAtCollision);
	UNREFERENCED_PARAMETER(interTime);
	UNREFERENCED_PARAMETER(checkLineEdges);

	return 0; // no intersection
}


/******************************************************************************/
/*!

*/
/******************************************************************************/
int CheckMovingCircleToLineEdge(bool withinBothLines,
	const Circle& circle,
	const AEVec2& ptEnd,
	const LineSegment& lineSeg,
	AEVec2& interPt,
	AEVec2& normalAtCollision,
	float& interTime)
{
	// your code goes here
	UNREFERENCED_PARAMETER(withinBothLines);
	UNREFERENCED_PARAMETER(circle);
	UNREFERENCED_PARAMETER(ptEnd);
	UNREFERENCED_PARAMETER(lineSeg);
	UNREFERENCED_PARAMETER(interPt);
	UNREFERENCED_PARAMETER(normalAtCollision);
	UNREFERENCED_PARAMETER(interTime);

	return 0;//no collision
}



/******************************************************************************/
/*!
	
 */
/******************************************************************************/
void CollisionResponse_CircleLineSegment(const AEVec2 &ptInter, 
										 const AEVec2 &normal,
										 AEVec2 &ptEnd, 
										 AEVec2 &reflected)
{
	// your code goes here
	UNREFERENCED_PARAMETER(ptInter);
	UNREFERENCED_PARAMETER(normal);
	UNREFERENCED_PARAMETER(ptEnd);
	UNREFERENCED_PARAMETER(reflected);
}
