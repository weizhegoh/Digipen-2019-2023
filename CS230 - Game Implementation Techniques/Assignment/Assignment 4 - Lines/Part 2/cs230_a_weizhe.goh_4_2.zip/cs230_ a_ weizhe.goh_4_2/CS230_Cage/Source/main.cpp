/******************************************************************************/
/*!
\file		main.cpp
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh\@digipen.edu
\date   	July 31, 2020
\brief		Consist of the main game loop function for Cage

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/

#include "main.h"


// ---------------------------------------------------------------------------
// Globals
float	 g_dt;
double	 g_appTime;


/******************************************************************************/
/*!
	Starting point of the application
*/
/******************************************************************************/
int WINAPI WinMain(HINSTANCE instanceH, HINSTANCE prevInstanceH, LPSTR command_line, int show)
{
	UNREFERENCED_PARAMETER(prevInstanceH);
	UNREFERENCED_PARAMETER(command_line);
	// Initialize the system
	AESysInit (instanceH, show, 1024, 768, 1, 60, false, NULL);

	GameStateMgrInit(GS_STATE::GS_CAGE);

	AESysSetWindowTitle("Collision: Circles - LineSegments");

	while(gGameStateCurr != GS_STATE::GS_QUIT)
	{
		// reset the system modules
		AESysReset();

		// If not restarting, load the gamestate
		if(gGameStateCurr != GS_STATE::GS_RESTART)
		{
			GameStateMgrUpdate();
			GameStateLoad();
		}
		else
			gGameStateNext = gGameStateCurr = gGameStatePrev;

		// Initialize the gamestate
		GameStateInit();

		while(gGameStateCurr == gGameStateNext)
		{
			AESysFrameStart();

			AEInputUpdate();

			GameStateUpdate();

			GameStateDraw();
			
			AESysFrameEnd();

			// check if forcing the application to quit
			if ((AESysDoesWindowExist() == false) || AEInputCheckTriggered(AEVK_ESCAPE))
				gGameStateNext = GS_STATE::GS_QUIT;

			g_dt = (f32)AEFrameRateControllerGetFrameTime();

			//hack
			if (g_dt > 0.016f)
				g_dt = 0.016f;

			g_appTime += g_dt;
		}
		
		GameStateFree();

		if(gGameStateNext != GS_STATE::GS_RESTART)
			GameStateUnload();

		gGameStatePrev = gGameStateCurr;
		gGameStateCurr = gGameStateNext;
	}

	// free the system
	AESysExit();
}