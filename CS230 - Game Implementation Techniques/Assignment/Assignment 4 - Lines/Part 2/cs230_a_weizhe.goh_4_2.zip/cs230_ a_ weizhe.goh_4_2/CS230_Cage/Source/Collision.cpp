/******************************************************************************/
/*!
\file		Collision.cpp
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh\@digipen.edu
\date   	July 31, 2020
\brief		Consist of functions required to calculate collision between circle 
			and line segment

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/

#include "main.h"

/******************************************************************************/
/*!
	Calculate line segment from the input position and direction
 */
/******************************************************************************/
void BuildLineSegment(LineSegment &lineSegment, 
					  const CS230::Vec2 &pos,
					  float scale, 
					  float dir)
{
	CS230::Vec2 Vector{ cosf(dir) * (scale * 0.5f), sinf(dir) * (scale * 0.5f) };

	lineSegment.m_pt0 = pos - Vector;
	lineSegment.m_pt1 = pos + Vector;

	CS230::Vec2 normal;
	CS230::Vec2 vector = { lineSegment.m_pt1 - lineSegment.m_pt0 };

	CS230::Vector2DNormalize(normal, vector);
	
	lineSegment.m_normal = { normal.y, -normal.x };
}

/******************************************************************************/
/*!
	Calculate collision between circle and line segment. Returns 1 for intersection 
	and returns 0 for no intersection
 */
/******************************************************************************/
int CollisionIntersection_CircleLineSegment(const Circle &circle, 
											const CS230::Vec2 &ptEnd,
											const LineSegment &lineSeg, 
											CS230::Vec2 &interPt, 
											CS230::Vec2 &normalAtCollision,
											float &interTime,
											bool& checkLineEdges)
{
	UNREFERENCED_PARAMETER(checkLineEdges);

	//if (N.Bs - N.P0 <= -R)
	// Consider an imaginary line segment distant by -R, opposite N direction
	if ((CS230::Vector2DDotProduct(lineSeg.m_normal, circle.m_center) - CS230::Vector2DDotProduct(lineSeg.m_normal, lineSeg.m_pt0)) <= -circle.m_radius)
	{
		//Check if circle velocity vector is within the end point of line Segment. 
		CS230::Vec2 circleVelocity = ptEnd - circle.m_center;

		//Calculate M, the outward velocity to Velocity V
		CS230::Vec2 M;
		CS230::Vector2DNormalize(M, { circleVelocity.y, -circleVelocity.x });

		//Calculate p0' and p1'
		CS230::Vec2 pZeroPrime = lineSeg.m_pt0 - (circle.m_radius * lineSeg.m_normal);
		CS230::Vec2 pOnePrime = lineSeg.m_pt1 - (circle.m_radius * lineSeg.m_normal);

		//Calculate vector BsP0' and BsP1'
		//To simulate line segment edge points
		CS230::Vec2 BsP0Prime = pZeroPrime - circle.m_center;
		CS230::Vec2 BsP1Prime = pOnePrime - circle.m_center;

		//if (M.BsP0' * M.BsP1' < 0)
		if ((CS230::Vector2DDotProduct(M, BsP0Prime) * CS230::Vector2DDotProduct(M, BsP1Prime)) < 0)
		{
			//Ti = (N.P0 - N.Bs - R) / N.V 
			// N.V != 0
			interTime = (CS230::Vector2DDotProduct(lineSeg.m_normal, lineSeg.m_pt0)
						- CS230::Vector2DDotProduct(lineSeg.m_normal, circle.m_center) - circle.m_radius)
						/ CS230::Vector2DDotProduct(lineSeg.m_normal, circleVelocity);

			//if (0 <= Ti <= 1)
			//if Ti is between 0 or 1, collision exist. 
			if (interTime >= 0.0f && interTime <= 1.0f)
			{
				//Bi = Bs + V * Ti
				//find intersection point, Bi
				interPt = circle.m_center + (circleVelocity * interTime);

				//B'e = Apply Reflection(-N.BiBe)
				//Normal of reflection is -N
				normalAtCollision = -lineSeg.m_normal;

				//Intersection
				return 1; 
			}
		}
	}	
	// else if (N.Bs - N.P0 >= R)
	// Consider an imaginary line segment distant by +R, same N direction
	else if ((CS230::Vector2DDotProduct(lineSeg.m_normal, circle.m_center) - CS230::Vector2DDotProduct(lineSeg.m_normal, lineSeg.m_pt0)) >= circle.m_radius)
	{
		//Check if circle velocity vector is within the end point of line Segment. 
		CS230::Vec2 circleVelocity = ptEnd - circle.m_center;

		//Calculate M, the outward velocity to Velocity V
		CS230::Vec2 M;
		CS230::Vector2DNormalize(M, { circleVelocity.y, -circleVelocity.x });

		//Calculate p0' and p1'
		CS230::Vec2 pZeroPrime = lineSeg.m_pt0 + (circle.m_radius * lineSeg.m_normal);
		CS230::Vec2 pOnePrime = lineSeg.m_pt1 + (circle.m_radius * lineSeg.m_normal);

		//Calculate vector BsP0' and BsP1'
		//To simulate line segment edge points
		CS230::Vec2 BsP0Prime = pZeroPrime - circle.m_center;
		CS230::Vec2 BsP1Prime = pOnePrime - circle.m_center;

		//if (M.BsP0' * M.BsP1' < 0)
		if ((CS230::Vector2DDotProduct(M, BsP0Prime) * CS230::Vector2DDotProduct(M, BsP1Prime)) < 0)
		{
			//Ti = (N.P0 - N.Bs + R) / N.V 
			// N.V != 0
			interTime = (CS230::Vector2DDotProduct(lineSeg.m_normal, lineSeg.m_pt0)
						- CS230::Vector2DDotProduct(lineSeg.m_normal, circle.m_center) + circle.m_radius)
						/ CS230::Vector2DDotProduct(lineSeg.m_normal, circleVelocity);

			//if (0 <= Ti <= 1)
			//if Ti is between 0 or 1, collision exist. 
			if (interTime >= 0.0f && interTime <= 1.0f)
			{
				//Bi = Bs + V * Ti
				//find intersection point, Bi
				interPt = circle.m_center + (circleVelocity * interTime);

				//B'e = Apply Reflection(N.BiBe)
				//Normal of reflection is N
				normalAtCollision = lineSeg.m_normal;

				//Intersection
				return 1;
			}
		}
	}

	return 0; // no intersection
}

///******************************************************************************/
///*!
//
//*/
///******************************************************************************/
//int CheckMovingCircleToLineEdge(bool withinBothLines,
//	const Circle& circle,
//	const AEVec2& ptEnd,
//	const LineSegment& lineSeg,
//	AEVec2& interPt,
//	AEVec2& normalAtCollision,
//	float& interTime)
//{
//	// your code goes here
//	UNREFERENCED_PARAMETER(withinBothLines);
//	UNREFERENCED_PARAMETER(circle);
//	UNREFERENCED_PARAMETER(ptEnd);
//	UNREFERENCED_PARAMETER(lineSeg);
//	UNREFERENCED_PARAMETER(interPt);
//	UNREFERENCED_PARAMETER(normalAtCollision);
//	UNREFERENCED_PARAMETER(interTime);
//
//	return 0;//no collision
//}

/******************************************************************************/
/*!
	Calculate reflection after colliding with line segment 
 */
/******************************************************************************/
void CollisionResponse_CircleLineSegment(const CS230::Vec2 &ptInter,
										 const CS230::Vec2 &normal,
										 CS230::Vec2 &ptEnd, 
										 CS230::Vec2 &reflected)
{
	//Calculate penetration vector
	CS230::Vec2 penetration = ptEnd - ptInter;

	//Calculate ball position reflected
	ptEnd = ptInter + penetration - (2 * CS230::Vector2DDotProduct(normal, penetration)) * normal;

	//Calculate reflection vector
	CS230::Vec2 reflection{ ptEnd - ptInter };

	//Normalize reflection position vector
	CS230::Vector2DNormalize(reflection, reflection);

	//Assign reflection vector to reflected vector
	reflected = reflection;
}