/******************************************************************************/
/*!
\file		Vector2D.cpp
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh\@digipen.edu
\date   	July 31, 2020
\brief		Consist of all functions required to implement a 2D vector library

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/

#include "Vector2D.h"
#include <math.h>

namespace CS230
{
	Vector2D::Vector2D(float _x, float _y) : x(_x), y(_y) {}

	// Assignment operators
	Vector2D& Vector2D::operator += (const Vector2D& rhs)
	{
		this->x += rhs.x;
		this->y += rhs.y;

		return *this;
	}

	Vector2D& Vector2D::operator -= (const Vector2D& rhs)
	{
		this->x -= rhs.x;
		this->y -= rhs.y;

		return *this;
	}

	Vector2D& Vector2D::operator *= (float rhs)
	{
		this->x *= rhs;
		this->y *= rhs;

		return *this;
	}

	Vector2D& Vector2D::operator /= (float rhs)
	{
		this->x /= rhs;
		this->y /= rhs;

		return *this;
	}

	// Unary operators
	Vector2D Vector2D::operator -() const
	{
		Vector2D v2;

		v2.x = -(this->x);
		v2.y = -(this->y);

		return v2;
	}

	/**************************************************************************/
	/*!
		Plus operator function adds vector lhs and vector rhs and store it into 
		new vector v2Add. Returns v2Add as a result. 
	*/
	/**************************************************************************/
	Vector2D operator + (const Vector2D& lhs, const Vector2D& rhs)
	{
		Vector2D v2Add;

		v2Add.x = lhs.x + rhs.x;
		v2Add.y = lhs.y + rhs.y;

		return v2Add;
	}

	/**************************************************************************/
	/*!
		Subtract operator function subtract vector rhs from vector lhs and store 
		it into new vector v2Subtract. Returns v2Subtract as a result.
	*/
	/**************************************************************************/
	Vector2D operator - (const Vector2D& lhs, const Vector2D& rhs)
	{
		Vector2D v2Subtract;

		v2Subtract.x = lhs.x - rhs.x;
		v2Subtract.y = lhs.y - rhs.y;

		return v2Subtract;
	}

	/**************************************************************************/
	/*!
		Multiplication operator function mutiplies vector lhs by rhs and store
		it into new vector v2Multiply. Returns v2Multiply as a result.
	*/
	/**************************************************************************/
	Vector2D operator * (const Vector2D& lhs, float rhs)
	{
		Vector2D v2Multiply;

		v2Multiply.x = lhs.x * rhs;
		v2Multiply.y = lhs.y * rhs;

		return v2Multiply;
	}

	/**************************************************************************/
	/*!
		Multiplication operator function multiplies vector rhs by lhs and store 
		it into new vector v2Multiply. Returns v2Multiply as a result.  
	*/
	/**************************************************************************/
	Vector2D operator * (float lhs, const Vector2D& rhs)
	{
		Vector2D v2Multiply;

		v2Multiply.x = rhs.x * lhs;
		v2Multiply.y = rhs.y * lhs;

		return v2Multiply;
	}

	/**************************************************************************/
	/*!
		Division operator function divides vector lhs by rhs and store it into 
		new vector v2Divide. Returns v2Divide as a result. 
	*/
	/**************************************************************************/
	Vector2D operator / (const Vector2D& lhs, float rhs)
	{
		Vector2D v2Divide;

		v2Divide.x = lhs.x / rhs;
		v2Divide.y = lhs.y / rhs;

		return v2Divide;
	}

	/**************************************************************************/
	/*!
		In this function, pResult will be the unit vector of pVec0
	*/
	/**************************************************************************/
	void	Vector2DNormalize(Vector2D& pResult, const Vector2D& pVec0)
	{
		float v2Magnitude = (pVec0.x * pVec0.x) + (pVec0.y * pVec0.y);
		v2Magnitude = static_cast<float>(sqrt(v2Magnitude));

		pResult = pVec0 / v2Magnitude;
	}

	/**************************************************************************/
	/*!
		This function returns the length of the vector pVec0
	 */
	/**************************************************************************/
	float	Vector2DLength(const Vector2D& pVec0)
	{
		float v2Length = (pVec0.x * pVec0.x) + (pVec0.y * pVec0.y);
		v2Length = static_cast<float>(sqrt(v2Length));

		return v2Length;
	}

	/**************************************************************************/
	/*!
		This function returns the square of pVec0's length. Avoid the square root
	 */
	/**************************************************************************/
	float	Vector2DSquareLength(const Vector2D& pVec0)
	{
		float v2SqLength = (pVec0.x * pVec0.x) + (pVec0.y * pVec0.y);

		return v2SqLength;
	}

	/**************************************************************************/
	/*!
		In this function, pVec0 and pVec1 are considered as 2D points.
		The distance between these 2 2D points is returned
	 */
	/**************************************************************************/
	float	Vector2DDistance(const Vector2D& pVec0, const Vector2D& pVec1)
	{
		float v2Distance = ((pVec1.x - pVec0.x) * (pVec1.x - pVec0.x)) + ((pVec1.y - pVec0.y) * (pVec1.y - pVec0.y));
		v2Distance = static_cast<float>(sqrt(v2Distance));

		return v2Distance;
	}

	/**************************************************************************/
	/*!
		In this function, pVec0 and pVec1 are considered as 2D points.
		The squared distance between these 2 2D points is returned.
		Avoid the square root
	 */
	/**************************************************************************/
	float	Vector2DSquareDistance(const Vector2D& pVec0, const Vector2D& pVec1)
	{
		float v2SqDistance = ((pVec1.x - pVec0.x) * (pVec1.x - pVec0.x)) + ((pVec1.y - pVec0.y) * (pVec1.y - pVec0.y));
		
		return v2SqDistance;
	}


	/**************************************************************************/
	/*!
		This function returns the dot product between pVec0 and pVec1
	 */
	/**************************************************************************/
	float	Vector2DDotProduct(const Vector2D& pVec0, const Vector2D& pVec1)
	{
		return (pVec0.x * pVec1.x) + (pVec0.y * pVec1.y);
	}

	/**************************************************************************/
	/*!
		This function returns the cross product magnitude
		between pVec0 and pVec1
	 */
	/**************************************************************************/
	float	Vector2DCrossProductMag(const Vector2D& pVec0, const Vector2D& pVec1)
	{
		return (pVec0.x * pVec1.y) - (pVec0.y * pVec1.x);
	}
}