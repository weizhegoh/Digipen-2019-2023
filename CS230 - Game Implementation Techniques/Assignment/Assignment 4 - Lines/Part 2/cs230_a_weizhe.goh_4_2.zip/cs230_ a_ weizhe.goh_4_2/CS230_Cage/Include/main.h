/******************************************************************************/
/*!
\file		main.h
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh\@digipen.edu
\date   	July 31, 2020
\brief		Consist of all neccessary global externs and headers for Cage

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/


#ifndef CS230_MAIN_H_
#define CS230_MAIN_H_

//------------------------------------
// Globals

extern float	g_dt;
extern double	g_appTime;

// ---------------------------------------------------------------------------
// includes

#include "AEEngine.h"
#include "Math.h"

#include <iostream>
#include <fstream>
#include <string>

#include "GameStateMgr.h"
#include "GameState_Cage.h"
#include "Collision.h"

#include "Vector2D.h"
#include "Matrix3x3.h"
#endif // CS230_MAIN_H_