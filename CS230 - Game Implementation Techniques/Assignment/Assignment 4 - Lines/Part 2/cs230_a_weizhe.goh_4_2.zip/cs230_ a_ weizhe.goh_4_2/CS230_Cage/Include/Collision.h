/******************************************************************************/
/*!
\file		Collision.h
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh\@digipen.edu
\date   	July 31, 2020
\brief		Consist of declaration and functions needed to calculate collision
			between circle and the line segment

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/

#ifndef CS230_COLLISION_H_
#define CS230_COLLISION_H_

#include "Vector2D.h"

/******************************************************************************/
/*!
	Struct/Class Definitions
 */
/******************************************************************************/
struct LineSegment
{
	CS230::Vec2	m_pt0;
	CS230::Vec2	m_pt1;
	CS230::Vec2	m_normal;
};

void BuildLineSegment(LineSegment& lineSegment,										//Line segment reference - input
						const CS230::Vec2& pos,										//position - input
						float scale,												//scale - input
						float dir);													//direction - input

/******************************************************************************/
/*!
	Struct/Class Definitions
 */
/******************************************************************************/
struct Circle
{
	CS230::Vec2  m_center;
	float	m_radius;
};
 
// INTERSECTION FUNCTIONS
int CollisionIntersection_CircleLineSegment(const Circle& circle,					//Circle data - input
											const CS230::Vec2& ptEnd,				//End circle position (Be) - input
											const LineSegment& lineSeg,				//Line segment - input
											CS230::Vec2& interPt,					//Intersection point - output
											CS230::Vec2& normalAtCollision,			//Normal vector at collision time - output
											float& interTime,						//Intersection time ti - output
											bool& checkLineEdges);					//The last parameter is new - for Extra Credits: true = check collision with line segment edges

//// Extra credits
//int CheckMovingCircleToLineEdge(bool withinBothLines,								//Flag stating that the circle is starting from between 2 imaginary line segments distant +/- Radius respectively - input
//								const Circle& circle,								//Circle data - input
//								const CS230::Vec2& ptEnd,							//End circle position (Be) - input
//								const LineSegment& lineSeg,							//Line segment - input
//								CS230::Vec2& interPt,								//Intersection point - output
//								CS230::Vec2& normalAtCollision,						//Normal vector at collision time - output
//								float& interTime);									//Intersection time ti - output

// RESPONSE FUNCTIONS
void CollisionResponse_CircleLineSegment(const CS230::Vec2& ptInter,				//Intersection position of the circle - input
										const CS230::Vec2& normal,					//Normal vector of reflection on collision time - input
										CS230::Vec2& ptEnd,							//Final position of the circle after reflection - output
										CS230::Vec2& reflected);					//Normalized reflection vector direction - output


#endif // CS230_COLLISION_H_