/******************************************************************************/
/*!
\file		GameState_Cage.h
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh\@digipen.edu
\date   	July 31, 2020
\brief	    Consist of all declarations and functions required for cage asssignment

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/

#ifndef CS230_GAME_STATE_PLAY_H_
#define CS230_GAME_STATE_PLAY_H_


// ---------------------------------------------------------------------------

void GameStateCageLoad(void);
void GameStateCageInit(void);
void GameStateCageUpdate(void);
void GameStateCageDraw(void);
void GameStateCageFree(void);
void GameStateCageUnload(void);

// ---------------------------------------------------------------------------

#endif // CS230_GAME_STATE_PLAY_H_