/******************************************************************************/
/*!
\file		GameStateMgr.cpp
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh@digipen.edu
\date   	June 11, 2020
\brief		Consists of functions responsible in switching game states

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/
#include "main.h"

// ---------------------------------------------------------------------------
// globals

// variables to keep track the current, previous and next game state
unsigned int	gGameStateInit;
unsigned int	gGameStateCurr;
unsigned int	gGameStatePrev;
unsigned int	gGameStateNext;

// pointer to functions for game state life cycles functions
void (*GameStateLoad)()		= 0;
void (*GameStateInit)()		= 0;
void (*GameStateUpdate)()	= 0;
void (*GameStateDraw)()		= 0;
void (*GameStateFree)()		= 0;
void (*GameStateUnload)()	= 0;

/******************************************************************************/
/*!
	This functions initialize the game state manager.
*/
/******************************************************************************/
void GameStateMgrInit(unsigned int gameStateInit)
{
	// set the initial game state
	gGameStateInit = gameStateInit;

	// reset the current, previoud and next game
	gGameStateCurr = gGameStatePrev;
	gGameStatePrev = gGameStateNext;
	gGameStateNext = gGameStateInit;

	// call the update to set the function pointers
	GameStateMgrUpdate();
}

/******************************************************************************/
/*!
	This function updates the game state manager
*/
/******************************************************************************/
void GameStateMgrUpdate()
{
	if ((gGameStateCurr == GS_RESTART) || (gGameStateCurr == GS_QUIT))
		return;

	switch (gGameStateCurr)
	{
	case GS_ASTEROIDS:
		GameStateLoad = GameStateAsteroidsLoad;			// load game state asteroids
		GameStateInit = GameStateAsteroidsInit;			// Initialize game state asteroids 
		GameStateUpdate = GameStateAsteroidsUpdate;		// Update game state asteroids
		GameStateDraw = GameStateAsteroidsDraw;			// Draw game state asteroids
		GameStateFree = GameStateAsteroidsFree;			// Free game state asteroids
		GameStateUnload = GameStateAsteroidsUnload;		// Unload game state asteroids
		break;

	case GS_RESTART: break;
	case GS_QUIT:	break;
	default:
		AE_FATAL_ERROR("invalid state!!"); break;
	}
}
