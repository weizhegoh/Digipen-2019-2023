/******************************************************************************/
/*!
\file		Main.cpp
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh@digipen.edu
\date   	June 11, 2020
\brief		Consist of the main game loop function of Asteroids

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/

#include "main.h"
#include <memory>

// ---------------------------------------------------------------------------
// Globals
float	 g_dt;
double	 g_appTime;


/******************************************************************************/
/*!
	Starting point of the application
*/
/******************************************************************************/
int WINAPI WinMain(HINSTANCE instanceH, HINSTANCE prevInstanceH, LPSTR command_line, int show)
{
	UNREFERENCED_PARAMETER(prevInstanceH);
	UNREFERENCED_PARAMETER(command_line);

	//// Enable run-time memory check for debug builds.
	#if defined(DEBUG) | defined(_DEBUG)
		_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
	#endif

	//int * pi = new int;

	// Initialize the system
	AESysInit (instanceH, show, 800, 600, 1, 60, false, NULL);

	// Changing the window title
	AESysSetWindowTitle("Asteroids Demo!");

	//set background color
	AEGfxSetBackgroundColor(0.0f, 0.0f, 0.0f);

	GameStateMgrInit(GS_ASTEROIDS);										//Game state manager initialize

	while(gGameStateCurr != GS_QUIT)									//while current not equal to quit game state
	{
		// reset the system modules
		AESysReset();

		// If not restarting, load the gamestate
		if(gGameStateCurr != GS_RESTART)								//if current state not equal to restart game state
		{
			GameStateMgrUpdate();										//Update game state manager. Set function pointers to each new state
			GameStateLoad();											//load game state
		}
		else
			gGameStateNext = gGameStateCurr = gGameStatePrev;			

		// Initialize the gamestate
		GameStateInit();												//Initialise Game State

		while(gGameStateCurr == gGameStateNext)							// if current game state equal to next game state
		{
			AESysFrameStart();											// start frame rate
				
			AEInputUpdate();											// Update Input									

			GameStateUpdate();											// Update game state

			GameStateDraw();											// Draw game state
			
			AESysFrameEnd();											// end frame rate

			// check if forcing the application to quit
			if ((AESysDoesWindowExist() == false) || AEInputCheckTriggered(AEVK_ESCAPE))
				gGameStateNext = GS_QUIT;

			g_dt = (f32)AEFrameRateControllerGetFrameTime();
			g_appTime += g_dt;
		}
		
		GameStateFree();												// free game state

		if(gGameStateNext != GS_RESTART)								// if next game start equal to restart
			GameStateUnload();											// Unload game state

		gGameStatePrev = gGameStateCurr;								// Set previous game state to current
		gGameStateCurr = gGameStateNext;								// Set current game state to next
	}

	// free the system
	AESysExit();
}