/******************************************************************************/
/*!
\file		Collision.h
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh@digipen.edu
\date   	June 11, 2020
\brief		Consist of CollisionIntersection_RectRect function prototype which
			first parameter are of type AABB and second parameter is velocity

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/

#ifndef CS230_COLLISION_H_
#define CS230_COLLISION_H_

#include "AEEngine.h"

/**************************************************************************/
/*!
	Structure definition & Function Prototype
	*/
/**************************************************************************/
struct AABB
{
	//AEVec2	c; // center
	//float  r[2]; // holds half width and half height
	
	AEVec2	min;
	AEVec2	max;
};

bool CollisionIntersection_RectRect(const AABB & aabb1, const AEVec2 & vel1,		//function call to check for collision betwen two objects
									const AABB & aabb2, const AEVec2 & vel2);


#endif // CS230_COLLISION_H_