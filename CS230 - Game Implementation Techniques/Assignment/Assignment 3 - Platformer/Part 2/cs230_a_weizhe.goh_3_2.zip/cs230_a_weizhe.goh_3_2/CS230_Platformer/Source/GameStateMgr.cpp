/******************************************************************************/
/*!
\file		GameStateMgr.cpp
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh@digipen.edu
\date   	July 18, 2020
\brief		Consist of functions responsible in switching game states

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/

#include "main.h"
#include "Level2.h"
#include "Menu.h"

// ---------------------------------------------------------------------------
// globals

// variables to keep track the current, previous and next game state
unsigned int	gGameStateInit;
unsigned int	gGameStateCurr;
unsigned int	gGameStatePrev;
unsigned int	gGameStateNext;

// pointer to functions for game state life cycles functions
void (*GameStateLoad)()		= 0;
void (*GameStateInit)()		= 0;
void (*GameStateUpdate)()	= 0;
void (*GameStateDraw)()		= 0;
void (*GameStateFree)()		= 0;
void (*GameStateUnload)()	= 0;

/******************************************************************************/
/*!
	This function initialize the game state manager.
*/
/******************************************************************************/
void GameStateMgrInit(unsigned int gameStateInit)
{
	// set the initial game state
	gGameStateInit = gameStateInit;

	// reset the current, previoud and next game
	gGameStateCurr = gGameStatePrev;
	gGameStatePrev = gGameStateNext;
	gGameStateNext = gGameStateInit;

	// call the update to set the function pointers
	GameStateMgrUpdate();
}

/******************************************************************************/
/*!
	This function updates the game state manager.
*/
/******************************************************************************/
void GameStateMgrUpdate()
{
	if ((gGameStateCurr == GS_RESTART) || (gGameStateCurr == GS_QUIT))
		return;

	switch (gGameStateCurr)
	{

	case GS_MENU:
		GameStateLoad = Menu_Load;
		GameStateInit = Menu_Init;
		GameStateUpdate = Menu_Update;
		GameStateDraw = Menu_Draw;
		GameStateFree = Menu_Free;
		GameStateUnload = Menu_Unload;
		break;

	case GS_PLATFORM:
		GameStateLoad	= GameStatePlatformLoad;
		GameStateInit	= GameStatePlatformInit;
		GameStateUpdate	= GameStatePlatformUpdate;
		GameStateDraw	= GameStatePlatformDraw;
		GameStateFree	= GameStatePlatformFree;
		GameStateUnload	= GameStatePlatformUnload;
		break;
	
	case GS_LEVEL2:
		GameStateLoad = Level2_Load;
		GameStateInit = Level2_Init;
		GameStateUpdate = Level2_Update;
		GameStateDraw = Level2_Draw;
		GameStateFree = Level2_Free;
		GameStateUnload = Level2_Unload;
		break;

	case GS_RESTART:
		break;

	case GS_QUIT:
		break;

	default:
		AE_FATAL_ERROR("invalid state!!");
	}
}
