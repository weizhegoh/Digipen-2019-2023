/******************************************************************************/
/*!
\file		Level2.cpp
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh@digipen.edu
\date   	July 18, 2020
\brief		Consist of 6 function required for level 2 platform. 

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
 /******************************************************************************/

#include "Level2.h"
#include "main.h"
#include "GameState_Platform.h"

/******************************************************************************/
/*!
	"Load" function of Level 2
*/
/******************************************************************************/
void Level2_Load()
{
	GameStatePlatformLoad();
}

/******************************************************************************/
/*!
	"Initialize" function of Level 2
*/
/******************************************************************************/
void Level2_Init()
{
	GameStatePlatformInit(); 
}

/******************************************************************************/
/*!
	"Update" function of Level 2 
*/
/******************************************************************************/
void Level2_Update()
{
	GameStatePlatformUpdate();
}

/******************************************************************************/
/*!
	Draw all game object instance required for Level 2
*/
/******************************************************************************/
void Level2_Draw()
{
	GameStatePlatformDraw();
}

/******************************************************************************/
/*!
	Free all game object instances at the end of the game 
*/
/******************************************************************************/
void Level2_Free()
{
	GameStatePlatformFree();
}

/******************************************************************************/
/*!
	Unload all game object before termination or to be reinitialized
*/
/******************************************************************************/
void Level2_Unload()
{
	GameStatePlatformUnload();
}