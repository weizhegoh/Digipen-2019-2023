/******************************************************************************/
/*!
\file		Menu.cpp
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh@digipen.edu
\date   	July 18, 2020
\brief		Consist of the all 6 functions required for main menu

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
 /******************************************************************************/

#include "main.h"

extern s8 FontId;

/******************************************************************************/
/*!
	"Load" function for Main Menu
*/
/******************************************************************************/
void Menu_Load()
{

}

/******************************************************************************/
/*!
	"Initialize" function for Main Menu
*/
/******************************************************************************/
void Menu_Init()
{	

}

/******************************************************************************/
/*!
	"Update" function for Main Menu
*/
/******************************************************************************/
void Menu_Update()
{
	if (AEInputCheckCurr(AEVK_1))													//Press 1 to enter level 1
	{
		gGameStateNext = GS_PLATFORM;
	}

	if (AEInputCheckCurr(AEVK_2))													//Press 2 to enter level 2
	{
		gGameStateNext = GS_LEVEL2;
	}

	if (AEInputCheckCurr(AEVK_ESCAPE))												//Press ESCAPE key to Quit game
	{
		gGameStateNext = GS_QUIT;
	}
}

/******************************************************************************/
/*!
	Draw all game object instance required for Main Menu
*/
/******************************************************************************/
void Menu_Draw()
{
	char strBuffer[100], strBuffer2[100], strBuffer3[100], strBuffer4[100];

	memset(strBuffer, 0, 100 * sizeof(char));
	memset(strBuffer2, 0, 100 * sizeof(char));
	memset(strBuffer3, 0, 100 * sizeof(char));
	memset(strBuffer4, 0, 100 * sizeof(char));

	sprintf_s(strBuffer, "Welcome to Platformer!");									
	sprintf_s(strBuffer2, "Press 1 to enter level 1");
	sprintf_s(strBuffer3, "Press 2 to enter level 2");
	sprintf_s(strBuffer4, "Press ESC to quit game");

	AEGfxSetBlendMode(AE_GFX_BM_BLEND);
	AEGfxPrint(FontId, strBuffer, -0.25f, 0.7f, 1.0f, 1.0f, 1.0f, 1.0f);
	AEGfxPrint(FontId, strBuffer2, -0.25f, 0.1f, 1.0f, 1.0f, 1.0f, 1.0f);
	AEGfxPrint(FontId, strBuffer3, -0.25f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f);
	AEGfxPrint(FontId, strBuffer4, -0.25f, -0.7f, 1.0f, 1.0f, 1.0f, 1.0f);
}

/******************************************************************************/
/*!
	"Free" function for Main Menu
*/
/******************************************************************************/
void Menu_Free()
{

}

/******************************************************************************/
/*!
	"Unload" function for Main Menu
*/
/******************************************************************************/
void Menu_Unload()
{

}