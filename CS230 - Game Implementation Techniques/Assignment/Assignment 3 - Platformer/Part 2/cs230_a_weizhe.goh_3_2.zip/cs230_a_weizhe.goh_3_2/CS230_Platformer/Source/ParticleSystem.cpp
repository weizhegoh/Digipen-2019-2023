/******************************************************************************/
/*!
\file		ParticleSystem.cpp
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh@digipen.edu
\date   	July 18, 2020
\brief		Consist of all functions to create particle system

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
 /******************************************************************************/

#include "ParticleSystem.h"
#include "main.h"

/******************************************************************************/
/*!
	"Load" function for particle Mesh and Textures
*/
/******************************************************************************/
void Particle_Load(Particle* particleSyst)
{
	int i;
	for (i = 0; i < NUM_MAX_PARTICLE; ++i)
	{
		AEGfxMeshStart();
		AEGfxTriAdd(
			-0.3f, -0.3f, 0xFFFF0000, 0.0f, 0.0f,
			0.3f, -0.3f, 0xFFFF0000, 0.0f, 0.0f,
			-0.3f, 0.3f, 0xFFFF0000, 0.0f, 0.0f);

		AEGfxTriAdd(
			-0.3f, 0.3f, 0xFFFF0000, 0.0f, 0.0f,
			0.3f, -0.3f, 0xFFFF0000, 0.0f, 0.0f,
			0.3f, 0.3f, 0xFFFF0000, 0.0f, 0.0f);

		particleSyst[i].pMesh = AEGfxMeshEnd();
		AE_ASSERT_MESG(particleSyst[i].pMesh, "fail to create object!!");
	}
}

/******************************************************************************/
/*!
	Spawn Particle according to pHero Position
*/
/******************************************************************************/
void Particle_Spawn(Particle* particleSyst, float posX, float posY)					
{
	int i;
	
	for (i = 0; i < NUM_MAX_PARTICLE; ++i)
	{
		if (particleSyst[i].Flag == 1)
			continue;

		particleSyst[i].position.x = posX + AERandFloat() * 1.0f;
		particleSyst[i].position.y = posY + AERandFloat() * 0.5f;
		particleSyst[i].Flag = 1;
	}
}

/******************************************************************************/
/*!
	"Update" function of Particle System
*/
/******************************************************************************/
void Particle_Update(Particle* particleSyst)
{
	int i;

	for (i = 0; i < NUM_MAX_PARTICLE; ++i)
	{
		if (particleSyst[i].Flag == 0)
			continue;

		(particleSyst[i].size) = particleSyst[i].lifetime;							//particle size decreases and disappear overtime
		AEMtx33 scale, rot, trans;

		AEMtx33Scale(&scale, particleSyst[i].scale * particleSyst[i].size, particleSyst[i].scale * particleSyst[i].size);
		AEMtx33Rot(&rot, particleSyst[i].currdir);
		AEMtx33Trans(&trans, particleSyst[i].position.x, particleSyst[i].position.y);
		
		AEMtx33Concat(&particleSyst[i].Transform, &rot, &scale);
		AEMtx33Concat(&particleSyst[i].Transform, &trans, &particleSyst[i].Transform);

		particleSyst[i].velocity.x = AERandFloat() * 0.1f;
		particleSyst[i].velocity.y = AERandFloat() * 0.05f;

		particleSyst[i].position.x += particleSyst[i].velocity.x;
		particleSyst[i].position.y -= particleSyst[i].velocity.y;

		particleSyst[i].lifetime -= g_dt;

		if (particleSyst[i].lifetime <= 0.0f)
		{
			particleSyst[i].Flag = 0;
			particleSyst[i].lifetime = 1.0f;
		}
	}
}

/******************************************************************************/
/*!
	"Draw" function of Particle System
*/
/******************************************************************************/
void Particle_Draw(Particle* particleSyst)
{
	int i;

	for (i = 0; i < NUM_MAX_PARTICLE; ++i)
	{
		if (particleSyst[i].Flag == 0)
			continue;

		AEMtx33Concat(&particleSyst[i].Transform, &MapTransform, &particleSyst[i].Transform);
		AEGfxSetTransform(particleSyst[i].Transform.m);
		AEGfxMeshDraw(particleSyst[i].pMesh, AE_GFX_MDM_TRIANGLES);
	}
}

/******************************************************************************/
/*!
	Free all game object instances at the end of the game
*/
/******************************************************************************/
void Particle_Free(Particle *particleSyst)
{
	int i;

	for (i = 0; i < NUM_MAX_PARTICLE; ++i)
	{
		AEGfxMeshFree(particleSyst[i].pMesh);
	}
}