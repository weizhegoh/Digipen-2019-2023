/******************************************************************************/
/*!
\file		main.cpp
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh@digipen.edu
\date   	July 18, 2020
\brief		Consist of the main game loop function for Platformer

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/

#include "main.h"
#include <iostream>

// ---------------------------------------------------------------------------
// Globals
float	 g_dt;
double	 g_appTime;
s8		 FontId;

/******************************************************************************/
/*!
	Starting point of the application
*/
/******************************************************************************/
int WINAPI WinMain(HINSTANCE instanceH, HINSTANCE prevInstanceH, LPSTR command_line, int show)
{
#if defined(DEBUG) | defined(_DEBUG)
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif

	UNREFERENCED_PARAMETER(prevInstanceH);
	UNREFERENCED_PARAMETER(command_line);
	// Initialize the system
	AESysInit (instanceH, show, 800, 600, 1, 60, false, NULL);

	// Changing the window title
	AESysSetWindowTitle("CS230_Platformer");

	//set background color
	AEGfxSetBackgroundColor(0.0f, 0.0f, 0.0f);

	FontId = AEGfxCreateFont("Resources/Fonts/Arial Italic.ttf", 20);

	GameStateMgrInit(GS_MENU);											//Game State Manager Initialize

	while(gGameStateCurr != GS_QUIT)									//while current not equal to quit game state
	{
		// reset the system modules
		AESysReset();

		// If not restarting, load the gamestate
		if(gGameStateCurr != GS_RESTART)								//if current state not equal to restart game state
		{
			GameStateMgrUpdate();										//Update game state manager. Set function to each new state
			GameStateLoad();											//load game state
		}
		else
			gGameStateNext = gGameStateCurr = gGameStatePrev;

		// Initialize the gamestate
		GameStateInit();												

		while(gGameStateCurr == gGameStateNext)							//if current game state equal to next game state
		{
			AESysFrameStart();											//start frame rate

			AEInputUpdate();											//Update Input

			GameStateUpdate();											//Update game state

			GameStateDraw();											//Draw game state
			
			AESysFrameEnd();											//end frame rate

			// check if forcing the application to quit
			if ((AESysDoesWindowExist() == false))
				gGameStateNext = GS_QUIT;

			g_dt = (f32)AEFrameRateControllerGetFrameTime();
			g_appTime += g_dt;
		}
		
		GameStateFree();												//free game state

		if(gGameStateNext != GS_RESTART)								//if next game state equal to restart
			GameStateUnload();											//Unload game state

		gGameStatePrev = gGameStateCurr;								//Set previous game state to current
		gGameStateCurr = gGameStateNext;								//Set current game state to next
	}

	// free the system
	AEGfxDestroyFont(FontId);
	AESysExit();
}