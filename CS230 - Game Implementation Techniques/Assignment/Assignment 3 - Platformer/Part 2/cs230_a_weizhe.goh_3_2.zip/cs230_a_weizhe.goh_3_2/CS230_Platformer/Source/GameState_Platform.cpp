/******************************************************************************/
/*!
\file		GameState_Platform.cpp
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh@digipen.edu
\date   	July 18, 2020
\brief		Consist of all functions for level 1 platformer

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/

#include "main.h"
#include <iostream>
#include "ParticleSystem.h"

/******************************************************************************/
/*!
	Defines
*/
/******************************************************************************/
const unsigned int	GAME_OBJ_NUM_MAX		= 32;	//The total number of different objects (Shapes)
const unsigned int	GAME_OBJ_INST_NUM_MAX	= 2048;	//The total number of different game object instances

//Gameplay related variables and values
float				GRAVITY					= -20.0f;
const float			JUMP_VELOCITY			= 11.0f;
const float			MOVE_VELOCITY_HERO		= 4.0f;
const float			MOVE_VELOCITY_ENEMY		= 7.5f;
const double		ENEMY_IDLE_TIME			= 2.0;
const int			HERO_LIVES				= 3;

//Flags
const unsigned int	FLAG_ACTIVE				= 0x00000001;
const unsigned int	FLAG_VISIBLE			= 0x00000002;
const unsigned int	FLAG_NON_COLLIDABLE		= 0x00000004;

//Collision flags
const unsigned int	COLLISION_LEFT			= 0x00000001;	//0001
const unsigned int	COLLISION_RIGHT			= 0x00000002;	//0010
const unsigned int	COLLISION_TOP			= 0x00000004;	//0100
const unsigned int	COLLISION_BOTTOM		= 0x00000008;	//1000

enum TYPE_OBJECT
{
	TYPE_OBJECT_EMPTY,			//0
	TYPE_OBJECT_COLLISION,		//1
	TYPE_OBJECT_HERO,			//2
	TYPE_OBJECT_ENEMY1,			//3
	TYPE_OBJECT_COIN			//4
};

//State machine states
enum class STATE
{
	STATE_NONE,
	STATE_GOING_LEFT,
	STATE_GOING_RIGHT
};

//State machine inner states
enum class INNER_STATE
{
	INNER_STATE_ON_ENTER,
	INNER_STATE_ON_UPDATE,
	INNER_STATE_ON_EXIT
};

/******************************************************************************/
/*!
	Struct/Class Definitions
*/
/******************************************************************************/
struct GameObj
{
	unsigned int		type;		// object type
	AEGfxVertexList *	pMesh;		// pbject
};

struct GameObjInst
{
	GameObj *		pObject;	// pointer to the 'original'
	unsigned int	flag;		// bit flag or-ed together
	float			scale;
	AEVec2			posCurr;	// object current position
	AEVec2			velCurr;	// object current velocity
	float			dirCurr;	// object current direction

	AEMtx33			transform;	// object drawing matrix
	
	AABB			boundingBox;// object bouding box that encapsulates the object

	//Used to hold the current 
	int				gridCollisionFlag;

	// pointer to custom data specific for each object type
	void*			pUserData;

	//State of the object instance
	enum			STATE state;
	enum			INNER_STATE innerState;

	//General purpose counter (This variable will be used for the enemy state machine)
	double			counter;
};

/******************************************************************************/
/*!
	File globals
*/
/******************************************************************************/
static int				HeroLives;
static int				Hero_Initial_X;
static int				Hero_Initial_Y;
static int				TotalCoins;

// list of original objects
static GameObj			*sGameObjList;
static unsigned int		sGameObjNum;

// list of object instances
static GameObjInst		*sGameObjInstList;
static unsigned int		sGameObjInstNum;

//Binary map data
static int				**MapData;
static int				**BinaryCollisionArray;
static int				BINARY_MAP_WIDTH;
static int				BINARY_MAP_HEIGHT;
static GameObjInst		*pBlackInstance;
static GameObjInst		*pWhiteInstance;
AEMtx33					MapTransform;

int						GetCellValue(int X, int Y);
int						CheckInstanceBinaryMapCollision(float PosX, float PosY, 
														float scaleX, float scaleY);
void					SnapToCell(float *Coordinate);
int						ImportMapDataFromFile(char *FileName);
void					FreeMapData(void);

// function to create/destroy a game object instance
static GameObjInst*		gameObjInstCreate (unsigned int type, float scale, 
											AEVec2* pPos, AEVec2* pVel, 
											float dir, enum STATE startState);
static void				gameObjInstDestroy(GameObjInst* pInst);

//We need a pointer to the hero's instance for input purposes
static GameObjInst		*pHero;

//State machine functions
void					EnemyStateMachine(GameObjInst *pInst);

bool					updateLivesScore = TRUE;										// Update Hero lives and Score
static unsigned long	sScore;															// Current Score
static unsigned long	coinsLeft;														// Number of coins left
AEVec2					camPos;															// Camera Position
Particle  		     	myParticle[NUM_MAX_PARTICLE];									// Particle Array

/******************************************************************************/
/*!
	"Load" function of this state
*/
/******************************************************************************/
void GameStatePlatformLoad(void)
{
	sGameObjList = (GameObj *)calloc(GAME_OBJ_NUM_MAX, sizeof(GameObj));
	sGameObjInstList = (GameObjInst *)calloc(GAME_OBJ_INST_NUM_MAX, sizeof(GameObjInst));
	sGameObjNum = 0;

	GameObj* pObj;

	//Creating the black object
	pObj		= sGameObjList + sGameObjNum++;
	pObj->type	= TYPE_OBJECT_EMPTY;

	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFF000000, 0.0f, 0.0f,
		 0.5f,  -0.5f, 0xFF000000, 0.0f, 0.0f, 
		-0.5f,  0.5f, 0xFF000000, 0.0f, 0.0f);
	
	AEGfxTriAdd(
		-0.5f, 0.5f, 0xFF000000, 0.0f, 0.0f,
		 0.5f,  -0.5f, 0xFF000000, 0.0f, 0.0f, 
		0.5f,  0.5f, 0xFF000000, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create object!!");
		
	
	//Creating the white object
	pObj		= sGameObjList + sGameObjNum++;
	pObj->type	= TYPE_OBJECT_COLLISION;

	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFFFFFFFF, 0.0f, 0.0f,
		 0.5f,  -0.5f, 0xFFFFFFFF, 0.0f, 0.0f, 
		-0.5f,  0.5f, 0xFFFFFFFF, 0.0f, 0.0f);
	
	AEGfxTriAdd(
		-0.5f, 0.5f, 0xFFFFFFFF, 0.0f, 0.0f, 
		 0.5f,  -0.5f, 0xFFFFFFFF, 0.0f, 0.0f, 
		0.5f,  0.5f, 0xFFFFFFFF, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create object!!");

	//Creating the hero object
	pObj		= sGameObjList + sGameObjNum++;
	pObj->type	= TYPE_OBJECT_HERO;

	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFF0000FF, 0.0f, 0.0f, 
		 0.5f,  -0.5f, 0xFF0000FF, 0.0f, 0.0f, 
		-0.5f,  0.5f, 0xFF0000FF, 0.0f, 0.0f);
	
	AEGfxTriAdd(
		-0.5f, 0.5f, 0xFF0000FF, 0.0f, 0.0f,
		 0.5f,  -0.5f, 0xFF0000FF, 0.0f, 0.0f, 
		0.5f,  0.5f, 0xFF0000FF, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create object!!");

	//Creating the enemy1 object
	pObj		= sGameObjList + sGameObjNum++;
	pObj->type	= TYPE_OBJECT_ENEMY1;

	AEGfxMeshStart();
	AEGfxTriAdd(
		-0.5f, -0.5f, 0xFFFF0000, 0.0f, 0.0f, 
		 0.5f,  -0.5f, 0xFFFF0000, 0.0f, 0.0f, 
		-0.5f,  0.5f, 0xFFFF0000, 0.0f, 0.0f);
	
	AEGfxTriAdd(
		-0.5f, 0.5f, 0xFFFF0000, 0.0f, 0.0f, 
		 0.5f,  -0.5f, 0xFFFF0000, 0.0f, 0.0f, 
		0.5f,  0.5f, 0xFFFF0000, 0.0f, 0.0f);

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create object!!");

	//Creating the Coin object
	pObj		= sGameObjList + sGameObjNum++;
	pObj->type	= TYPE_OBJECT_COIN;

	AEGfxMeshStart();
	//Creating the circle shape
	int Parts = 12;
	for(float i = 0; i < Parts; ++i)
	{
		AEGfxTriAdd(
		0.0f, 0.0f, 0xFFFFFF00, 0.0f, 0.0f, 
		cosf(i*2*PI/Parts)*0.5f,  sinf(i*2*PI/Parts)*0.5f, 0xFFFFFF00, 0.0f, 0.0f, 
		cosf((i+1)*2*PI/Parts)*0.5f,  sinf((i+1)*2*PI/Parts)*0.5f, 0xFFFFFF00, 0.0f, 0.0f);
	}

	pObj->pMesh = AEGfxMeshEnd();
	AE_ASSERT_MESG(pObj->pMesh, "fail to create object!!");

	Particle_Load(myParticle);

	//Setting intital binary map values
	MapData = 0;
	BinaryCollisionArray = 0;
	BINARY_MAP_WIDTH = 0;
	BINARY_MAP_HEIGHT = 0;

	//Importing Data

	switch (gGameStateCurr)
	{
	case GS_PLATFORM:

		if (!ImportMapDataFromFile("Resources/Levels/Exported.txt"))
		{
			gGameStateNext = GS_QUIT;
		}

		break;

	case GS_LEVEL2:
		if (!ImportMapDataFromFile("Resources/Levels/Exported2.txt"))
		{
			gGameStateNext = GS_QUIT;
		}

		break;
	}

	//Computing the matrix which take a point out of the normalized coordinates system
	//of the binary map
	/***********
	Compute a transformation matrix and save it in "MapTransform".
	This transformation transforms any point from the normalized coordinates system of the binary map.
	Later on, when rendering each object instance, we should concatenate "MapTransform" with the
	object instance's own transformation matrix

	Compute a translation matrix (-Grid width/2, -Grid height/2) and save it in "trans"
	Compute a scaling matrix and save it in "scale")
	Concatenate scale and translate and save the result in "MapTransform"
	***********/
	AEMtx33 scale, trans;

	float x = (float)(BINARY_MAP_WIDTH) / 2;
	float y = (float)(BINARY_MAP_HEIGHT) / 2;

	AEMtx33Trans(&trans, -x, -y);
	AEMtx33Scale(&scale, (float)(AEGetWindowWidth()/BINARY_MAP_WIDTH), (float)(AEGetWindowHeight()/BINARY_MAP_HEIGHT));
	AEMtx33Concat(&MapTransform, &scale, &trans);
}

/******************************************************************************/
/*!
	"Initialize" function of this state
*/
/******************************************************************************/
void GameStatePlatformInit(void)
{
	int i, j;

	pHero = 0;
	pBlackInstance = 0;
	pWhiteInstance = 0;
	TotalCoins = 0;

	//Create an object instance representing the black cell.
	//This object instance should not be visible. When rendering the grid cells, each time we have
	//a non collision cell, we position this instance in the correct location and then we render it
	pBlackInstance = gameObjInstCreate(TYPE_OBJECT_EMPTY, 1.0f, 0, 0, 0.0f, STATE::STATE_NONE);
	pBlackInstance->flag ^= FLAG_VISIBLE;
	pBlackInstance->flag |= FLAG_NON_COLLIDABLE;

	//Create an object instance representing the white cell.
	//This object instance should not be visible. When rendering the grid cells, each time we have
	//a collision cell, we position this instance in the correct location and then we render it
	pWhiteInstance = gameObjInstCreate(TYPE_OBJECT_COLLISION, 1.0f, 0, 0, 0.0f, STATE::STATE_NONE);
	pWhiteInstance->flag ^= FLAG_VISIBLE;
	pWhiteInstance->flag |= FLAG_NON_COLLIDABLE;

	//Setting the inital number of hero lives
	HeroLives = HERO_LIVES;

	GameObjInst *pInst;
	AEVec2 Pos;

	// creating the main character, the enemies and the coins according 
	// to their initial positions in MapData

	/***********
	Loop through all the array elements of MapData 
	(which was initialized in the "GameStatePlatformLoad" function
	from the .txt file
		if the element represents a collidable or non collidable area
			don't do anything

		if the element represents the hero
			Create a hero instance
			Set its position depending on its array indices in MapData
			Save its array indices in Hero_Initial_X and Hero_Initial_Y 
			(Used when the hero dies and its position needs to be reset)

		if the element represents an enemy
			Create an enemy instance
			Set its position depending on its array indices in MapData
			
		if the element represents a coin
			Create a coin instance
			Set its position depending on its array indices in MapData
			
	***********/
	for (i = 0; i < BINARY_MAP_WIDTH; ++i)
	{
		for (j = 0; j < BINARY_MAP_HEIGHT; ++j)
		{
			Pos.x = j + 0.5f;
			Pos.y = i + 0.5f;

			if (MapData[i][j] == TYPE_OBJECT_HERO)
			{
				pHero = gameObjInstCreate(TYPE_OBJECT_HERO, 0.99f, &Pos, 0, 0.0f, STATE::STATE_NONE);
				Hero_Initial_X = (int)Pos.x;
				Hero_Initial_Y = (int)Pos.y;
			}
			else if (MapData[i][j] == TYPE_OBJECT_ENEMY1)
			{
				pInst = gameObjInstCreate(TYPE_OBJECT_ENEMY1, 1.0f, &Pos, 0, 0.0f, STATE::STATE_GOING_LEFT);
			}
			else if (MapData[i][j] == TYPE_OBJECT_COIN)
			{
				++TotalCoins;
				coinsLeft = TotalCoins;
				pInst = gameObjInstCreate(TYPE_OBJECT_COIN, 1.0f, &Pos, 0, 0.0f, STATE::STATE_NONE);
			}
		}
	}
}

/******************************************************************************/
/*!
	"Update" function of this state
*/
/******************************************************************************/
void GameStatePlatformUpdate(void)
{
	int i;
	GameObjInst* pInst;

	//Handle Input
	/***********
	if right is pressed
		Set hero velocity X to MOVE_VELOCITY_HERO
	else
	if left is pressed
		Set hero velocity X to -MOVE_VELOCITY_HERO
	else
		Set hero velocity X to 0

	if space is pressed AND Hero is colliding from the bottom
		Set hero velocity Y to JUMP_VELOCITY

	if Escape is pressed
		Exit to menu
	***********/

	if (gGameStateCurr == GS_LEVEL2)
	{
		AEGfxGetCamPosition(&camPos.x, &camPos.y);

		camPos.x = pHero->posCurr.x;
		camPos.y = pHero->posCurr.y;

		AEVec2Set(&camPos, camPos.x, camPos.y);
		AEMtx33MultVec(&camPos, &MapTransform, &camPos);
		AEGfxSetCamPosition(camPos.x, camPos.y);
	}
	else
	{
		camPos.x = 0.0f;
		camPos.y = 0.0f;
		AEGfxSetCamPosition(camPos.x, camPos.y);
	}

	if (AEInputCheckCurr(AEVK_RIGHT))
	{
		pHero->velCurr.x = MOVE_VELOCITY_HERO;
		Particle_Spawn(myParticle, pHero->posCurr.x, pHero->posCurr.y);
	}
	else if (AEInputCheckCurr(AEVK_LEFT))
	{
		pHero->velCurr.x = -MOVE_VELOCITY_HERO;
		Particle_Spawn(myParticle, pHero->posCurr.x, pHero->posCurr.y);
	}
	else
	{
		pHero->velCurr.x = 0;
	}

	if (gGameStateCurr == GS_LEVEL2)
	{
		if (AEInputCheckTriggered(AEVK_SPACE) && (pHero->gridCollisionFlag |= COLLISION_BOTTOM))
		{
			pHero->velCurr.y = JUMP_VELOCITY;
			Particle_Spawn(myParticle, pHero->posCurr.x, pHero->posCurr.y);
		}
	}
	else if (AEInputCheckTriggered(AEVK_SPACE) && (pHero->gridCollisionFlag &= COLLISION_BOTTOM))
	{
		pHero->velCurr.y = JUMP_VELOCITY;
		Particle_Spawn(myParticle, pHero->posCurr.x, pHero->posCurr.y);
	}

	if (AEInputCheckReleased(AEVK_ESCAPE))
	{
		gGameStateNext = GS_MENU;
		sScore = 0;
	}

	//Update object instances physics and behavior
	for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
	{
		pInst = sGameObjInstList + i;

		// skip non-active object
		if (0 == (pInst->flag & FLAG_ACTIVE))
			continue;

		/****************
		Apply gravity
			Velocity Y = Gravity * Frame Time + Velocity Y

		If object instance is an enemy
			Apply enemy state machine
		****************/

		if (pInst->pObject->type == TYPE_OBJECT_HERO)
		{
			if (gGameStateCurr == GS_LEVEL2)
			{
				GRAVITY = -10.0f;
			}
			else
			{
				GRAVITY = -20.0f;
			}

			Particle_Spawn(myParticle,pHero->posCurr.x, pHero->posCurr.y);

			pInst->velCurr.y += GRAVITY * g_dt;
		}

		if (pInst->pObject->type == TYPE_OBJECT_ENEMY1)
		{
			EnemyStateMachine(pInst);
		}
	}

	Particle_Update(myParticle);

	//Update object instances positions
	for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
	{
		pInst = sGameObjInstList + i;

		// skip non-active object
		if (0 == (pInst->flag & FLAG_ACTIVE))
			continue;

		/**********
		update the position using: P1 = V1*dt + P0
		Get the bouding rectangle of every active instance:
			boundingRect_min = -BOUNDING_RECT_SIZE * instance->scale + instance->pos
			boundingRect_max = BOUNDING_RECT_SIZE * instance->scale + instance->pos
		**********/

		pInst->posCurr.x += pInst->velCurr.x * g_dt;
		pInst->posCurr.y += pInst->velCurr.y * g_dt;

		AEVec2Set(&pInst->boundingBox.min, pInst->posCurr.x + pInst->scale * -0.5f, pInst->posCurr.y + pInst->scale * -0.5f);
		AEVec2Set(&pInst->boundingBox.max, pInst->posCurr.x + pInst->scale * 0.5f, pInst->posCurr.y + pInst->scale * 0.5f);
	}

	//Check for grid collision
	for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
	{
		pInst = sGameObjInstList + i;

		// skip non-active object instances
		if (0 == (pInst->flag & FLAG_ACTIVE))
			continue;

		/*************
		Update grid collision flag

		if collision from bottom
			Snap to cell on Y axis
			Velocity Y = 0

		if collision from top
			Snap to cell on Y axis
			Velocity Y = 0

		if collision from left
			Snap to cell on X axis
			Velocity X = 0

		if collision from right
			Snap to cell on X axis
			Velocity X = 0
		*************/

		pInst->gridCollisionFlag = CheckInstanceBinaryMapCollision(pInst->posCurr.x, pInst->posCurr.y, 1, 1);

		if (pInst->gridCollisionFlag & COLLISION_LEFT)											// Check for Left collision
		{
			SnapToCell(&pInst->posCurr.x);
			pInst->velCurr.x = 0.0f;
		}

		if (pInst->gridCollisionFlag & COLLISION_RIGHT)											// Check for Right collision
		{
			SnapToCell(&pInst->posCurr.x);
			pInst->velCurr.x = 0.0f;
		}

		if (pInst->gridCollisionFlag & COLLISION_TOP)											// Check for Top collision
		{
			SnapToCell(&pInst->posCurr.y);
			pInst->velCurr.y = 0.0f;
		}

		if (pInst->gridCollisionFlag & COLLISION_BOTTOM)										// Check for bottom collision
		{
			SnapToCell(&pInst->posCurr.y);
			pInst->velCurr.y = 0.0f;
		}
	}

	//Checking for collision among object instances:
	//Hero against enemies
	//Hero against coins

	/**********
	for each game object instance
		Skip if it's inactive or if it's non collidable

		If it's an enemy
			If collision between the enemy instance and the hero (rectangle - rectangle)
				Decrement hero lives
				Reset the hero's position in case it has lives left, otherwise RESTART the level

		If it's a coin
			If collision between the coin instance and the hero (rectangle - rectangle)
				Remove the coin and decrement the coin counter.
				Quit the game level to the menu in case no more coins are left
	**********/

	for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
	{
		pInst = sGameObjInstList + i;

		if ((pInst->flag & FLAG_ACTIVE) == 0)													// skip non-active object
			continue;

		if (pInst->pObject->type == TYPE_OBJECT_ENEMY1)
		{
			if (CollisionIntersection_RectRect(pInst->boundingBox, pInst->velCurr, pHero->boundingBox, pHero->velCurr) == TRUE)
			{
				--HeroLives;

				updateLivesScore = TRUE;

				pHero->posCurr.x = (float)Hero_Initial_X + 0.5f;
				pHero->posCurr.y = (float)Hero_Initial_Y;

				if (HeroLives == 0)
				{
					gGameStateNext = GS_MENU;
					sScore = 0;
					coinsLeft = TotalCoins;
				}
			}
		}
		else if (pInst->pObject->type == TYPE_OBJECT_COIN)
		{
			if (CollisionIntersection_RectRect(pInst->boundingBox, pInst->velCurr, pHero->boundingBox, pHero->velCurr) == TRUE)
			{
				++sScore;
				--coinsLeft;

				updateLivesScore = TRUE;

				gameObjInstDestroy(pInst);

				if (gGameStateCurr == GS_PLATFORM && coinsLeft == 0)
				{
					gGameStateNext = GS_LEVEL2;
				}

				if (gGameStateCurr == GS_LEVEL2 && coinsLeft == 0)
				{
					gGameStateNext = GS_MENU;
					sScore = 0;
				}
			}
		}
	}

	//Computing the transformation matrices of the game object instances
	for (i = 0; i < GAME_OBJ_INST_NUM_MAX; ++i)
	{
		AEMtx33 scale, rot, trans, TRANS;
		pInst = sGameObjInstList + i;

		// skip non-active object
		if (0 == (pInst->flag & FLAG_ACTIVE))
			continue;

		AEMtx33Scale(&scale, pInst->scale, pInst->scale);
		AEMtx33Rot(&rot, pInst->dirCurr);
		AEMtx33Trans(&trans, pInst->posCurr.x, pInst->posCurr.y);

		AEMtx33Concat(&TRANS, &rot, &scale);
		AEMtx33Concat(&pInst->transform, &trans, &TRANS);
	}
}

/******************************************************************************/
/*!
	Draw all game object instance required
*/
/******************************************************************************/
void GameStatePlatformDraw(void)
{
	//Drawing the tile map (the grid)
	int i, j;
	AEMtx33 cellTranslation, cellFinalTransformation;

	//Drawing the tile map

	/******REMINDER*****
	You need to concatenate MapTransform with the transformation matrix 
	of any object you want to draw. MapTransform transform the instance 
	from the normalized coordinates system of the binary map
	*******************/

	/*********
	for each array element in BinaryCollisionArray (2 loops)
		Compute the cell's translation matrix acoording to its 
		X and Y coordinates and save it in "cellTranslation"
		Concatenate MapTransform with the cell's transformation 
		and save the result in "cellFinalTransformation"
		Send the resultant matrix to the graphics manager using "AEGfxSetTransform"

		Draw the instance's shape depending on the cell's value using "AEGfxMeshDraw"
			Use the black instance in case the cell's value is TYPE_OBJECT_EMPTY
			Use the white instance in case the cell's value is TYPE_OBJECT_COLLISION
	*********/

	AEGfxSetRenderMode(AE_GFX_RM_COLOR);
	AEGfxTextureSet(NULL, 0, 0);

	for (i = 0; i < BINARY_MAP_WIDTH; ++i)
	{
		for (j = 0; j < BINARY_MAP_HEIGHT; ++j)
		{
			if (BinaryCollisionArray[j][i] == TYPE_OBJECT_EMPTY)
			{
				pBlackInstance->posCurr.x = i + 0.5f;
				pBlackInstance->posCurr.y = j + 0.5f;

				AEMtx33Trans(&cellTranslation, pBlackInstance->posCurr.x, pBlackInstance->posCurr.y);
				AEMtx33Concat(&cellFinalTransformation, &MapTransform, &cellTranslation);
				AEGfxSetTransform(cellFinalTransformation.m);
				AEGfxMeshDraw(pBlackInstance->pObject->pMesh, AE_GFX_MDM_TRIANGLES);
			}
			else if (BinaryCollisionArray[j][i] == TYPE_OBJECT_COLLISION)
			{
				pWhiteInstance->posCurr.x = i + 0.5f;
				pWhiteInstance->posCurr.y = j + 0.5f;

				AEMtx33Trans(&cellTranslation, pWhiteInstance->posCurr.x, pWhiteInstance->posCurr.y);
				AEMtx33Concat(&cellFinalTransformation, &MapTransform, &cellTranslation);
				AEGfxSetTransform(cellFinalTransformation.m);
				AEGfxMeshDraw(pWhiteInstance->pObject->pMesh, AE_GFX_MDM_TRIANGLES);
			}
		}
	}

	//Drawing the object instances
	/**********
	For each active and visible object instance
		Concatenate MapTransform with its transformation matrix
		Send the resultant matrix to the graphics manager using "AEGfxSetTransform"
		Draw the instance's shape using "AEGfxMeshDraw"
	**********/
	for (i = 0; i < GAME_OBJ_INST_NUM_MAX; i++)
	{
		GameObjInst* pInst = sGameObjInstList + i;

		// skip non-active object
		if (0 == (pInst->flag & FLAG_ACTIVE) || 0 == (pInst->flag & FLAG_VISIBLE))
			continue;
		
		//Don't forget to concatenate the MapTransform matrix with the transformation of each game object instance

		AEMtx33Concat(&pInst->transform, &MapTransform, &pInst->transform);
		AEGfxSetTransform(pInst->transform.m);
		AEGfxMeshDraw(pInst->pObject->pMesh, AE_GFX_MDM_TRIANGLES);
	}

	Particle_Draw(myParticle);
	
	if (updateLivesScore)
	{
		char strBuffer[100], strBuffer2[100], strBuffer3[100];

		memset(strBuffer, 0, 100 * sizeof(char));
		memset(strBuffer2, 0, 100 * sizeof(char));
		memset(strBuffer3, 0, 100 * sizeof(char));

		if (HeroLives == 0)
		{
			printf("You Lose!\n\n");
		}
		else if (gGameStateCurr == GS_LEVEL2 && coinsLeft == 0)
		{
			printf("You Win!\n\n");
		}
		else
		{
			sprintf_s(strBuffer, "Lives:  %i", HeroLives);
			//AEGfxPrint(650, 30, (u32)-1, strBuffer);	
			printf("%s \n", strBuffer);

			sprintf_s(strBuffer2, "Score:  %i", sScore);
			printf("%s \n", strBuffer2);

			sprintf_s(strBuffer3, "Coins Left:  %i", coinsLeft);
			printf("%s \n\n", strBuffer3);
		}

		updateLivesScore = FALSE;
	}
}

/******************************************************************************/
/*!
	Free all game object instances at the end of the game
*/
/******************************************************************************/
void GameStatePlatformFree(void)
{
	// kill all object in the list
	for (unsigned int i = 0; i < GAME_OBJ_INST_NUM_MAX; i++)
		gameObjInstDestroy(sGameObjInstList + i);
}

/******************************************************************************/
/*!
	Unload all game object before termination or to be reinitialized
*/
/******************************************************************************/
void GameStatePlatformUnload(void)
{
	// free all CREATED mesh
	for (u32 i = 0; i < sGameObjNum; i++)
		AEGfxMeshFree(sGameObjList[i].pMesh);

	/*********
	Free the map data
	*********/
	FreeMapData();
	Particle_Free(myParticle);
	free(sGameObjInstList);
	free(sGameObjList);
}

/******************************************************************************/
/*!
	Create new object instance
*/
/******************************************************************************/
GameObjInst* gameObjInstCreate(unsigned int type, float scale, 
							   AEVec2* pPos, AEVec2* pVel, 
							   float dir, enum STATE startState)
{
	AEVec2 zero;
	AEVec2Zero(&zero);

	AE_ASSERT_PARM(type < sGameObjNum);
	
	// loop through the object instance list to find a non-used object instance
	for (unsigned int i = 0; i < GAME_OBJ_INST_NUM_MAX; i++)
	{
		GameObjInst* pInst = sGameObjInstList + i;

		// check if current instance is not used
		if (pInst->flag == 0)
		{
			// it is not used => use it to create the new instance
			pInst->pObject			 = sGameObjList + type;
			pInst->flag				 = FLAG_ACTIVE | FLAG_VISIBLE;
			pInst->scale			 = scale;
			pInst->posCurr			 = pPos ? *pPos : zero;
			pInst->velCurr			 = pVel ? *pVel : zero;
			pInst->dirCurr			 = dir;
			pInst->pUserData		 = 0;
			pInst->gridCollisionFlag = 0;
			pInst->state			 = startState;
			pInst->innerState		 = INNER_STATE::INNER_STATE_ON_ENTER;
			pInst->counter			 = 0;
			
			// return the newly created instance
			return pInst;
		}
	}

	return 0;
}

/******************************************************************************/
/*!
	Kill each active game object instance
*/
/******************************************************************************/
void gameObjInstDestroy(GameObjInst* pInst)
{
	// if instance is destroyed before, just return
	if (pInst->flag == 0)
		return;

	// zero out the flag
	pInst->flag = 0;
}

/******************************************************************************/
/*!
	This function retrieves the value of the element (X;Y) in BinaryCollisionArray.
	Before retrieving the value, it should check that the supplied X and Y values
	are not out of bounds (in that case return 0)
 */
 /******************************************************************************/
int GetCellValue(int X, int Y)
{
	int cellValue = 0;

	if (X < 0 || Y < 0 || X >= BINARY_MAP_WIDTH || Y >= BINARY_MAP_HEIGHT)
	{
		return 0;
	}
	else
	{
		cellValue = BinaryCollisionArray[Y][X];
		return cellValue;
	}
}

/******************************************************************************/
/*!
	This function creates 2 hot spots on each side of the object instance,
	and checks if each of these hot spots is in a collision area (which means
	the cell if falls in has a value of 1).
	At the beginning of the function, a "Flag" integer should be initialized to 0.
	Each time a hot spot is in a collision area, its corresponding bit
	in "Flag" is set to 1.
	Finally, the function returns the integer "Flag"
	The position of the object instance is received as PosX and PosY
	The size of the object instance is received as scaleX and scaleY

	Note: This function assume the object instance's size is 1 by 1
		  (the size of 1 tile)

	Creating the hotspots:
		-Handle each side separately.
		-2 hot spots are needed for each collision side.
		-These 2 hot spots should be positioned on 1/4 above the center
		and 1/4 below the center

	Example: Finding the hots spots on the left side of the object instance

	float x1, y1, x2, y2;

	-hotspot 1
	x1 = PosX + scaleX/2	To reach the right side
	y1 = PosY + scaleY/4	To go up 1/4 of the height

	-hotspot 2
	x2 = PosX + scaleX/2	To reach the right side
	y2 = PosY - scaleY/4	To go down 1/4 of the height
 */
 /******************************************************************************/
int CheckInstanceBinaryMapCollision(float PosX, float PosY, float scaleX, float scaleY)
{
	//At the end of this function, "Flag" will be used to determine which sides
	//of the object instance are colliding. 2 hot spots will be placed on each side.

	int FLAG = 0;
	float x1 = 0.0f, y1 = 0.0f, x2 = 0.0f, y2 = 0.0f;

	x1 = PosX - scaleX / 2.0f;											//left-top hotspot
	y1 = PosY + scaleY / 4.0f;

	x2 = PosX - scaleX / 2.0f;											//left-btm hotspot
	y2 = PosY - scaleY / 4.0f;


	if (GetCellValue((int)x1, (int)y1) || GetCellValue((int)x2, (int)y2))
	{
		FLAG |= COLLISION_LEFT;

	}

	x1 = PosX + scaleX / 2.0f;											//right-top hotspot
	y1 = PosY + scaleY / 4.0f;

	x2 = PosX + scaleX / 2.0f;											//right-btm hotspot
	y2 = PosY - scaleY / 4.0f;

	if (GetCellValue((int)x1, (int)y1) || GetCellValue((int)x2, (int)y2))
	{
		FLAG |= COLLISION_RIGHT;

	}

	x1 = PosX - scaleX / 4.0f;											//top-left hotspot
	y1 = PosY + scaleY / 2.0f;

	x2 = PosX + scaleX / 4.0f;											//top-right hotspot
	y2 = PosY + scaleY / 2.0f;

	if (GetCellValue((int)x1, (int)y1) || GetCellValue((int)x2, (int)y2))
	{
		FLAG |= COLLISION_TOP;

	}

	x1 = PosX - scaleX / 4.0f;											//btm-left hotspot 
	y1 = PosY - scaleY / 2.0f;

	x2 = PosX + scaleX / 4.0f;											//btm-right hotspot
	y2 = PosY - scaleY / 2.0f;

	if (GetCellValue((int)x1, (int)y1) || GetCellValue((int)x2, (int)y2))
	{
		FLAG |= COLLISION_BOTTOM;
	}

	return FLAG;
}

/******************************************************************************/
/*!
	This function snaps the value sent as parameter to the center of the cell.
	It is used when a sprite is colliding with a collision area from one
	or more side.
	To snap the value sent by "Coordinate", find its integral part by type
	casting it to an integer, then add 0.5 (which is half the cell's width
	or height)
 */
 /******************************************************************************/

void SnapToCell(float *Coordinate)
{
	*Coordinate = (int)(*Coordinate) + 0.5f;
}
/******************************************************************************/
/*!
	This function opens the file name "FileName" and retrieves all the map data.
	It allocates memory for the 2 arrays: MapData & BinaryCollisionArray
	The first line in this file is the width of the map.
	The second line in this file is the height of the map.
	The remaining part of the file is a series of numbers
	Each number represents the ID (or value) of a different element in the
	double dimensionaly array.

	Example:

	Width 5
	Height 5
	1 1 1 1 1
	1 1 1 3 1
	1 4 2 0 1
	1 0 0 0 1
	1 1 1 1 1


	After importing the above data, "MapData" and " BinaryCollisionArray"
	should be

	1 1 1 1 1
	1 1 1 3 1
	1 4 2 0 1
	1 0 0 0 1
	1 1 1 1 1

	and

	1 1 1 1 1
	1 1 1 0 1
	1 0 0 0 1
	1 0 0 0 1
	1 1 1 1 1

	respectively.

	Finally, the function returns 1 if the file named "FileName" exists,
	otherwise it returns 0
 */
 /******************************************************************************/
int ImportMapDataFromFile(char *FileName)
{
	int i, j;

	if (FileName == NULL)
	{
		std::cout << "FileName is NULL" << std::endl;
		return 0;													//return 0 if FileName is NULL				
	}

	FILE* file = NULL;

	fopen_s(&file, FileName, "r");

	if (!file)
	{
		std::cout << "File not found" << std::endl;
		return 0;													//return 0 if file not found			
	}

	fscanf_s(file, "Width %d\n", &BINARY_MAP_WIDTH);
	fscanf_s(file, "Height %d\n", &BINARY_MAP_HEIGHT);

	if (BINARY_MAP_HEIGHT <= 0 || BINARY_MAP_WIDTH <= 0)
	{
		std::cout << "Map height or width less or equal to zero" << std::endl;
		return 0;													//return 0 if map height or width is zero
	}

	//mapData[y][x]
	MapData = new int* [BINARY_MAP_HEIGHT];							//Y axis or row 

	//binaryCollisionArray[y][x]
	BinaryCollisionArray = new int* [BINARY_MAP_HEIGHT];			//X axis or column

	for (i = 0; i < BINARY_MAP_HEIGHT; ++i)
	{
		MapData[i] = new int[BINARY_MAP_WIDTH];
		BinaryCollisionArray[i] = new int[BINARY_MAP_WIDTH];
	}

	for (i = 0; i < BINARY_MAP_HEIGHT; ++i)
	{
		for (j = 0; j < BINARY_MAP_WIDTH; ++j)
		{
			fscanf_s(file, "%d ", &MapData[i][j]);

			if (MapData[i][j] != 1)
			{
				BinaryCollisionArray[i][j] = 0;
			}
			else
			{
				BinaryCollisionArray[i][j] = 1;
			}
		}
	}

	fclose(file);

	return 1;														//return 1 when function succeed
}

/******************************************************************************/
/*!
	This function frees the memory that was allocated for the 2 arrays MapData
	& BinaryCollisionArray which was allocated in the "ImportMapDataFromFile"
	function
 */
 /******************************************************************************/
void FreeMapData(void)
{
	int i;

	for (i = 0; i < BINARY_MAP_HEIGHT; ++i)
	{
		delete[] BinaryCollisionArray[i];
		delete[] MapData[i];
	}

	delete[] BinaryCollisionArray;
	delete[] MapData;
}

/******************************************************************************/
/*!
	Set state machine and inner states of Enemies
*/
/******************************************************************************/
void EnemyStateMachine(GameObjInst *pInst)
{
	/***********
	This state machine has 2 states: STATE_GOING_LEFT and STATE_GOING_RIGHT
	Each state has 3 inner states: INNER_STATE_ON_ENTER, INNER_STATE_ON_UPDATE, INNER_STATE_ON_EXIT
	Use "switch" statements to determine which state and inner state the enemy is currently in.


	STATE_GOING_LEFT
		INNER_STATE_ON_ENTER
			Set velocity X to -MOVE_VELOCITY_ENEMY 
			Set inner state to "on update"

		INNER_STATE_ON_UPDATE
			If collision on left side OR bottom left cell is non collidable
				Initialize the counter to ENEMY_IDLE_TIME
				Set inner state to on exit
				Set velocity X to 0


		INNER_STATE_ON_EXIT
			Decrement counter by frame time
			if counter is less than 0 (sprite's idle time is over)
				Set state to "going right"
				Set inner state to "on enter"

	STATE_GOING_RIGHT is basically the same, with few modifications.

	***********/

	switch (pInst->state)
	{
	case STATE::STATE_GOING_LEFT:

		switch (pInst->innerState)
		{
		case INNER_STATE::INNER_STATE_ON_ENTER:

			pInst->velCurr.x = -MOVE_VELOCITY_ENEMY;
			pInst->innerState = INNER_STATE::INNER_STATE_ON_UPDATE;
			break;

		case INNER_STATE::INNER_STATE_ON_UPDATE:

			if (pInst->gridCollisionFlag & COLLISION_LEFT ||
				GetCellValue((int)(pInst->posCurr.x - 0.6), (int)(pInst->posCurr.y - 1)) != 1)
			{
				pInst->velCurr.x = 0;
				pInst->counter = ENEMY_IDLE_TIME;
				pInst->innerState = INNER_STATE::INNER_STATE_ON_EXIT;
			}

			break;

		case INNER_STATE::INNER_STATE_ON_EXIT:

			pInst->counter -= g_dt;

			if (pInst->counter < 0)
			{
				pInst->state = STATE::STATE_GOING_RIGHT;
				pInst->innerState = INNER_STATE::INNER_STATE_ON_ENTER;
			}

			break;
		}

		break;
	
	case STATE::STATE_GOING_RIGHT:

		switch (pInst->innerState)
		{
		case INNER_STATE::INNER_STATE_ON_ENTER:

			pInst->velCurr.x = MOVE_VELOCITY_ENEMY;
			pInst->innerState = INNER_STATE::INNER_STATE_ON_UPDATE;
			break;

		case INNER_STATE::INNER_STATE_ON_UPDATE:

			if (pInst->gridCollisionFlag & COLLISION_RIGHT ||
				GetCellValue((int)(pInst->posCurr.x + 0.6), (int)(pInst->posCurr.y - 1)) != 1 )
			{
				pInst->velCurr.x = 0;
				pInst->counter = ENEMY_IDLE_TIME;
				pInst->innerState = INNER_STATE::INNER_STATE_ON_EXIT;
			}

			break;

		case INNER_STATE::INNER_STATE_ON_EXIT:

			pInst->counter -= g_dt;

			if (pInst->counter < 0)
			{
				pInst->state = STATE::STATE_GOING_LEFT;
				pInst->innerState = INNER_STATE::INNER_STATE_ON_ENTER;
			}
			
			break;
		}
		break;
	}
}