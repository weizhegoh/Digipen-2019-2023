/******************************************************************************/
/*!
\file		ParticleSystem.h
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh@digipen.edu
\date   	July 18, 2020
\brief		Consist of all functions prototypes and structures to create particle 
			System

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
 /******************************************************************************/

#ifndef CS230_PARTICLE_SYSTEM_H_
#define CS230_PARTICLE_SYSTEM_H_

#include "main.h"

#define NUM_MAX_PARTICLE 100

struct Particle
{
	AEVec2 velocity = { 0.0f , 0.0f };				//Particle speed
	AEVec2 position	= { 0.0f , 0.0f };				//Particle position

	float lifetime = 1.0f;							//Particle lifetime
	float size = 0.0f;								//Particle size
	float currdir = 0.0f;							//Particle current direction
	float scale = 0.05f;							//Particle scale

	int Flag = 0;									

	AEMtx33 Transform = {0.0f, 0.0f };
	AEGfxVertexList* pMesh = nullptr;
};

void Particle_Load(Particle* particleSyst);
void Particle_Spawn(Particle* particleSyst, float posX, float posY);
void Particle_Update(Particle* particleSyst);
void Particle_Draw(Particle* particleSyst);
void Particle_Free(Particle* particleSyst);

#endif	//CS230_PARTICLE_SYSTEM_H_