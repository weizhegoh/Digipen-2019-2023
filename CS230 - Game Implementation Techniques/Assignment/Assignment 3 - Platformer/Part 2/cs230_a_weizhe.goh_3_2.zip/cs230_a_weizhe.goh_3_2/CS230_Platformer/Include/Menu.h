/******************************************************************************/
/*!
\file		Menu.h
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh@digipen.edu
\date   	July 18, 2020
\brief		Consist of the all 6 functions prototypes required for main menu

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
 /******************************************************************************/

#ifndef CS230_MENU_H_
#define CS230_MENU_H_

void Menu_Load();
void Menu_Init();
void Menu_Update();
void Menu_Draw();
void Menu_Free();
void Menu_Unload();

#endif	//CS230_MENU_H_
