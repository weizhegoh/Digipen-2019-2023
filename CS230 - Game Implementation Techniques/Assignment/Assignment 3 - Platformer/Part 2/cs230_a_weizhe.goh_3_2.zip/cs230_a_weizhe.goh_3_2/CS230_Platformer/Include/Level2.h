/******************************************************************************/
/*!
\file		Level2.h
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh@digipen.edu
\date   	July 18, 2020
\brief		Consist of 6 function prototype required for level 2 platform.

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
 /******************************************************************************/

#ifndef CS230_LEVEL2_H_
#define CS230_LEVEL2_H_

void Level2_Load();
void Level2_Init();
void Level2_Update();
void Level2_Draw();
void Level2_Free();
void Level2_Unload();

#endif //CS230_LEVEL2_H_