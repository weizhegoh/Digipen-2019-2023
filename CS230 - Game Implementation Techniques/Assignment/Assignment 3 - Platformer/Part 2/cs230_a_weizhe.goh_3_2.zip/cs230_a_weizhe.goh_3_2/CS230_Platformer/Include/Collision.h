/******************************************************************************/
/*!
\file		Collision.h
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh@digipen.edu
\date   	July 18, 2020
\brief		Consist of CollisionIntersection_RectRect function prototype

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/

#ifndef CS230_COLLISION_H_
#define CS230_COLLISION_H_

/**************************************************************************/
/*!
	Structure definition & Function Prototype
	*/
/**************************************************************************/
struct AABB
{
	AEVec2	min;
	AEVec2	max;
};

bool CollisionIntersection_RectRect(const AABB &aabb1, const AEVec2 &vel1,		//function call for collision between two objects
									const AABB &aabb2, const AEVec2 &vel2);


#endif // CS230_COLLISION_H_