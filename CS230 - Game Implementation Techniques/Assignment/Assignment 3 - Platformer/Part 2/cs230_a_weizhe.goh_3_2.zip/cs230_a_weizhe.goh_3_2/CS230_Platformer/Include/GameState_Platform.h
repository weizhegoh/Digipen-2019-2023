/******************************************************************************/
/*!
\file		GameState_Platform.h
\author 	Goh Wei Zhe, weizhe.goh, 440000119
\par    	email: weizhe.goh@digipen.edu
\date   	July 18, 2020
\brief		Consist of 6 functions to load, initialize, update, draw, free and 
			unload platform

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
 */
/******************************************************************************/

#ifndef CS230_GAME_STATE_PLAY_H_
#define CS230_GAME_STATE_PLAY_H_

extern AEMtx33 MapTransform;

// ---------------------------------------------------------------------------

void GameStatePlatformLoad(void);
void GameStatePlatformInit(void);
void GameStatePlatformUpdate(void);
void GameStatePlatformDraw(void);
void GameStatePlatformFree(void);
void GameStatePlatformUnload(void);

// ---------------------------------------------------------------------------

#endif // CS230_GAME_STATE_PLAY_H_