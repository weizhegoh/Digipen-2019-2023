/* Start Header ************************************************************************/
/*!
\file	Level1.cpp
\author Goh Wei Zhe , weizhe.goh, 440000119
\par    weizhe.goh@digipen.edu
\date   June 4, 2020
\brief  Consist main of Level 1 game state function to be called from other files 
		to load, initialize, update, draw, free	and unload its data.

Copyright (C) 20xx DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents
without the prior written consent of DigiPen Institute of
Technology is prohibited.
*/
/* End Header **************************************************************************/

#include <iostream>
#include "pch.h"
#include "System.h"
#include "Level1.h"
#include "GameStateManager.h"

int Level1_Counter;

// ----------------------------------------------------------------------------
// This function loads all necessary assets in Level 1
// It should be called once before the start of the level
// It loads assets like textures, meshes and music files etc�
// ----------------------------------------------------------------------------
void Leve1_Load()
{
	int counter = 0;
	std::ifstream readFile;
	readFile.open("../Data/Level1_Counter.txt");

	if (!readFile)
	{
		myFile << "Unable to open Level1_Counter" << std::endl;
	}
	else
	{
		while (readFile >> counter)
		{
			Level1_Counter = counter;
		}
			myFile << "Level1:Load" << std::endl;

	}
}

// ----------------------------------------------------------------------------
// This function initialize objects needed in Level 1 such as lives such as 
// initializing the number of lives to 3 each time.
// Used to prepare the states data in order to be used for the first time
// It loads no data
// If state is restarted, this cycle function is used
// ----------------------------------------------------------------------------
void Leve1_Initialize()
{
	myFile << "Level1:Initialize" << std::endl;
}

// ----------------------------------------------------------------------------
// This function updates user inputs, game logic or gameplay in Level 1 such as
// updating number of lives, decrementing or increasing it.
// ----------------------------------------------------------------------------
void Leve1_Update()
{
	--Level1_Counter;

	if (Level1_Counter == 0)
	{
		next = GS_LEVEL2;
	}
	myFile << "Level1:Update" << std::endl;
}

// ----------------------------------------------------------------------------
// This function draws draw such as meshes and textures in Level 1
// Sends data to the graphics engine component
// ----------------------------------------------------------------------------
void Leve1_Draw()
{
	myFile << "Level1:Draw" << std::endl;
}

// ----------------------------------------------------------------------------
// This function clears up state of level 1 so that it can be ready to be 
// unloaded or initialized again.
// No data is dumped in this function
// ----------------------------------------------------------------------------
void Leve1_Free()
{
	myFile << "Level1:Free" << std::endl;
}

// ----------------------------------------------------------------------------
// This function is called when the level 1 state should be terminated.
// It dumps back all the data that was loaded in the state load function.
// ----------------------------------------------------------------------------
void Leve1_Unload()
{
	myFile << "Level1:Unload" << std::endl;
}