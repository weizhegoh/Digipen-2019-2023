/* Start Header ************************************************************************/
/*!
\file	GameStateList.h
\author Goh Wei Zhe , weizhe.goh, 440000119
\par    weizhe.goh@digipen.edu
\date   June 4, 2020
\brief  Includes an enumeration consisting of all possible level states and other special 
		stats like start and restart. 

Copyright (C) 20xx DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents
without the prior written consent of DigiPen Institute of
Technology is prohibited.
*/
/* End Header **************************************************************************/

#pragma once
#ifndef  GAMESTATELIST_H
#define  GAMESTATELIST_H

enum GS_STATES			//enumeration of all game states
{
	GS_LEVEL1 = 0,
	GS_LEVEL2,

	GS_QUIT,
	GS_RESTART
};

#endif