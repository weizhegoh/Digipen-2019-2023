/* Start Header ************************************************************************/
/*!
\file	GameStateManager.cpp
\author Goh Wei Zhe , weizhe.goh, 440000119
\par    weizhe.goh@digipen.edu
\date   June 4, 2020
\brief  Game State Manager responsible of Initializing Game State, switching the game loop
		and frame rate controller. Consist of 6 cycle functions: Load, Initialize, Update, 
		Draw, Free, Unload. 

Copyright (C) 20xx DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents
without the prior written consent of DigiPen Institute of
Technology is prohibited.
*/
/* End Header **************************************************************************/

#include "pch.h"
#include "GameStateManager.h"
#include "Level1.h"
#include "Level2.h"
#include "System.h"

int current = 0, previous = 0, next = 0;

FP fpLoad = nullptr, fpInitialize = nullptr, fpUpdate = nullptr, fpDraw = nullptr, fpFree = nullptr, fpUnload = nullptr;

// ----------------------------------------------------------------------------
// This function initialize the game state manager
// Sets the previous, current and next indicator to initial stating state.
// ----------------------------------------------------------------------------
void GSM_Initialize(int startingState)
{
	current = previous = next = startingState;
	
	myFile << "GSM:Initialize" << std::endl;
}

// ----------------------------------------------------------------------------
// This function updates the game state manager
// Set function pointers to the appropriate function each time we change a new
// state level
// ----------------------------------------------------------------------------
void GSM_Update()
{
	myFile << "GSM:Update" << std::endl;

	switch (current)
	{
	case GS_LEVEL1:		
		fpLoad = Leve1_Load;
		fpInitialize = Leve1_Initialize;
		fpUpdate = Leve1_Update;
		fpDraw = Leve1_Draw;
		fpFree = Leve1_Free;
		fpUnload = Leve1_Unload;
		break;
	case GS_LEVEL2:
		fpLoad = Leve2_Load;
		fpInitialize = Leve2_Initialize;
		fpUpdate = Leve2_Update;
		fpDraw = Leve2_Draw;
		fpFree = Leve2_Free;
		fpUnload = Leve2_Unload;
		break;
	case GS_RESTART:
		break;
	case GS_QUIT:
		break;
	default:
		break;
	}
}