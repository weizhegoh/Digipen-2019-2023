/* Start Header ************************************************************************/
/*!
\file	System.cpp
\author Goh Wei Zhe , weizhe.goh, 440000119
\par    weizhe.goh@digipen.edu
\date   June 4, 2020
\brief  System to handle initializing input manager, graphics manager, etc and to terminate
		program. 

Copyright (C) 20xx DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents
without the prior written consent of DigiPen Institute of
Technology is prohibited.
*/
/* End Header **************************************************************************/

#include <iostream>
#include "pch.h"
#include  "System.h"

std::ofstream myFile;

// ----------------------------------------------------------------------------
// This function intitialize the game system such as background colour, 
// console size etc.
// ----------------------------------------------------------------------------
void System_Initialize()
{
	myFile.open("../Data/Output.txt");

	if (!myFile)
	{
		myFile << "Unabe to open Output.txt" << std::endl;
	}
	else
	{
		myFile << "System:Initialize" << std::endl;
	}
}

// ----------------------------------------------------------------------------
// This function terminates and closes the game system
// ----------------------------------------------------------------------------
void System_Exit()
{
	myFile << "System:Exit" << std::endl;
	myFile.close();
}