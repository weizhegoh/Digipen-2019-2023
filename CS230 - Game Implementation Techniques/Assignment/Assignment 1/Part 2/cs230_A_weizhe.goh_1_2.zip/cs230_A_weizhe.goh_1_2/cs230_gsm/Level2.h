/* Start Header ************************************************************************/
/*!
\file	Level2.h
\author Goh Wei Zhe , weizhe.goh, 440000119
\par    weizhe.goh@digipen.edu
\date   June 4, 2020
\brief  Consist of Load, Initialise, Update, Draw, Free and Unload of Level 2 to be included
		in other files.

Copyright (C) 20xx DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents
without the prior written consent of DigiPen Institute of
Technology is prohibited.
*/
/* End Header **************************************************************************/

#pragma once
#ifndef LEVEL2_H
#define LEVEL2_H

void Leve2_Load();			//Load neccessary data and initialise it in Level 2.

void Leve2_Initialize();	//Prepares the level 2 state data in order to be use for the first time

void Leve2_Update();		//Updates level 2 state data like user input, time, or gameplay logic

void Leve2_Draw();			//Sends Level 2 data to the graphic engine component and renders it

void Leve2_Free();			//Clean up level 2 state. Make state ready to be unloaded or initialized again

void Leve2_Unload();		//Terminate Level 2.

#endif
