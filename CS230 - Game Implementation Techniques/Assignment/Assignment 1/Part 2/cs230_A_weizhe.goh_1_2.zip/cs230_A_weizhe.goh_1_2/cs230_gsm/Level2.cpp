/* Start Header ************************************************************************/
/*!
\file	Level2.cpp
\author Goh Wei Zhe , weizhe.goh, 440000119
\par    weizhe.goh@digipen.edu
\date   June 4, 2020
\brief  Consist main function of Load, Initialise, Update, Draw, Free and Unload of Level 2
		to be called from other files.

Copyright (C) 20xx DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents
without the prior written consent of DigiPen Institute of
Technology is prohibited.
*/
/* End Header **************************************************************************/

#include <iostream>
#include "pch.h"
#include "Level2.h"
#include "System.h"
#include "GameStateManager.h"

int Level2_Counter, Level2_Lives;

// ----------------------------------------------------------------------------
// This function loads all necessary assets in Level 2
// It should be called once before the start of the leve2
// It loads assets like textures, meshes and music files etc�
// ----------------------------------------------------------------------------
void Leve2_Load()
{
	int lives = 0;
	std::ifstream readFile;
	readFile.open("../Data/Level2_Lives.txt");

	if (!readFile)
	{
		myFile << "Unable to open Level2_Lives" << std::endl;
	}
	else
	{
		while (readFile >> lives)
		{
			Level2_Lives = lives;
		}
		myFile << "Level2:Load" << std::endl;
	}

}

// ----------------------------------------------------------------------------
// This function initialize objects needed in Level 2 such as number of lives to 3
// each time. 
// Used to prepare the states data in order to be used for the first time
// It loads no data
// If state is restarted, this cycle function is used
// ----------------------------------------------------------------------------
void Leve2_Initialize()
{
	int counter = 0;
	std::ifstream readFile;
	readFile.open("../Data/Level2_Counter.txt");

	if (!readFile)
	{
		myFile << "Unable to open Level2_Counter" << std::endl;
	}
	else
	{
		while (readFile >> counter)
		{
			Level2_Counter = counter;
		}
		myFile << "Level2:Initialize" << std::endl;
	}
}

// ----------------------------------------------------------------------------
// This function updates user inputs, game logic or gameplay in Level 2 such as
// updating number of lives, decrementing or increasing it.
// ----------------------------------------------------------------------------
void Leve2_Update()
{
	Level2_Counter--;

	if (Level2_Counter == 0)
	{
		Level2_Lives--;
	}
	
	if (Level2_Lives == 0 )
	{
		next = GS_QUIT;
	}

	if (Level2_Lives > 0 && Level2_Counter == 0)
	{
		next = GS_RESTART; 
	}

	myFile << "Level2:Update" << std::endl;
}

// ----------------------------------------------------------------------------
// This function draws draw such as meshes and textures in Level 2
// Sends data to the graphics engine component
// ----------------------------------------------------------------------------
void Leve2_Draw()
{
	myFile << "Level2:Draw" << std::endl;
}

// ----------------------------------------------------------------------------
// This function clears up state of level 2 so that it can be ready to be 
// unloaded or initialized again.
// No data is dumped in this function
// ----------------------------------------------------------------------------
void Leve2_Free()
{
	myFile << "Level2:Free" << std::endl;
}

// ----------------------------------------------------------------------------
// This function is called when the level 2 state should be terminated.
// It dumps back all the data that was loaded in the state load function.
// ----------------------------------------------------------------------------
void Leve2_Unload()
{
	myFile << "Level2:Unload" << std::endl;
}