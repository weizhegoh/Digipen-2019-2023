/* Start Header ************************************************************************/
/*!
\file	pch.cpp
\author Goh Wei Zhe , weizhe.goh, 440000119
\par    weizhe.goh@digipen.edu
\date   June 4, 2020
\brief  source file corresponding to the pre-compiled header

Copyright (C) 20xx DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents
without the prior written consent of DigiPen Institute of
Technology is prohibited.
*/
/* End Header **************************************************************************/

#include "pch.h"

// When you are using pre-compiled headers, this source file is necessary for compilation to succeed.
