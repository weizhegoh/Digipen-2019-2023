/* Start Header ************************************************************************/
/*!
\file	Input.h
\author Goh Wei Zhe , weizhe.goh, 440000119
\par    weizhe.goh@digipen.edu
\date   June 4, 2020
\brief  Consist of input handle function to include in other files.
		Handle reading input from the keyboard and process it.

Copyright (C) 20xx DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents
without the prior written consent of DigiPen Institute of
Technology is prohibited.
*/
/* End Header **************************************************************************/

#pragma once
#ifndef  INPUT_H
#define  INPUT_H

void Input_Handle();		//handle user inputs and process it

#endif