/* Start Header ************************************************************************/
/*!
\file	Input.cpp
\author Goh Wei Zhe , weizhe.goh, 440000119
\par    weizhe.goh@digipen.edu
\date   June 4, 2020
\brief  Consist of main input handle Function to be called in other files.
		Handle reading input from the keyboard and process it.

Copyright (C) 20xx DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents
without the prior written consent of DigiPen Institute of
Technology is prohibited.
*/
/* End Header **************************************************************************/

#include <iostream>
#include "pch.h"
#include "Input.h"
#include "System.h"

// ----------------------------------------------------------------------------
// This function handles input reading input from keyboard and process it
// ----------------------------------------------------------------------------
void Input_Handle()
{
	myFile << "Input:Handle" << std::endl;
}