/* Start Header ************************************************************************/
/*!
\file	cs230_gam.cpp
\author Goh Wei Zhe , weizhe.goh, 440000119
\par    weizhe.goh@digipen.edu
\date   June 4, 2020
\brief  Contains the 'main' function. Program execution begins and ends there.

Copyright (C) 20xx DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents
without the prior written consent of DigiPen Institute of
Technology is prohibited.
*/
/* End Header **************************************************************************/

#include <iostream>
#include "pch.h"
#include "GameStateManager.h"
#include "System.h"
#include "Input.h"

//Implement the pseudo-code of A1_P1 here
int main()
{
  //Game system initialize
  System_Initialize();

  //Game state manager initialize
  GSM_Initialize(GS_LEVEL1);

  while (current != GS_QUIT)      //while current not equal to Quit game state
  {
      if (current != GS_RESTART)  //if current state not equal to restart game state
      {
          GSM_Update();           //Update Game State Manager. Set function pointers to each new state
          fpLoad();               //Load game state level
      }
      else                        //if current state equal to restart game state
      {
          next = previous;        //set previous game state as next game state
          current = previous;     //Then, set previous game state as current game state
      }
      
      fpInitialize();             //Initialize game level state ready to be called

      //Game loop
      while(next == current)      //while current game state equal to current game state 
      {
          Input_Handle();         //Handles input from player
          fpUpdate();             //Update state data
          fpDraw();               //Render object
      }
      
      fpFree();                   //Clean up state, make state ready to be unloaded and initialized again
      
      if (next != GS_RESTART)     // if next game state not equal to restart game state
      {
          fpUnload();             //Terminate game state.
      }
      
      previous = current;         //set current game state to previous game state
      current = next;             //set next game state to current
  }
  
  //Game system exit (terminate)
  System_Exit();                  //Terminate game system
  return 0;
}
