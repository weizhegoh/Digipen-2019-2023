/* Start Header ************************************************************************/
/*!
\file	Level1.h
\author Goh Wei Zhe , weizhe.goh, 440000119
\par    weizhe.goh@digipen.edu
\date   June 4, 2020
\brief  Consist of Load, Initialise, Update, Draw, Free and Unload of Level 1 to be included 
		in other files.

Copyright (C) 20xx DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents
without the prior written consent of DigiPen Institute of
Technology is prohibited.
*/
/* End Header **************************************************************************/

#pragma once
#ifndef LEVEL1_H
#define LEVEL1_H

void Leve1_Load();			//Load neccessary data and initialise it in Level 1.

void Leve1_Initialize();	//Prepares the level 1 state data in order to be use for the first time

void Leve1_Update();		//Updates level 1 state data like user input, time, or gameplay logic

void Leve1_Draw();			//Sends Level 1 data to the graphic engine component and renders it
	
void Leve1_Free();			//Clean up level 1 state. Make state ready to be unloaded or initialized again 

void Leve1_Unload();		//Terminate Level 1. 

#endif