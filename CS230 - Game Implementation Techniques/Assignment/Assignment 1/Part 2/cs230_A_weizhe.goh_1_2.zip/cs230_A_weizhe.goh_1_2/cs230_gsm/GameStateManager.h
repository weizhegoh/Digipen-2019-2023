/* Start Header ************************************************************************/
/*!
\file	GameStateManager.h
\author Goh Wei Zhe , weizhe.goh, 440000119
\par    weizhe.goh@digipen.edu
\date   June 4, 2020
\brief  Responsible for switching states and calling the corresponding state functionalities

Copyright (C) 20xx DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents
without the prior written consent of DigiPen Institute of
Technology is prohibited.
*/
/* End Header **************************************************************************/

#pragma once
#ifndef GAMESTATEMANAGER_H
#define GAMESTATEMANAGER_H

typedef void(*FP)(void);			

extern int current, previous, next;		

extern FP fpLoad, fpInitialize, fpUpdate, fpDraw, fpFree, fpUnload;

void GSM_Initialize(int startingState);	// Initialize Game state Manager
void GSM_Update();						// Update Game state Manager 

#endif