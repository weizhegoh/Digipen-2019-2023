/*!*****************************************************************************
\file functions.cpp
\author Vadim Surov, Goh Wei Zhe
\par DP email: vsurov\@digipen.edu, weizhe.goh\@digipen.edu
\par Course: CS380
\par Section: B
\par Programming Assignment 9
\date 07-14-2021
\brief
This file has declarations and definitions that are required for submission
*******************************************************************************/

#include "functions.h"

namespace AI
{


} // end namespace