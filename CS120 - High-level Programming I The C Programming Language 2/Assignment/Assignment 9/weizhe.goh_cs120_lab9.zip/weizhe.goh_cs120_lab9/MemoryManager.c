/******************************************************************************
filename MemoryManager.c
author Goh Wei Zhe
email weizhe.goh@digipen.edu
date created 21 Mar 2020
Brief Description: Create Memory pool, scans unused element, allocate and 
deallocate  an element from pool and free memory pool.
******************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "MemoryManager.h"

#define NUM_BITS 8

void printBinary(struct MemoryPool* memory)
{
  unsigned int binary = 0, bitSize = 0, block = 0, bit = 0;
  
  bitSize = memory->count/NUM_BITS;
  
  for(block = 0; block < bitSize; ++block)
  {
    printf("Block[%d]: ", block);

    for (bit = 0; bit < NUM_BITS; ++bit)
    {      
      if(memory->isActive[block] & (1<<bit))
      {
        binary = 1;
        printf("%d ", binary);
      }
      else
      {
        binary = 0;
        printf("%d ", binary);

      }
    }
    printf("\n");
  }
  printf("\n");
}

int MemoryMgrCreatePool(struct MemoryPool* result, unsigned int unitSize, unsigned int count)
{
  unsigned int blockIndex = 0, bitSize = 0;
  unsigned char MAX_CHAR = 255;
  
  if(result == NULL || unitSize == 0 || count == 0)
  {
    return MM_FAILED;
  }
  
  if(count%NUM_BITS!=0)
  {
    result->count = count + (NUM_BITS-count%NUM_BITS);
  }
  
  result->unitSize = unitSize;
  result->seekerIndex = 0;
  
  result->allocatedMemory = (char*)malloc(unitSize*result->count);
  
  if (result->allocatedMemory == NULL)
  {
    result->count = 0;
    result->unitSize = 0;
	  return MM_FAILED;
  }
  
  result->isActive = (char*)malloc(sizeof(char)*(result->count/NUM_BITS)); 
  
  if(result->isActive == NULL)
  {
    result->count = 0;
    result->unitSize = 0;
    free(result->allocatedMemory);
    result->allocatedMemory = NULL;
    return MM_FAILED;
  }

  bitSize = (result->count)/NUM_BITS;

  for(blockIndex = 0; blockIndex < bitSize; ++blockIndex)
  {
    result->isActive[blockIndex] = (char)MAX_CHAR;
  }

  printBinary(result); 
  
  return MM_OK;
}

void* MemoryMgrAllocate(struct MemoryPool* pool)
{  
  unsigned int bitSize = 0, blockIndex = 0, bitIndex = 0;

  if(pool == NULL)
  {
    return NULL; 
  }
  
  bitSize = pool->count/NUM_BITS;

  for(blockIndex = 0; blockIndex< bitSize; ++blockIndex)
  {
    if(pool->isActive[blockIndex] != 0)
    {
      break;
    }
  }
  
  if(blockIndex == bitSize)
  {
    return NULL;
  }
  
  for(bitIndex = 0; bitIndex < NUM_BITS ;++bitIndex)
  {
    if(pool->isActive[blockIndex] & (1<<bitIndex))
    {
      break;
    }
  }
  
  pool->isActive[blockIndex] &= (char)~(1<<bitIndex);
  
  printBinary(pool); 
  
  return pool->allocatedMemory + ((blockIndex * NUM_BITS + bitIndex)* pool->unitSize);
}

void MemoryMgrDeallocate(struct MemoryPool* pool, void* target)
{
  unsigned int blockIndex = 0, bitIndex = 0, numElement = 0;
  
  if(pool == NULL || target == NULL)
  {
    return; 
  }
  
  numElement = (unsigned int)((char*)(target)-(pool->allocatedMemory))/pool->unitSize;
  
  bitIndex = numElement%NUM_BITS;
  blockIndex = numElement/NUM_BITS;
  
  pool->isActive[blockIndex] |= (char)(1<<bitIndex);

  printBinary(pool); 
}


void MemoryMgrFreePool(struct MemoryPool* target)
{
  if(target == NULL)
  {
    return;
  }
  if(target->isActive!=NULL)
  {
    free(target->isActive);
    target->isActive = NULL;
  }
  
  if(target->allocatedMemory!=NULL)
  { 
    free(target->allocatedMemory);
    target->allocatedMemory = NULL;
  }
  
  target->count = 0;
  target->unitSize = 0;
  target->seekerIndex = 0;
  target->seekerIndex = 0;
}

unsigned int MemoryMgrInactiveCount(struct MemoryPool* target)
{
  unsigned int blockIndex = 0, bitIndex = 0, inactiveCount = 0, bitSize = 0;

  if(target == NULL)
  { 
    return MM_FAILED;
  }

  bitSize = target->count/NUM_BITS;

  for(blockIndex = 0; blockIndex < bitSize;++blockIndex)
  {
    for (bitIndex = 0; bitIndex < NUM_BITS; ++bitIndex)
    {
      if((target->isActive[blockIndex] & (1<<bitIndex)))
      {
        inactiveCount++;
      }
    }
  }
  
  return inactiveCount;
}