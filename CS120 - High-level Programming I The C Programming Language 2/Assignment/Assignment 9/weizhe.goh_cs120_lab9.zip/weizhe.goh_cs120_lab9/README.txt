• /* Start Header ------------------------------------------------------
Copyright (C) 2019 DigiPen Institute of Technology.
File Name: MemoryManager.c
Purpose: Create Memory pool, scans unused element, allocate and 
deallocate  an element from pool and free memory pool.
Language: C programming
Platform: GCC c89
Project: weizhe.goh_cs120_lab9
Author: Goh Wei Zhe 
Student Login: weizhe.goh / 440000119
StudentID: 1900806
Creation date: 26th March 2020
End Header --------------------------------------------------------*/ 

Compile in GCC:
1. gcc -Wall -Werror -Wextra -Wconversion -ansi -pedantic -o MemoryManager.exe MemoryManagerDriver.c MemoryManager.c
2. Enter: MemoryManager

Compile in Visual Studio: 
1. Change directory to where the folder is and enter.
2. Enter: cl /W4 /WX /nologo /Za /FeMemoryManager.exe /TC MemoryManagerDriver.c MemoryManager.c
3. Enter: MemoryManager
 
