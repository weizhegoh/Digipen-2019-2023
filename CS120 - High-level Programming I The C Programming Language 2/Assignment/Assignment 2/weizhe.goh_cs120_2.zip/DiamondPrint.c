/**************************
filename: DiamondPrint.c
author: Goh Wei Zhe
email: weizhe.goh@digipen.edu
date: 21 January 2020
Brief Description: Print out diamond pattern
**************************/

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
  int num=0, i=0, j=0;

  num = atoi(argv[1]);
  
  if(argc!=2 || num<=0)
  {
    printf("Invalid usage: <ProgramName>.exe <DiamondSize:int>");
    return 1;   
  }

  for(i=1; i<=num ;++i)
  {
    for(j=i; j<num;++j)
    {
      printf(" ");
    }
    
    for(j=1; j<=i;++j)
    {
      printf("%d",j%10);
    }
  
    for(j=i;j>1;--j)
    {
      printf("%d",(j-1)%10);
    }
    
    printf("\n");
  }
  
  for(i=1;i<num;++i)
  {
    for(j=num+i; j>num;--j)
    {
      printf(" ");
    }
    
    for(j=1;j<=num-i;++j)
    {
      printf("%d",j%10);
    }
    
    for(j=num-i;j>1;--j)
    {
      printf("%d",(j-1)%10);
    }
    printf("\n");
  }
  return 0;
}