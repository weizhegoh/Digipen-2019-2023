/******************************************************************************
filename CSVParserDriver.c
author Goh Wei Zhe
email weizhe.goh@digipen.edu
date created 5th March 2019
Brief Description: Read contents of CSV file and display all entries, then
deallocate all entries
******************************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "CSVParser.h"

int ReadCSVFile(struct CSVData* result, const char* filePath)
{ 
  int fileLength = 0;
  int  row = 0, column = 0, rowCount = 0, colCount = 0, i = 0;
  FILE* inputFile = NULL; 
  char character, *fileBuffer = NULL, *token = NULL, *newline;

  if(result == NULL || filePath == NULL)
    return FAIL;
  
  inputFile = fopen(filePath,"r");  
  
  if(inputFile == NULL)
  {
    printf("InputFile does not exist\n");
    return FAIL;
  } 
  
  ++row;
  fseek(inputFile,0,SEEK_END);
  fileLength = (int)(ftell(inputFile));
  fseek(inputFile, 0, SEEK_SET);
    
  if(fileLength == 0)
  {
    printf("FilePath is Empty\n");
    return FAIL;
  }
  
  while(!feof(inputFile))
  {
    character = (char)fgetc(inputFile);
    if(character == '\n')
    {
      row++;
    }
  } 
  
  fseek(inputFile, 0, SEEK_SET);
  result->size = row;
  
  result->rowData = 
  (struct CSVRow*)malloc(sizeof(struct CSVRow)*(unsigned long)(row));
  
  if(result->rowData == NULL)
  {
    printf("Fail to malloc number of rowCounts\n");
    fclose(inputFile);
    return FAIL;
  }
  
  fileBuffer = (char*)malloc(sizeof(char)*(unsigned long)(fileLength));

  if(fileBuffer == NULL)
  {
    printf("Fail to malloc fileBuffer\n");
    free(result->rowData);
    fclose(inputFile);
    return FAIL;
  }
    
  while(fgets(fileBuffer,fileLength, inputFile))
  {
    for(i=0;i<(signed int)(strlen(fileBuffer));++i)
    {
      if(fileBuffer[i] == ',')
      {
        column++;
      }
    }
    column+=1;
    
    result->rowData[rowCount].colData = 
    (char**)malloc(sizeof(char*)*(unsigned long)(column));
    
    if(result->rowData[rowCount].colData == NULL)
    {
      printf("Unable to malloc number of coloumns\n");
      free(fileBuffer);
      free(result->rowData);
      fclose(inputFile);
      return FAIL;
    }
    result->rowData[rowCount].size = column;
    rowCount++;
    column = 0;
  }
  
  fseek(inputFile, 0, SEEK_SET);
  rowCount = 0;

  while(fgets(fileBuffer, fileLength, inputFile))
  {
    token = strtok(fileBuffer, ",");
    
    while(token)
    {
      newline = strchr(token, '\n');
      
      if(newline)
      {
        *newline = 0;
      }
      result->rowData[rowCount].colData[colCount]=
      (char*)malloc(sizeof(char)*(strlen(token)+1));
     
      if(result->rowData[rowCount].colData[colCount] == NULL)
      {
        printf("Unable to malloc row %d column %d\n",rowCount,colCount);
        
        for(i = 0; i< result->size;++i)
        {
          free(result->rowData[i].colData);
        }
        
        free(fileBuffer);
        free(result->rowData);
        fclose(inputFile);
        return FAIL;
      }
      strcpy(result->rowData[rowCount].colData[colCount],token);
      
      token = strtok(NULL, ",");
      colCount++;
    }
    ++rowCount;
    colCount = 0;
  }
  
  free(fileBuffer);
  fclose(inputFile);
  return OK;
}

char* GetEntry(struct CSVData* data, int rowIndex, int colIndex)
{
  if(data == NULL)
    return NULL;
  
  if(rowIndex < 0  || (rowIndex >= data->size))
    return NULL;
  
  if(colIndex < 0 || colIndex >= data->rowData[rowIndex].size)
    return NULL;

  return (data->rowData[rowIndex].colData[colIndex]);
}

void FreeCSVData(struct CSVData* target)
{
  int i = 0, j = 0;
  
  if(target == NULL)
  {
    printf("Data File is empty\n");
    return;
  }
  
  for(i = 0; i< target->size;++i)
  {
    for(j = 0; j< target->rowData[i].size; ++j)
    {
      free(target->rowData[i].colData[j]);
    }
    free(target->rowData[i].colData);
  }
  free(target->rowData);
  
  printf("\nCSV Data successfully deallocated\n");
}
