• /* Start Header ------------------------------------------------------
Copyright (C) 2019 DigiPen Institute of Technology.
File Name: CSVParser.c
Purpose: Understanding of Linked List, memory allocation and pointers. 
	 Read contents of CSV file and display all entries, then deallocate all entries
Language: C programming
Platform: GCC c89
Project: weizhe.goh_cs120_lab7
Author: Goh Wei Zhe 
Student Login: weizhe.goh / 440000119
StudentID: 1900806
Creation date: 5th March 2020
End Header --------------------------------------------------------*/ 

Compile in GCC:
1. gcc -Wall -Werror -Wextra -Wconversion -ansi -pedantic -o CSVParser.exe CSVParserDriver.c CSVParser.c
2. Enter: CSVParser

Compile in Visual Studio: 
1. Change directory to where the folder is and enter.
2. Enter: cl /W4 /WX /nologo /Za /FeCSVParser.exe /TC CSVParserDriver.c CSVParser.c
3. Enter: CSVParser
 
