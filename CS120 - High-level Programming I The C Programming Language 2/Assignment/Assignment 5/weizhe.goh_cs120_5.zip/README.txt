• /* Start Header ------------------------------------------------------
Copyright (C) 2019 DigiPen Institute of Technology.
File Name: List.c
Purpose: Understanding of Linked List and pointers. 
Language: C programming
Platform: GCC c89
Project: weizhe.goh_cs120_5
Author: Goh Wei Zhe 
Student Login: weizhe.goh / 440000119
StudentID: 1900806
Creation date: 7 Feb 2020
End Header --------------------------------------------------------*/ 


Compile in GCC:
gcc -Wall -Werror -Wextra -Wconversion -ansi -pedantic -o List.exe ListDriver.c List.c

Type: List

Compile in Visual Studio: 
1. Change directory to where the folder is and enter.
2. type: cl /W4 /WX /nologo /Za /FeList.exe /TC ListDriver.c List.c

 
