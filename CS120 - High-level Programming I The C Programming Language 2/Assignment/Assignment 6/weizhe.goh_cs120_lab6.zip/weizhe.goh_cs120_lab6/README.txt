• /* Start Header ------------------------------------------------------
Copyright (C) 2019 DigiPen Institute of Technology.
File Name: StringList.c
Purpose: Understanding of Linked List and pointers. 
Language: C programming
Platform: GCC c89
Project: weizhe.goh_cs120_lab6
Author: Goh Wei Zhe 
Student Login: weizhe.goh / 440000119
StudentID: 1900806
Creation date: 26 Feb 2020
End Header --------------------------------------------------------*/ 

Compile in GCC:
1. gcc -Wall -Werror -Wextra -Wconversion -ansi -pedantic -o StringList.exe StringListDriver.c StringList.c
2. Enter: StringList

Compile in Visual Studio: 
1. Change directory to where the folder is and enter.
2. Enter: cl /W4 /WX /nologo /Za /FeStringList.exe /TC StringListDriver.c StringList.c
3. Enter: StringList
 
