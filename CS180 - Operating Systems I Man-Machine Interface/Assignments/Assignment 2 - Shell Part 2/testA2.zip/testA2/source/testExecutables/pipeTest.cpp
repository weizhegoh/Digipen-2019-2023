#include <iostream>
#include <string>

int main(int argc, char** argv)
{
  int pipeNum = 0;
  std::string temp;
  pipeNum = atoi(argv[1]);
  std::cin >> temp;
  std::cout << "pipe" << pipeNum << temp << std::endl;
}