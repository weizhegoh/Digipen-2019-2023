#include <iostream>


int main(int argc, char** argv)
{
    if(argc > 2)
    {
        for(int i = 1; i < argc; ++i)
            std::cout << "var" << i - 1 << ": " << argv[i]<<std::endl;
    }
    std::cout <<"bin runned\n";
}