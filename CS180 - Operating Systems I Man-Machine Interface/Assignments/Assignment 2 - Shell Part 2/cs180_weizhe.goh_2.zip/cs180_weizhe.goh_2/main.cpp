/* Start Header
*****************************************************************/
/*!
\file   main.cpp
\author Goh Wei Zhe, weizhe.goh, 440000119
\par    email: weizhe.goh\@digipen.edu
\date   October 20, 2020 
\brief  To create a basic shell program called uShell and provide 
        a Makefile. 
        
        To learn and understand the basic of the internals process
        creation and management of a shell program. 

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
*/
/* End Header
*******************************************************************/

#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <map>
#include <cstring>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include <algorithm>

#define READ_END 0
#define WRITE_END 1

/******************************************************************************/
/*!
    Global variables 
*/
/******************************************************************************/
int num = 0;
bool verboseMode = false, exitStatus = true, setPath = false;

std::string userInput, PATH, variable2;
std::string path = "uShell", arrow = ">";
std::string openBraces = "${", closeBraces = "}", space = " ";

std::vector<std::string> strArr;
std::map<std::string, std::string> map;

//background process variables
bool bg = false, lastProgram = false;
static std::map<int, std::pair<int, bool>> process_map;
int current_processId = 0;

//pipe variable 
bool executePipe = false;
std::string pipeline = "|";
std::vector<std::vector<std::string>> pipeVector;

/******************************************************************************/
/*!
\fn     bool getInput()

\brief  Function to get user input and assign into an array of vector 
*/
/******************************************************************************/
bool getInput()
{
    getline(std::cin, userInput);
    std::istringstream stream{ userInput };

    if (verboseMode)
        std::cout << userInput << std::endl;

    while (stream.good())
    {
        std::string userInput, str, variable;
        stream >> userInput;

        //handle comments 
        if (userInput == "#")           
            break;
        
        //handle background jobs
        if (userInput == "&")
        {
            bg = true;
            break;
        }
        else 
            bg = false;

        size_t sPos, nPos, cPos = 0;
        
        //Handle nested setvar command 
        while (sPos = userInput.find(openBraces, cPos),
               sPos != std::string::npos)
        {
            if (sPos > cPos)
                str += userInput.substr(cPos, sPos - cPos);

            if (nPos = userInput.find(closeBraces, sPos),
                nPos != std::string::npos)
            {
                size_t current = 0, next = 0;

                while (next != std::string::npos)
                {
                    if (next > nPos)
                        break;

                    current = next + 1;
                    next = userInput.find(openBraces, current);
                }

                --current;

                if (sPos != current)
                {
                    str += userInput.substr(sPos, current - sPos);
                    cPos = current;

                    variable = userInput.substr(cPos + 2, nPos - (cPos + 2));
                }
                else
                    variable = userInput.substr(sPos + 2, nPos - (sPos + 2));

                std::map<std::string, std::string>::iterator it;
                it = map.find(variable);

                if (it != map.end())
                    str += it->second;
                else
                {
                    size_t found = 0; 
                    found = variable.find("#");
                    
                    if(found != static_cast<size_t>(-1))
                    {
                        std::cout << userInput << std::endl;
                        userInput.clear();
                    }
                    else
                    {
                       variable2 = userInput.substr(nPos + 1);
                        
                        std::cout << "Error: " << variable << variable2
                        << " is not a defined variable" << std::endl;
                    }
                    userInput.clear();
                    return 0;
                }
            }
            else
                break;

            cPos = nPos + 1;
        }
        
        str += userInput.substr(cPos, userInput.length());
        strArr.push_back(str);
    }
    return 0;
}

/******************************************************************************/
/*!
\fn     void echo()

\brief  Prints out the rest of the arguments 

        echo <arguments>
*/
/******************************************************************************/
void echo()
{
    strArr.erase(strArr.begin());
    
    if (strArr.empty())
        return;
    
    std::string inputString;

    for (auto& arr : strArr)
    {
        inputString += arr;
        inputString += " ";
    }

    inputString.pop_back();
    std::cout << inputString << std::endl;
}

/******************************************************************************/
/*!
\fn     void changePrompt()

\brief  Changes the prompt to the string given by str.

        changeprompt <str>
*/
/******************************************************************************/
void changePrompt()
{
    strArr.erase(strArr.begin());

    if (strArr.empty()){return;}
    
	path.clear();

    std::string newPath;
    for (auto& arr : strArr)
    {
        newPath += arr;
        newPath += " ";
    }

    newPath.pop_back();
    path.clear();
    path.replace(0, newPath.length(), newPath);
}

/******************************************************************************/
/*!
\fn     bool externalCommand()

\brief  shell program searches through the directory in the PATH variable that 
        is seperated by a colon character ':' to find the executable for running 
        the external command. 
*/
/******************************************************************************/
bool externalCommand()
{
    //Nested vector of commands 
    std::vector<std::vector<std::string>> commandList;
    std::vector<std::string> bufferVector;
    
    for (size_t i = 0; i < strArr.size(); ++i)
    {
        //seperate commands using |
        if (!strArr[i].compare("|"))
        {
            commandList.push_back(bufferVector);
            bufferVector.clear();
            continue;
        }
        
        bufferVector.push_back(strArr[i].c_str());
    }
    commandList.push_back(bufferVector);

    size_t find = 0; 
    find = commandList.back().front().find(".exe");
    
    if(find == static_cast<size_t>(-1))
    {
        std::cout << strArr.back() << ": command not found" << std::endl;
        return 0;
    }

    int toWaitPid;  // the PID of the program that will be waiting
    int new_fd[2];  // "current" file descriptor
    int prev_fd[2]; // "previous" file descriptor

    //loop all commands 
    for (auto &command : commandList)
    {
        // spilting up path if seperated with ':' and replace with ' '
        std::replace(command.front().begin(), command.front().end(), ':', ' ');
        
        std::stringstream _tempss;
        _tempss << command.front();
        
        std::vector<std::string> pathway;
        std::string _tempstr;

        while (_tempss >> _tempstr)
            pathway.push_back(_tempstr);

        //pipe if there is next command 
        if (command != commandList.back() && (commandList.size() > 1))
            pipe(new_fd);

        int pid;
        pid = fork();

        //Child Process
        if (pid == 0)
        {
            int check;
            for (auto &i : pathway)
            {
                std::vector<const char *> strings;

                //find back slash and forward slash 
                std::size_t found = i.find_last_of("/\\"); 
                
                std::string pathway = i.substr(0, found);
                
                 if(setPath)
                {
                    pathway = PATH;
                    setPath = false;
                }
                
                (found == std::string::npos) ? found = 0 : found++;
                
                std::string file = i.substr(found);
                strings.push_back(file.c_str());
                
                for (size_t count = 1; count < command.size(); ++count)
                    strings.push_back(command[count].c_str());
                
                //Pipe if there is previous command 
                if (command != commandList.front() && (commandList.size() > 1))
                {
                    dup2(prev_fd[READ_END], 0);
                    close(prev_fd[READ_END]);
                    close(prev_fd[WRITE_END]);
                }
                
                //Pipe if there is next command 
                if (command != commandList.back() && (commandList.size() > 1))
                {
                    close(new_fd[READ_END]);
                    dup2(new_fd[WRITE_END], 1);
                    close(new_fd[WRITE_END]);
                }

                strings.push_back(NULL);
                if (!pathway.compare(file))
                {
                    //check in local directory 
                    check = execv(pathway.c_str(), const_cast<char *const *>(strings.data()));
                    //else check in PATH 
                    check = execvp(pathway.c_str(), const_cast<char *const *>(strings.data()));
                }
                else
                {
                    //check in given path 
                    check = execv(i.c_str(), const_cast<char *const *>(strings.data()));
                }
            }
            if (check == -1)
            {
                std::cout << "Error: " << strArr.front() << " cannot be found" << std::endl;
            }
            exit(1); // cannot do any exec command
        }
        //fork error 
        else if (pid < 0)
            perror(path.c_str());
        //Parent process 
        else
        {
            int status;   
            
            //background process 
            if(bg == true)
            {
                std::pair<int, bool>tmp{pid, false};
                process_map.emplace(current_processId, tmp);
                std::cout << "[" << current_processId << "]" << " " << pid << std::endl;
                ++current_processId;
                sleep(1);
            }
            
            //pipe if there is a previous command 
            if (command != commandList.front() && (commandList.size() > 1))
            {
                close(prev_fd[READ_END]);
                close(prev_fd[WRITE_END]);
            }
            
            //pipe if there is a next command 
            if (command != commandList.back() && (commandList.size() > 1))
            {
                prev_fd[READ_END] = new_fd[READ_END];
                prev_fd[WRITE_END] = new_fd[WRITE_END];
            }
            
            //Last command 
            if (command == commandList.back() && (commandList.size() > 1))
            {
                toWaitPid = pid;
                lastProgram = true;
            }
            
            if (WIFEXITED(status))
            {
                //if child cannot find any exec file 
                if (WEXITSTATUS(status))
                {
                    return 1;
                }
            }
        }
    }

    if ((commandList.size() > 1))
    {
        close(prev_fd[READ_END]);
        close(prev_fd[WRITE_END]);
    }

    //wait 
    if (!bg || lastProgram)
    {
        waitpid(toWaitPid, NULL, 0);
        lastProgram = false;
        bg = false;
        sleep(1);
    }
    lastProgram = false;
    return 0;
}

/******************************************************************************/
/*!
\fn     void invalidCommand()

\brief  Function to print message if invalid command. 
*/
/******************************************************************************/
void invalidCommand()
{
    std::string msg;

    for (auto& arr : strArr)
    {
        msg += arr;
        msg += " ";
    }

    msg.pop_back();
    std::cout << msg << ": command not found" << std::endl;
}

/******************************************************************************/
/*!
\fn     void setvar()

\brief  Define and change the value of a variable.

        setvar <varname> <value>
*/
/******************************************************************************/
void setvar()
{
    strArr.erase(strArr.begin());
    std::string string1, string2;
    
    string1 = strArr[0];
    strArr.erase(strArr.begin());

    if (!strArr.empty())
    {
        for (auto& arr : strArr)
        {
            string2 += arr;
            string2 += " ";
        }

        string2.pop_back();
    }
    
    if(string1 == "PATH")
    {
        setPath = true;
        PATH = string2;        
        return;
    }

    std::map<std::string, std::string>::iterator it;

    it = map.find(string1);

    if (it != map.end())
    {
        if (string1 == it->first)
        {
            it->second = string2;
        }
    }

    map.insert(std::make_pair(string1, string2));
}

/******************************************************************************/
/*!
\fn     void finish()

\brief  Forces shell program to wait for particular background processes to 
        complete before continuing. 
        
        finish <process index> 
*/
/******************************************************************************/
void finish()
{
    int process_index = 0;
    
    strArr.erase(strArr.begin());
    std::string string; 
    
    if(!strArr.size())
    {
        std::cout << "Error: no such process index." << std::endl;
        return;
    }

    for (auto& arr : strArr)
    {
        string += arr;
        string += " ";
    }

    string.pop_back();
    process_index = std::stoi(string);
    
    auto it = process_map.find(process_index);
    
    int status; 
    
    if(it != process_map.end())
    {
        if(!it->second.second)
		{
			do
			{
				waitpid(it->second.first,&status, WUNTRACED);
			}while (!WIFEXITED(status) && !WIFSIGNALED(status));
			
            std::cout << "process " << it->second.first 
            << " exited with exit status 0." << std::endl;
			
            it->second.second = true;
		}
		else
		{
			std::cout << "Process Index " << it->first << " Process ID " 
            << it->second.first << " is no longer a child process." << std::endl;
		}
    }
    else
    {
        std::cout << "Error: no such process index." << std::endl;
        return;
    }
}

/******************************************************************************/
/*!
\fn     void exitProgram()

\brief  Terminate shell program with an exit value given by num. If num is not 
        given, the default exit value is 0.
        
        exit <num> 
*/
/******************************************************************************/
void exitProgram()
{
    strArr.erase(strArr.begin());
    std::string string; 
    
    if(!strArr.size())
    {
        exitStatus = 0; 
        return;
    }
    
    for (auto& arr : strArr)
    {
        string += arr;
        string += " ";
    }

    string.pop_back();
    num = std::stoi(string);
    
    exitStatus = 0;
}

/******************************************************************************/
/*!
\fn     int main(int argc, char* argv[])

\brief  main loop to execute uShell program 
*/
/******************************************************************************/
int main(int argc, char* argv[])
{
    //verbose mode
    if (argc == 2)
    {
        if ((!strcmp(argv[1], "-v") || !strcmp(argv[1], "[-v]")))
            verboseMode = true;
        else
            verboseMode = false;
    }
    
    while (exitStatus)
    {
        std::cout << path << arrow;

        if (getInput() || !userInput.size() || !strArr.size())
        {
            strArr.clear();
            continue;
        }
        
        size_t found = 0; 
        found = userInput.find(".exe");
        
        if (strArr.front() == "echo")
            echo();
        else if (strArr.front() == "setvar")
            setvar();
        else if (strArr.front() == "changeprompt")
            changePrompt();
        else if (strArr.front() == "finish")
            finish();
        else if (strArr.front() == "exit")
            exitProgram();
        else if (found != static_cast<size_t>(-1))
            externalCommand();
        else
            invalidCommand();
        
        strArr.clear();
    }
    return num;
}