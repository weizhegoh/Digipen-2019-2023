#include <iostream>
#include "MemoryManager.h"

int main()
{
	MemoryManager m(75);

	std::cout << "The original block..." << std::endl;
	m.dump(std::cout);
	char *first=(char*)m.allocate(10);
	char *second=(char*)m.allocate(13);
	char *third=(char*)m.allocate(12);
	char *fourth=(char*)m.allocate(11);
	char *fifth=(char*)m.allocate(14);
	
	std::cout << first << std::endl;
	
	m.deallocate(second);
	m.deallocate(fourth);
	char *sixth=(char*)m.allocate(10);
	std::cout << std::endl <<  ".... after allocating sixth ...." << std::endl;
	m.dump(std::cout);
	/*****
		For Best Fit, the 10 bytes will be allocated where fourth was.
		For Worst Fit, the 10 bytes will be allocatd in the last block (not allocated previously).
		For First Fit, the 10 bytes will be allocated where second was.
	******/
	m.deallocate(third);
	std::cout << std::endl<<  ".... after deallocating third ...." << std::endl;	
	m.dump(std::cout);
	
	m.deallocate(fifth);
	std::cout << std::endl <<  ".... after deallocating fifth ...." << std::endl;	
	m.dump(std::cout);
	
}