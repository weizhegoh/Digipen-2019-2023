/* Start Header
*****************************************************************/
/*!
\file   main.cpp
\author Goh Wei Zhe, weizhe.goh, 440000119
\par    email: weizhe.goh\@digipen.edu
\date   October 7, 2020 
\brief  To create a basic shell program called uShell and provide 
        a Makefile.

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
*/
/* End Header
*******************************************************************/

#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <map>
#include <cstring>
#include <sys/wait.h>
#include <unistd.h>

int num = 0;
bool verboseMode = false, exitStatus = true, setPath = false;

std::string userInput, PATH, variable2;
std::string path = "uShell", arrow = ">";
std::string openBraces = "${", closeBraces = "}", space = " ";

std::vector<std::string> strArr;
std::map<std::string, std::string> map;

bool getInput()
{
    getline(std::cin, userInput);
    std::istringstream stream{ userInput };

    if (verboseMode)
        std::cout << userInput << std::endl;

    while (stream.good())
    {
        std::string userInput, str, variable;
        stream >> userInput;

        if (userInput == "#")
            break;

        size_t sPos, nPos, cPos = 0;

        while (sPos = userInput.find(openBraces, cPos),
               sPos != std::string::npos)
        {
            if (sPos > cPos)
                str += userInput.substr(cPos, sPos - cPos);

            if (nPos = userInput.find(closeBraces, sPos),
                nPos != std::string::npos)
            {
                size_t current = 0, next = 0;

                while (next != std::string::npos)
                {
                    if (next > nPos)
                        break;

                    current = next + 1;
                    next = userInput.find(openBraces, current);
                }

                --current;

                if (sPos != current)
                {
                    str += userInput.substr(sPos, current - sPos);
                    cPos = current;

                    variable = userInput.substr(cPos + 2, nPos - (cPos + 2));
                }
                else
                    variable = userInput.substr(sPos + 2, nPos - (sPos + 2));

                std::map<std::string, std::string>::iterator it;
                it = map.find(variable);

                if (it != map.end())
                    str += it->second;
                else
                {
                    size_t found = 0; 
                    found = variable.find("#");
                    
                    if(found != static_cast<size_t>(-1))
                    {
                        std::cout << userInput << std::endl;
                        userInput.clear();
                    }
                    else
                    {
                       variable2 = userInput.substr(nPos + 1);
                        
                        std::cout << "Error: " << variable << variable2
                        << " is not a defined variable" << std::endl;
                    }
                    userInput.clear();
                    return 0;
                }
            }
            else
                break;

            cPos = nPos + 1;
        }
        
        str += userInput.substr(cPos, userInput.length());
        strArr.push_back(str);
    }
    return 0;
}

void echo()
{
    strArr.erase(strArr.begin());
    
    if (strArr.empty())
        return;

    std::string inputString;

    for (auto& arr : strArr)
    {
        inputString += arr;
        inputString += " ";
    }

    inputString.pop_back();
    std::cout << inputString << std::endl;
}

void changePrompt()
{
    strArr.erase(strArr.begin());

    if (strArr.empty())
    {
        return;
    }
    
	path.clear();

    std::string newPath;
    for (auto& arr : strArr)
    {
        newPath += arr;
        newPath += " ";
    }

    newPath.pop_back();
    path.clear();
    path.replace(0, newPath.length(), newPath);
}

bool externalCommand()
{
    for (int i = 0; i < (int)strArr[0].size(); ++i)
    {
        if (!(strArr[0].compare(i, 1, ":")))
            strArr[0].replace(i, 1, " ");
    }

    std::stringstream stream{ strArr[0] };
    std::vector<std::string> path;
    std::string s;

    while (stream.good())
    {
        stream >> s;
        path.push_back(s);
    }
    
    int pid;
    pid = fork();

    if (pid == 0)
    {
        for (auto& subPath : path)
        {
            std::vector<const char*> str;
            std::size_t found = subPath.find_last_of("/\\");

            std::string path = subPath.substr(0, found);
            
            if(setPath)
            {
                path = PATH;
                setPath = false;
            }
            
            (found == std::string::npos) ? found = 0 : ++found;
            
            std::string file = subPath.substr(found);
            str.push_back(file.c_str());

            for (size_t i = 1; i < strArr.size(); ++i)
                str.push_back(strArr[i].c_str());

            str.push_back(NULL);

            if (!path.compare(file))
            {
                execv(path.c_str(), const_cast<char* const*>(str.data()));
                execvp(path.c_str(), const_cast<char* const*>(str.data()));
            }
            else
                execv(subPath.c_str(), const_cast<char* const*>(str.data()));
        }
        exit(1);
    }
    else
    {
        int status;
        wait(&status);

        if (WIFEXITED(status))
            if (WEXITSTATUS(status))
                return 1;
    }
    return 0;
}

void invalidCommand()
{
    std::string msg;

    for (auto& arr : strArr)
    {
        msg += arr;
        msg += " ";
    }

    msg.pop_back();
    std::cout << msg << ": command not found" << std::endl;
}

void setvar()
{
    strArr.erase(strArr.begin());
    std::string string1, string2;
    
    string1 = strArr[0];
    strArr.erase(strArr.begin());

    if (!strArr.empty())
    {
        for (auto& arr : strArr)
        {
            string2 += arr;
            string2 += " ";
        }

        string2.pop_back();
    }
    
    if(string1 == "PATH")
    {
        setPath = true;
        PATH = string2;        
        return;
    }

    std::map<std::string, std::string>::iterator it;

    it = map.find(string1);

    if (it != map.end())
    {
        if (string1 == it->first)
        {
            it->second = string2;
        }
    }

    map.insert(std::make_pair(string1, string2));
}

void exit()
{
    strArr.erase(strArr.begin());
    std::istringstream stream(userInput);
    stream >> num;

    exitStatus = 0;
}

int main(int argc, char* argv[])
{
    if (argc == 2)
    {
        if ((!strcmp(argv[1], "-v") || !strcmp(argv[1], "[-v]")))
            verboseMode = true;
        else
            verboseMode = false;
    }
    
    while (exitStatus)
    {
        std::cout << path << arrow;

        if (getInput())
            continue;

        if (!strArr.size())
            continue;
        
        size_t found = 0; 
        found = strArr.front().find(".exe");
        
        if (strArr.front() == "echo")
            echo();
        else if (strArr.front() == "setvar")
            setvar();
        else if (strArr.front() == "changeprompt")
            changePrompt();
        else if (strArr.front() == "exit")
            exit();
        else if (found != static_cast<size_t>(-1))
        {
            if (externalCommand())
                std::cout << "Error: " << strArr.front() 
                << " cannot be found" << std::endl;
        }
        else
        {
            invalidCommand();
        }
        strArr.clear();
    }
    //std::cout << num << std::endl;
    return num;
}