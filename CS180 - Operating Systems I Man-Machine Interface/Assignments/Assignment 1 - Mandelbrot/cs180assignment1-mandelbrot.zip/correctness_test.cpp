// correctness_test.cpp
// jsh 10/09

#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include "render_point.h"
using namespace std;


COLORREF RenderPoint(double x, double y, int N) {
  double a = 0.0, b = 0.0, norm2 = 0.0;
  int n;
  for (n = 0; norm2 < 4.0 && n < N; ++n) {
    double c = a*a - b*b + x;
    b = 2.0*a*b + y;
    a = c;
    norm2 = a*a + b*b;
  }
  int value = int(255*(1 - double(n)/N));
  return RGB(value,value,value);
}



int main(void) {
  srand(unsigned(time(0)));
  const int COUNT = 100,
            NMAX  = 1024;

  int correct_count = 0;
  double diff = 0.0,
         diff_sq = 0.0;
  for (int i=0; i < COUNT; ++i) {
    double x = 2.0 - 4.0*rand()/double(RAND_MAX),
           y = 2.0 - 4.0*rand()/double(RAND_MAX);
    int n = rand() % NMAX;
    COLORREF value = render_point(x,y,n),
             correct = RenderPoint(x,y,n);
    double dred = double(GetRValue(value)) - double(GetRValue(correct)),
           dgreen = double(GetGValue(value)) - double(GetGValue(correct)),
           dblue = double(GetBValue(value)) - double(GetBValue(correct)),
           d_sq = sqrt(dred*dred + dgreen*dgreen + dblue*dblue);
    diff += sqrt(d_sq);
    diff_sq += d_sq;
    if (value == correct)
      ++correct_count;
  }

  double average = (100.0 * correct_count)/COUNT;
  cout << fixed << setprecision(0);
  cout << "correct(%): " << average << endl;
  diff /= COUNT;
  diff_sq = sqrt(diff_sq/COUNT - diff*diff);
  cout << "average difference = " << diff
       << " +/- " << diff_sq << endl;
  return 0;
}

