// render.h
// -- prototype for render function
// cs180 1/08

#ifndef CS180_RENDER_POINT
#define CS180_RENDER_POINT

#include <windows.h>


COLORREF render_point(double x, double y, int N);

#endif
