// efficiency_test.cpp
// cs180 9/30
//
// Note: must be linked with 'render_point' function.

#include <iostream>
#include <iomanip>
#include <ctime>
#include <cmath>
#include "render_point.h"
using namespace std;


int main(void) {
  const int TRIALS = 25,
            ITER = 5120,
            XSTEPS = 100,
            YSTEPS = 100;
  const double XMIN = -1.0,
               XMAX = 1.0,
               YMIN = -1.0,
               YMAX = 1.0;

  double average = 0.0,
         stddev = 0.0;
  for (int n=0; n < TRIALS; ++n) {
    clock_t ticks = clock();
    double dx = (XMAX - XMIN)/XSTEPS,
           dy = (YMAX - YMIN)/YSTEPS;
    for (int i=0; i < YSTEPS; ++i) {
      double y = YMIN + i*dy;
      for (int j=0; j < XSTEPS; ++j)
        render_point(XMIN+j*dx,y,ITER);
    }
    ticks = clock() - ticks;
    double value = double(ticks)/CLOCKS_PER_SEC;
    average += value;
    stddev += value*value;
  }

  average /= TRIALS;
  stddev = sqrt(stddev/TRIALS - average*average);
  average *= 1000;
  stddev *= 1000;
  cout << fixed << setprecision(0);
  cout << "average = " << average
       << " +/- " << stddev
       << " ms" << endl;
  return 0;
}
