/* Start Header
*****************************************************************/
/*!
\file   render_point.cpp
\author Goh Wei Zhe, weizhe.goh, 440000119
\par    email: weizhe.goh\@digipen.edu
\date   September 13, 2020 
\brief  To speed up the rendering process using inline assembler

Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the
prior written consent of DigiPen Institute of Technology is prohibited.
*/
/* End Header
*******************************************************************/

// render_point0.cpp
// jsh 1/08

#include "render_point.h"

COLORREF render_point(double x, double y, int N){
  double norm2 = 0.0;
  int n = 0;
  
  __asm 
  {  
    fldz //st(5) a*a
    fldz //st(4) b*b
    fldz //st(3) c
    fldz //st(2) b
    fldz //st(1) a
    fldz //st(0) 
  }
  
  for (n = 0; norm2 < 4.0 && n < N; ++n) 
  {
    __asm 
    {
      fxch st(3)            //a*a 
      fsub st(0), st(4)     //a*a - b*b
      fadd x                //a*a - b*b + x
      fxch st(3)            //c = a*a - b*b + x
      
      fxch st(2)            
      fmul st(0), st(1)     //b*a
      fadd st(0), st(0)     //2*b*a
      fadd y                //2*b*a + y
      fst st(4)             //b = 2*a*b+y  store in b*b
      
      fmul st(0), st(0)     //b*b
      fxch st(4)            //swap b*b 
      fxch st(2)            
      
      fxch st(3)
      fst st(1)             //a = c
      
      fmul st(0), st(0)     //a*a
      fst st(5)              
      fxch st(3)            
     
      fxch st(5)    
      fadd st(0), st(4)     //a*a + b*b
      fst norm2             //norm2 = a*a + b*b 
      fxch st(5)            
    }
  }
  __asm
  {
    fstp st(0)
    fstp st(0) 
    fstp st(0)
    fstp st(0) 
    fstp st(0)
    fstp st(0) 
  }
  
  int value = int(255*(1 - double(n)/N));
  return RGB(value,value,value);
}
