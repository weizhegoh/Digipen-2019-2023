#ifndef PETERSON_H
#define PETERSON_H
void get_mutex(int);
void release_mutex(int);
#endif
