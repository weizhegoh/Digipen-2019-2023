#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
int main()
{
  std::string str;
  std::cout << "$";
  while(true)
  {
    std::getline(std::cin, str);
    auto pos = str.find(' ');
    std::string cmd(str.begin(), str.begin()+pos);
    if(cmd=="echo")
    {
      std::string rest(str.begin()+pos, str.end());
      std::cout<< rest << std::endl;
    }
    else
    {
      int cpid = fork();
      if(!cpid)
      {
        execlp(cmd.c_str(), cmd.c_str(), NULL);
      }
      else
      {
        int status;
        wait(&status);
      }
    }
    std::cout << "$";
  }
}